{{- $RX_COMMENT_FULL := `(\\["]|"(?:\\"|[^"])*")|(\/\/.*|\/\*[\s\S]*?\*\/)` -}}
{{- $RX_COMMENT := "(\n|^)[ \\t]*//[^\n]+" -}}

{{- $namespace:= env "NOMAD_NAMESPACE" -}}
{{- $consul_key_prefix:= env "CONSUL_PREFIX" -}}
{{- $ROOT_PATH:= (print $consul_key_prefix $namespace) -}}

{{- /* REDIS CACHE */ -}} 
{{- $redis_cache_servers:= key (print $ROOT_PATH "/infra/redis/cache/servers") | split ";" }}
{{- $redis_cache_sentinel_name:= key (print $ROOT_PATH "/infra/redis/cache/sentinelName") }}
{{- $redis_cache_dbnumber:= key (print $ROOT_PATH "/infra/redis/cache/dbnumber") }}
{{- $redis_cache_password:= key (print $ROOT_PATH "/secret/redis/cache/password") }}

{{- /* REDIS BULLQUEUE */ -}} 
{{- $redis_bullqueue_servers:= key (print $ROOT_PATH "/infra/redis/bullqueue/servers") | split ";" }}
{{- $redis_bullqueue_sentinel_name:= key (print $ROOT_PATH "/infra/redis/bullqueue/sentinelName") }}
{{- $redis_bullqueue_dbnumber:= key (print $ROOT_PATH "/infra/redis/bullqueue/dbnumber") }}
{{- $redis_bullqueue_password:= key (print $ROOT_PATH "/secret/redis/bullqueue/password") }}

{{- /* REDIS LOCK */ -}} 
{{- $redis_lock_servers:= key (print $ROOT_PATH "/infra/redis/lock/servers") | split ";" }}
{{- $redis_lock_sentinel_name:= key (print $ROOT_PATH "/infra/redis/lock/sentinelName") }}
{{- $redis_lock_dbnumber:= key (print $ROOT_PATH "/infra/redis/lock/dbnumber") }}
{{- $redis_lock_password:= key (print $ROOT_PATH "/secret/redis/lock/password") }}

{{- /* RABBIT */ -}}
{{- $rabbit_host:= key (print $ROOT_PATH "/infra/rabbitmq/host") -}}
{{- $rabbit_heartbeat:= key (print $ROOT_PATH "/infra/rabbitmq/rabbitmq_heartbeat") -}}
{{- $rabbit_usename:= key (print $ROOT_PATH "/secret/rabbitmq/username") -}}
{{- $rabbit_password:= key (print $ROOT_PATH "/secret/rabbitmq/password") -}}

{{- /* MONGO MASTER */ -}}
{{- $mongo_master_username:= key (print $ROOT_PATH "/secret/mongodb/master/username") }}
{{- $mongo_master_password:= key (print $ROOT_PATH "/secret/mongodb/master/password") }}
{{- $mongo_master_authendb:= key (print $ROOT_PATH "/secret/mongodb/master/authendb") }}
{{- $mongo_master_replicaSet:= key (print $ROOT_PATH "/infra/mongodb/master/replicaSet") }}
{{- $mongo_master_servers:= key (print $ROOT_PATH "/infra/mongodb/master/servers") }}

{{- /* MONGO SURVEY */ -}}
{{- $mongo_survey_username:= key (print $ROOT_PATH "/secret/mongodb/survey/username") }}
{{- $mongo_survey_password:= key (print $ROOT_PATH "/secret/mongodb/survey/password") }}
{{- $mongo_survey_authendb:= key (print $ROOT_PATH "/secret/mongodb/survey/authendb") }}
{{- $mongo_survey_replicaSet:= key (print $ROOT_PATH "/infra/mongodb/survey/replicaSet") }}
{{- $mongo_survey_servers:= key (print $ROOT_PATH "/infra/mongodb/survey/servers") }}

{{- /* MONGO JOB */ -}}
{{- $mongo_job_username:= key (print $ROOT_PATH "/secret/mongodb/job/username") }}
{{- $mongo_job_password:= key (print $ROOT_PATH "/secret/mongodb/job/password") }}
{{- $mongo_job_authendb:= key (print $ROOT_PATH "/secret/mongodb/job/authendb") }}
{{- $mongo_job_replicaSet:= key (print $ROOT_PATH "/infra/mongodb/job/replicaSet") }}
{{- $mongo_job_servers:= key (print $ROOT_PATH "/infra/mongodb/job/servers") }}

{{- /* OPENTELEMETRY */ -}}
{{- define "shouldEnableOtel" -}}
  {{- $ROOT_PATH := . -}}
  {{- $global := key (print $ROOT_PATH "/application/fbpos-worker/opentelemetry/active") -}}
  {{- $index := env "NOMAD_ALLOC_INDEX" -}}

  {{- $enabled := false -}}
  {{- if and (eq $global "true") (eq $index "0") -}}
    {{- $enabled = true -}}
  {{- end -}}
  {{- $enabled -}}
{{- end }}

{
  "serve": {
    "port": 3000
  },
  "production": true,
  "rabbitMQ": {
    "exchanges": [
      {
        "name": "fbexchange03",
        "type": "topic",
        "options": {
          "durable": false
        }
      }
    ],
    "uri": "amqp://{{ $rabbit_usename }}:{{ $rabbit_password }}@{{ $rabbit_host }}/facebookpos?heartbeat={{ $rabbit_heartbeat }}",
    "connectionInitOptions": {
      "wait": false,
      "heartbeatIntervalInSeconds": 20
    },
    "prefetchCount": 20,
    "mainExchange": "fbexchange03"
  },
  "thirdParty": {
    "kiotviet": {
      "auditTrail": {
        "url": "{{- key (print $ROOT_PATH "/endpoint/kv_auditTrail_url") -}}"
      },
      "internalApi": {
        "url": "{{- key (print $ROOT_PATH "/endpoint/kiotvietInternalApi") -}}",
        "accessKey": "{{ key (print $ROOT_PATH "/secret/kiotvietInternalApiAccessKey") }}"
      },
      "coreApi": {
        "url": "{{- key (print $ROOT_PATH "/endpoint/coreInternalApi") -}}",
        "accessKey": "{{ key (print $ROOT_PATH "/secret/coreInternalApiAccessKey") }}"
      }
    },
    "facebook": {
      "appId": "{{ key (print $ROOT_PATH "/secret/fbpos-worker/appID") }}",
      "appSecret": "{{ key (print $ROOT_PATH "/secret/fbpos-worker/appSecret") }}",
      "appAccessToken": "{{ key (print $ROOT_PATH "/secret/fbpos-worker/appAccessToken") }}",
      "graphApiEndpoint": "{{ keyOrDefault (print $ROOT_PATH "/endpoint/graphApiEndpoint") "https://graph.facebook.com" }}",
      "graphApiProxyEndpoint": "{{ keyOrDefault (print $ROOT_PATH "/endpoint/graphApiEndpoint") "" }}",
      "graphVersion": "{{ keyOrDefault (print $ROOT_PATH "/endpoint/graphVersion") "v21.0" }}",
      "useProxy": {{ keyOrDefault (print $ROOT_PATH "/endpoint/useGraphProxy") "false" }}
    },
    "googleChat": {
        "webhookUrl": "{{ keyOrDefault (print $ROOT_PATH "/application/fbpos-service/endpoint/googleChatUrl") "" }}",
        "serviceId": ""
    }
  },
  "fbposMasterRepository": {
    "db": {
      "uri": "mongodb://{{ $mongo_master_username }}:{{ $mongo_master_password }}@{{ $mongo_master_servers }}/{{ $mongo_master_authendb }}?replicaSet={{ $mongo_master_replicaSet }}&maxPoolSize=100",
      "dbName": "kvfb_master"
    },
    "currentGroup": "5"
  },
  "dbGroupsRepository": [
{{- $mongogroup_tree:= safeTree (print $ROOT_PATH "/infra/mongodb/groups") | explode }}
{{- $group_length := len $mongogroup_tree }}
{{- range $k, $v:= $mongogroup_tree -}}
{{- $mongo_group_username:= key (print $ROOT_PATH "/secret/mongodb/groups/" $k "/username") -}}
{{- $mongo_group_password:= key (print $ROOT_PATH "/secret/mongodb/groups/" $k "/password") -}}
{{- $mongo_group_authendb:= key (print $ROOT_PATH "/secret/mongodb/groups/" $k "/authendb") -}}
{{- $mongo_group_replicaset:= key (print $ROOT_PATH "/infra/mongodb/groups/" $k "/replicaSet") -}}
{{- $mongo_group_servers:= $v.servers -}}
{{- $mongo_group_group:= $v.group -}}
{{- $mongo_group_dbname:= $v.dbname }}
{{- $group_length = $group_length | subtract 1 }}
      {
        "group": "{{ $mongo_group_group }}",
        "url": "mongodb://{{ $mongo_group_username }}:{{ $mongo_group_password }}@{{ $mongo_group_servers }}/{{ $mongo_group_authendb }}?maxPoolSize=100",
        "dbname": "{{ $mongo_group_dbname }}",
        "options": {
          "replicaSet": "{{ $mongo_group_replicaset }}",
          "maxPoolSize": 3,
          "readPreference": "nearest"
        }
      }{{ if ne 0 $group_length }},{{ end }}
  {{- end }}
  ],
  "cache": {
    "ioredis": {
      "namespace": "normal",
      "db": {{ $redis_cache_dbnumber }},
      "sentinels": [
        {{- range $index, $server := $redis_cache_servers }}
        {{- if $server }}
        {{- $parts := split ":" $server }}
        {
          "host": "{{ index $parts 0 }}",
          "port": {{ index $parts 1 }}
        }{{ if ne (add $index 1) (len $redis_cache_servers) }},{{ end }}
        {{- end }}
        {{- end }}
      ],
      "name": "{{ $redis_cache_sentinel_name }}",
      "password": "{{ $redis_cache_password }}",
      "ttl": 600,
      "keyPrefix": "fbpos-services:"
    }
  },
  "redlock": {
    "ioredis": {
      "namespace": "normal",
      "db": {{ $redis_lock_dbnumber }},
      "sentinels": [
        {{- range $index, $server := $redis_lock_servers }}
        {{- if $server }}
        {{- $parts := split ":" $server }}
        {
          "host": "{{ index $parts 0 }}",
          "port": {{ index $parts 1 }}
        }{{ if ne (add $index 1) (len $redis_lock_servers) }},{{ end }}
        {{- end }}
        {{- end }}
      ],
      "name": "{{ $redis_lock_sentinel_name }}",
      "password": "{{ $redis_lock_password }}",
      "ttl": 600,
      "keyPrefix": "fbpos-services:lock"
    },
    "settings": {
      "driftFactor": 0.01,
      "retryCount": 10,
      "retryDelay": 100,
      "retryJitter": 200,
      "automaticExtensionThreshold": 500
    }
  },
  "opentelemetry": {
    "active": {{ template "shouldEnableOtel" $ROOT_PATH }},
    "services": {{ keyOrDefault (print $ROOT_PATH "/application/fbpos-worker/opentelemetry/services") "[]" }},
    "url": "{{ key (print $ROOT_PATH "/application/fbpos-worker/opentelemetry/url") }}"
  },
  "logger": {
      "transports": [
        "file"
      ],
      "level": "info"
   },
  {{- $GLOBAL_PROXY_ENABLED:= keyOrDefault (print $ROOT_PATH "/endpoint/UseProxyFeature/enabled") "false" | parseBool -}}
  {{- $app_proxy_enabled:= keyOrDefault (print $ROOT_PATH "/endpoint/UseProxyFeature/enabled-apps/fbpos-worker-report-v2") "true" | parseBool -}}
  "forwardProxy": {
    "active": {{ and $GLOBAL_PROXY_ENABLED $app_proxy_enabled }},
    "proxyUrl": "{{ keyOrDefault (print $ROOT_PATH "/endpoint/UseProxyFeature/endpoint") "" }}"
  },
  "serviceName": "fbpos-worker-report-v2"
}
