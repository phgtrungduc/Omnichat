import { Module } from '@nestjs/common';
import { CoreModule } from './core/core.module';
import { CreateOrUpdateKvCustomerModule } from './modules/create-or-update-kv-customer/create-or-update-kv-customer.module';
import { CreateOrUpdateFbuserProfileModule } from './modules/create-or-update-fbuser-profile/create-or-update-fbuser-profile.module';
import { AlertNotificationModule } from '@kiotviet-facebook-services/alert-notification';

@Module({
  imports: [
    CoreModule,
    CreateOrUpdateKvCustomerModule,
    CreateOrUpdateFbuserProfileModule,
    AlertNotificationModule
  ],
  controllers: [],
  providers: [],
})
export class AppModule { }
