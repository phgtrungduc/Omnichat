import { Inject, Injectable } from '@nestjs/common';
import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    ERROR_MESSAGE_REDLOCK,
    FakeSocialType,
    ITiktokValidateLiveComment,
    KvBaseException,
    KvLogger,
    KvRabbitMQException,
    KvResponseMongoDbException,
    RabbitMQConfigAutoCreateKvCustomerTiktokLive,
    RabbitMqConfigKvOrderTiktokLive,
    SocialTypes,
} from '@kiotviet-facebook-services/common';
import { pick } from 'lodash';
import { CustomerSocialTypes, IKVCustomer, KvCustomerService } from '@kiotviet-facebook-services/kv-internal-api';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import {
    SocialUserKvCustomerService,
    TiktokLivestreamScriptService
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { RedisLockService, REDLOCK_CONST } from "@kiotviet-facebook-services/lock";
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class CreateOrUpdateKvCustomerTiktokLiveService {
    private readonly _rabbitMQConfig;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _kvCustomerService: KvCustomerService,
        private readonly _tiktokLivestreamScriptService: TiktokLivestreamScriptService,
        private readonly _socialUserKvCustomerService: SocialUserKvCustomerService,
        private readonly _redlockService: RedisLockService,
        private readonly _amqpConnection: AmqpConnection,
        @Inject(CACHE_MANAGER) private readonly _cache: Cache,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');

    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigAutoCreateKvCustomerTiktokLive.ROUTING_KEY,
        queue: `fbpos-worker-customer:${RabbitMQConfigAutoCreateKvCustomerTiktokLive.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _autoCreateKvCustomerTiktokLive(payload: ITiktokValidateLiveComment) {
        const prefixLog = this.prefixLog('_autoCreateKvCustomerTiktokLive');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.RetailerId': payload?.retailerId,
                'Kv.RetailerCode': payload?.retailerCode,
                'Kv.BranchId': payload?.branchId,
                'Kv.SocialId': payload?.liveUserId,
                'Kv.SocialType': SocialTypes.TIKTOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        const { userId, profilePictureUrl, liveUserId, retailerCode, retailerId, branchId } = payload;
        this._logger.info(logInput, `${prefixLog} received payload`);

        if (!userId || !liveUserId || !retailerCode || !retailerId) {
            return Promise.resolve();
        }
        try {
            const lock = await this._redlockService.acquire(
                [`${REDLOCK_CONST.LOCK_KEYS.AUTO_CREATE_KV_CUSTOMER_TIKTOK}${liveUserId}:${userId}`],
                5000,
                {}
            );

            const socialUserKvCustomer = await this._socialUserKvCustomerService.handleReadSocialUserKvCustomer({
                userId,
                retailerId,
                branchId
            });
            if (!socialUserKvCustomer) {
                const avatar = await this._getAvatarUploadFromProfilePic(retailerCode, profilePictureUrl);
                const customer = await this._createNewCustomer(payload, avatar);
                await this._updateSocialUserKvCustomer({ userId, retailerCode, retailerId, branchId, customer });
            }
            this._sentEventToMQForCreatingOrder(payload);
            await this._redlockService.release(lock).catch(e => this._logger.error(`${prefixLog} release lock err`, e)); // Release lock
            this._logger.info(logInput, `${prefixLog} success`);
        } catch (error) {
            if (error.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._handleError(prefixLog, error, logInput);
        }
        return Promise.resolve();
    }

    private async _createNewCustomer(
        payload: ITiktokValidateLiveComment,
        avatar = ''
    ): Promise<IKVCustomer> {
        const {
            userId,
            uniqueId,
            nickname,
            PhoneNumber,
            retailerCode,
            retailerId: RetailerId,
            branchId: BranchId
        } = payload;

        const result = await this._kvCustomerService.createCustomer({
            RetailerId,
            BranchId,
            Customer: {
                Type: CustomerSocialTypes.TiktokLive,
                IsOnline: true,
                Name: nickname || uniqueId,
                CustomerSocials: [{
                    RetailerId,
                    BranchId,
                    PageIdFacebook: FakeSocialType.TIKTOK, // Mặc định 1 userid chỉ tạo 1 khách hàng kv,
                    PsidFacebook: userId,
                    UidFacebook: userId,
                }],
                ...PhoneNumber && { ContactNumber: PhoneNumber },
                ...avatar && { Avatar: avatar }
            },
        }, retailerCode, RetailerId, `${BranchId}`);

        if (result?.data) {
            return result?.data;
        }
        return null;
    }

    private async _updateSocialUserKvCustomer({
        userId,
        retailerId,
        retailerCode,
        branchId,
        customer
    }) {
        try {
            await this._socialUserKvCustomerService.updateSocialUserKvCustomer({
                userId: userId, retailerId, branchId, retailerCode,
                kvCustomerId: customer.Id,
                kvCustomerCode: customer.Code,
                socialType: SocialTypes.TIKTOK
            }, true);
        } catch (error) {
            throw new KvResponseMongoDbException(error.stack);
        }
    }

    private async _getAvatarUploadFromProfilePic(retailerCode: string, profilePictureUrl: string) {
        try {
            if (profilePictureUrl) {
                const avatarUpload = await this._kvCustomerService.uploadImageUrl({
                    retailerCode: retailerCode,
                    imageDirectUrl: profilePictureUrl,
                });
                return avatarUpload.data?.Status == 'Success' && avatarUpload.data?.Message || profilePictureUrl;
            }
        } catch (e) {
            const prefixLog = this.prefixLog('_getAvatarUploadFromProfilePic');
            this._logger.error({ MessageTemplate: { retailerCode, profilePictureUrl }, Error: new KvBaseException(e.stack) }, `${prefixLog} fail`);
        }

        return '';
    }

    private _sentEventToMQForCreatingOrder(payload: ITiktokValidateLiveComment) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigKvOrderTiktokLive.ROUTING_KEY, payload).catch(err => {
            const prefixLog = this.prefixLog('_sentEventToMQ');
            this._logger.error({ MessageTemplate: { payload }, Error: err }, `${prefixLog} fail`);
        });
    }

    private _handleError(prefixLog: string, error: any, logInput: IKvLogInput) {
        this._logger.error({ ...logInput, Error: new KvBaseException(error.stack) }, `${prefixLog} fail`);
    }
}
