import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { CreateOrUpdateKvCustomerService } from './create-or-update-kv-customer.service';
import { KvInternalApiModule } from '@kiotviet-facebook-services/kv-internal-api';
import { FacebookSdkModule } from '@kiotviet-facebook-services/facebook-sdk';
import { LockModule } from "@kiotviet-facebook-services/lock";
import { CreateOrUpdateKvCustomerCatalogService } from "./create-or-update-kv-customer-catalog.service";

@Module({
    imports: [CommonModule, KvRabbitMQModule, KvInternalApiModule, FacebookSdkModule, LockModule],
    providers: [CreateOrUpdateKvCustomerService, CreateOrUpdateKvCustomerCatalogService],
})
export class CreateOrUpdateKvCustomerModule {
}
