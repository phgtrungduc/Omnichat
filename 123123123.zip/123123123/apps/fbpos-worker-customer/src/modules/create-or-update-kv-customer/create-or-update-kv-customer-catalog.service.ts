import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    ERROR_MESSAGE_REDLOCK,
    IFrom,
    IMessenger,
    IndustryTypes,
    KvBaseException,
    KvLogger,
    KvRabbitMQException,
    KvResponseInternalApiException,
    KvResponseMongoDbException,
    RabbitMQConfigAutoCreateKvCustomerCatalog,
    RabbitMqConfigKvOrderCatalog,
    SocialTypes,
} from '@kiotviet-facebook-services/common';
import { FacebookUserService } from '@kiotviet-facebook-services/facebook-sdk';
import {
    FbCatalogConnectionService,
    FbUserProfile,
    FbUserProfileRepository,
    MongodbGroupService,
    SocialUserKvCustomerDocument,
    SocialUserKvCustomerService,
    WebhookSubscriptionRepository
} from '@kiotviet-facebook-services/fbpos-master-repository';
import {
    CustomerSocialTypes,
    IAdditionalCatalog,
    IKVCustomer,
    KvCustomerService
} from '@kiotviet-facebook-services/kv-internal-api';
import { Injectable } from '@nestjs/common';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

interface IRetailerInfo {
    pageId: string;
    retailerCode: string;
    retailerId: number;
    branchId: number;
    catalogId?: string;
}

@Injectable()
export class CreateOrUpdateKvCustomerCatalogService {
    private readonly _rabbitMQConfig;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _kvCustomerService: KvCustomerService,
        private readonly _fbUserProfileRepository: FbUserProfileRepository,
        private readonly _webhookSubscriptionRepository: WebhookSubscriptionRepository,
        private readonly _facebookUserService: FacebookUserService,
        private readonly _socialUserKvCustomerService: SocialUserKvCustomerService,
        private readonly _fbCatalogConnectionService: FbCatalogConnectionService,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _mongodbGroupService: MongodbGroupService,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');

    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigAutoCreateKvCustomerCatalog.ROUTING_KEY,
        queue: `fbpos-worker-customer:${RabbitMQConfigAutoCreateKvCustomerCatalog.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _autoCreateKvCustomerCatalog(payload: IMessenger) {
        const { Order, PageId: pageId, SenderId: fbUserId } = payload;
        const prefixLog = this.prefixLog('_autoCreateKvCustomerCatalog');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': payload?.PageId,
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        try {
            if (!pageId || !fbUserId || !Order?.products?.length) {
                return Promise.resolve();
            }
            const productCatalogs = await this._getProductCatalogs(pageId, Order.products.map(item => item.id));
            if (!productCatalogs?.length) {
                return Promise.resolve();
            }
            const { retailerId, retailerCode, branchId, catalogId } = productCatalogs[0];
            const catalogConnection = await this._fbCatalogConnectionService.getCatalogConnection(retailerId, catalogId, pageId);
            if (!catalogConnection) {
                return Promise.resolve();
            }
            // TODO: trường hợp bên dưới chỉ đúng với hàng hóa chỉ nằm trên 1 catalogId duy nhất
            const socialInfo = await this._webhookSubscriptionRepository.getSubscriptionBySocialId(pageId, true);
            if ([IndustryTypes.HOTEL, IndustryTypes.SALON, IndustryTypes.FNB].includes(socialInfo?.Industry)) {
                return Promise.resolve();
            }
            const socialName = socialInfo && (socialInfo.PageInfo && socialInfo.PageInfo['name'] || socialInfo.InstagramInfo && socialInfo.InstagramInfo['username']) || '';
            const socialUserKvCustomer = await this._getOrCreateSocialUserKvCustomer(fbUserId, {
                retailerId: retailerId || catalogConnection.retailerId,
                branchId: branchId || catalogConnection.branchId,
                retailerCode,
                pageId
            }
                , {
                    PageName: socialName,
                    PageUrl: `https://facebook.com/${pageId}`,
                    CatalogName: catalogConnection.catalogName
                }
            );
            if (!socialUserKvCustomer) {
                return Promise.resolve();
            }
            this._sentEventToMQForCreatingOrder(socialUserKvCustomer, {
                retailerId,
                retailerCode,
                branchId,
                pageId,
                catalogId
            }, payload);
            this._logger.info(logInput, `${prefixLog} success`);
        } catch (error) {
            if (error.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._logger.error({ ...logInput, Error: new KvBaseException(error.stack) }, `${prefixLog} fail`);
        }
        return Promise.resolve();
    }

    private async _getProductCatalogs(pageId: string, productCatalogIds: string[]): Promise<any[]> {
        const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
        const productCatalogsColl = db.collection(this._mongodbGroupService.productCatalogsCollName);

        return productCatalogsColl
            .find({ pageId, product_catalog_id: { $in: productCatalogIds } })
            .project({ id: 1, product_catalog_id: 1, catalogId: 1, retailerId: 1, retailerCode: 1, branchId: 1 })
            .toArray();
    }

    /**
     * Step 1 : find mapping in fbpos mongodb
     * Step 2 : if step 1 not found, call api findbysocialid for mapping social
     * Step 3 : if step 2 not found, create new customer and mapping
     * If found mapping, it finished
     * @param fbUserId
     * @param retailerInfo
     * @param additionalCatalog
     * @private
     */
    private async _getOrCreateSocialUserKvCustomer(fbUserId: string, retailerInfo: IRetailerInfo, additionalCatalog: IAdditionalCatalog): Promise<SocialUserKvCustomerDocument> {
        const { retailerCode, retailerId, branchId, pageId } = retailerInfo;
        const profile = await this._createAndGetFbUserProfile(fbUserId, pageId);

        const socialUserKvCustomer = await this._getMappingKvCustomer(fbUserId, retailerInfo);
        if (socialUserKvCustomer) {
            return socialUserKvCustomer;
        }
        // Create new KV Customer and saving mapping
        if (!socialUserKvCustomer) {
            const avatar = await this._getAvatarUploadFromProfilePic(profile, retailerInfo);
            const customer = await this._createNewCustomer(profile, retailerInfo, avatar, additionalCatalog);
            if (customer) {
                await this._updateSocialUserKvCustomer({
                    retailerId,
                    retailerCode,
                    branchId,
                    userId: profile.id,
                    customer,
                    socialType: SocialTypes.FACEBOOK
                })
                return await this._socialUserKvCustomerService.getSocialUserKvCustomersById(fbUserId, retailerId, branchId?.toString());
            }
            return null;
        }

        return socialUserKvCustomer;
    }

    private async _createAndGetFbUserProfile(id: string, socialId: string) {
        const profile = await this._fbUserProfileRepository.findOne({ id }, { lean: true });
        if (profile) {
            return profile;
        }
        const socialInfo = await this._webhookSubscriptionRepository.getSubscriptionBySocialId(socialId);
        if (!socialInfo) {
            return null;
        }
        const res = await this._facebookUserService.getPsidProfile({
            psid: id,
            access_token: socialInfo.AccessToken
        });

        return res as FbUserProfile;
    }

    private async _getMappingKvCustomer(fbUserId: string, retailerInfo: IRetailerInfo): Promise<SocialUserKvCustomerDocument> {
        const { retailerCode, branchId, retailerId, pageId } = retailerInfo;

        if (!retailerCode) {
            return null;
        }
        try {
            const result = await this._kvCustomerService.findBySocialId({
                retailerCode,
                retailerId,
                branchId,
                pageIdFacebook: pageId,
                SocialId: fbUserId,
                SocialIds: null,
                Type: CustomerSocialTypes.Facebook
            });


            const foundCustomerMapping = result?.data;
            if (foundCustomerMapping || result?.['status'] === 204) {
                return await this._updateAndFindOneSocialKvCustomer(fbUserId, retailerInfo, foundCustomerMapping);
            }
        } catch (err) {
            const prefixLog = this.prefixLog('_getMappingKvCustomer');
            this._logger.error({ MessageTemplate: { fbUserId, retailerInfo }, Error: new KvResponseInternalApiException(err.stack, { cause: err }) }, `${prefixLog} fail`);
        }

        return await this._socialUserKvCustomerService.getSocialUserKvCustomersById(fbUserId, retailerId, branchId?.toString());
    }

    private async _updateAndFindOneSocialKvCustomer(fbUserId: string,
        retailerInfo: IRetailerInfo,
        foundCustomerMapping: IKVCustomer): Promise<SocialUserKvCustomerDocument> {
        const { retailerCode, retailerId, branchId } = retailerInfo;
        const params = {
            userId: fbUserId,
            retailerId,
            branchId,
            socialType: SocialTypes.FACEBOOK
        };
        let socialUserKvCustomer = await this._socialUserKvCustomerService.handleReadSocialUserKvCustomer(params);
        if (foundCustomerMapping && !foundCustomerMapping['isDeleted']) {
            if (!socialUserKvCustomer) {
                socialUserKvCustomer = {
                    ...params,
                    kvCustomerId: foundCustomerMapping.Id.toString(),
                    kvCustomerCode: foundCustomerMapping.Code,
                } as any;
            } else {
                socialUserKvCustomer.kvCustomerId = foundCustomerMapping.Id.toString();
                socialUserKvCustomer.kvCustomerCode = foundCustomerMapping.Code;
                socialUserKvCustomer.branchId = branchId?.toString();
                socialUserKvCustomer.retailerId = retailerId;
                socialUserKvCustomer.retailerCode = retailerCode;
            }
            await this._socialUserKvCustomerService.updateSocialUserKvCustomer(socialUserKvCustomer, true);
        } else {
            if (socialUserKvCustomer) {
                await this._socialUserKvCustomerService.deleteOneSocialUserKvCustomer(socialUserKvCustomer);
            }
        }
        return await this._socialUserKvCustomerService.handleReadSocialUserKvCustomer(params);
    }

    private async _createNewCustomer(
        fbUser: IFrom,
        retailerInfo: IRetailerInfo,
        avatar = '',
        additionalCatalog: IAdditionalCatalog
    ): Promise<IKVCustomer> {
        const { retailerId: RetailerId, retailerCode: RetailerCode, branchId: BranchId, pageId: PageId } = retailerInfo;

        const result = await this._kvCustomerService.createCustomer({
            RetailerId,
            BranchId,
            Customer: {
                Type: CustomerSocialTypes.Facebook,
                IsOnline: true,
                Name: fbUser.name,
                CustomerSocials: [{
                    RetailerId,
                    BranchId,
                    PageIdFacebook: PageId,
                    PsidFacebook: fbUser.id,
                    UidFacebook: fbUser.id,
                }],
                ...avatar && { Avatar: avatar }
            },
            ...additionalCatalog && {
                CatalogName: additionalCatalog.CatalogName,
                PageName: additionalCatalog.PageName,
                PageUrl: additionalCatalog.PageUrl
            }
        }, RetailerCode, RetailerId, BranchId?.toString());

        if (result?.data) {
            return result?.data;
        }
        return null;
    }

    private async _updateSocialUserKvCustomer({
        userId,
        retailerId,
        retailerCode,
        branchId,
        customer,
        socialType
    }) {
        try {
            await this._socialUserKvCustomerService.updateSocialUserKvCustomer({
                userId: userId, retailerId, branchId, retailerCode,
                kvCustomerId: customer.Id,
                kvCustomerCode: customer.Code,
                socialType
            }, true);
        } catch (error) {
            throw new KvResponseMongoDbException(error.stack);
        }
    }

    private async _getAvatarUploadFromProfilePic(fbUser: IFrom, retailerInfo: IRetailerInfo) {
        try {
            const { retailerCode: RetailerCode, pageId: PageId } = retailerInfo;

            let profilePic = fbUser.profile_pic;
            if (!profilePic) {
                const socialInfo = await this._webhookSubscriptionRepository.getSubscriptionBySocialId(PageId);
                if (!socialInfo) {
                    return null;
                }
                const { AccessToken } = socialInfo;
                profilePic = await this._getFacebookUserProfilePic(fbUser.id, AccessToken);
            }

            if (profilePic) {
                const avatarUpload = await this._kvCustomerService.uploadImageUrl({
                    retailerCode: RetailerCode,
                    imageDirectUrl: profilePic,
                });
                return avatarUpload.data?.Status == 'Success' && avatarUpload.data?.Message;
            }
        } catch (e) {
            const responseError = e?.response;
            const prefixLog = this.prefixLog('_getAvatarUploadFromProfilePic');
            this._logger.error({ MessageTemplate: { fbUser, retailerInfo }, Error: new KvBaseException(e.stack) }, `${prefixLog} fail`);
        }

        return '';
    }

    private async _getFacebookUserProfilePic(fbUserId: string, accessToken: string): Promise<string> {
        const profile = await this._fbUserProfileRepository.findOne({ id: fbUserId }, { lean: true });
        if (profile) {
            return profile.profile_pic;
        }
        const res = await this._facebookUserService.getPsidProfile({ psid: fbUserId, access_token: accessToken });

        return res.picture?.data?.url;
    }

    private _sentEventToMQForCreatingOrder(socialUserKvCustomer: SocialUserKvCustomerDocument, retailerInfo: IRetailerInfo, payload: IMessenger) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigKvOrderCatalog.ROUTING_KEY,
            {
                ...payload,
                ...retailerInfo,
                socialUserKvCustomer
            }
        )
            .catch(err => {
                const prefixLog = this.prefixLog('_sentEventToMQForCreatingOrder');
                this._logger.error({ MessageTemplate: { socialUserKvCustomer, retailerInfo, payload }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
            });
    }
}
