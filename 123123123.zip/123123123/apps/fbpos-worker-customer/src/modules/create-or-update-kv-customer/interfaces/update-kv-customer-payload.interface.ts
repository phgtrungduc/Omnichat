import { IFeed, IFrom } from "@kiotviet-facebook-services/common";

export class IUpdateKvCustomerPayload {
    EventType: string;
    RetailerId: string;
    RetailerCode: string;
    KvCustomerId: string;
    AvatarUrl: string;
}

export interface ICreateOrUpdateCustomerPayload extends IFeed {
    fbUser?: IFrom;
    RetailerId: string;
    RetailerCode: string;
    BranchId: string;
    PageId: string;
    PhoneNumber: string;

    IsAutoCreateKvCustomer: boolean;
    IsValidateFormula: boolean;
    IsAlmostValidate: boolean;
    videoId: string;
    productIdFound: string;
    quantity: number;
}
