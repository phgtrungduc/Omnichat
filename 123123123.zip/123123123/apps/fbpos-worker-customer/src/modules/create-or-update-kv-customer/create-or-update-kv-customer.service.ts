import { Inject, Injectable } from '@nestjs/common';
import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    ERROR_MESSAGE_REDLOCK,
    getFbUser,
    IFrom,
    IndustryTypes,
    KiotVietEventTypes,
    KvBaseException,
    KvLogger,
    KvRabbitMQException,
    KvResponseMongoDbException,
    RabbitMQConfigAutoCreateKvCustomer,
    RabbitMqConfigKvOrder,
    RabbitMqConfigUnsubscribeFacebookPage,
    RabbitMQConfigUpdateKvCustomer,
    SocialTypes,
} from '@kiotviet-facebook-services/common';
import {
    ICreateOrUpdateCustomerPayload,
    IUpdateKvCustomerPayload
} from './interfaces/update-kv-customer-payload.interface';
import { pick } from 'lodash';
import { CustomerSocialTypes, IKVCustomer, KvCustomerService } from '@kiotviet-facebook-services/kv-internal-api';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import {
    FbUserProfileRepository,
    SocialUserKvCustomerService,
    WebhookSubscriptionRepository
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { FacebookUserService } from '@kiotviet-facebook-services/facebook-sdk';
import {
    ICreateKvOrderPayload
} from "../../../../fbpos-worker-order/src/modules/create-kv-order/interface/create-kv-order.interface";
import { RedisLockService, REDLOCK_CONST } from "@kiotviet-facebook-services/lock";
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class CreateOrUpdateKvCustomerService {
    private readonly _rabbitMQConfig;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _kvCustomerService: KvCustomerService,
        private readonly _fbUserProfileRepository: FbUserProfileRepository,
        private readonly _webhookSubscriptionRepository: WebhookSubscriptionRepository,
        private readonly _facebookUserService: FacebookUserService,
        private readonly _socialUserKvCustomerService: SocialUserKvCustomerService,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _redlockService: RedisLockService,
        @Inject(CACHE_MANAGER) private readonly _cache: Cache,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');

    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigUpdateKvCustomer.ROUTING_KEY,
        queue: `fbpos-worker-customer:${RabbitMQConfigUpdateKvCustomer.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _updateKvCustomer(payload: IUpdateKvCustomerPayload) {
        const { EventType, RetailerCode, RetailerId, AvatarUrl, KvCustomerId } = payload;
        const prefixLog = this.prefixLog('_updateKvCustomer');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.RetailerCode': RetailerCode,
                'Kv.RetailerId': RetailerId,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        if (!EventType || EventType !== KiotVietEventTypes.UploadKvCustomer) {
            return Promise.resolve();
        }

        try {
            await this._kvCustomerService.updateAvatar({
                retailerCode: RetailerCode,
                retailerId: RetailerId,
                avatarUrl: AvatarUrl,
                customerId: KvCustomerId,
            });

            this._logger.info(logInput, `${prefixLog} success`);
        } catch (error) {
            if (error.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._handleError(prefixLog, error, logInput);

        }
        return Promise.resolve();
    }

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigAutoCreateKvCustomer.ROUTING_KEY,
        queue: `fbpos-worker-customer:${RabbitMQConfigAutoCreateKvCustomer.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _autoCreateKvCustomer(payload: ICreateOrUpdateCustomerPayload) {
        const { RetailerId, RetailerCode, BranchId, InstagramId, PageId, videoId } = payload;
        const prefixLog = this.prefixLog('_autoCreateKvCustomer');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.RetailerCode': RetailerCode,
                'Kv.RetailerId': RetailerId,
                'Kv.BranchId': BranchId,
                'Kv.SocialId': payload?.InstagramId || payload?.PageId,
                'Kv.SocialType': payload?.InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        const fbUser = payload.fbUser || getFbUser(payload);
        if (!fbUser || !fbUser.id) {
            return Promise.resolve();
        }

        try {
            const params = {
                retailerId: RetailerId,
                retailerCode: RetailerCode,
                branchId: BranchId,
                userId: fbUser.id
            }

            const socialInfo = await this._webhookSubscriptionRepository.getSubscriptionBySocialId(PageId, true);
            if ([IndustryTypes.HOTEL, IndustryTypes.SALON, IndustryTypes.FNB].includes(socialInfo?.Industry)) {
                return Promise.resolve();
            }
            const lock = await this._redlockService.acquire(
                [`${REDLOCK_CONST.LOCK_KEYS.AUTO_CREATE_KV_CUSTOMER_FACEBOOK.NAME}${fbUser.id}`],
                REDLOCK_CONST.LOCK_KEYS.AUTO_CREATE_KV_CUSTOMER_FACEBOOK.TTL,
                {},
            );


            const socialUserKvCustomer = await this._socialUserKvCustomerService.handleReadSocialUserKvCustomer(params);
            if (!socialUserKvCustomer) {
                const avatar = await this._getAvatarUploadFromProfilePic(payload, fbUser);
                const customer = await this._createNewCustomer(fbUser, payload, avatar);
                if (customer) {
                    await Promise.all([
                        this._updateFbUserProfile(fbUser.id, RetailerId, BranchId, customer),
                        this._updateSocialUserKvCustomer({
                            ...params as any,
                            customer,
                            socialType: InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK
                        })
                    ]);
                }
            }
            this._sentEventToMQForCreatingOrder({
                PageId: PageId,
                VideoId: videoId,
                FromSource: 'fbpos-worker-customer'
            })
            this._logger.info(logInput, `${prefixLog} success`);
            await this._redlockService.release(lock);

        } catch (error) {
            if (error.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._handleError(prefixLog, error, logInput, PageId);

        }
        return Promise.resolve();
    }

    private async _createNewCustomer(
        fbUser: IFrom,
        payload: ICreateOrUpdateCustomerPayload,
        avatar = ''
    ): Promise<IKVCustomer> {
        const { RetailerId, RetailerCode, BranchId, PageId, PhoneNumber, InstagramId } = payload;

        const result = await this._kvCustomerService.createCustomer({
            RetailerId,
            BranchId,
            Customer: {
                Type: InstagramId ? CustomerSocialTypes.Instagram : CustomerSocialTypes.Facebook,
                IsOnline: true,
                Name: fbUser.name,
                CustomerSocials: [{
                    RetailerId,
                    BranchId,
                    PageIdFacebook: PageId,
                    PsidFacebook: fbUser.id,
                    UidFacebook: fbUser.id,
                }],
                ...PhoneNumber && { ContactNumber: PhoneNumber },
                ...avatar && { Avatar: avatar }
            },
        }, RetailerCode, parseInt(RetailerId), BranchId);

        if (result?.data) {
            return result?.data;
        }
        return null;
    }

    private async _updateFbUserProfile(fbUserId: string, retailerId: string, branchId: string, cachedCustomer: IKVCustomer,) {
        try {
            await this._fbUserProfileRepository.updateOne(
                { id: fbUserId },
                {
                    $addToSet: {
                        kvCustomers: {
                            kvCustomerId: cachedCustomer.Id,
                            kvCustomerCode: cachedCustomer.Code,
                            branchId,
                            retailerId
                        },
                    },
                },
                { upsert: true },
            );
        } catch (error) {
            throw new KvResponseMongoDbException(error.stack);
        }
    }

    private async _getAvatarUploadFromProfilePic(payload: ICreateOrUpdateCustomerPayload, fbUser: IFrom) {
        try {
            const { RetailerCode, PageId } = payload;

            let profilePic = fbUser.profile_pic;
            if (!profilePic) {
                const socialInfo = await this._webhookSubscriptionRepository.getSubscriptionBySocialId(PageId);
                if (!socialInfo) {
                    return null;
                }
                const { AccessToken } = socialInfo;
                profilePic = await this._getFacebookUserProfilePic(fbUser.id, AccessToken);
            }

            if (profilePic) {
                const avatarUpload = await this._kvCustomerService.uploadImageUrl({
                    retailerCode: RetailerCode,
                    imageDirectUrl: profilePic,
                });
                return avatarUpload.data?.Status == 'Success' && avatarUpload.data?.Message;
            }
        } catch (e) {
            const prefixLog = this.prefixLog('_getAvatarUploadFromProfilePic');
            this._logger.error({ MessageTemplate: { payload }, Error: new KvBaseException(e.stack) }, `${prefixLog} fail`);
        }

        return '';
    }

    private async _getFacebookUserProfilePic(fbUserId: string, accessToken: string): Promise<string> {
        const profile = await this._fbUserProfileRepository.findOne({ id: fbUserId }, { lean: true });
        if (profile) {
            return profile.profile_pic;
        }
        const res = await this._facebookUserService.getPsidProfile({ psid: fbUserId, access_token: accessToken });

        return res.picture?.data?.url;
    }

    private async _updateSocialUserKvCustomer({
        userId,
        retailerId,
        retailerCode,
        branchId,
        customer,
        socialType
    }) {
        try {
            await this._socialUserKvCustomerService.updateSocialUserKvCustomer({
                userId: userId, retailerId, branchId, retailerCode,
                kvCustomerId: customer.Id,
                kvCustomerCode: customer.Code,
                socialType
            }, true);
        } catch (error) {
            throw new KvResponseMongoDbException(error.stack);
        }
    }

    private _sentEventToMQForCreatingOrder(payload: ICreateKvOrderPayload) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigKvOrder.ROUTING_KEY, payload).catch(err => {
            const prefixLog = this.prefixLog('_sentEventToMQForCreatingOrder');
            this._logger.error({ MessageTemplate: { payload }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }

    private _handleError(prefixLog: string, error: any, logInput: IKvLogInput, pageId = null) {

        const responseError = error?.response;
        if (pageId && 'KvRetailerExpireException' === responseError?.statusText) {
            // this._sentEventToMQForUnsubscribingPage(pageId);
        }

        this._logger.error({ ...logInput, Error: new KvBaseException(error.stack) }, `${prefixLog} fail`);
    }

    /**
     * Nếu gian hàng Kiotviet bị khóa hoặc hết hạn, unsubscribe fanpage để giảm tải lỗi và data rác
     * @param pageId
     * @private
     */
    private _sentEventToMQForUnsubscribingPage(PageId: string) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigUnsubscribeFacebookPage.ROUTING_KEY, { PageId })
            .catch(err => {
                const prefixLog = this.prefixLog('_sentEventToMQForUnsubscribingFanpage');
                this._logger.error({ MessageTemplate: { PageId }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
            });
    }
}
