import { IFeed } from "@kiotviet-facebook-services/common";

export interface ICreateOrUpdateFbUserProfilePayload extends IFeed {
    RetailerId: string;
    RetailerCode: string;
    BranchId: string;
    PageId: string;
    PhoneNumber: string;

    // For livestream
    IsAutoCreateKvCustomer: boolean;
    IsValidateFormula: boolean;
    IsAlmostValidate: boolean;
    videoId: string;
    productIdFound: string;
    quantity: number;
}
