import { Inject, Injectable } from '@nestjs/common';
import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    ERROR_MESSAGE_REDLOCK,
    FakeSocialType,
    ITiktokValidateLiveComment,
    KvBaseException,
    KvLogger,
    KvRabbitMQException,
    KvResponseInternalApiException,
    RabbitMQConfigAutoCreateKvCustomerTiktokLive,
    RabbitMQConfigCreateOrUpdateTiktokUserProfile,
    SocialTypes,
    UserLivestreamType,
} from '@kiotviet-facebook-services/common';

import { pick } from 'lodash';
import { CustomerSocialTypes, KvCustomerService } from '@kiotviet-facebook-services/kv-internal-api';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import {
    SocialUserKvCustomerDocument,
    SocialUserKvCustomerService,
    TiktokLivestreamScriptService,
    TiktokUserProfile,
    TiktokUserProfileService
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { RedisLockService, REDLOCK_CONST } from '@kiotviet-facebook-services/lock';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class CreateOrUpdateTiktokUserProfileService {
    private readonly _rabbitMQConfig;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _kvCustomerService: KvCustomerService,
        private readonly _tiktokUserProfileService: TiktokUserProfileService,
        private readonly _redlockService: RedisLockService,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _socialUserKvCustomerService: SocialUserKvCustomerService,
        private readonly _tiktokLivestreamScriptService: TiktokLivestreamScriptService,
        @Inject(CACHE_MANAGER) private readonly _cache: Cache,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigCreateOrUpdateTiktokUserProfile.ROUTING_KEY,
        queue: `fbpos-worker-customer:${RabbitMQConfigCreateOrUpdateTiktokUserProfile.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _createOrUpdateTiktokUserProfile(payload: ITiktokValidateLiveComment) {
        const {
            liveUserId,
            userId,
            uniqueId,
            nickname,
            livestreamScriptId,
            profilePictureUrl,
        } = payload;
        const prefixLog = this.prefixLog('_createOrUpdateTiktokUserProfile');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.RetailerCode': payload.retailerCode,
                'Kv.RetailerId': payload.retailerId,
                'Kv.BranchId': payload.branchId,
                'Kv.SocialId': payload.liveUserId,
                'Kv.SocialType': SocialTypes.TIKTOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        if (!liveUserId || !userId || !livestreamScriptId) {
            return Promise.resolve();
        }
        try {

            const lock = await this._redlockService.acquire(
                [`${REDLOCK_CONST.LOCK_KEYS.AUTO_CREATE_TIKTOK_PROFILE}${userId}`],
                5000,
                {},
            );

            let profile = await this._createAndGetTiktokUserProfile({
                userId,
                uniqueId,
                nickname,
                livestreamScriptId,
            });
            // profile = this._getLivestreamInfoes(profile, payload);
            delete profile['_id'];
            profile.avatar = profilePictureUrl;
            await this._tiktokUserProfileService.handleUpdateTiktokUserProfile(profile, true);
            // const [, socialUserKvCustomer] = await Promise.all([
            //     this._tiktokUserProfileService.handleUpdateTiktokUserProfile(profile, true),
            //     this._getMappingKvCustomer(profile.id, payload),
            // ])

            // this._sentEventToMQ(socialUserKvCustomer, payload);

            this._logger.info(logInput, `${prefixLog} success`);

            await this._redlockService.release(lock).catch(e => this._logger.error(`${prefixLog} release lock err`, e));
        } catch (error) {
            if (error.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._logger.error({ ...logInput, Error: new KvBaseException(error.stack) }, `${prefixLog} fail`);

        }

        return Promise.resolve();
    }

    private async _createAndGetTiktokUserProfile({ userId, uniqueId, nickname, livestreamScriptId }) {
        const profile = await this._tiktokUserProfileService.handleReadTiktokUserProfile(userId, livestreamScriptId);

        if (profile) {
            return profile;
        }
        return (await this._tiktokUserProfileService.handleUpdateTiktokUserProfile({
            livestreamScriptId,
            id: userId,
            uniqueId,
            nickname
        }, true)) as TiktokUserProfile
    }

    private _getLivestreamInfoes(profile: TiktokUserProfile, payload: ITiktokValidateLiveComment): TiktokUserProfile {
        const newProfile = { ...profile };
        const { IsValidateFormula, livestreamScriptId, kvProductId } = payload;

        if (livestreamScriptId === newProfile.livestreamScriptId) {
            if (kvProductId) {
                newProfile.kvProductIds = newProfile.kvProductIds.includes(`${kvProductId}`)
                    ? newProfile.kvProductIds :
                    [...newProfile.kvProductIds, `${kvProductId}`];
            }
            if (IsValidateFormula) {
                newProfile.type = UserLivestreamType.VALIDATE_FORMULA;
            }
        }
        return newProfile;
    }

    private async _getMappingKvCustomer(userId: string, payload: ITiktokValidateLiveComment): Promise<SocialUserKvCustomerDocument> {
        const { retailerCode, retailerId, branchId } = payload;

        if (!retailerCode || !retailerId) {
            return null;
        }
        try {
            const result = await this._kvCustomerService.findBySocialId({
                retailerCode,
                retailerId,
                branchId,
                pageIdFacebook: FakeSocialType.TIKTOK, // Mặc định 1 userid chỉ tạo 1 khách hàng kv
                SocialIds: null,
                SocialId: userId,
                Type: CustomerSocialTypes.TiktokLive
            });
            const foundCustomerMapping = result.data;
            const params = { userId: userId, retailerId, branchId };
            let socialUserKvCustomer = await this._socialUserKvCustomerService.handleReadSocialUserKvCustomer(params);

            if (foundCustomerMapping && !foundCustomerMapping['isDeleted']) {
                if (!socialUserKvCustomer) {
                    socialUserKvCustomer = {
                        ...params,
                        kvCustomerId: foundCustomerMapping.Id.toString(),
                        kvCustomerCode: foundCustomerMapping.Code,
                        socialType: SocialTypes.TIKTOK
                    } as any;
                } else {
                    socialUserKvCustomer.kvCustomerId = foundCustomerMapping.Id.toString();
                    socialUserKvCustomer.kvCustomerCode = foundCustomerMapping.Code;
                    socialUserKvCustomer.branchId = branchId?.toString();
                    socialUserKvCustomer.retailerId = retailerId;
                    socialUserKvCustomer.retailerCode = retailerCode;
                }
                await this._socialUserKvCustomerService.updateSocialUserKvCustomer(socialUserKvCustomer, true);

            } else {
                // Nếu không tìm KvCustomer mà vẫn còn mapping thì xóa mapping đi
                if (socialUserKvCustomer) {
                    await this._socialUserKvCustomerService.deleteOneSocialUserKvCustomer(socialUserKvCustomer);
                    socialUserKvCustomer = null;
                }
            }
            return socialUserKvCustomer;
        } catch (err) {
            const prefixLog = this.prefixLog('_getMappingKvCustomer');
            this._logger.error({ MessageTemplate: { payload, userId }, Error: new KvResponseInternalApiException(err.stack, { cause: err }) }, `${prefixLog} fail`);
        }

        return null;
    }


    private _sentEventToMQ(socialUserKvCustomer: SocialUserKvCustomerDocument, payload: ITiktokValidateLiveComment) {
        const { IsAutoCreateKvCustomer, IsValidateFormula } = payload;
        const isCreateCustomer = IsAutoCreateKvCustomer && IsValidateFormula && !socialUserKvCustomer;
        if (!isCreateCustomer) {
            return;
        }

        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMQConfigAutoCreateKvCustomerTiktokLive.ROUTING_KEY, payload)
            .catch(err => {
                const prefixLog = this.prefixLog('_sentEventToMQ');
                this._logger.error({ MessageTemplate: { socialUserKvCustomer, payload }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
            });
    }
}
