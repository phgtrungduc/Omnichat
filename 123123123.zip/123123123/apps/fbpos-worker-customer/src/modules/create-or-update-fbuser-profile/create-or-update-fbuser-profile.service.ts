import { Inject, Injectable } from '@nestjs/common';
import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    ERROR_MESSAGE_REDLOCK,
    getFbUser,
    IFrom,
    KvBaseException,
    KvLogger,
    KvRabbitMQException,
    KvResponseInternalApiException,
    RabbitMQConfigAutoCreateKvCustomer,
    RabbitMQConfigCreateOrUpdateFbUserProfile,
    SocialTypes,
} from '@kiotviet-facebook-services/common';
import { ICreateOrUpdateFbUserProfilePayload } from './interfaces/create-or-update-fbuser-profile-payload.interface';
import { pick } from 'lodash';
import { CustomerSocialTypes, IKVCustomer, KvCustomerService } from '@kiotviet-facebook-services/kv-internal-api';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import {
    FbUserProfile,
    FbUserProfileRepository,
    SocialUserKvCustomerService,
    WebhookSubscriptionRepository
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { FacebookUserService } from '@kiotviet-facebook-services/facebook-sdk';
import { RedisLockService, REDLOCK_CONST } from '@kiotviet-facebook-services/lock';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class CreateOrUpdateFbUserProfileService {

    private readonly _rabbitMQConfig;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _kvCustomerService: KvCustomerService,
        private readonly _fbUserProfileRepository: FbUserProfileRepository,
        private readonly _webhookSubscriptionRepository: WebhookSubscriptionRepository,
        private readonly _facebookUserService: FacebookUserService,
        private readonly _redlockService: RedisLockService,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _socialUserKvCustomerService: SocialUserKvCustomerService,
        @Inject(CACHE_MANAGER) private readonly _cache: Cache,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigCreateOrUpdateFbUserProfile.ROUTING_KEY,
        queue: `fbpos-worker-customer:${RabbitMQConfigCreateOrUpdateFbUserProfile.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _createOrUpdateFbUserProfile(payload: ICreateOrUpdateFbUserProfilePayload) {
        const { PageId } = payload;
        const prefixLog = this.prefixLog('_createOrUpdateFbUserProfile');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.RetailerCode': payload?.RetailerCode,
                'Kv.RetailerId': payload?.RetailerId,
                'Kv.BranchId': payload?.BranchId,
                'Kv.SocialId': payload?.InstagramId || payload?.PageId,
                'Kv.SocialType': payload?.InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        const fbUser = getFbUser(payload);

        if (!fbUser || !fbUser.id || fbUser.id === PageId) {
            return Promise.resolve();
        }
        try {
            const lock = await this._redlockService.acquire(
                [`${REDLOCK_CONST.LOCK_KEYS.AUTO_CREATE_FB_PROFILE}${fbUser.id}`],
                5000,
                {},
            );

            let profile = await this._createAndGetFbUserProfile(fbUser, PageId);
            profile = this._getLivestreamInfoes(profile, payload);
            profile = await this._getMappingKvCustomer(profile, payload);
            await this._fbUserProfileRepository.updateOne(
                { id: fbUser.id },
                profile,
                { upsert: true },
            );
            this._sentEventToMQ(profile, payload);
            this._logger.info(logInput, `${prefixLog} success`);

            await this._redlockService.release(lock);
        } catch (error) {
            if (error.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._logger.error({ ...logInput, Error: new KvBaseException(error.stack) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }

    private async _createAndGetFbUserProfile(fbUser: IFrom, socialId: string) {
        const profile = await this._fbUserProfileRepository.findOne({ id: fbUser.id }, { lean: true });
        if (profile) {
            return profile;
        }
        const socialInfo = await this._webhookSubscriptionRepository.getSubscriptionBySocialId(socialId);
        if (!socialInfo) {
            return null;
        }
        const res = await this._facebookUserService.getPsidProfile({
            psid: fbUser.id,
            access_token: socialInfo.AccessToken
        });

        return res as FbUserProfile;
    }

    private _getLivestreamInfoes(profile: FbUserProfile, payload: ICreateOrUpdateFbUserProfilePayload): FbUserProfile {
        const newProfile = { ...profile };
        const { IsValidateFormula, IsAlmostValidate, videoId, productIdFound, quantity } = payload;

        if (videoId) {
            const found = (newProfile.livestreamInfoes || []).find(info => info['videoId'] === videoId);
            const newVideoIdProductId = `${videoId}_${productIdFound}`;
            if (found) {
                const currentVideoIdProductId = found['videoId_productId'] || [];

                if (IsValidateFormula) {
                    found['isValidate'] = IsValidateFormula;
                }

                if (IsAlmostValidate) {
                    found['isAlmostValidate'] = IsAlmostValidate;
                }

                if (productIdFound && quantity && (IsValidateFormula || IsAlmostValidate)) {
                    found['videoId_productId'] = (currentVideoIdProductId.includes(newVideoIdProductId) ? currentVideoIdProductId : [...currentVideoIdProductId, newVideoIdProductId])
                }

            } else {
                newProfile.livestreamInfoes = [...(newProfile.livestreamInfoes || []), {
                    videoId,
                    isValidate: IsValidateFormula,
                    isAlmostValidate: IsAlmostValidate,
                    videoId_productId: [newVideoIdProductId]
                }]
            }

            return newProfile;
        }
    }

    private async _getMappingKvCustomer(profile: FbUserProfile, payload: ICreateOrUpdateFbUserProfilePayload): Promise<FbUserProfile> {
        const newProfile = { ...profile };
        const { RetailerCode, RetailerId, BranchId, PageId, InstagramId } = payload;

        const { kvCustomers } = newProfile;
        if (!RetailerCode) {
            return newProfile;
        }
        try {
            const result = await this._kvCustomerService.findBySocialId({
                retailerCode: RetailerCode,
                retailerId: RetailerId,
                branchId: BranchId,
                pageIdFacebook: PageId,
                SocialId: newProfile.id,
                SocialIds: null,
                Type: InstagramId ? CustomerSocialTypes.Instagram : CustomerSocialTypes.Facebook
            });
            const foundCustomerMapping = result.data;
            const foundMapping = kvCustomers && kvCustomers.find(customer => customer['branchId'] === BranchId);

            if (foundCustomerMapping && !foundCustomerMapping['isDeleted']) {
                if (!foundMapping) {
                    newProfile.kvCustomers = [...kvCustomers || [],
                    {
                        kvCustomerId: foundCustomerMapping['Id'],
                        kvCustomerCode: foundCustomerMapping['Code'],
                        branchId: BranchId,
                        retailerId: RetailerId,
                        retailerCode: RetailerCode
                    }];
                } else {
                    foundMapping['kvCustomerId'] = foundCustomerMapping['Id'];
                    foundMapping['kvCustomerCode'] = foundCustomerMapping['Code'];
                    foundMapping['branchId'] = BranchId;
                    foundMapping['retailerId'] = RetailerId;
                    foundMapping['retailerCode'] = RetailerCode;
                }
            } else {
                // Nếu không tìm KvCustomer mà vẫn còn mapping thì xóa mapping đi
                if (foundMapping) {
                    newProfile.kvCustomers = kvCustomers.filter(cus => cus['branchId'] !== BranchId);
                }
            }


            // Update bảng mới cho luồng mới
            await this._updateSocialKvCustomer(profile, payload, foundCustomerMapping);
        } catch (err) {
            const prefixLog = this.prefixLog('_getMappingKvCustomer');
            this._logger.error({ MessageTemplate: { payload, profile }, Error: new KvResponseInternalApiException(err.stack, { cause: err }) }, `${prefixLog} fail`);
        }

        return newProfile;

    }

    private async _updateSocialKvCustomer(profile: FbUserProfile, payload: ICreateOrUpdateFbUserProfilePayload, foundCustomerMapping: IKVCustomer) {
        const { RetailerCode, RetailerId, BranchId, InstagramId } = payload;
        const params = {
            userId: profile.id,
            retailerId: RetailerId,
            branchId: BranchId,
            socialType: InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK
        };
        let socialUserKvCustomer = await this._socialUserKvCustomerService.handleReadSocialUserKvCustomer(params);
        if (foundCustomerMapping && !foundCustomerMapping['isDeleted']) {
            if (!socialUserKvCustomer) {
                socialUserKvCustomer = {
                    ...params,
                    kvCustomerId: foundCustomerMapping.Id.toString(),
                    kvCustomerCode: foundCustomerMapping.Code,
                } as any;
            } else {
                socialUserKvCustomer.kvCustomerId = foundCustomerMapping.Id.toString();
                socialUserKvCustomer.kvCustomerCode = foundCustomerMapping.Code;
                socialUserKvCustomer.branchId = BranchId
                socialUserKvCustomer.retailerId = parseInt(RetailerId);
                socialUserKvCustomer.retailerCode = RetailerCode;
            }
            await this._socialUserKvCustomerService.updateSocialUserKvCustomer(socialUserKvCustomer, true);
        } else {
            // Nếu không tìm KvCustomer mà vẫn còn mapping thì xóa mapping đi
            if (socialUserKvCustomer) {
                await this._socialUserKvCustomerService.deleteOneSocialUserKvCustomer(socialUserKvCustomer);
            }
        }
    }

    private _sentEventToMQ(fbUser: FbUserProfile, payload: ICreateOrUpdateFbUserProfilePayload) {
        const { IsAutoCreateKvCustomer, IsValidateFormula, BranchId } = payload;
        const isCreateCustomer = IsAutoCreateKvCustomer && IsValidateFormula && !(fbUser.kvCustomers || []).find(cus => cus['branchId'] === BranchId);
        if (!isCreateCustomer) {
            return;
        }
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMQConfigAutoCreateKvCustomer.ROUTING_KEY, {
            ...payload,
            fbUser
        }).catch(err => {
            const prefixLog = this.prefixLog('_sentEventToMQ');
            this._logger.error({ MessageTemplate: { payload, fbUser }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }

}
