import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    ERROR_MESSAGE_REDLOCK,
    FacebookResponseException,
    getFbUser,
    IFrom,
    KvBaseException,
    KvLogger,
    KvRabbitMQException,
    RabbitMQConfigAutoCreateKvCustomer,
    RabbitMQConfigCreateOrUpdateFbUserProfileV2,
    SocialTypes,
    UserLivestreamType
} from '@kiotviet-facebook-services/common';
import { FacebookUserService } from "@kiotviet-facebook-services/facebook-sdk";
import {
    FbLivestreamScriptService,
    FbUserProfileV2,
    FbUserProfileV2Service,
    SocialUserKvCustomerDocument,
    SocialUserKvCustomerService,
    WebhookSubscriptionRepository
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { CustomerSocialTypes, KvCustomerService } from '@kiotviet-facebook-services/kv-internal-api';
import { RedisLockService, REDLOCK_CONST } from '@kiotviet-facebook-services/lock';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject, Injectable } from '@nestjs/common';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
import { ICreateOrUpdateFbUserProfilePayload } from "./interfaces/create-or-update-fbuser-profile-payload.interface";

const config = require('config');

@Injectable()
export class CreateOrUpdateFbUserProfileV2Service {

    private readonly _rabbitMQConfig;

    constructor(
        @Inject(CACHE_MANAGER) private readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _kvCustomerService: KvCustomerService,
        private readonly _fbUserProfileV2Service: FbUserProfileV2Service,
        private readonly _redlockService: RedisLockService,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _socialUserKvCustomerService: SocialUserKvCustomerService,
        private readonly _fbLivestreamScriptService: FbLivestreamScriptService,
        private readonly _webhookSubscriptionRepository: WebhookSubscriptionRepository,
        private readonly _facebookUserService: FacebookUserService,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigCreateOrUpdateFbUserProfileV2.ROUTING_KEY,
        queue: `fbpos-worker-customer:${RabbitMQConfigCreateOrUpdateFbUserProfileV2.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _createOrUpdateFbUserProfileV2(payload: ICreateOrUpdateFbUserProfilePayload) {
        const { PageId, videoId } = payload;
        const prefixLog = this.prefixLog('_createOrUpdateFbUserProfileV2');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': payload?.InstagramId || payload?.PageId,
                'Kv.SocialType': payload?.InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        const fbUser = getFbUser(payload);

        if (!fbUser || !fbUser.id || fbUser.id === PageId) {
            return Promise.resolve();
        }
        try {
            const lock = await this._redlockService.acquire(
                [`${REDLOCK_CONST.LOCK_KEYS.AUTO_CREATE_FB_PROFILE_V2}${fbUser.id}`],
                5000,
                {},
            );

            let profile = await this._createAndGetFbUserProfile(fbUser, videoId, PageId);
            profile = this._getLivestreamInfoes(profile, payload);
            delete profile['_id'];
            const [, socialUserKvCustomer] = await Promise.all([
                this._fbUserProfileV2Service.handleUpdateFacebookUserProfile(profile, true),
                this._getMappingKvCustomer(profile.id, payload),
            ])

            this._sentEventToMQ(socialUserKvCustomer, payload);
            await this._redlockService.release(lock);
            this._logger.info(logInput, `${prefixLog} success`);
        } catch (error) {
            if (error.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._logger.error({ ...logInput, Error: new KvBaseException(error.stack) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }

    private async _createAndGetFbUserProfile(fbUser: IFrom, videoId: string, socialId: string) {
        const { id: userId, name } = fbUser;
        const profile = await this._fbUserProfileV2Service.handleReadFacebookUserProfile(userId, videoId);

        if (profile) {
            return profile;
        }
        const socialInfo = await this._webhookSubscriptionRepository.getSubscriptionBySocialId(socialId);
        if (!socialInfo) {
            return null;
        }
        try {
            const res = await this._facebookUserService.getPsidProfile({
                psid: userId,
                access_token: socialInfo.AccessToken
            });
            if (res.picture?.data?.url) {
                res['profile_pic'] = res.picture?.data?.url;
                delete res.picture;
            }
            return (await this._fbUserProfileV2Service.handleUpdateFacebookUserProfile({
                ...res,
                name: res?.name || name,
                id: userId,
                videoId,
                socialId,
                socialType: SocialTypes.FACEBOOK
            }, true)) as FbUserProfileV2;
        } catch (e) {
            const prefixLog = this.prefixLog('_createAndGetFbUserProfile');
            this._logger.error({
                MessageTemplate: {
                    fbUser,
                    socialId,
                    videoId,
                }, Error: new FacebookResponseException(e.stack, { cause: e })
            }, `${prefixLog} fail`);
        }

        return (await this._fbUserProfileV2Service.handleUpdateFacebookUserProfile({
            name: name,
            id: userId,
            videoId,
            socialId,
            socialType: SocialTypes.FACEBOOK
        }, true)) as FbUserProfileV2;
    }

    private _getLivestreamInfoes(profile: FbUserProfileV2, payload: ICreateOrUpdateFbUserProfilePayload): FbUserProfileV2 {
        const newProfile = { ...profile };
        const { IsValidateFormula, IsAlmostValidate, videoId, productIdFound } = payload;

        if (videoId === newProfile.videoId) {
            if (productIdFound) {
                newProfile.kvProductIds = newProfile.kvProductIds.includes(`${productIdFound}`)
                    ? newProfile.kvProductIds :
                    [...newProfile.kvProductIds, `${productIdFound}`];
            }
            if (!newProfile.type && IsValidateFormula) {
                newProfile.type = UserLivestreamType.VALIDATE_FORMULA;
            }
            // if (IsAlmostValidate) {
            //     newProfile.type = UserLivestreamType.ALMOST_VALIDATE;
            // }
        }
        return newProfile;
    }

    private async _getMappingKvCustomer(userId: string, payload: ICreateOrUpdateFbUserProfilePayload): Promise<SocialUserKvCustomerDocument> {
        const { RetailerCode, RetailerId, BranchId, PageId } = payload;

        if (!RetailerCode || !RetailerId) {
            return null;
        }
        try {
            const result = await this._kvCustomerService.findBySocialId({
                retailerCode: RetailerCode,
                retailerId: RetailerId,
                branchId: BranchId,
                // pageIdFacebook: FakeSocialType.FaceBook, // Mặc định 1 userid chỉ tạo 1 khách hàng kv
                pageIdFacebook: PageId,
                SocialIds: null,
                SocialId: userId,
                Type: CustomerSocialTypes.Facebook
            });
            const foundCustomerMapping = result.data;
            const params = { userId: userId, retailerId: RetailerId, branchId: BranchId };
            let socialUserKvCustomer = await this._socialUserKvCustomerService.handleReadSocialUserKvCustomer(params);

            if (foundCustomerMapping && !foundCustomerMapping['isDeleted']) {
                if (!socialUserKvCustomer) {
                    socialUserKvCustomer = {
                        ...params,
                        kvCustomerId: foundCustomerMapping.Id.toString(),
                        kvCustomerCode: foundCustomerMapping.Code,
                        socialType: SocialTypes.FACEBOOK
                    } as any;
                } else {
                    socialUserKvCustomer.kvCustomerId = foundCustomerMapping.Id.toString();
                    socialUserKvCustomer.kvCustomerCode = foundCustomerMapping.Code;
                    socialUserKvCustomer.branchId = BranchId?.toString();
                    socialUserKvCustomer.retailerId = parseInt(RetailerId);
                    socialUserKvCustomer.retailerCode = RetailerCode;
                }
                await this._socialUserKvCustomerService.updateSocialUserKvCustomer(socialUserKvCustomer, true);

            } else {
                // Nếu không tìm KvCustomer mà vẫn còn mapping thì xóa mapping đi
                if (socialUserKvCustomer) {
                    await this._socialUserKvCustomerService.deleteOneSocialUserKvCustomer(socialUserKvCustomer);
                    socialUserKvCustomer = null;
                }
            }
            return socialUserKvCustomer;
        } catch (err) {
            const prefixLog = this.prefixLog('_getMappingKvCustomer');
            this._logger.error({ MessageTemplate: { payload, userId }, Error: err }, `${prefixLog} fail`);
        }

        return null;
    }


    private _sentEventToMQ(socialUserKvCustomer: SocialUserKvCustomerDocument, payload: ICreateOrUpdateFbUserProfilePayload) {
        const { IsAutoCreateKvCustomer, IsValidateFormula } = payload;
        const isCreateCustomer = IsAutoCreateKvCustomer && IsValidateFormula && !socialUserKvCustomer;
        if (!isCreateCustomer) {
            return;
        }

        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMQConfigAutoCreateKvCustomer.ROUTING_KEY, payload)
            .catch(err => {
                const prefixLog = this.prefixLog('_sentEventToMQ');
                this._logger.error({ MessageTemplate: { socialUserKvCustomer, payload }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
            });
    }

}
