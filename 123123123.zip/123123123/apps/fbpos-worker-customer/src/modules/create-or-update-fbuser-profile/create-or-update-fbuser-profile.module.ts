import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { CreateOrUpdateFbUserProfileService } from './create-or-update-fbuser-profile.service';
import { KvInternalApiModule } from '@kiotviet-facebook-services/kv-internal-api';
import { FacebookSdkModule } from '@kiotviet-facebook-services/facebook-sdk';
import { LockModule } from '@kiotviet-facebook-services/lock';
import { CreateOrUpdateFbUserProfileV2Service } from "./create-or-update-fbuser-profile-v2.service";
import { CreateOrUpdateTiktokUserProfileService } from "./create-or-update-tiktok-user-profile.service";

@Module({
    imports: [CommonModule, KvRabbitMQModule, KvInternalApiModule, FacebookSdkModule, LockModule],
    providers: [CreateOrUpdateFbUserProfileService, CreateOrUpdateFbUserProfileV2Service, CreateOrUpdateTiktokUserProfileService],
})
export class CreateOrUpdateFbuserProfileModule {
}
