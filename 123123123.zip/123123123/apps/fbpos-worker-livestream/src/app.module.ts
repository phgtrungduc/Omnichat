import { Module } from '@nestjs/common';
import { CoreModule } from './core/core.module';
import { LivestreamAiIntegrationModule } from "./modules/livestream-ai-integration/livestream-ai-integration.module";
import { LivestreamResetCacheModule } from './modules/livestream-reset-cache/livestream-reset-cache.module';
import {
    TiktokLivestreamWebhookProcessModule
} from "./modules/tiktok-livestream-webhook-process/tiktok-livestream-webhook-process.module";

@Module({
    imports: [
        CoreModule,
        LivestreamAiIntegrationModule,
        LivestreamResetCacheModule,
        TiktokLivestreamWebhookProcessModule
    ],
    controllers: [],
    providers: [],
})
export class AppModule {
}
