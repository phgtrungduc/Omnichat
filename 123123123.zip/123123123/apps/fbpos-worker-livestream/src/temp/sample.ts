import { ITiktokLiveComment } from "@kiotviet-facebook-services/common";

export const payload: ITiktokLiveComment = {
  "event": "chat",
  "livestreamScriptId": "667a2f20a629bcfdf0e7f3f4",
  "liveUserId": "61863519709",
  "liveUniqueId": "trantran7978",
  "rawData": {
    "emotes": [],
    "comment": "Cực phẩm kk",
    "userId": "7325324287174460423",
    "secUid": "MS4wLjABAAAACNA63zweGrZrcXLLSTJUUiXCD_Ede2aRtdFpuvDw2I0X3siMT3_gHQbNWwxpDggq",
    "uniqueId": "user2688076593271",
    "nickname": "Phuong Anh",
    "profilePictureUrl": "https://p16-sign-sg.tiktokcdn.com/aweme/100x100/tos-alisg-avt-0068/e29fe05aa60338d7256effde32d14a3c.webp?lk3s=a5d48078&nonce=56879&refresh_token=ca7118e553878bf85bc17c5d23061c60&x-expires=1719471600&x-signature=xp%2BlCZ%2BzuZULZPca31YD4sD9hWo%3D&shp=a5d48078&shcp=fdd36af4",
    "followRole": 1,
    "userBadges": [],
    "userSceneTypes": [],
    "userDetails": {
      "createTime": "0",
      "bioDescription": "",
      "profilePictureUrls": [
        "https://p16-sign-sg.tiktokcdn.com/tos-alisg-avt-0068/e29fe05aa60338d7256effde32d14a3c~tplv-tiktok-shrink:72:72.webp?lk3s=a5d48078&nonce=67220&refresh_token=41acf9f74eac4cdbb82febb772d1b6dc&x-expires=1719471600&x-signature=NaTYXW%2FyqkNHj1TQ%2BSboa9Orrzs%3D&shp=a5d48078&shcp=fdd36af4",
        "https://p16-sign-sg.tiktokcdn.com/aweme/100x100/tos-alisg-avt-0068/e29fe05aa60338d7256effde32d14a3c.webp?lk3s=a5d48078&nonce=56879&refresh_token=ca7118e553878bf85bc17c5d23061c60&x-expires=1719471600&x-signature=xp%2BlCZ%2BzuZULZPca31YD4sD9hWo%3D&shp=a5d48078&shcp=fdd36af4",
        "https://p9-sign-sg.tiktokcdn.com/aweme/100x100/tos-alisg-avt-0068/e29fe05aa60338d7256effde32d14a3c.webp?lk3s=a5d48078&nonce=82791&refresh_token=53d04a69d45dd9587d4f07a13920756a&x-expires=1719471600&x-signature=sjphdFtXH32s9u0ZIhJft3e2q5c%3D&shp=a5d48078&shcp=fdd36af4",
        "https://p16-sign-sg.tiktokcdn.com/aweme/100x100/tos-alisg-avt-0068/e29fe05aa60338d7256effde32d14a3c.jpeg?lk3s=a5d48078&nonce=61023&refresh_token=d8620495013ab5f53741e82392993360&x-expires=1719471600&x-signature=XOhFJkwwB1GlPnaTaqn2QQNQh2I%3D&shp=a5d48078&shcp=fdd36af4"
      ]
    },
    "followInfo": {
      "followingCount": 119,
      "followerCount": 17,
      "followStatus": 1,
      "pushStatus": 0
    },
    "isModerator": false,
    "isNewGifter": false,
    "isSubscriber": false,
    "topGifterRank": null,
    "gifterLevel": 0,
    "teamMemberLevel": 0,
    "msgId": "7384333682155834113",
    "createTime": "1719299188022"
  },
  "id": "7384333682155834113",
  "createTime": 1719299188022,
  "userId": "7325324287174460423",
  "comment": "Cực phẩm kk",
  "uniqueId": "user2688076593271",
  "nickname": "Phuong Anh",
  "profilePictureUrl": "https://p16-sign-sg.tiktokcdn.com/aweme/100x100/tos-alisg-avt-0068/e29fe05aa60338d7256effde32d14a3c.webp?lk3s=a5d48078&nonce=56879&refresh_token=ca7118e553878bf85bc17c5d23061c60&x-expires=1719471600&x-signature=xp%2BlCZ%2BzuZULZPca31YD4sD9hWo%3D&shp=a5d48078&shcp=fdd36af4"
}
