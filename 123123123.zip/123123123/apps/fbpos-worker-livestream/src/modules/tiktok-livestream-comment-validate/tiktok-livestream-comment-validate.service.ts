import { AmqpConnection, RabbitSubscribe } from "@golevelup/nestjs-rabbitmq";
import {
    ITiktokLiveComment,
    ITiktokValidateLiveComment,
    KvBaseException,
    KvLogger,
    KvRabbitMQException,
    RabbitMQConfigAutoPrint,
    RabbitMQConfigCreateOrUpdateTiktokUserProfile,
    RabbitMqConfigLivestreamTiktokCart,
    RabbitMqConfigTiktokLivestream,
    RabbitMqConfigTiktokNotification,
    RabbitMqConfigTiktokReportLivestreamDashboard,
    standardizeString,
    TiktokEventTypes,
    TiktokSyntaxCreateOrderType
} from "@kiotviet-facebook-services/common";
import {
    MongodbGroupService,
    TiktokLivestreamScript,
    TiktokLivestreamScriptDocument,
    TiktokLivestreamScriptService
} from "@kiotviet-facebook-services/fbpos-master-repository";
import { Inject, Injectable } from "@nestjs/common";
import * as _ from 'lodash';
import { pick } from 'lodash';
import { ITiktokResultValidate } from "./interfaces/tiktok-result-validate.interface";
import { Types } from "mongoose";
import { Cache, CACHE_MANAGER } from "@nestjs/cache-manager";
import { CACHE_KEYS } from "@kiotviet-facebook-services/cache";

const config = require('config');
const MAX_EVENTS_FOR_REPORT = 10;
const MIN_TIME_BETWEEN_REPORTS = 3000; // 3s

@Injectable()
export class TiktokLivestreamValidateService {
    private _rabbitMQConfig: any;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _tiktokLivestreamScriptService: TiktokLivestreamScriptService,
        private readonly _amqpConnection: AmqpConnection,
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    /**
     * Luồng đi comment
     * Validate => Tạo cart => Tạo Order
     *          => Tạo UserProfile => Tạo KvAutoCustomer => Tạo Order
     * @param payload
     * @private
     */
    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigTiktokLivestream.ROUTING_KEY,
        queue: `fbpos-worker-livestream:${RabbitMqConfigTiktokLivestream.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: {'x-queue-type': 'quorum'},
        },
    })
    private async _handleTiktokLiveComment(payload: ITiktokLiveComment) {
        const prefixLog = this.prefixLog('_handleTiktokLiveComment');
        const baseInfoLog = {
            Context: {payload},
            SourceContext: '_handleTiktokLiveComment',
        };
        this._logger.info(`${prefixLog} received`, baseInfoLog);
        try {
            const {userId, liveUserId, livestreamScriptId, comment} = payload;
            if (userId === liveUserId) {
                this._logger.warn(`${prefixLog} warning: Comment from host livestream`, baseInfoLog);
                return Promise.resolve();
            }
            const tiktokLivestreamScript = await this._tiktokLivestreamScriptService.findById(livestreamScriptId);

            if (!tiktokLivestreamScript) {
                this._logger.warn(`${prefixLog} warning: Tiktok livestream not setup successfully`, baseInfoLog);
                return Promise.resolve();
            }
            const {retailerId, retailerCode, branchId, LiveStreamFormula} = tiktokLivestreamScript;

            const {isValid, kvProducts, matchingKeywords} = this._validateComment(comment, tiktokLivestreamScript);
            const update = {
                IsValidateFormula: isValid,
                ...kvProducts?.length && {
                    quantity: 1,
                    kvProductId: kvProducts[0].KvProductId,
                    kvProductCode: kvProducts[0].KvProductCode,
                    highlightMessage: this._getHighlightMessage(kvProducts[0]),
                    kvProducts: kvProducts.map(product => {
                        return _.pick(product, ['KvProductId', 'KvProductCode', 'KvProductName'])
                    })
                },
                ...matchingKeywords?.length && {matchingKeywords},
                ...(kvProducts?.length || matchingKeywords?.length) && {
                    highlightMessage: kvProducts?.length ? this._getHighlightMessage(kvProducts[0]) : matchingKeywords[0]
                }
            }
            if (isValid) {
                await this._calculateValidateComments(payload, tiktokLivestreamScript);
                await this._updateComment(payload, update)
            }

            this._sentEventToMQ({
                ...payload, ...update,
                retailerId, retailerCode, branchId, event: TiktokEventTypes.VALIDATE_COMMENT,
                IsAutoCreateKvCustomer: LiveStreamFormula?.UseFeature
            }, tiktokLivestreamScript);

            this._processSendMQToCalculateReport(livestreamScriptId);
            this._logger.info(`${prefixLog} success`, baseInfoLog);

        } catch (error) {
            this._logger.error(`${prefixLog} fail`, new KvBaseException(error.stack), {
                ...baseInfoLog,
                ErrorContext: pick(error, ['message', 'stack']),
            });
        }

        return Promise.resolve();
    }

    private _validateComment(comment: string, tiktokLivestreamScript: TiktokLivestreamScriptDocument): ITiktokResultValidate {
        if (comment) {
            comment = standardizeString(comment);
            if (TiktokSyntaxCreateOrderType.DETAIL_KEYWORD == tiktokLivestreamScript.syntaxCreateOrderType && tiktokLivestreamScript.products) {
                return this._validateCommentByDetailKeyWord(comment, tiktokLivestreamScript);
            } else if (TiktokSyntaxCreateOrderType.GENERAL_KEYWORD == tiktokLivestreamScript.syntaxCreateOrderType && tiktokLivestreamScript.generalKeyWords) {
                return this._validateCommentByGeneralKeyword(comment, tiktokLivestreamScript);
            }
        }

        return {isValid: false, kvProducts: [], matchingKeywords: []};
    }

    private _validateCommentByDetailKeyWord(comment: string, tiktokLivestreamScript: TiktokLivestreamScriptDocument): ITiktokResultValidate {
        const {products} = tiktokLivestreamScript;
        const matchingProducts = products.map(product => {
            const matchingKeys = this.handleKey(product.ProductKey.map(standardizeString), comment);
            return {
                product,
                matchingKeywords: matchingKeys?.map(x => x.key),
                sortIndex: matchingKeys?.length ? matchingKeys?.reduce((min, obj) => (obj.value < min.value ? obj : min))?.value : -1
            };
        }).filter(product => product.matchingKeywords.length > 0).sort((a, b) => a.sortIndex - b.sortIndex);

        return {
            isValid: matchingProducts?.length > 0,
            kvProducts: matchingProducts.map(matching => matching.product),
            matchingKeywords: matchingProducts.flatMap(matching => matching.matchingKeywords)
        }
    }

    private _validateCommentByGeneralKeyword(comment: string, tiktokLivestreamScript: TiktokLivestreamScriptDocument): ITiktokResultValidate {
        const lowerCaseKeywords = tiktokLivestreamScript.generalKeyWords.map(x => standardizeString(x.Key));
        const matchingKeywords = this.handleKey(lowerCaseKeywords, comment).map(x => x.key);
        return {
            isValid: matchingKeywords.length > 0,
            matchingKeywords,
            kvProducts: []
        }

    }

    private async _updateComment(payload: ITiktokLiveComment, dataSet: any) {
        const {liveUserId, id} = payload;
        const db = await this._mongodbGroupService.getDatabase({type: 'tiktok'});
        return db.collection(this._mongodbGroupService.tiktokConversationDetailsCollName).updateOne(
            {id, liveUserId},
            {$set: dataSet},
            {upsert: true});
    }

    private async _calculateValidateComments(payload: ITiktokLiveComment, tiktokLivestreamScript: TiktokLivestreamScript) {
        const {liveUserId, id} = payload;
        const db = await this._mongodbGroupService.getDatabase({type: 'tiktok'});
        const existComment = await db.collection(this._mongodbGroupService.tiktokConversationDetailsCollName).findOne({id});
        // Check trường hợp 1 comment có thể bắn nhiều lần
        if (existComment?.IsValidateFormula) {
            return;
        }
        const {retailerId, retailerCode} = tiktokLivestreamScript;
        return this._tiktokLivestreamScriptService.updateTiktokLivestreamScript(
            retailerId,
            retailerCode,
            {_id: new Types.ObjectId(tiktokLivestreamScript['_id']), $inc: {totalValidComments: 1}}
        )
    }

    private _getHighlightMessage(kvProduct: any, quantity = 1) {
        return `${this._getProductFullName(kvProduct)} x${quantity}`;
    }

    private _getProductFullName(product: any): string {
        let name = product.KvProductName;
        if (product.KvAttributeLabel || product.KvUnit) {
            name = product.KvProductName + (product.KvAttributeLabel ? ('-' + product.KvAttributeLabel) : '') + (product.KvUnit ? ' (' + product.KvUnit + ')' : '');
        }
        return name;
    }

    /**
     *
     * @param keys key to validate map with comment
     * @param comment
     * @returns object with property : key and value
     */
    private handleKey(keys: Array<string>, comment: string): Array<IObjectValidateComment> {
        let res: IObjectValidateComment[] = [];
        if (keys && keys.length) {
            keys.forEach(x => res.push({
                key: x,
                value: this._containsExactString(comment, x)
            }));
            if (res && res.length) {
                res = res.filter(x => x.value > -1);
                res = res.sort((a, b) => a.value - b.value);
                return res;
            }
        }
        return res;
    }

    /**
     * the input stringOne and stringTwo must be standardize and lowercase
     * @param stringOne
     * @param stringTwo
     * @returns : return true if stringOne contain stringTwo, and false with others
     */
    private _containsExactString(stringOne: string, stringTwo: string): number {
        const regex = /[a-zA-Z0-9áàảãạăắằẳẵặâấầẩẫậđéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵ]/;
        const startIndex = stringOne.indexOf(stringTwo);

        if (startIndex !== -1) {
            const endIndex = startIndex + stringTwo.length;

            const isStartValid = (startIndex === 0 || !regex.test(stringOne[startIndex - 1]));
            const isEndValid = (endIndex === stringOne.length || !regex.test(stringOne[endIndex]));

            if (isStartValid && isEndValid) {
                return startIndex;
            }
        }
        return -1;
    }

    private _sentEventToMQ(event: ITiktokValidateLiveComment, tiktokLivestreamScript: TiktokLivestreamScript) {
        let routingKey = RabbitMQConfigCreateOrUpdateTiktokUserProfile.ROUTING_KEY;
        if (event.IsValidateFormula) {
            routingKey += RabbitMqConfigTiktokNotification.ROUTING_KEY;
            routingKey += RabbitMqConfigLivestreamTiktokCart.ROUTING_KEY;

            if (tiktokLivestreamScript.LiveStreamFormula?.AutoPrinting) {
                routingKey += RabbitMQConfigAutoPrint.ROUTING_KEY;
            }
        }
        delete event.rawData;

        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, routingKey, event).catch(err => {
            this._logger.error(`${this.prefixLog('_sentEventToMQ')} fail`,
                new KvRabbitMQException(err.stack), {
                    SourceContext: '_sentEventToMQ',
                    Context: {...event},
                    ErrorContext: pick(err, ['message', 'stack'])
                });
        });
    }

    private _sentEventToCalculateReportMQ(livestreamScriptId: string) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigTiktokReportLivestreamDashboard.ROUTING_KEY, {
            livestreamScriptId,
            event: TiktokEventTypes.UPDATE_ANALYTIC
        }).catch(err => {
            this._logger.error(`${this.prefixLog('_sentEventToMQ')} fail`,
                new KvRabbitMQException(err.stack), {
                    SourceContext: '_sentEventToMQ',
                    Context: {...event},
                    ErrorContext: pick(err, ['message', 'stack'])
                });
        });
    }

    /**
     * Khi nhận đủ 10 comment thì tính report
     * Nếu dưới 10 comment thì 5s sau tính report
     * @param livestreamScriptId
     * @private
     */
    private async _processSendMQToCalculateReport(livestreamScriptId: string) {
        let livestreamDictionary = await this._cache.get(CACHE_KEYS.LIVESTREAM_TIKTOK_DICTIONARY.NAME) as any;
        if (!livestreamDictionary) {
            livestreamDictionary = {};
        }
        livestreamDictionary[livestreamScriptId] = (livestreamDictionary[livestreamScriptId] || 0) + 1;
        const total = livestreamDictionary[livestreamScriptId];
        if (total >= MAX_EVENTS_FOR_REPORT) {
            this._sentEventToCalculateReportMQ(livestreamScriptId);
            delete livestreamDictionary[livestreamScriptId];
            await this._cache.set(CACHE_KEYS.LIVESTREAM_TIKTOK_DICTIONARY.NAME, livestreamDictionary, {ttl: CACHE_KEYS.LIVESTREAM_TIKTOK_DICTIONARY.TTL} as any);
        } else {
            setTimeout(async () => {
                if (total > 0) {
                    this._sentEventToCalculateReportMQ(livestreamScriptId);
                    delete livestreamDictionary[livestreamScriptId];
                    await this._cache.set(CACHE_KEYS.LIVESTREAM_TIKTOK_DICTIONARY.NAME, livestreamDictionary, {ttl: CACHE_KEYS.LIVESTREAM_TIKTOK_DICTIONARY.TTL} as any);
                }
            }, MIN_TIME_BETWEEN_REPORTS);
        }
    }

}

interface IObjectValidateComment {
    key: string;
    value: number;
}
