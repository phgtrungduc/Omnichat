import { Module } from '@nestjs/common';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { TiktokLivestreamValidateService } from './tiktok-livestream-comment-validate.service';
import { CacheModule } from "@kiotviet-facebook-services/cache";

@Module({
    imports: [FbPosMasterRepositoryModule, CommonModule, KvRabbitMQModule, CacheModule],
    providers: [TiktokLivestreamValidateService],
})
export class TiktokLiveStreamCommentValidateModule {
}
