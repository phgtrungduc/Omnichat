export interface ITiktokResultValidate {
  isValid: boolean;
  kvProducts?: any[];
  matchingKeywords?: string[];
}
