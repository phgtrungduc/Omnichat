// import { AmqpConnection } from "@golevelup/nestjs-rabbitmq";
// import { KvLogger } from "@kiotviet-facebook-services/common";
// import { MongodbGroupService, TiktokLivestreamScriptService } from "@kiotviet-facebook-services/fbpos-master-repository";
// import { Injectable } from "@nestjs/common";

// const config = require('config');

// @Injectable()
// export class TiktokLivestreamValidateService {
//   private _rabbitMQConfig: any;

//   constructor(
//     private readonly _logger: KvLogger,
//     private readonly _mongodbGroupService: MongodbGroupService,
//     private readonly _tiktokLivestreamScriptService: TiktokLivestreamScriptService,
//     private readonly _amqpConnection: AmqpConnection,
//   ) {
//     this._rabbitMQConfig = config.get('rabbitMQ');
//   }

//   prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

// }