// import { AmqpConnection, RabbitSubscribe } from "@golevelup/nestjs-rabbitmq";
// import { ITiktokLiveComment, ITiktokLivestreamInitAutoPrint, KvBaseException, KvLogger, RabbitMqConfigTiktokLivestreamInitAutoPrint, } from "@kiotviet-facebook-services/common";
// import { LivestreamPrint, LivestreamPrintService, MongodbGroupService, TiktokLivestreamScriptService } from "@kiotviet-facebook-services/fbpos-master-repository";
// import { Injectable } from "@nestjs/common";

// const config = require('config');
// @Injectable()
// export class TiktokLivestreamValidateService {
//     private _rabbitMQConfig: any;

//     constructor(
//         private readonly _logger: KvLogger,
//         private readonly _mongodbGroupService: MongodbGroupService,
//         private readonly _tiktokLivestreamScriptService: TiktokLivestreamScriptService,
//         private readonly _livestreamPrintService: LivestreamPrintService,
//         private readonly _amqpConnection: AmqpConnection,
//     ) {
//         this._rabbitMQConfig = config.get('rabbitMQ');
//     }

//     prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

//     @RabbitSubscribe({
//         exchange: config.get('rabbitMQ').mainExchange,
//         routingKey: RabbitMqConfigTiktokLivestreamInitAutoPrint.ROUTING_KEY,
//         queue: `fbpos-worker-livestream:${RabbitMqConfigTiktokLivestreamInitAutoPrint.QUEUE_NAME}`,
//         queueOptions: {
//             durable: true,
//             arguments: { 'x-queue-type': 'quorum' },
//         },
//     })
//     private async _handleInitAutoPrintLivestreamTiktok(payload: ITiktokLivestreamInitAutoPrint) {
//         const prefixLog = this.prefixLog('_handleInitAutoPrintLivestreamTiktok');
//         const baseInfoLog = {
//             Context: { payload },
//             SourceContext: '_handleInitAutoPrintLivestreamTiktok',
//         };
//         try {
//             await this._handleLivestreamStarted(payload);

//         } catch (err) {
//             this._logger.error(`${prefixLog} error`, new KvBaseException(err.stack), {
//                 SourceContext: '_handleInitAutoPrintLivestreamTiktok',
//                 Context: baseInfoLog,
//                 ErrorContext: { message: err.message, stack: err.stack },
//             });
//         }
//     }

//     private async _handleLivestreamStarted(data: ITiktokLivestreamInitAutoPrint) {
//         const {status, livestreamScriptId, userUniqueId} = data;
//         const livestreamPrintData = await this._livestreamPrintService.findByUserUniqueId(userUniqueId);

//     }
// }