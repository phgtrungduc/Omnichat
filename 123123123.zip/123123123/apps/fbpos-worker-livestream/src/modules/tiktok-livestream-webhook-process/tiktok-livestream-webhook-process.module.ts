import { Module } from '@nestjs/common';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { TiktokLivestreamWebhookProcessService } from "./tiktok-livestream-webhook-process.service";

@Module({
    imports: [FbPosMasterRepositoryModule, CommonModule, KvRabbitMQModule],
    providers: [TiktokLivestreamWebhookProcessService],
})
export class TiktokLivestreamWebhookProcessModule {
}
