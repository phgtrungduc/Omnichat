// Sample data
// {
//     emotes: [
//     ],
//     comment: "Có bim bim bán ko anh",
//     userId: "7175466821049730074",
//     secUid: "MS4wLjABAAAA-DJrJZ9k5ZT_KS1AXiLvDd7M34eamiA5oYaweTcptxu3oYB9FHyKq0LVDmHhSgr7",
//     uniqueId: "user9820021048561",
//     nickname: "user9820021048561",
//     profilePictureUrl: "https://p16-sign-va.tiktokcdn.com/musically-maliva-obj/1594805258216454~c5_100x100.webp?lk3s=a5d48078&nonce=63556&refresh_token=fb0da1fb2e31b1557eb0de169bbe5f5e&x-expires=1718262000&x-signature=ANiv1iOnkyP4UpeK2ecPxEx3zes%3D&shp=a5d48078&shcp=fdd36af4",
//     followRole: 0,
//     userBadges: [
//     ],
//     userSceneTypes: [
//     ],
//     userDetails: {
//       createTime: "0",
//       bioDescription: "",
//       profilePictureUrls: [
//         "https://p16-sign-va.tiktokcdn.com/musically-maliva-obj/1594805258216454~tplv-tiktok-shrink:72:72.webp?lk3s=a5d48078&nonce=17166&refresh_token=b0cd338ac40f0b77b82da62a500dd062&x-expires=1718262000&x-signature=O6a79oyaWeJJkOVjuzDt3UPR7OE%3D&shp=a5d48078&shcp=fdd36af4",
//         "https://p16-sign-va.tiktokcdn.com/musically-maliva-obj/1594805258216454~c5_100x100.webp?lk3s=a5d48078&nonce=63556&refresh_token=fb0da1fb2e31b1557eb0de169bbe5f5e&x-expires=1718262000&x-signature=ANiv1iOnkyP4UpeK2ecPxEx3zes%3D&shp=a5d48078&shcp=fdd36af4",
//         "https://p16-sign-va.tiktokcdn.com/musically-maliva-obj/1594805258216454~c5_100x100.jpeg?lk3s=a5d48078&nonce=5420&refresh_token=cab558477c2d6d7fcb92ee61bacd8c91&x-expires=1718262000&x-signature=VEuKB4kFRfyTrUyPhrnACTwsGCY%3D&shp=a5d48078&shcp=fdd36af4",
//       ],
//     },
//     followInfo: {
//       followingCount: 2,
//       followerCount: 3,
//       followStatus: 0,
//       pushStatus: 0,
//     },
//     isModerator: false,
//     isNewGifter: false,
//     isSubscriber: false,
//     topGifterRank: null,
//     gifterLevel: 0,
//     teamMemberLevel: 0,
//     msgId: "7379142496682756885",
//     createTime: "1718090504203",
// }

export class TiktokComment {
    event: string;
    livestreamScriptId: string;
    liveUserId: string;
    liveUniqueId: string;
    rawData: any;
    _id: string;
    id: string;
    createTime: number;
    userId: string;
    comment: string;
    uniqueId: string;
    nickname: string;
    profilePictureUrl: string;

    constructor(data: any, roomOwner: any, livestreamScriptId: string) {
        this.event = 'chat';
        this.livestreamScriptId = livestreamScriptId;
        this.liveUserId = roomOwner.liveUserId;
        this.liveUniqueId = roomOwner.liveUniqueId;
        this.rawData = data;
        this._id = data.msgId;
        this.id = data.msgId;
        this.createTime = typeof data.createTime === 'string' ? Number(data.createTime) : data.createTime;
        this.userId = data.userId;
        this.comment = data.comment;
        this.uniqueId = data.uniqueId;
        this.nickname = data.nickname;
        this.profilePictureUrl = data.profilePictureUrl;
    }
}
