import { AmqpConnection, RabbitSubscribe } from "@golevelup/nestjs-rabbitmq";
import {
    ITiktokWebhookEvent,
    KvLogger,
    KvRabbitMQException,
    RabbitMqConfigTiktokReportLivestreamDashboard,
    RabbitMQConfigTiktokWebhook,
    SocialTypes,
    TiktokEventTypes
} from "@kiotviet-facebook-services/common";
import { TiktokLivestreamScriptService } from "@kiotviet-facebook-services/fbpos-master-repository";
import { Inject, Injectable } from "@nestjs/common";
import { pick } from 'lodash';
import { TiktokComment } from "./models/tiktok-comment";
import { CACHE_KEYS } from "@kiotviet-facebook-services/cache";
import { Cache, CACHE_MANAGER } from "@nestjs/cache-manager";
import { IKvLogInput } from "libs/shared/common/src/lib/logger/interfaces/logger.interface";

const config = require('config');
const QUEUE_ROUTING = {
    chat: 'tiktok.db.tiktoknotification.tiktokcomment.tiktokautocreateuserprofile',
    member: 'tiktok.tiktoknotification',
    roomUser: 'tiktok.tiktoknotification',
    like: 'tiktok.tiktoknotification',
    streamEnd: 'tiktok.tiktoknotification.tiktoklivereportdashboard'
}

interface ITiktokWebhook {
    data: ITiktokWebhookEvent;
    event: TiktokEventTypes;
}

const MAX_EVENTS_FOR_REPORT = 10;
const MIN_TIME_BETWEEN_REPORTS = 3000; // 3s
@Injectable()
export class TiktokLivestreamWebhookProcessService {
    private readonly _rabbitMQConfig;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _tiktokLivestreamScriptService: TiktokLivestreamScriptService,
        private readonly _amqpConnection: AmqpConnection,
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigTiktokWebhook.ROUTING_KEY,
        queue: `fbpos-worker-livestream:${RabbitMQConfigTiktokWebhook.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _handleWebhookTiktokProcess(payload: ITiktokWebhook) {
        const prefixLog = this.prefixLog('_handleWebhookTiktokProcess');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': payload?.data?.liveUserId?.toString(),
                'Kv.SocialType': SocialTypes.TIKTOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);
        switch (payload.event) {
            case TiktokEventTypes.CHAT:
                await this._handlerChat(payload);
                break;
            case TiktokEventTypes.STREAM_END:
                await this._handlerStreamEnd(payload);
                break;
            case TiktokEventTypes.DISCONNECTED:
                // await this._handlerDisconnected(payload);
                break;
        }
        this._logger.info(logInput, `${prefixLog} success`);
        return Promise.resolve();
    }


    private async _handlerChat(payload: ITiktokWebhook) {
        const { liveUniqueId, liveUserId, livestreamScriptId } = payload.data;
        const comment = new TiktokComment(payload.data, { liveUserId, liveUniqueId }, livestreamScriptId);
        this.broadcast(comment);
        if (payload?.data?.livestreamScriptId) {
            await this._processSendMQToCalculateReportTiktok(payload?.data?.livestreamScriptId);
        }
    }

    private async _handlerStreamEnd(payload: ITiktokWebhook) {
        const { livestreamScriptId } = payload.data;
        const livestreamScipt = await this._tiktokLivestreamScriptService.getTiktokLivestreamScript(0, { _id: livestreamScriptId });
        if (livestreamScipt) {
            this._tiktokLivestreamScriptService.setEndLivestreamScript(livestreamScriptId);
            this.broadcast({ event: 'streamEnd', livestreamScriptId, liveUserId: livestreamScipt.userId, retailerId: livestreamScipt.retailerId });
        }
    }

    private async _handlerDisconnected(payload: ITiktokWebhook) {
        const { livestreamScriptId } = payload.data;
        const livestreamScipt = await this._tiktokLivestreamScriptService.getTiktokLivestreamScript(0, { _id: livestreamScriptId });
        if (livestreamScipt.status !== 3) {
            //disconnect by user
            if (true) {
                this._tiktokLivestreamScriptService.setEndLivestreamScript(livestreamScriptId);
                this.broadcast({ event: 'streamEnd', livestreamScriptId, liveUserId: livestreamScipt.userId, retailerId: livestreamScipt.retailerId });
            }
            //disconnect by network
            else {
                //retry
            }
        }
    }

    private broadcast(payload: any) {
        const { event } = payload;

        if (!QUEUE_ROUTING[event]) {
            return;
        }
        const routingKey = `${QUEUE_ROUTING[event]}.${event}`;
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, routingKey, payload).catch(err => {
            const prefixLog = this.prefixLog('broadcast');
            this._logger.error({ MessageTemplate: { payload }, Error: err }, `${prefixLog} fail`);
        });
    }

    /**
     * Khi nhận đủ 10 comment thì tính report
     * Nếu dưới 10 comment thì 5s sau tính report
     * @param livestreamScriptId
     * @private
     */
    private async _processSendMQToCalculateReportTiktok(livestreamScriptId: string) {
        let livestreamDictionary = await this._cache.get(CACHE_KEYS.LIVESTREAM_DICTIONARY.NAME) as any;
        if (!livestreamDictionary) {
            livestreamDictionary = {};
        }
        livestreamDictionary[livestreamScriptId] = (livestreamDictionary[livestreamScriptId] || 0) + 1;
        const total = livestreamDictionary[livestreamScriptId];
        if (total >= MAX_EVENTS_FOR_REPORT) {
            this._sentEventToCalculateReportTiktokMQ(livestreamScriptId);
            delete livestreamDictionary[livestreamScriptId];
            await this._cache.set(CACHE_KEYS.LIVESTREAM_DICTIONARY.NAME, livestreamDictionary, { ttl: CACHE_KEYS.LIVESTREAM_DICTIONARY.TTL } as any);
        } else {
            setTimeout(async () => {
                if (total > 0) {
                    this._sentEventToCalculateReportTiktokMQ(livestreamScriptId);
                    delete livestreamDictionary[livestreamScriptId];
                    await this._cache.set(CACHE_KEYS.LIVESTREAM_DICTIONARY.NAME, livestreamDictionary, { ttl: CACHE_KEYS.LIVESTREAM_DICTIONARY.TTL } as any);
                }
            }, MIN_TIME_BETWEEN_REPORTS);
        }
    }


    private _sentEventToCalculateReportTiktokMQ(livestreamScriptId: string) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigTiktokReportLivestreamDashboard.ROUTING_KEY, {
            livestreamScriptId,
        }).catch(err => {
            const prefixLog = this.prefixLog('_sentEventToCalculateReportTiktokMQ');
            this._logger.error({ MessageTemplate: { livestreamScriptId }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }
}
