import { RabbitSubscribe } from "@golevelup/nestjs-rabbitmq";
import { KvLogger, RabbitMqConfigResetCacheLivestream } from "@kiotviet-facebook-services/common";
import { FbLivestreamScriptService } from "@kiotviet-facebook-services/fbpos-master-repository";
import { Injectable } from "@nestjs/common";

const config = require('config');

interface LivestreamResetCache {
    videoId: string;
}

@Injectable()
export class LivestreamResetCacheService {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _LivestreamScriptService: FbLivestreamScriptService,
    ) {
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigResetCacheLivestream.ROUTING_KEY,
        queue: `fbpos-worker-livestream:${RabbitMqConfigResetCacheLivestream.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: {'x-queue-type': 'quorum'},
        },
    })
    private async _handleResetCacheLivestream(payload: LivestreamResetCache) {
        const prefixLog = this.prefixLog('_handleResetCacheLivestream');
        const baseInfoLog = {
            Context: {payload},
            SourceContext: '_handleResetCacheLivestream',
        };
        await this._LivestreamScriptService.clearCacheScript(payload.videoId);
        return Promise.resolve();
    }

}
