import { Module } from '@nestjs/common';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { LivestreamResetCacheService } from "./livestream-reset-cache.service";

@Module({
    imports: [FbPosMasterRepositoryModule, CommonModule, KvRabbitMQModule],
    providers: [LivestreamResetCacheService],
})
export class LivestreamResetCacheModule {
}
