import { Module } from '@nestjs/common';
import { FbPosMasterRepositoryModule, TiktokLivestreamScriptService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { TiktokLivestreamAutoPrintService } from './tiktok-livestream-auto-print-handle.service';

@Module({
    imports: [FbPosMasterRepositoryModule, CommonModule, KvRabbitMQModule],
    providers: [TiktokLivestreamAutoPrintService],
})
export class TiktokLivestreamAutoPrintHandleModule {
}
