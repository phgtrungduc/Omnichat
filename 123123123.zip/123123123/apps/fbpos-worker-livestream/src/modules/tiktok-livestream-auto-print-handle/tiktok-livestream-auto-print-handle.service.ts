import { AmqpConnection, RabbitSubscribe } from "@golevelup/nestjs-rabbitmq";
import { ITiktokLivestreamAutoPrint, ITiktokValidateLiveComment, KvBaseException, KvLogger, KvRabbitMQException, RabbitMQConfigAutoPrint, RabbitMqConfigTiktokNotification, TiktokAutoPrintEventTypes, TiktokEventTypes, TiktokLivestreamAutoPrintType, TiktokLivestreamLabelComment, TiktokSyntaxCreateOrderType, } from "@kiotviet-facebook-services/common";
import { MongodbGroupService, TiktokLivestreamScript, TiktokLivestreamScriptService } from "@kiotviet-facebook-services/fbpos-master-repository";
import { CACHE_MANAGER, Cache } from "@nestjs/cache-manager";
import { Inject, Injectable } from "@nestjs/common";
import { pick } from 'lodash';

const config = require('config');
@Injectable()
export class TiktokLivestreamAutoPrintService {
    private _rabbitMQConfig: any;

    constructor(
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _tiktokLivestreamScriptService: TiktokLivestreamScriptService,
        private readonly _amqpConnection: AmqpConnection,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigAutoPrint.ROUTING_KEY,
        queue: `${RabbitMQConfigAutoPrint.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _handleAutoPrintLivestreamTiktok(payload: ITiktokValidateLiveComment) {
        const prefixLog = this.prefixLog('_handleAutoPrintLivestreamTiktok');
        const baseInfoLog = {
            Context: { payload },
            SourceContext: '_handleAutoPrintLivestreamTiktok',
        };
        // this._logger.info(`${prefixLog} received`, payload);
        try {
            const { livestreamScriptId, matchingKeywords, kvProductId, id } = payload;
            const livestreamScript = await this._tiktokLivestreamScriptService.findById(livestreamScriptId) as TiktokLivestreamScript;
            if (!livestreamScript) {
                this._logger.warn(`${prefixLog} warning: livestream script has not been created`, baseInfoLog);
                return Promise.resolve();
            }
            
            if (livestreamScript.livestreamSocketId && livestreamScript.LiveStreamFormula.AutoPrinting) {
                const tiktokDB = await this._mongodbGroupService.getDatabase({
                    type: 'tiktok',
                });
                let updateCommentTiktok = {

                };
                const autoPrintType = livestreamScript.LiveStreamFormula.AutoPrintType;
                if (autoPrintType == TiktokLivestreamAutoPrintType.LIMIT_NUMBER) {
                    //general keyword
                    
                    if (livestreamScript.syntaxCreateOrderType == TiktokSyntaxCreateOrderType.GENERAL_KEYWORD && matchingKeywords?.length){
                        const matchKey = livestreamScript.generalKeyWords.find(x => x.Key == matchingKeywords[0]);
                        if (!matchKey) {
                            this._logger.error(`${prefixLog} cannot find matching keyword in DB`, baseInfoLog);
                            return Promise.resolve();
                        }
                        if ((matchKey.AutoPrinted || 0) < (livestreamScript.LiveStreamFormula.AutoPrintingLimitNumber || 0)) {
                            //update auto printed
                            await this._tiktokLivestreamScriptService.updatePrintedGeneral(livestreamScriptId, matchKey._id);
                        }
                        else {
                            this._logger.warn(`${prefixLog} warning: printed over limit auto print`, baseInfoLog);
                            return Promise.resolve();
                        }

                        
                        //set label for message

                        updateCommentTiktok = {
                            label: TiktokLivestreamLabelComment.EARLIEST
                        };
                        

                        const labelingData = {
                            id: id, 
                            label: TiktokLivestreamLabelComment.EARLIEST,
                            event: TiktokEventTypes.LABEL_COMMENT,
                            SocketId: livestreamScript.livestreamSocketId,
                            retailerId: payload.retailerId
                        }
                        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, `${RabbitMqConfigTiktokNotification.ROUTING_KEY}`, labelingData).catch(err => {
                            this._logger.error(`${this.prefixLog('_sentCreatedSuccessEventToMQ')} fail`,
                                new KvRabbitMQException(err.stack), {
                                SourceContext: '_sentCreatedSuccessEventToMQ',
                                Context: { payload },
                                ErrorContext: pick(err, ['message', 'stack'])
                            });
                        });
                        this._logger.info(`${prefixLog} update Label success`);
                    }

                    //detail key word
                    if (livestreamScript.syntaxCreateOrderType == TiktokSyntaxCreateOrderType.DETAIL_KEYWORD && kvProductId) {
                        const matchProduct = livestreamScript.products.find(x => x.KvProductId == kvProductId);
                        if (!matchProduct) {
                            this._logger.error(`${prefixLog} cannot find matching product in DB`, baseInfoLog);
                            return Promise.resolve();
                        }
                        if ((matchProduct.AutoPrinted || 0) < (livestreamScript.LiveStreamFormula.AutoPrintingLimitNumber || 0)) {
                            //update auto printed
                            await this._tiktokLivestreamScriptService.updatePrintedDetail(livestreamScriptId, matchProduct.KvProductId);
                        }
                        else {
                            this._logger.warn(`${prefixLog} warning: printed over limit auto print`, baseInfoLog);
                            return Promise.resolve();
                        }     
                    }
                }
                const notifyData = {
                    ...payload,
                    SocketId: livestreamScript.livestreamSocketId,
                    PrintData: [payload],
                    event: TiktokEventTypes.TIKTOK_AUTOPRINT,
                    EventType: TiktokAutoPrintEventTypes.LivestreamAutoPrint
                } as ITiktokLivestreamAutoPrint;

                updateCommentTiktok = {
                    ... updateCommentTiktok,
                    HasPrinted : true
                }

                tiktokDB.collection(this._mongodbGroupService.tiktokConversationDetailsCollName).updateOne({ id: id },
                    { "$set": updateCommentTiktok }
                );
                
                this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, `${RabbitMqConfigTiktokNotification.ROUTING_KEY}`, notifyData).catch(err => {
                    this._logger.error(`${this.prefixLog('_sentCreatedSuccessEventToMQ')} fail`,
                        new KvRabbitMQException(err.stack), {
                        SourceContext: '_sentCreatedSuccessEventToMQ',
                        Context: { payload },
                        ErrorContext: pick(err, ['message', 'stack'])
                    });
                });
            } else {
                //not have socket, set cache for 1 day and handle when start print 
                // const cacheKey = `${CACHE_KEYS.SOCKET_DISCONNECTED_TIKTOK_AUTO_PRINT_QUEUE.NAME}${livestreamScript.userUniqueId}`;
                // this._cache.set(
                //     cacheKey,
                //     payload,
                //     CACHE_KEYS.SOCKET_DISCONNECTED_TIKTOK_AUTO_PRINT_QUEUE.TTL
                // );

                //no meaning -> do nothing 
            }
            // this._logger.info(`${prefixLog} success`, payload);
        } catch (err) {
            this._logger.error(`${prefixLog} error`, new KvBaseException(err.stack), {
                SourceContext: '_handleAutoPrintLivestreamTiktok',
                Context: baseInfoLog,
                ErrorContext: { message: err.message, stack: err.stack },
            });
        }
    }
}
