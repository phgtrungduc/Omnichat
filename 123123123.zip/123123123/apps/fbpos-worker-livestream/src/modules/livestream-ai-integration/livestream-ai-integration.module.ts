import { Module } from '@nestjs/common';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { LivestreamAiIntegrationService } from "./livestream-ai-integration.service";
import { KvKafkaModule } from "@kiotviet-facebook-services/kvkafka";

@Module({
    imports: [FbPosMasterRepositoryModule, CommonModule, KvRabbitMQModule, KvKafkaModule],
    providers: [LivestreamAiIntegrationService],
})
export class LivestreamAiIntegrationModule {
}
