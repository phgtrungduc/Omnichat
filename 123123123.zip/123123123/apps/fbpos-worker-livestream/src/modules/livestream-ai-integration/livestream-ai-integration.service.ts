import { AmqpConnection, RabbitSubscribe } from "@golevelup/nestjs-rabbitmq";
import {
    EventTypes,
    IFeed,
    ITiktokLiveComment,
    KvBaseException,
    KvLogger,
    KvRabbitMQException,
    LivestreamSyntaxCreateOrderType,
    RabbitMqConfigLivestreamAIIntegration,
    RabbitMqConfigNotification,
    RabbitMqConfigReportLivestreamDashboard,
    RabbitMqConfigTiktokNotification,
    RabbitMqConfigTiktokReportLivestreamDashboard,
    sleep,
    SocialTypes,
    TiktokEventTypes
} from "@kiotviet-facebook-services/common";
import {
    FbLivestreamScriptService,
    MongodbGroupService,
    TiktokLivestreamScriptService
} from "@kiotviet-facebook-services/fbpos-master-repository";
import { Inject, Injectable } from "@nestjs/common";
import { KvKafkaService } from "@kiotviet-facebook-services/kvkafka";
import { EachMessagePayload } from "@nestjs/microservices/external/kafka.interface";
import { IKafkaPayloadLivestream, IPayloadLivestreamAI } from "@kiotviet-facebook-services/kv-livestream-ai";
import { pick } from 'lodash';
import { IntentCodeAITypes } from "../../../../../libs/shared/kv-livestream-ai/src/lib/common";
import { CACHE_KEYS } from "@kiotviet-facebook-services/cache";
import { Cache, CACHE_MANAGER } from "@nestjs/cache-manager";
import { IKvLogInput } from "libs/shared/common/src/lib/logger/interfaces/logger.interface";

const config = require('config');
const MAX_EVENTS_FOR_REPORT = 10;
const MIN_TIME_BETWEEN_REPORTS = 3000; // 3s
@Injectable()
export class LivestreamAiIntegrationService {

    private readonly _livestreamAITopic: string;
    private _livestreamAIConfig: {
        topic: string;
        enable: boolean;
        pageIds: string[]
    }
    private _rabbitMQConfig: any;


    constructor(
        private readonly _logger: KvLogger,
        private readonly _tiktokLivestreamScriptService: TiktokLivestreamScriptService,
        private readonly _fbLivestreamScriptService: FbLivestreamScriptService,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _kvKafkaService: KvKafkaService,
        private readonly _amqpConnection: AmqpConnection,
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
        this._livestreamAIConfig = config.get('livestreamAI');
        this._livestreamAITopic = this._livestreamAIConfig?.topic;
        this._kvKafkaService.init(
            'livestream-ai-result',
            config.get('kafka')?.kafkaGroupId || 'fbpos-worker-livestream-v2-consumer',
            config.get('kafka')?.kafkaTopic || 'fbpos.livestream-ai_result',
            this._savingResultAI,
        );
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigLivestreamAIIntegration.ROUTING_KEYS,
        queue: `fbpos-worker-livestream:${RabbitMqConfigLivestreamAIIntegration.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _handlerLivestreamIntegration(payload: IFeed | ITiktokLiveComment) {
        const prefixLog = this.prefixLog('_handlerLivestreamIntegration');

        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': payload['PageId'] || payload['livestreamScriptId'],
                'Kv.SocialType': payload['livestreamScriptId'] ? SocialTypes.TIKTOK : SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        if (payload['PageId']) {
            await this._handlerFacebookLivestreamIntegration(payload as IFeed, prefixLog, logInput);
        } else if (payload['livestreamScriptId']) {
            await this._handlerTiktokLivestreamIntegration(payload as ITiktokLiveComment, prefixLog, logInput);
        }
        this._logger.info(logInput, `${prefixLog} success`);
        return Promise.resolve();
    }

    private async _handlerFacebookLivestreamIntegration(payload: IFeed, prefixLog: string, logInput: IKvLogInput) {
        const { SenderId, SenderName, PageId, videoId, Message, _id } = payload;
        if (!this._livestreamAIConfig.enable && !this._livestreamAIConfig.pageIds.includes(PageId)) {
            return Promise.resolve()
        }

        if (PageId === SenderId) {
            return Promise.resolve()
        }

        if (!Message) {
            return Promise.resolve()
        }
        try {
            const livestreamScript = await this._fbLivestreamScriptService.getFbLivestreamScript('', { videoId });
            if (!livestreamScript ||
                (LivestreamSyntaxCreateOrderType.DETAIL_KEYWORD === livestreamScript.DETAIL_KEYWORD && !livestreamScript.LiveStreamFormula?.Fields?.length) ||
                (LivestreamSyntaxCreateOrderType.GENERAL_KEYWORD === livestreamScript.DETAIL_KEYWORD && !livestreamScript.generalKeyWords?.length)) {
                return Promise.resolve();
            }
            const syntax = LivestreamSyntaxCreateOrderType.DETAIL_KEYWORD === livestreamScript.DETAIL_KEYWORD ?
                livestreamScript.LiveStreamFormula?.Fields?.map(item => item.Name).join(' ') : 'ProductCode';
            const products = livestreamScript.products?.length ? livestreamScript.products.map(item => {
                return {
                    Key: item.ProductKey || [],
                    Code: item.KvProductCode || '',
                    Name: item.KvProductName || '',
                    AttributeLabel: item.KvAttributeLabel || ''
                }
            }) : [];
            const jsonContent: IPayloadLivestreamAI = {
                Comment: Message,
                CommentId: _id,
                SenderName,
                Type: SocialTypes.FACEBOOK,
                Syntax: syntax,
                Products: products,
                SocialId: PageId,
                VideoId: videoId
            };
            const key = `${SocialTypes.FACEBOOK}_${PageId}_${videoId}`;
            await this._kvKafkaService.send(this._livestreamAITopic, {
                topicName: this._livestreamAITopic,
                key,
                jsonContent
            }, key);
        } catch (err) {
            this._logger.error({ ...logInput, Error: new KvBaseException(err.stack) }, `${prefixLog} fail`);
        }
    }

    private async _handlerTiktokLivestreamIntegration(payload: ITiktokLiveComment, prefixLog: string, logInput: IKvLogInput) {
        const { liveUserId, liveUniqueId, livestreamScriptId, userId, nickname, id, comment } = payload;
        // Bật tắt config
        if (!this._livestreamAIConfig.enable && !this._livestreamAIConfig.pageIds.includes(liveUserId)) {
            return Promise.resolve()
        }

        if (liveUserId === userId) {
            return Promise.resolve()
        }
        try {
            const tiktokLivestreamScript = await this._tiktokLivestreamScriptService.findById(livestreamScriptId);
            if (!tiktokLivestreamScript) {
                return Promise.resolve();
            }
            const syntax = 'ProductCode';
            const jsonContent: IPayloadLivestreamAI = {
                Comment: comment,
                CommentId: id,
                SenderName: nickname,
                Type: SocialTypes.TIKTOK,
                Syntax: syntax,
                Products: [],
                SocialId: liveUserId,
                SocialName: liveUniqueId,
                VideoId: livestreamScriptId
            };
            const key = `${SocialTypes.TIKTOK}_${liveUserId}_${livestreamScriptId}`;
            await this._kvKafkaService.send(this._livestreamAITopic, {
                topicName: this._livestreamAITopic,
                key,
                jsonContent
            }, key);
        } catch (err) {
            this._logger.error({ ...logInput, Error: new KvBaseException(err.stack) }, `${prefixLog} fail`);
        }
    }

    private readonly _savingResultAI = async (payload: EachMessagePayload) => {
        const prefixLog = this.prefixLog('_savingResultAI');

        const { topic, message } = payload;
        let logInput: IKvLogInput = {};
        try {
            let value: IKafkaPayloadLivestream = !topic ? message.value : JSON.parse(message.value.toString());
            value = value as IKafkaPayloadLivestream;

            const { SocialId, CommentId, Type } = value.jsonContent;

            logInput = {
                MessageTemplate: { value },
                Properties: {
                    'Kv.SocialId': SocialId,
                    'Kv.SocialType': Type,
                    SourceContext: prefixLog,
                    _startTime: Date.now()
                }
            }
            this._logger.info(logInput, `${prefixLog} received payload`);

            const { IntentAI } = value;

            if (SocialId && IntentAI && SocialTypes.FACEBOOK === Type) {
                await sleep(1500); // Dùng để đợi job validate chạy xong trước
                const db = await this._mongodbGroupService.getDatabase({
                    socialId: SocialId,
                });
                const exist = await db.collection(SocialId).findOne({ _id: CommentId });
                const isNotSavingIntentAI = exist?.IsValidateFormula || exist?.IsAlmostValidateFormula;
                const code = IntentAI?.intent?.code || -1;
                const promises = [db.collection(SocialId).updateOne({ _id: CommentId }, {
                    $set: {
                        IntentAI,
                        ...!isNotSavingIntentAI && code && { IntentCodeAIType: code }
                    }
                })];
                if (!isNotSavingIntentAI) {
                    promises.push(this._sentEventMQToNotification(value.jsonContent, code));
                    promises.push(this._processSendMQToCalculateReport(value?.jsonContent?.VideoId));
                    // promises.push(this._updateFbLivestreamScript(value.jsonContent, code));

                }
                await Promise.all(promises);
            } else if (SocialId && IntentAI && SocialTypes.TIKTOK === Type) {
                const db = await this._mongodbGroupService.getDatabase({ type: 'tiktok' });
                const code = IntentAI?.intent?.code || -1;
                const promises = [db.collection(this._mongodbGroupService.tiktokConversationDetailsCollName).updateOne({ _id: CommentId }, {
                    $set: {
                        IntentAI,
                        IntentCodeAIType: code
                    }
                })];
                promises.push(this._sentEventMQToTiktokNotification(value.jsonContent, code));
                promises.push(this._processSendMQToCalculateReportTiktok(value?.jsonContent?.VideoId));

                await Promise.all(promises);
            }

            this._logger.info(logInput, `${prefixLog} success`);

        } catch (err) {
            this._logger.error({ ...logInput, Error: new KvBaseException(err.stack) }, `${prefixLog} fail`);
        }
    };

    private async _sentEventMQToNotification(payload: IPayloadLivestreamAI, IntentCodeAIType: IntentCodeAITypes | -1) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigNotification.ROUTING_KEY, {
            ...payload,
            PageId: payload.SocialId,
            IntentCodeAIType,
            SocialType: SocialTypes.FACEBOOK,
            EventType: EventTypes.UpdateCommentAITag
        }).catch(err => {
            const prefixLog = this.prefixLog('_sentEventMQToNotification');
            const logInput: IKvLogInput = {
                MessageTemplate: { payload, IntentCodeAIType },
                Properties: {
                    'Kv.SocialId': payload?.SocialId,
                    'Kv.SocialType': SocialTypes.FACEBOOK,
                    SourceContext: prefixLog,
                    _startTime: Date.now()
                }
            }
            this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }

    private async _sentEventMQToTiktokNotification(payload: IPayloadLivestreamAI, IntentCodeAIType: IntentCodeAITypes | -1) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigTiktokNotification.ROUTING_KEY, {
            ...payload,
            liveUserId: payload.SocialId,
            event: TiktokEventTypes.UPDATE_COMMENT_AI_TAG,
            IntentCodeAIType,
            SocialType: SocialTypes.TIKTOK,
        }).catch(err => {
            const prefixLog = this.prefixLog('_sentEventMQToNotification');
            const logInput: IKvLogInput = {
                MessageTemplate: { payload, IntentCodeAIType },
                Properties: {
                    'Kv.SocialId': payload?.SocialId,
                    'Kv.SocialType': SocialTypes.TIKTOK,
                    SourceContext: prefixLog,
                    _startTime: Date.now()
                }
            }
            this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }

    /**
     * Khi nhận đủ 10 comment thì tính report
     * Nếu dưới 10 comment thì 5s sau tính report
     * @param videoId
     * @private
     */
    private async _processSendMQToCalculateReport(videoId: string) {
        let livestreamDictionary = await this._cache.get(CACHE_KEYS.LIVESTREAM_DICTIONARY.NAME) as any;
        if (!livestreamDictionary) {
            livestreamDictionary = {};
        }
        livestreamDictionary[videoId] = (livestreamDictionary[videoId] || 0) + 1;
        const total = livestreamDictionary[videoId];
        if (total >= MAX_EVENTS_FOR_REPORT) {
            this._sentEventToCalculateReportMQ(videoId);
            delete livestreamDictionary[videoId];
            await this._cache.set(CACHE_KEYS.LIVESTREAM_DICTIONARY.NAME, livestreamDictionary, { ttl: CACHE_KEYS.LIVESTREAM_DICTIONARY.TTL } as any);
        } else {
            setTimeout(async () => {
                if (total > 0) {
                    this._sentEventToCalculateReportMQ(videoId);
                    delete livestreamDictionary[videoId];
                    await this._cache.set(CACHE_KEYS.LIVESTREAM_DICTIONARY.NAME, livestreamDictionary, { ttl: CACHE_KEYS.LIVESTREAM_DICTIONARY.TTL } as any);
                }
            }, MIN_TIME_BETWEEN_REPORTS);
        }
    }

    private _sentEventToCalculateReportMQ(VideoId: string) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigReportLivestreamDashboard.ROUTING_KEY, {
            VideoId,
        }).catch(err => {
            const prefixLog = this.prefixLog('_sentEventToCalculateReportMQ');
            const logInput: IKvLogInput = {
                MessageTemplate: { VideoId },
                Properties: {
                    SourceContext: prefixLog,
                    _startTime: Date.now()
                }
            }
            this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }

    /**
     * Khi nhận đủ 10 comment thì tính report
     * Nếu dưới 10 comment thì 5s sau tính report
     * @param livestreamScriptId
     * @private
     */
    private async _processSendMQToCalculateReportTiktok(livestreamScriptId: string) {
        let livestreamDictionary = await this._cache.get(CACHE_KEYS.LIVESTREAM_DICTIONARY.NAME) as any;
        if (!livestreamDictionary) {
            livestreamDictionary = {};
        }
        livestreamDictionary[livestreamScriptId] = (livestreamDictionary[livestreamScriptId] || 0) + 1;
        const total = livestreamDictionary[livestreamScriptId];
        if (total >= MAX_EVENTS_FOR_REPORT) {
            this._sentEventToCalculateReportTiktokMQ(livestreamScriptId);
            delete livestreamDictionary[livestreamScriptId];
            await this._cache.set(CACHE_KEYS.LIVESTREAM_DICTIONARY.NAME, livestreamDictionary, { ttl: CACHE_KEYS.LIVESTREAM_DICTIONARY.TTL } as any);
        } else {
            setTimeout(async () => {
                if (total > 0) {
                    this._sentEventToCalculateReportTiktokMQ(livestreamScriptId);
                    delete livestreamDictionary[livestreamScriptId];
                    await this._cache.set(CACHE_KEYS.LIVESTREAM_DICTIONARY.NAME, livestreamDictionary, { ttl: CACHE_KEYS.LIVESTREAM_DICTIONARY.TTL } as any);
                }
            }, MIN_TIME_BETWEEN_REPORTS);
        }
    }

    private _sentEventToCalculateReportTiktokMQ(livestreamScriptId: string) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigTiktokReportLivestreamDashboard.ROUTING_KEY, {
            livestreamScriptId,
        }).catch(err => {
            const prefixLog = this.prefixLog('_sentEventToCalculateReportTiktokMQ');
            const logInput: IKvLogInput = {
                MessageTemplate: { livestreamScriptId },
                Properties: {
                    SourceContext: prefixLog,
                    _startTime: Date.now()
                }
            }
            this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }

    private async _updateFbLivestreamScript(payload: IPayloadLivestreamAI, IntentCodeAIType: IntentCodeAITypes | -1) {
        const { VideoId } = payload;
        const livestreamScript = await this._fbLivestreamScriptService.getFbLivestreamScript('', { videoId: VideoId });
        if (!livestreamScript || !livestreamScript.pageId || !livestreamScript.retailerId) {
            return;
        }
        const { retailerId, retailerCode } = livestreamScript;
        await this._fbLivestreamScriptService.updateFbLivestreamScript(
            retailerId,
            retailerCode,
            {
                videoId: VideoId,
                ...IntentCodeAITypes.Care === IntentCodeAIType && { totalCareComments: (livestreamScript.totalCareComments || 0) + 1 },
                ...IntentCodeAITypes.Negative === IntentCodeAIType && { $inc: (livestreamScript.totalNegativeComments || 0) + 1 },
                ...IntentCodeAITypes.Positive === IntentCodeAIType && { $inc: (livestreamScript.totalPositiveComments || 0) + 1 },
            }
        );
    }
}
