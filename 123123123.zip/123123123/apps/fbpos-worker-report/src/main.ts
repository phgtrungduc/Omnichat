/**
 * This is not a production server yet!
 * This is only a minimal backend to get started.
 */
require('./tracer');
import { Logger } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { AlertNotificationService } from '@kiotviet-facebook-services/alert-notification';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const alertService = app.get<AlertNotificationService>(AlertNotificationService);
  const globalPrefix = 'api';
  app.setGlobalPrefix(globalPrefix);
  const port = process.env.PORT || 3000;
  await app.listen(port);
  Logger.log(`🚀 Application is running on: http://localhost:${port}/${globalPrefix}`);
  alertService.send(`🚀*[fbpos-worker-report-v2]* [Notification] Service was restarted`);
}

bootstrap();
