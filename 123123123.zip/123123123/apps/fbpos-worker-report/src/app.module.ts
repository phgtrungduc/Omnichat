import { Module } from '@nestjs/common';
import { CoreModule } from './core/core.module';
import { ReportInitModule } from './modules/report-init/report-init.module';
import { ReportMessageModule } from './modules/report-message/report-message.module';
import { ReportLivestreamProductModule } from './modules/report-livestream-product/report-livestream-product.module';
import {
    ReportLivestreamDashboardModule
} from './modules/report-livestream-dashboard/report-livestream-dashboard.module';
import { AlertNotificationModule } from '@kiotviet-facebook-services/alert-notification';
import {
    TiktokReportLivestreamDashboardModule
} from "./modules/tiktok-report-livestream-dashboard/tiktok-report-livestream-dashboard.module";
import { TiktokReportCommentModule } from "./modules/tiktok-report-comment/tiktok-report-comment.module";

@Module({
    imports: [
        CoreModule,
        ReportInitModule,
        ReportMessageModule,
        ReportLivestreamProductModule,
        ReportLivestreamDashboardModule,
        TiktokReportLivestreamDashboardModule,
        // TiktokReportCommentModule,
        AlertNotificationModule
    ],
    controllers: [],
    providers: [],
})
export class AppModule {
}
