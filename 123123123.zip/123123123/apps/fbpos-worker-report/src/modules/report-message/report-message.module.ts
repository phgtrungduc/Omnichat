import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { ReportMessageService } from './report-message.service';
import { LockModule } from '@kiotviet-facebook-services/lock';

@Module({
  imports: [CommonModule, KvRabbitMQModule, LockModule],
  providers: [ReportMessageService],
})
export class ReportMessageModule {
}
