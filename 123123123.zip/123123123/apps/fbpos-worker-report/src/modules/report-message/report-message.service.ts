import { RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    ERROR_MESSAGE_REDLOCK,
    KvLogger,
    KvResponseMongoDbException,
    RabbitMqConfigReportMessage,
    removeMinute,
    SocialTypes,
} from '@kiotviet-facebook-services/common';
import {
    FbUserProfileService,
    MongodbGroupService,
    PageSubscriptionService,
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { RedisLockService, REDLOCK_CONST } from '@kiotviet-facebook-services/lock';
import { Injectable } from '@nestjs/common';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class ReportMessageService {
    constructor(
        private readonly _logger: KvLogger,
        private readonly _redlockService: RedisLockService,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _pageSubscriptionService: PageSubscriptionService,
        private readonly _fbUserProfileService: FbUserProfileService
    ) {
    }

    prefixLog = (functionName: string) =>
        this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigReportMessage.ROUTING_KEY,
        queue: `fbpos-worker-report:${RabbitMqConfigReportMessage.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _handleReportMessage(payload: any) {
        const prefixLog = this.prefixLog('_handleReportMessage');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': payload?.PageId,
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }

        this._logger.info(logInput, `${prefixLog} received payload`);

        const { PageId: pageId, SenderId: senderId } = payload;

        if (pageId === senderId) {
            return;
        }

        try {
            const pageSetting = await this._pageSubscriptionService.getPageSetting(
                pageId
            );
            if (!pageSetting || !pageSetting.InitMessageReport) {
                return;
            }

            const timestampByHour = removeMinute(
                new Date(payload.TimeStamp)
            ).getTime();
            const fromInbox = payload.Type === 'messenger';
            const fromComment = payload.Type === 'feed';
            const isCreated = payload.Action === 'create';

            const dataByHour: any = {};

            dataByHour.TotalMessages = 1;
            dataByHour.TotalConversations = isCreated ? 1 : 0;
            dataByHour.TotalMessagesFromComment = fromComment ? 1 : 0;
            dataByHour.TotalMessagesFromInbox = fromInbox ? 1 : 0;
            dataByHour.TotalConversationsFromComment =
                isCreated && fromComment ? 1 : 0;
            dataByHour.TotalConversationsFromInbox = isCreated && fromInbox ? 1 : 0;
            dataByHour.TotalCustomers = 0;

            const db = await this._mongodbGroupService.getDatabase({
                socialId: pageId,
            });

            let lock;
            try {
                const senderId = payload.SenderId;
                lock = await this._redlockService.acquire(
                    [`${REDLOCK_CONST.LOCK_KEYS.REPORT_MESSAGE_BY_USER.NAME}${senderId}`],
                    REDLOCK_CONST.LOCK_KEYS.REPORT_MESSAGE_BY_USER.TTL,
                    {},
                );
                const user = await this._fbUserProfileService.handleReadFbUserProfile(
                    senderId
                );

                if (!user || !user.markForReport) {
                    await this._fbUserProfileService.handleUpdateFbUserProfile(
                        { id: senderId, socialId: pageId, markForReport: true },
                        true
                    );
                    dataByHour.TotalCustomers = 1;
                }

                await db.collection(pageId + '_conversation').updateOne(
                    { _id: 'r' + timestampByHour },
                    {
                        $set: {
                            _id: 'r' + timestampByHour,
                            Type: 'statistics',
                            TimeStamp: timestampByHour,
                        },
                        $inc: dataByHour,
                    },
                    { upsert: true }
                );
            } catch (error) {
                if (error.message.includes(ERROR_MESSAGE_REDLOCK)) {
                    return Promise.reject();
                }

                throw error;
            } finally {
                if (lock) {
                    await this._redlockService.release(lock);

                }
            }
            this._logger.info(logInput, `${prefixLog} success`);
        } catch (error) {
            this._logger.error({ ...logInput, Error: new KvResponseMongoDbException(error.stack) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }
}
