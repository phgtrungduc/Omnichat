import { TiktokEventTypes } from "@kiotviet-facebook-services/common";

export interface ITiktokReportDashboardPayload {
  event: TiktokEventTypes;
  livestreamScriptId: string; // _id
}
