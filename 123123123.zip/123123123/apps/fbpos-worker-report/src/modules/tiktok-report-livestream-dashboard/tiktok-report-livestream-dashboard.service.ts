import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    KvBaseException,
    KvLogger,
    KvRabbitMQException,
    RabbitMqConfigTiktokNotification,
    RabbitMqConfigTiktokReportLivestreamDashboard,
    SocialTypes,
    TiktokEventTypes,
} from '@kiotviet-facebook-services/common';
import {
    MongodbGroupService,
    TiktokCartsService,
    TiktokLivestreamScriptDocument,
    TiktokLivestreamScriptService,
    TiktokUserProfileService,
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { Injectable } from '@nestjs/common';
import { ITiktokReportDashboardPayload } from "./interface/tiktok-report-dashboard-payload.interface";
import { Types } from "mongoose";
import { pick } from 'lodash';
import { IntentCodeAITypes } from "../../../../../libs/shared/kv-livestream-ai/src/lib/common";
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class TiktokReportLivestreamDashboardService {
    private _rabbitMQConfig: any;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _tiktokLivestreamScriptService: TiktokLivestreamScriptService,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _tiktokCartService: TiktokCartsService,
        private readonly _tiktokUserProfileService: TiktokUserProfileService
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigTiktokReportLivestreamDashboard.ROUTING_KEY,
        queue: `fbpos-worker-report:${RabbitMqConfigTiktokReportLivestreamDashboard.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _handleTiktokReportLivestreamDashboard(payload: ITiktokReportDashboardPayload) {
        const prefixLog = this.prefixLog('_handleTiktokReportLivestreamDashboard');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': payload?.livestreamScriptId,
                'Kv.SocialType': SocialTypes.TIKTOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        const { livestreamScriptId } = payload;

        if (!livestreamScriptId) {
            return Promise.resolve(true);
        }

        try {
            const tiktokLivestreamScript = await this._tiktokLivestreamScriptService.findById(livestreamScriptId);
            if (!tiktokLivestreamScript) {
                return Promise.resolve(true);
            }
            const { userId, retailerCode, retailerId } = tiktokLivestreamScript;
            const db = await this._mongodbGroupService.getDatabase({ type: 'tiktok' })

            // const [{
            //     totalOrders,
            //     revenue
            // }, totalComments, totalValidComments, totalCustomers, totalCustomerValidateFormulas, totalCustomerCreatedOrders] =
            //     await Promise.all([
            //         this._getTotalOrdersAndRevenue(livestreamScriptId),
            //         this._getTotalComments(userId, livestreamScriptId, db),
            //         this._getTotalValidComments(userId, livestreamScriptId, db),
            //         this._getTotalCustomers(livestreamScriptId),
            //         this._getTotalCustomers(livestreamScriptId, UserLivestreamType.VALIDATE_FORMULA),
            //         this._getTotalCustomerOrders(livestreamScriptId),
            //     ]);
            const [totalComments,
                totalValidComments,
                totalCommentPrinted,
                totalCustomerCommentPrinted,
                totalCustomers,
                {
                    totalCareComments,
                    totalNegativeComments,
                    totalPositiveComments
                }] =
                await Promise.all([
                    this._getTotalComments(userId, livestreamScriptId, db),
                    this._getTotalValidComments(userId, livestreamScriptId, db),
                    this._getTotalCommentsHasPrinted(userId, livestreamScriptId, db),
                    this._getTotalCustomerCommentsHasPrinted(livestreamScriptId),
                    this._getTotalCustomers(livestreamScriptId),
                    this._getTotalCommentHasAITag(userId, livestreamScriptId, db)
                ]);
            await this._tiktokLivestreamScriptService.updateTiktokLivestreamScript(
                retailerId,
                retailerCode,
                {
                    _id: new Types.ObjectId(livestreamScriptId),
                    totalComments, totalValidComments, totalCommentPrinted, totalCustomerCommentPrinted, totalCustomers,
                    totalCareComments, totalNegativeComments, totalPositiveComments
                }
            )
            this._sendUpdateAnalyticTiktokLivestreamScript(tiktokLivestreamScript, {
                totalComments, totalValidComments, totalCommentPrinted, totalCustomerCommentPrinted, totalCustomers,
                totalCareComments, totalNegativeComments, totalPositiveComments
            });
            this._logger.info(logInput, `${prefixLog} success`);

        } catch (err) {
            this._logger.error({ ...logInput, Error: new KvBaseException(err.stack) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }

    private async _getTotalComments(liveUserId: string, livestreamScriptId: string, db: any) {
        return await db.collection(this._mongodbGroupService.tiktokConversationDetailsCollName).count({
            liveUserId,
            livestreamScriptId
        });
    }

    private async _getTotalValidComments(liveUserId: string, livestreamScriptId: string, db: any) {
        return await db.collection(this._mongodbGroupService.tiktokConversationDetailsCollName).count({
            liveUserId,
            livestreamScriptId,
            IsValidateFormula: true
        });
    }

    private async _getTotalCommentsHasPrinted(liveUserId: string, livestreamScriptId: string, db: any) {
        return await db.collection(this._mongodbGroupService.tiktokConversationDetailsCollName).count({
            liveUserId,
            livestreamScriptId,
            HasPrinted: true
        });
    }


    private async _getTotalCustomerCommentsHasPrinted(livestreamScriptId: string) {
        return await this._tiktokUserProfileService.getCountCustomersHasPrintedByLivestreamId(livestreamScriptId)
    }

    private async _getTotalCustomerOrders(livestreamScriptId: string | number) {
        return await this._tiktokCartService.countTotalCarts(livestreamScriptId);
    }

    private async _getTotalOrdersAndRevenue(livestreamScriptId: string | number) {
        return await this._tiktokCartService.getTotalOrdersAndRevenue(livestreamScriptId);
    }

    private async _getTotalCustomers(livestreamScriptId: string | number, type = null) {
        return await this._tiktokUserProfileService.getCountCustomersByLivestreamId(livestreamScriptId, type);
    }

    private async _getTotalCommentHasAITag(
        liveUserId: string,
        livestreamScriptId: string | number,
        db: any
    ) {
        const result = await db.collection(this._mongodbGroupService.tiktokConversationDetailsCollName).find({
            liveUserId,
            livestreamScriptId,
            IntentCodeAIType: { $exists: true },
        }, {
            projection: { IntentCodeAIType: 1, selectedKey: 1 }  // Include IntentCodeAIType and selectedKey fields
        }).toArray();

        return {
            totalCareComments: result?.filter(item => IntentCodeAITypes.Care === item.IntentCodeAIType)?.length,
            totalNegativeComments: result?.filter(item => IntentCodeAITypes.Negative === item.IntentCodeAIType)?.length,
            totalPositiveComments: result?.filter(item => IntentCodeAITypes.Positive === item.IntentCodeAIType)?.length
        };
    }

    private _sendUpdateAnalyticTiktokLivestreamScript(tiktokLivestreamScript: TiktokLivestreamScriptDocument, {
        totalComments,
        totalValidComments,
        totalCommentPrinted,
        totalCustomerCommentPrinted,
        totalCustomers,
        totalCareComments,
        totalNegativeComments,
        totalPositiveComments
    }) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange,
            `${RabbitMqConfigTiktokNotification.ROUTING_KEY}`,
            {
                event: TiktokEventTypes.UPDATE_ANALYTIC,
                livestreamScriptId: tiktokLivestreamScript._id,
                liveUserId: tiktokLivestreamScript.userId,
                totalComments,
                totalValidComments,
                totalCommentPrinted,
                totalCustomerCommentPrinted,
                totalCustomers,
                totalCareComments,
                totalNegativeComments,
                totalPositiveComments
            }
        ).catch(err => {
            const prefixLog = this.prefixLog('_sendUpdateAnalyticTiktokLivestreamScript');
            this._logger.error({ MessageTemplate: { tiktokLivestreamScript }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);

        });
    }

}
