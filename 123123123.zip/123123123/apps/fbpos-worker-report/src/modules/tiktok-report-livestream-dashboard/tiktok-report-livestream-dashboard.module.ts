import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { TiktokReportLivestreamDashboardService } from './tiktok-report-livestream-dashboard.service';

@Module({
  imports: [CommonModule, KvRabbitMQModule],
  providers: [TiktokReportLivestreamDashboardService],
})
export class TiktokReportLivestreamDashboardModule {}
