import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { TiktokReportCommentService } from './tiktok-report-comment.service';

@Module({
  imports: [CommonModule, KvRabbitMQModule],
  providers: [TiktokReportCommentService],
})
export class TiktokReportCommentModule {
}
