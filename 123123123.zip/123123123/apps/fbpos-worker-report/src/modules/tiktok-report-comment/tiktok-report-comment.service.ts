import { RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    ITiktokLiveComment,
    KvBaseException,
    KvLogger,
    RabbitMqConfigTiktokReportComment,
    SocialTypes,
} from '@kiotviet-facebook-services/common';
import {
    MongodbGroupService,
    TiktokLivestreamScriptService,
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { Injectable } from '@nestjs/common';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
import { Types } from "mongoose";

const config = require('config');

@Injectable()
export class TiktokReportCommentService {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _tiktokLivestreamScriptService: TiktokLivestreamScriptService,
    ) {
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigTiktokReportComment.ROUTING_KEY,
        queue: `fbpos-worker-report:${RabbitMqConfigTiktokReportComment.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _handleReportTiktokComment(payload: ITiktokLiveComment) {
        const prefixLog = this.prefixLog('_handleReportTiktokComment');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': payload?.liveUniqueId,
                'Kv.SocialType': SocialTypes.TIKTOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }

        this._logger.info(logInput, `${prefixLog} received payload`);

        const { livestreamScriptId, id: commentId, userId } = payload;
        if (!livestreamScriptId) {
            return Promise.resolve(true);
        }

        try {
            const tiktokLivestreamScript = await this._tiktokLivestreamScriptService.findById(livestreamScriptId);
            if (!tiktokLivestreamScript) {
                return Promise.resolve(true);
            }
            const { userId: liveUserId, retailerCode, retailerId } = tiktokLivestreamScript;
            const db = await this._mongodbGroupService.getDatabase({ type: 'tiktok' })
            const checkExist = await db.collection(this._mongodbGroupService.tiktokConversationDetailsCollName).findOne({
                id: commentId,
                liveUserId
            });
            if (!checkExist || !checkExist.markForReport) {
                await Promise.all([
                    db.collection(this._mongodbGroupService.tiktokConversationDetailsCollName).updateOne({
                        id: commentId,
                        liveUserId
                    }, { $set: { markForReport: true } }),
                    this._tiktokLivestreamScriptService.updateTiktokLivestreamScript(
                        retailerId,
                        retailerCode,
                        {
                            _id: new Types.ObjectId(livestreamScriptId), $inc: {
                                totalComments: 1,
                            }
                        }
                    )
                ]);
            }
            this._logger.info(logInput, `${prefixLog} success`);
        } catch (err) {
            this._logger.error({ ...logInput, Error: new KvBaseException(err.stack) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }

}
