import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    ERROR_MESSAGE_REDLOCK,
    EventTypes,
    KvBaseException,
    KvLogger,
    KvRabbitMQException,
    RabbitMqConfigNotification,
    RabbitMqConfigReportLivestreamProduct,
    SocialTypes,
} from '@kiotviet-facebook-services/common';
import { FbLivestreamScriptService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { RedisLockService, REDLOCK_CONST } from '@kiotviet-facebook-services/lock';
import { Injectable } from '@nestjs/common';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class ReportLivestreamProductService {
    private _rabbitMQConfig: any;

    constructor(
        private readonly _logger: KvLogger,
        private readonly fbLivestreamScriptService: FbLivestreamScriptService,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _redislockService: RedisLockService
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) =>
        this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigReportLivestreamProduct.ROUTING_KEY,
        queue: `fbpos-worker-report:${RabbitMqConfigReportLivestreamProduct.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _handleReportLivestreamProduct(payload: any) {
        const prefixLog = this.prefixLog('_handleReportLivestreamProduct');

        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        const { videoId, pageId } = payload;
        let changeProducts = payload.changeProducts;
        changeProducts = (changeProducts || []).filter(
            (product) => product.productId
        );

        if (!videoId || !pageId || !changeProducts || !changeProducts.length) {
            return Promise.resolve();
        }

        try {
            const lock = await this._redislockService.acquire(
                [`${REDLOCK_CONST.LOCK_KEYS.LIVESTREAM_PRODUCT.NAME}${videoId}`],
                REDLOCK_CONST.LOCK_KEYS.LIVESTREAM_PRODUCT.TTL,
                {}
            );

            const fbLivestreamScript = await this.fbLivestreamScriptService.getFbLivestreamScript(undefined, { videoId });
            if (!fbLivestreamScript?.products?.length) {
                await this._redislockService.release(lock);
                return Promise.resolve();
            }
            const { products } = fbLivestreamScript;
            const eventSockets = [];
            changeProducts.forEach((itemChange) => {
                const { productId, quantity } = itemChange;
                const found = products.find(
                    (product) => product.KvProductId === productId
                );
                if (found) {
                    found.OrderQuantity = (found.OrderQuantity || 0) + quantity;
                    eventSockets.push({
                        PageId: pageId,
                        ProductId: productId,
                        VideoId: videoId,
                        Quantity: found.OrderQuantity,
                        EventType: EventTypes.LivestreamUpdateOrderQuantity,
                    });
                }
            });
            if (eventSockets.length) {
                await this.fbLivestreamScriptService.updateFbLivestreamScript(
                    fbLivestreamScript.retailerId,
                    fbLivestreamScript.retailerCode,
                    fbLivestreamScript
                );
                eventSockets.forEach((eventSocket) => {
                    this._amqpConnection
                        .publish(
                            this._rabbitMQConfig.mainExchange,
                            RabbitMqConfigNotification.ROUTING_KEY,
                            eventSocket
                        )
                        .catch((err) => {
                            this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
                        });
                });
            }

            await this._redislockService.release(lock);
            this._logger.info(logInput, `${prefixLog} success`);
        } catch (err) {
            if (err.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._logger.error({ ...logInput, Error: new KvBaseException(err.stack) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }
}
