import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { ReportLivestreamProductService } from './report-livestream-product.service';
import { LockModule } from '@kiotviet-facebook-services/lock';

@Module({
  imports: [CommonModule, KvRabbitMQModule, LockModule],
  providers: [ReportLivestreamProductService],
})
export class ReportLivestreamProductModule {}
