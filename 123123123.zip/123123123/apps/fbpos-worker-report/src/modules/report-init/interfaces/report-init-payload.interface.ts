export class IReportInitPayload {
  PageId: string;
  Month?: number;
  Limit?: number;
  To?: number;
  From?: number;
}
