import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { ReportInitService } from './report-init.service';

@Module({
  imports: [CommonModule, KvRabbitMQModule],
  providers: [ReportInitService],
})
export class ReportInitModule {
}
