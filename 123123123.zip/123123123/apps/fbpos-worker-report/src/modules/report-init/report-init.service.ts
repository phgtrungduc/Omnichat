import { RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
  KvLogger,
  KvResponseMongoDbException,
  RabbitMqConfigReportInit,
  removeMinute,
  SocialTypes,
} from '@kiotviet-facebook-services/common';
import {
  ConversationService,
  MongodbGroupService,
  PageSubscriptionService,
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { Injectable } from '@nestjs/common';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
import { IReportInitPayload } from './interfaces/report-init-payload.interface';
const config = require('config');

@Injectable()
export class ReportInitService {
  private readonly ONE_DAY_TIME = 24 * 60 * 60 * 1000;

  constructor(
    private readonly _logger: KvLogger,
    private readonly _mongodbGroupService: MongodbGroupService,
    private readonly conversationService: ConversationService,
    private readonly pageSubscriptionService: PageSubscriptionService
  ) { }

  prefixLog = (functionName: string) =>
    this._logger.getPrefixLog(this.constructor.name, functionName);

  @RabbitSubscribe({
    exchange: config.get('rabbitMQ').mainExchange,
    routingKey: RabbitMqConfigReportInit.ROUTING_KEY,
    queue: `fbpos-worker-report:${RabbitMqConfigReportInit.QUEUE_NAME}`,
    queueOptions: {
      durable: true,
      arguments: { 'x-queue-type': 'quorum' },
    },
  })
  private async _handleReportInit(payload: IReportInitPayload) {
    const prefixLog = this.prefixLog('_handleReportInit');

    const logInput: IKvLogInput = {
      MessageTemplate: { payload },
      Properties: {
        'Kv.SocialId': payload?.PageId,
        'Kv.SocialType': SocialTypes.FACEBOOK,
        SourceContext: prefixLog,
        _startTime: Date.now()
      }
    }
    this._logger.info(logInput, `${prefixLog} received payload`);

    const pageId = payload.PageId;
    const month = payload.Month || 3;
    const limit = payload.Limit || 5000;
    let to = payload.To;
    let from = payload.From;

    try {
      if (!from && !to) {
        // get list messages order by descending
        // filter with 3 months recently
        const lowerBoundDuration = month * 30 * this.ONE_DAY_TIME;
        to = +new Date();
        from = new Date(to - lowerBoundDuration).getTime();
      }

      // array count conversations created and messages by hour
      const statistics = [];

      // map store conversation-id
      const conversationIdMap = {};
      const customerIdMap = {};

      let hasMoreMessage = true;
      while (hasMoreMessage) {
        const filters = [
          {
            TimeStamp: { $gte: from, $lte: to },
          },
        ];
        const messages = await this.conversationService.getMessages({
          socialId: pageId,
          moreFilters: filters,
          limit,
        });

        if (messages && messages.length < limit) {
          hasMoreMessage = false;
        } else {
          from = messages[messages.length - 1].TimeStamp;
        }

        this._calculateStatistics(
          pageId,
          messages,
          statistics,
          conversationIdMap,
          customerIdMap
        );
      }

      const result = await this.onDone(pageId, statistics);
      await this.pageSubscriptionService.updatePageSetting(pageId, {
        InitMessageReport: true,
      });
      this._logger.info(logInput, `${prefixLog} success`);

    } catch (e) {
      this._logger.error({ ...logInput, Error: new KvResponseMongoDbException(e.stack) }, `${prefixLog} fail`);
    }

    return Promise.resolve();
  }

  private _calculateStatistics(
    pageId: string,
    messages: any[],
    statistics: any,
    conversationIdMap: any,
    customerIdMap: any
  ) {
    messages.forEach((message) => {
      // ignore if message sent from page
      if (message.SenderId === pageId) {
        return;
      }

      const fromInbox = message.Field === 'messenger';
      const fromComment = message.Field === 'feed';
      const notExistsConversation = !conversationIdMap[message.GroupId];
      const notExistsCustomer = !customerIdMap[message.SenderId];

      const timestampByHour = removeMinute(
        new Date(message.TimeStamp)
      ).getTime();

      // push message by hour
      const dataByHour = statistics.find(
        (item) => item.TimeStamp === timestampByHour
      );
      if (dataByHour) {
        dataByHour.TotalMessages++;
        dataByHour.TotalConversations =
          dataByHour.TotalConversations + (notExistsConversation ? 1 : 0);
        dataByHour.TotalCustomers =
          dataByHour.TotalCustomers + (notExistsCustomer ? 1 : 0);
        dataByHour.TotalMessagesFromComment =
          dataByHour.TotalMessagesFromComment + (fromComment ? 1 : 0);
        dataByHour.TotalMessagesFromInbox =
          dataByHour.TotalMessagesFromInbox + (fromInbox ? 1 : 0);
        dataByHour.TotalConversationsFromComment =
          dataByHour.TotalConversationsFromComment +
          (notExistsConversation && fromComment ? 1 : 0);
        dataByHour.TotalConversationsFromInbox =
          dataByHour.TotalConversationsFromInbox +
          (notExistsConversation && fromInbox ? 1 : 0);
      } else {
        statistics.push({
          TotalMessages: 1,
          TotalMessagesFromComment: fromComment ? 1 : 0,
          TotalMessagesFromInbox: fromInbox ? 1 : 0,
          TotalConversations: notExistsConversation ? 1 : 0,
          TotalConversationsFromComment:
            notExistsConversation && fromComment ? 1 : 0,
          TotalConversationsFromInbox:
            notExistsConversation && fromInbox ? 1 : 0,
          TotalCustomers: notExistsCustomer ? 1 : 0,
          TimeStamp: timestampByHour,
          _id: 'r' + timestampByHour,
          Type: 'statistics',
        });
      }

      conversationIdMap[message.GroupId] = true;
      customerIdMap[message.SenderId] = true;
    });
  }

  private async onDone(pageId: string, statistics: any) {
    if (!statistics || statistics.length === 0) {
      return {
        TotalMessages: 0,
        TotalConversations: 0,
      };
    }

    // write bulk
    const bulkOps = statistics.map((item) => ({
      updateOne: {
        filter: { _id: item._id },
        update: { $set: item },
        upsert: true,
      },
    }));

    const db = await this._mongodbGroupService.getDatabase({
      socialId: pageId,
    });
    await db.collection(pageId + '_conversation').bulkWrite(bulkOps);

    return {
      TotalMessages: statistics.reduce(
        (prev, current) => prev + current.TotalMessages,
        0
      ),
      TotalConversations: statistics.reduce(
        (prev, current) => prev + current.TotalConversations,
        0
      ),
    };
  }
}
