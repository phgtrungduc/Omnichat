import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    ERROR_MESSAGE_REDLOCK,
    EventTypes,
    KvBaseException,
    KvLogger,
    KvRabbitMQException,
    RabbitMqConfigNotification,
    RabbitMqConfigReportLivestreamDashboard, UserLivestreamType,
} from '@kiotviet-facebook-services/common';
import {
    FbCartsService,
    FbLivestreamScriptService, FbUserProfileV2Service,
    MongodbGroupService,
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { Injectable } from '@nestjs/common';
import { IntentCodeAITypes } from "../../../../../libs/shared/kv-livestream-ai/src/lib/common";
import { RedisLockService, REDLOCK_CONST } from "@kiotviet-facebook-services/lock";
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class ReportLivestreamDashboardService {
    private _rabbitMQConfig: any;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _fbLivestreamScriptService: FbLivestreamScriptService,
        private readonly _fbUserProfileV2Service: FbUserProfileV2Service,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _fbCartsService: FbCartsService,
        private readonly _redlockService: RedisLockService,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) =>
        this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigReportLivestreamDashboard.ROUTING_KEY,
        queue: `fbpos-worker-report:${RabbitMqConfigReportLivestreamDashboard.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _handleReportLivestreamDashboard(payload: any) {
        const prefixLog = this.prefixLog('_handleReportLivestreamDashboard');

        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        const { LivestreamId, VideoId } = payload;

        if (!LivestreamId && !VideoId) {
            return Promise.resolve(true);
        }

        try {
            // TODO vì 1 khách livestream nhiều sẽ block luồng
            // const lock = await this._redlockService.acquire(
            //     [`${REDLOCK_CONST.LOCK_KEYS.REPORT_LIVESTREAM_DASHBOARD.NAME}${VideoId || LivestreamId}`],
            //     REDLOCK_CONST.LOCK_KEYS.REPORT_LIVESTREAM_DASHBOARD.TTL,
            //     {},
            // );
            const filter = VideoId
                ? { videoId: VideoId }
                : { livestreamId: LivestreamId };
            const livestreamScript =
                await this._fbLivestreamScriptService.getFbLivestreamScript('', filter);
            if (
                !livestreamScript ||
                !livestreamScript.pageId ||
                !livestreamScript.retailerId
            ) {
                // logger.warn(`[report-livestream-dashboard-worker.processEvent] livestream script not found or not setup create order`, { ...objLog, Context: { jsonData } });
                return Promise.resolve(true);
            }

            const { retailerId, retailerCode, videoId, pageId } = livestreamScript;
            const db = await this._mongodbGroupService.getDatabase({
                socialId: pageId,
            });
            const [{ totalOrders, revenue },
                totalComments,
                totalValidComments,
                totalAlmostValidComments,
                totalCustomerCreatedOrders,
                totalCustomers,
                totalCustomerValidateFormulas,
                { totalCareComments, totalNegativeComments, totalPositiveComments }
            ] =
                await Promise.all([
                    this._getTotalOrdersAndRevenue(videoId),
                    this._getTotalComments(videoId, pageId, db),
                    this._getTotalValidComments(videoId, pageId, db),
                    this._getTotalAlmostValidComments(videoId, pageId, db),
                    this._getTotalCustomerOrders(videoId),
                    this._getTotalCustomers(videoId),
                    this._getTotalCustomers(videoId, UserLivestreamType.VALIDATE_FORMULA),
                    this._getTotalCommentHasAITag(videoId, pageId, db)
                ]);
            await this._fbLivestreamScriptService.updateFbLivestreamScript(
                retailerId,
                retailerCode,
                {
                    ...filter, totalComments,
                    totalValidComments,
                    totalAlmostValidComments,
                    totalOrders,
                    revenue,
                    totalCustomerCreatedOrders,
                    totalCustomers,
                    totalCustomerValidateFormulas,
                    totalCareComments,
                    totalNegativeComments,
                    totalPositiveComments
                }
            );

            const publishPayload = {
                PageId: pageId,
                VideoId: videoId,
                LivestreamId,
                TotalComments: totalComments,
                TotalOrders: totalOrders,
                TotalValidComments: totalValidComments,
                TotalAlmostValidComments: totalAlmostValidComments,
                Revenue: revenue,
                TotalCustomerCreatedOrders: totalCustomerCreatedOrders,
                TotalCustomers: totalCustomers,
                TotalCustomerValidateFormulas: totalCustomerValidateFormulas,
                TotalCareComments: totalCareComments,
                TotalNegativeComments: totalNegativeComments,
                TotalPositiveComments: totalPositiveComments,
                EventType: EventTypes.LivestreamUpdateDashBoard,
            };
            this._amqpConnection
                .publish(
                    this._rabbitMQConfig.mainExchange,
                    RabbitMqConfigNotification.ROUTING_KEY,
                    publishPayload
                )
                .catch((err) => {
                    this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} RabbitMqConfigNotification fail`);
                });

            this._logger.info(logInput, `${prefixLog} success`);
        } catch (err) {
            if (err.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._logger.error({ ...logInput, Error: new KvBaseException(err.stack) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }

    private async _getTotalComments(
        videoId: string | number,
        pageId: string,
        db: any
    ) {
        return await db.collection(pageId).count({
            videoId,
            State: {
                $in: [0, 1],
            },
        });
    }
    private async _getTotalCommentHasAITag(
        videoId: string | number,
        pageId: string,
        db: any
    ) {
        const result = await db.collection(pageId).find({
            videoId,
            IntentCodeAIType: { $exists: true },
        }, {
            projection: { IntentCodeAIType: 1, selectedKey: 1 }  // Include IntentCodeAIType and selectedKey fields
        }).toArray();

        return {
            totalCareComments: result?.filter(item => IntentCodeAITypes.Care === item.IntentCodeAIType)?.length,
            totalNegativeComments: result?.filter(item => IntentCodeAITypes.Negative === item.IntentCodeAIType)?.length,
            totalPositiveComments: result?.filter(item => IntentCodeAITypes.Positive === item.IntentCodeAIType)?.length
        };
    }

    private async _getTotalValidComments(
        videoId: string | number,
        pageId: string,
        db: any
    ) {
        return await db.collection(pageId).count({
            videoId,
            IsValidateFormula: true,
            State: {
                $in: [0, 1],
            },
        });
    }

    private async _getTotalAlmostValidComments(
        videoId: string | number,
        pageId: string,
        db: any
    ) {
        return await db.collection(pageId).count({
            videoId,
            IsAlmostValidateFormula: true,
            State: {
                $in: [0, 1],
            },
        });
    }


    private async _getTotalOrdersAndRevenue(videoId: string | number) {
        return await this._fbCartsService.getTotalOrdersAndRevenue(videoId);
    }

    private async _getTotalCustomerOrders(videoId: string | number) {
        return await this._fbCartsService.getTotalCustomerOrders(videoId);
    }

    private async _getTotalCustomers(videoId: string, type = null) {
        return await this._fbUserProfileV2Service.getCountCustomersByLivestreamId(videoId, type);
    }

}
