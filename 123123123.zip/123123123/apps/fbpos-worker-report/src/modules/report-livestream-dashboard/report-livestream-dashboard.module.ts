import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { ReportLivestreamDashboardService } from './report-livestream-dashboard.service';
import { LockModule } from "@kiotviet-facebook-services/lock";

@Module({
  imports: [CommonModule, KvRabbitMQModule, LockModule],
  providers: [ReportLivestreamDashboardService],
})
export class ReportLivestreamDashboardModule {}
