import { AlertNotificationModule } from '@kiotviet-facebook-services/alert-notification';
import { BullModule } from '@nestjs/bullmq';
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from "@nestjs/config";
import { CoreModule } from './core/core.module';
import {
    ProductCatalogOnHandSyncEsModule
} from "./modules/product-catalog-onhand-synces/product-catalog-onhand-synces.module";
import {
    ProductCatalogPriceSyncEsModule
} from "./modules/product-catalog-price-synces/product-catalog-price-synces.module";
import { ProductCatalogProductDeleteSyncEsModule } from './modules/product-catalog-product-delete-synces/product-catalog-product-delete-synces.module';
import { ProductCatalogProductInformationSyncEsModule } from './modules/product-catalog-product-information-synces/product-catalog-product-information-synces.module';
import { ProductCatalogScheduleModule } from "./modules/product-catalog-schedules/product-catalog-schedule.module";
import { ProductCatalogSyncToFbCatalogModule } from './modules/product-catalog-sync-to-fb-catalog/product-catalog-sync-to-fb-catalog.module';
import { ProductCatalogSyncModule } from "./modules/product-catalog-sync/product-catalog-sync.module";

@Module({
    imports: [
        CoreModule,
        ProductCatalogScheduleModule,
        ProductCatalogSyncModule,
        AlertNotificationModule,
        ProductCatalogPriceSyncEsModule,
        ProductCatalogOnHandSyncEsModule,
        ProductCatalogProductDeleteSyncEsModule,
        ProductCatalogProductInformationSyncEsModule,
        ProductCatalogSyncToFbCatalogModule,
        BullModule.forRootAsync({
            imports: [ConfigModule],
            inject: [ConfigService],
            useFactory: (config: ConfigService) => config.get('bullQueue'),
        }),
    ],
    controllers: [],
    providers: [],
})
export class AppModule {
}
