import { RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    KvBaseException,
    KvLogger,
    RabbitMQConfigCheckProductCatalogUpdates,
    SocialTypes,
} from '@kiotviet-facebook-services/common';
import { KvProductCatalogStatusEnum } from '@kiotviet-facebook-services/facebook-sdk';
import {
    FbCatalogConnectionDocument,
    FbCatalogUserTokenService,
    MongodbGroupService
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { Injectable } from '@nestjs/common';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
import { CatalogUtilsService } from '../../catalog-common/services/catalog-utils.service';


const config = require('config');

@Injectable()
export class ProductCatalogSyncService {
    private readonly BATCH_SIZE = 100;
    private readonly CONCURRENT_BATCHES = 5;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _fbCatalogUserTokenService: FbCatalogUserTokenService,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _catalogUtilsService: CatalogUtilsService,
    ) {
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigCheckProductCatalogUpdates.ROUTING_KEY,
        queue: `fbpos-worker-facebook-catalog:${RabbitMQConfigCheckProductCatalogUpdates.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _handlerCheckProductCatalogUpdates(payload: FbCatalogConnectionDocument) {
        const prefixLog = this.prefixLog('_handlerCheckProductCatalogUpdates');
        const { catalogId, retailerId, pageId } = payload;

        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.RetailerId': retailerId,
                'Kv.SocialId': pageId,
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        try {
            if (!catalogId || !retailerId || !pageId) {
                return Promise.resolve();
            }

            const fbCatalogUserToken = await this._fbCatalogUserTokenService.getLatestCatalogUserToken(retailerId, catalogId);
            if (!fbCatalogUserToken?.token) {
                return Promise.resolve();
            }

            const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
            const productCatalogsColl = db.collection(this._mongodbGroupService.productCatalogsCollName);

            try {
                const allRecords = await productCatalogsColl
                    .find({
                        pageId, catalogId, retailerId,
                        kvStatus: {
                            $in: [
                                KvProductCatalogStatusEnum.ERROR,
                                KvProductCatalogStatusEnum.FINISHED,
                                KvProductCatalogStatusEnum.WAITING
                            ]
                        }
                    }, { lean: 1 })
                    .toArray();

                if (allRecords.length === 0) {
                    return Promise.resolve();
                }



                const totalProcessed = await this._processParallelBatches(
                    allRecords,
                    catalogId,
                    fbCatalogUserToken.token,
                    productCatalogsColl,
                    prefixLog,
                    logInput
                );


                this._logger.info(logInput, `${prefixLog} success: ${totalProcessed} records processed`);
                return Promise.resolve();
            } catch (processingError) {
                this._logger.error({ ...logInput, Error: new KvBaseException(processingError.stack) }, `${prefixLog} processing fail`);


                throw processingError;
            }
        } catch (error) {
            this._logger.error({ ...logInput, Error: new KvBaseException(error.stack) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }

    private async _processBatch(
        productCatalogs: any[],
        catalogId: string,
        token: string,
        productCatalogsColl: any,
        prefixLog: string,
        logInput: IKvLogInput,
        batchNumber: number
    ): Promise<number> {
        try {


            const enrichedCatalogs = await this._catalogUtilsService.getAdditionalDataProductCatalog(
                catalogId,
                token,
                productCatalogs,
                this.BATCH_SIZE
            );

            await this._catalogUtilsService.bulkUpdateProductCatalogWithNewData(
                catalogId,
                enrichedCatalogs,
                productCatalogsColl
            );



            return productCatalogs.length;
        } catch (error) {
            this._logger.error({ ...logInput, Error: new KvBaseException(error.stack) }, `${prefixLog} batch ${batchNumber} processing failed`);
            throw error;
        }
    }

    private async _processParallelBatches(
        allRecords: any[],
        catalogId: string,
        token: string,
        productCatalogsColl: any,
        prefixLog: string,
        baseInfoLog: any
    ): Promise<number> {
        const batches = [];
        for (let i = 0; i < allRecords.length; i += this.BATCH_SIZE) {
            batches.push(allRecords.slice(i, i + this.BATCH_SIZE));
        }

        let totalProcessed = 0;
        for (let i = 0; i < batches.length; i += this.CONCURRENT_BATCHES) {
            const batchPromises = batches
                .slice(i, i + this.CONCURRENT_BATCHES)
                .map((batch, index) =>
                    this._processBatch(
                        batch,
                        catalogId,
                        token,
                        productCatalogsColl,
                        prefixLog,
                        baseInfoLog,
                        i + index + 1
                    )
                );

            const results = await Promise.all(batchPromises);
            totalProcessed += results.reduce((sum, count) => sum + count, 0);

            // const progress = Math.round((totalProcessed / allRecords.length) * 100);
            // this._logger.info(`${prefixLog} progress update`, {
            //     ...baseInfoLog,
            //     Progress: {
            //         processed: totalProcessed,
            //         total: allRecords.length,
            //         percentComplete: progress
            //     }
            // });
        }

        return totalProcessed;
    }
}
