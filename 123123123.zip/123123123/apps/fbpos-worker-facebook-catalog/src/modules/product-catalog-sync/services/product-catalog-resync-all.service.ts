import { RabbitSubscribe } from "@golevelup/nestjs-rabbitmq";
import { FacebookCatalogSyncInventoryTypes, KvBaseException, KvLogger, RabbitMQConfigReSyncAllProductCatalog, SocialTypes } from "@kiotviet-facebook-services/common";
import { CatalogAvailabilityEnum, CatalogItemConditionEnum, CatalogItemMethodEnum, IFacebookCatalogItemBatchRequest, KvProductCatalogStatusEnum } from "@kiotviet-facebook-services/facebook-sdk";
import { FbCatalogConnectionDocument, MongodbGroupService } from "@kiotviet-facebook-services/fbpos-master-repository";
import { KvProductService } from "@kiotviet-facebook-services/kv-internal-api";
import { Injectable } from "@nestjs/common";
import { IKvLogInput } from "libs/shared/common/src/lib/logger/interfaces/logger.interface";
import { MessageBrokerService } from "../../catalog-common/services/message-broker.service";


const config = require('config');

@Injectable()
export class ProductCatalogReSyncAllService {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _kvProductService: KvProductService,
        private readonly _messageBrokerService: MessageBrokerService,
    ) {
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigReSyncAllProductCatalog.ROUTING_KEY,
        queue: `fbpos-worker-facebook-catalog:${RabbitMQConfigReSyncAllProductCatalog.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _reSyncAllProductCatalog(payload: FbCatalogConnectionDocument) {
        const prefixLog = this.prefixLog('_reSyncAllProductCatalog');
        const { catalogId, retailerId, pageId, branchId, pricebookId, syncInventory } = payload;

        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.RetailerId': retailerId,
                'Kv.BranchId': branchId,
                'Kv.SocialId': pageId,
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        try {
            if (!catalogId || !retailerId || !pageId || !branchId) {
                return Promise.resolve();
            }

            const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
            const productCatalogsColl = db.collection(this._mongodbGroupService.productCatalogsCollName);

            let skip = 0;
            const limit = 1000;
            let totalProcessed = 0;
            let productCatalogUpdates: IFacebookCatalogItemBatchRequest[] = [];
            const productCatalogDeletes: IFacebookCatalogItemBatchRequest[] = [];

            let retailerCode = '';
            while (true) {
                const productCatalogs = await productCatalogsColl
                    .find({
                        pageId,
                        catalogId,
                        retailerId,
                        kvStatus: {
                            $in: [
                                KvProductCatalogStatusEnum.ERROR,
                                KvProductCatalogStatusEnum.FINISHED,
                                KvProductCatalogStatusEnum.WAITING
                            ]
                        }
                    }, { lean: 1 })
                    .skip(skip)
                    .limit(limit)
                    .toArray();

                if (productCatalogs.length === 0) {
                    break;
                }
                if (!retailerCode) {
                    retailerCode = productCatalogs[0].retailerCode;
                }

                const kvProductResponse = await this._kvProductService.getCatalogProducts({
                    BranchId: branchId,
                    RetailerCode: retailerCode,
                    PriceBookId: pricebookId || 0,
                    SyncInventory: syncInventory,
                    ProductIds: productCatalogs.map(item => item.kvProductId)
                });

                if (kvProductResponse?.Data?.length) {
                    const kvProducts = kvProductResponse.Data;

                    productCatalogs.forEach(item => {
                        const foundKvProduct = kvProducts.find(product => product.Id === item.kvProductId);
                        if (foundKvProduct) {
                            if (foundKvProduct.isDeleted || foundKvProduct.isActive === false || foundKvProduct.AllowsSale === false) {
                                productCatalogDeletes.push({
                                    method: CatalogItemMethodEnum.DELETE,
                                    data: {
                                        id: item.id
                                    }
                                }
                                )
                            } else {
                                const price = foundKvProduct.CustomValue || foundKvProduct.BasePrice || 0;
                                const image = foundKvProduct.ProductImages?.length > 0 ? foundKvProduct.ProductImages[0].Image : '';
                                let kvProductAttributeCatalogs = null;
                                if (foundKvProduct.ProductAttributes?.length) {
                                    kvProductAttributeCatalogs = foundKvProduct.ProductAttributes.map(attr => {
                                        const AttributeName = attr.Attribute?.Name || "";
                                        attr.AttributeName = AttributeName;
                                        return {
                                            name: AttributeName,
                                            value: attr.Value
                                        }
                                    })
                                }
                                if (foundKvProduct.Code !== item.id) {
                                    productCatalogDeletes.push({
                                        method: CatalogItemMethodEnum.DELETE,
                                        data: {
                                            id: item.id
                                        }
                                    }
                                    )
                                }
                                let inventory = foundKvProduct.OnHand;
                                //Không phải hàng combo phải trừ cả hàng khách đặt, nếu hàng combo thì đã tính toán trước đó rồi
                                if (FacebookCatalogSyncInventoryTypes.INVENTORY_EXCLUDING_ORDER_ITEM === syncInventory && foundKvProduct.ProductType !== 1) {
                                    inventory = inventory - (foundKvProduct.Reserved || 0);
                                }
                                inventory = Math.round(inventory * 1e6) / 1e6;
                                const title = foundKvProduct.Name;
                                productCatalogUpdates.push({
                                    method: CatalogItemMethodEnum.UPDATE,
                                    data: {
                                        id: foundKvProduct.Code,
                                        availability: inventory > 0 ? CatalogAvailabilityEnum.IN_STOCK : CatalogAvailabilityEnum.OUT_OF_STOCK,
                                        description: foundKvProduct.Description || '',
                                        image_link: image,
                                        condition: CatalogItemConditionEnum.NEW,
                                        link: item.link,
                                        price: `${price} VND`,
                                        title,
                                        inventory,
                                        quantity_to_sell_on_facebook: inventory,
                                        item_group_id: `${foundKvProduct.MasterProductId || foundKvProduct.Id}`,
                                        kvProduct: {
                                            id: foundKvProduct.Id,
                                            code: foundKvProduct.Code,
                                            name: title,
                                            description: foundKvProduct.Description || '',
                                            image,
                                            price,
                                            kvUnit: foundKvProduct.Unit || '',
                                            productAttributes: foundKvProduct.ProductAttributes || [],
                                            attributeLabel: foundKvProduct.ProductAttributes?.map(item => item.Value).join(' - ') || '',
                                            kvProductAttributeCatalogs: kvProductAttributeCatalogs || [],
                                            isMaster: foundKvProduct.MasterProductId === foundKvProduct.Id ||
                                                foundKvProduct.MasterProductId === null || foundKvProduct.MasterProductId === undefined
                                        },
                                        ...kvProductAttributeCatalogs && {
                                            additional_variant_attribute: kvProductAttributeCatalogs
                                                .map(attr => `${attr.name}:${attr.value}`)
                                                .join(", ")
                                        }
                                    }
                                });
                            }

                        } else {
                            // Case này đã xóa sản phẩm trên kv nhưng chưa xóa trên fb
                            const {
                                isRemove,
                                isActive,
                                allowsSale

                            } = item?.kvProductChange;
                            const needRemovedProductCatalog = isRemove || isActive === false || allowsSale === false;
                            if (needRemovedProductCatalog) {
                                productCatalogDeletes.push({
                                    method: CatalogItemMethodEnum.DELETE,
                                    data: {
                                        id: item.id
                                    }
                                });
                            }
                        }
                    });
                }

                totalProcessed += productCatalogs.length;
                skip += limit;
            }

            productCatalogUpdates = productCatalogUpdates.filter(item => !!item);
            if (productCatalogUpdates.length) {
                this._messageBrokerService.publishSyncProductsCatalog({
                    catalogId,
                    pageId,
                    retailerId,
                    retailerCode,
                    branchId,
                    data: productCatalogUpdates,
                    source: 'fbpos-worker-catalog-resync-all'
                });
            }
            if (productCatalogDeletes.length) {
                this._messageBrokerService.publishSyncProductsCatalog({
                    catalogId,
                    pageId,
                    retailerId,
                    retailerCode,
                    branchId,
                    data: productCatalogDeletes,
                    source: 'fbpos-worker-catalog-resync-all'
                });
            }

            this._logger.info(logInput, `${prefixLog} re-sync all product Catalog total: ${totalProcessed}`);
        } catch (error) {
            this._logger.error({ ...logInput, Error: new KvBaseException(error.stack) }, `${prefixLog} fail`);
        }


        return Promise.resolve();
    }

}
