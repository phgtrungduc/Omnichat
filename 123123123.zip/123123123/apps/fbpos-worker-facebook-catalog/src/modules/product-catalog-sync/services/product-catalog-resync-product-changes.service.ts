import { RabbitSubscribe } from "@golevelup/nestjs-rabbitmq";
import { KvBaseException, KvLogger, RabbitMQConfigReSyncAllProductChange, SocialTypes } from "@kiotviet-facebook-services/common";
import { CatalogAvailabilityEnum, CatalogItemMethodEnum, CatalogKvProductChangeEnum, IFacebookCatalogItemBatchRequest, KvProductCatalogStatusEnum } from "@kiotviet-facebook-services/facebook-sdk";
import { MongodbGroupService } from "@kiotviet-facebook-services/fbpos-master-repository";
import { Injectable } from "@nestjs/common";
import { IKvLogInput } from "libs/shared/common/src/lib/logger/interfaces/logger.interface";
import { MessageBrokerService } from "../../catalog-common/services/message-broker.service";
import { ICatalogReSyncProductChange } from "../interfaces/message-payload.interface";


const config = require('config');

@Injectable()
export class ProductCatalogReSyncProductChangesService {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _messeageBrokerService: MessageBrokerService,
    ) {
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigReSyncAllProductChange.ROUTING_KEY,
        queue: `fbpos-worker-facebook-catalog:${RabbitMQConfigReSyncAllProductChange.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _reSyncProductChangeCatalog(payload: ICatalogReSyncProductChange) {
        const prefixLog = this.prefixLog('_reSyncProductChangeCatalog');
        const { catalogId, retailerId, branchId, pageId, ids } = payload;

        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.RetailerId': retailerId,
                'Kv.BranchId': branchId,
                'Kv.SocialId': pageId,
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        try {
            if (!catalogId || !retailerId || !pageId || !branchId) {
                return Promise.resolve();
            }

            const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
            const productCatalogsColl = db.collection(this._mongodbGroupService.productCatalogsCollName);

            let skip = 0;
            const limit = 1000;
            let totalProcessed = 0;
            let productCatalogUpdates: IFacebookCatalogItemBatchRequest[] = [];
            let productCatalogDeletes: IFacebookCatalogItemBatchRequest[] = [];
            const validationErrorUpdates: any[] = [];


            let retailerCode = '';
            while (true) {
                const productCatalogs = await productCatalogsColl
                    .find({
                        pageId,
                        catalogId,
                        retailerId,
                        ...ids?.length && { id: { $in: ids } },
                        kvStatus: {
                            $in: [
                                KvProductCatalogStatusEnum.ERROR,
                                KvProductCatalogStatusEnum.FINISHED,
                                KvProductCatalogStatusEnum.WAITING,
                                KvProductCatalogStatusEnum.VALIDATION_SUCCESS,
                                KvProductCatalogStatusEnum.VALIDATION_ERROR
                            ]
                        },
                        kvProductChangeType: { $in: [CatalogKvProductChangeEnum.UPDATE, CatalogKvProductChangeEnum.REMOVE] }
                    }, { lean: 1 })
                    .skip(skip)
                    .limit(limit)
                    .toArray();

                if (productCatalogs.length === 0) {
                    break;
                }
                if (!retailerCode) {
                    retailerCode = productCatalogs[0].retailerCode;
                }

                productCatalogs.forEach(item => {
                    const { kvProductChange, kvProduct, inventory, availability, item_group_id, link, condition, kvStatus } = item;
                    
                    // Handle VALIDATION_ERROR case - collect for bulk update later
                    if (kvStatus === KvProductCatalogStatusEnum.VALIDATION_ERROR && kvProductChange) {
                        const {
                            code: codeUpdate,
                            image: imageUpdate,
                            name: nameUpdate,
                            description: descriptionUpdate,
                            kvUnit: kvUnitUpdate,
                            productAttributes: productAttributesUpdate,
                            onhand: onhandUpdate,
                            price: priceUpdate
                        } = kvProductChange;

                        // Prepare updated kvProduct
                        const updatedKvProduct = {
                            ...kvProduct,
                            ...(codeUpdate && { code: codeUpdate }),
                            ...(nameUpdate && { name: nameUpdate }),
                            ...(imageUpdate && { image: imageUpdate }),
                            ...(descriptionUpdate && { description: descriptionUpdate }),
                            ...(kvUnitUpdate && { kvUnit: kvUnitUpdate }),
                            ...(productAttributesUpdate && { productAttributes: productAttributesUpdate }),
                            ...(priceUpdate >= 0 && { price: priceUpdate })
                        };

                        // Check if product code is changed - need to update id in MongoDB
                        const isChangeProductCode = codeUpdate && codeUpdate !== item.id;
                        
                        // Add to bulk update array
                        validationErrorUpdates.push({
                            updateOne: {
                                filter: { pageId, catalogId, retailerId, id: item.id },
                                update: { 
                                    $set: { 
                                        kvProduct: updatedKvProduct,
                                        ...(onhandUpdate !== undefined && { inventory: onhandUpdate }),
                                        ...(isChangeProductCode && { id: codeUpdate }), // Update id if code changed
                                        updatedAt: Date.now()
                                    } 
                                }
                            }
                        });
                        
                        return; // Skip further processing for VALIDATION_ERROR items
                    }
                    
                    if (kvProductChange) {
                        const {
                            code,
                            image,
                            name,
                            description,
                            kvUnit,
                            productAttributes,
                            attributeLabel,
                            kvProductAttributeCatalogs,
                            price
                        } = kvProduct;

                        const {
                            code: codeUpdate,
                            image: imageUpdate,
                            name: nameUpdate,
                            description: descriptionUpdate,
                            kvUnit: kvUnitUpdate,
                            productAttributes: productAttributesUpdate,
                            isRemove,
                            isActive,
                            allowsSale,
                            onhand: onhandUpdate,
                            price: priceUpdate
                        } = kvProductChange;
                        const needRemovedProductCatalog = isRemove || isActive === false || allowsSale === false;
                        if (needRemovedProductCatalog) {
                            productCatalogDeletes.push({
                                method: CatalogItemMethodEnum.DELETE,
                                data: {
                                    id: item.id
                                }
                            }
                            )
                        } else {
                            let kvProductAttributeCatalogsUpdate = null;
                            if (productAttributesUpdate?.length) {
                                kvProductAttributeCatalogsUpdate = productAttributesUpdate.map(attr => {
                                    return {
                                        name: attr.AttributeName || "",
                                        value: attr.Value
                                    }
                                })
                            }
                            const isChangeProductCode = codeUpdate && codeUpdate !== item.id;
                            if (isChangeProductCode) {
                                productCatalogDeletes.push({
                                    method: CatalogItemMethodEnum.DELETE,
                                    data: {
                                        id: item.id
                                    }
                                }
                                )
                            }
                            const newAttributes = productAttributesUpdate || productAttributes || [];
                            const newInventory = onhandUpdate || inventory;
                            productCatalogUpdates.push({
                                method: CatalogItemMethodEnum.UPDATE,
                                data: {
                                    id: codeUpdate || code,
                                    description: descriptionUpdate || description || '',
                                    image_link: imageUpdate || image,
                                    condition,
                                    price: priceUpdate >= 0 ? `${priceUpdate} VND` : `${price} VND`,
                                    inventory: newInventory,
                                    quantity_to_sell_on_facebook: newInventory,
                                    availability: newInventory > 0 ? CatalogAvailabilityEnum.IN_STOCK : CatalogAvailabilityEnum.OUT_OF_STOCK,
                                    link,
                                    item_group_id,
                                    // // Nếu đổi code cần đăng hàng hóa mới, nên cần update lại các thông tin này
                                    // ...isChangeProductCode && {
                                    //     price: `${price} VND`,
                                    //     availability,
                                    //     inventory,
                                    //     quantity_to_sell_on_facebook: inventory,
                                    //     item_group_id,
                                    //     link,
                                    //     condition: CatalogItemConditionEnum.NEW,
                                    // },
                                    // ...onhandUpdate && {
                                    //     inventory: onhandUpdate,
                                    //     quantity_to_sell_on_facebook: onhandUpdate,
                                    //     availability: onhandUpdate > 0 ? CatalogAvailabilityEnum.IN_STOCK : CatalogAvailabilityEnum.OUT_OF_STOCK
                                    // },
                                    // ...priceUpdate > 0 && {
                                    //     price: `${priceUpdate} VND`
                                    // },
                                    title: nameUpdate || name,
                                    kvProduct: {
                                        id: kvProduct.id,
                                        code: codeUpdate || code,
                                        name: nameUpdate || name,
                                        image: imageUpdate || image,
                                        description: descriptionUpdate || description || '',
                                        price: priceUpdate >= 0 ? priceUpdate : kvProduct.price,
                                        kvUnit: kvUnitUpdate || kvUnit || '',
                                        productAttributes: newAttributes,
                                        attributeLabel: newAttributes?.map(item => item.Value).join(' - ') || attributeLabel || '',
                                        kvProductAttributeCatalogs: kvProductAttributeCatalogsUpdate || kvProductAttributeCatalogs || [],
                                        isMaster: kvProduct.isMaster
                                    },
                                    ...kvProductAttributeCatalogsUpdate && {
                                        additional_variant_attribute: kvProductAttributeCatalogsUpdate
                                            .map(attr => `${attr.name}:${attr.value}`)
                                            .join(", ")
                                    }
                                }
                            });

                        }
                    }


                })

                totalProcessed += productCatalogs.length;
                skip += limit;
            }

            productCatalogUpdates = productCatalogUpdates.filter(item => !!item);
            if (productCatalogUpdates.length) {
                this._messeageBrokerService.publishSyncProductsCatalog({
                    catalogId,
                    pageId,
                    retailerId,
                    retailerCode,
                    branchId,
                    data: productCatalogUpdates,
                    isAutoSync: payload.isAutoSync,
                    source: 'product-catalog-resync-all-product-change'
                });
            }

            productCatalogDeletes = productCatalogDeletes.filter(item => !!item);

            if (productCatalogDeletes.length) {
                this._messeageBrokerService.publishSyncProductsCatalog({
                    catalogId,
                    pageId,
                    retailerId,
                    retailerCode,
                    branchId,
                    data: productCatalogDeletes,
                    source: 'product-catalog-resync-all-product-change'
                });
            }

            // Apply bulk updates for VALIDATION_ERROR items
            if (validationErrorUpdates.length) {
                await productCatalogsColl.bulkWrite(validationErrorUpdates);
                this._logger.info(logInput, `${prefixLog} Applied ${validationErrorUpdates.length} bulk updates for VALIDATION_ERROR items`);
            }

            this._logger.info(logInput, `${prefixLog} re-sync all product Catalog total: ${totalProcessed}`);
        } catch (error) {
            this._logger.error({ ...logInput, Error: new KvBaseException(error.stack) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }
}
