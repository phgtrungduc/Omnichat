import { FbCatalogConnectionDocument } from "@kiotviet-facebook-services/fbpos-master-repository";

export interface ICatalogReSyncProductChange extends FbCatalogConnectionDocument{
    ids?: string[];
    isAutoSync?: boolean;
}
