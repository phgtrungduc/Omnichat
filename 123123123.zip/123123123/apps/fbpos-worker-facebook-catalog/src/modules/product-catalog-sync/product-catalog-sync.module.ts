import { CommonModule } from '@kiotviet-facebook-services/common';
import { FacebookSdkModule } from '@kiotviet-facebook-services/facebook-sdk';
import { KvInternalApiModule } from "@kiotviet-facebook-services/kv-internal-api";
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { Module } from '@nestjs/common';
import { CatalogCommonModule } from "../catalog-common/catalog-common.module";
import { ProductCatalogReSyncAllService, ProductCatalogReSyncProductChangesService, ProductCatalogSyncService } from './services';

@Module({
    imports: [
        CommonModule,
        KvRabbitMQModule,
        FacebookSdkModule,
        KvInternalApiModule,
        CatalogCommonModule
    ],
    providers: [
        ProductCatalogSyncService,
        ProductCatalogReSyncAllService,
        ProductCatalogReSyncProductChangesService
    ],
})
export class ProductCatalogSyncModule {
}
