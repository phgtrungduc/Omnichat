import {
    CapabilityToReviewStatusEnum,
    CapabilityToReviewTypeEnum, ErrorPriorityProductEnum,
    ErrorTypeProductEnum,
    IKvExternalCatalogProductItem, IProductCatalogError,
    KvProductCatalogStatusEnum
} from "@kiotviet-facebook-services/facebook-sdk";

export function buildTextSearch(data: IKvExternalCatalogProductItem) {
    return [
        data?.kvProduct?.code ? data?.kvProduct?.code : '',
        data?.kvProduct?.name ? data?.kvProduct?.name : '']
        .filter((value) => value)
        .join('|');
}

export function getKvStatusAndErrorProductCatalog(productCatalog: any): { error: IProductCatalogError, kvStatus: KvProductCatalogStatusEnum } {
    const { errors, capability_to_review_status } = productCatalog;
    if (errors?.length) {
        const isSingleOutOfStockError =
            errors.length === 1 &&
            errors[0]?.error_type === ErrorTypeProductEnum.PRODUCT_OUT_OF_STOCK;

        if (!isSingleOutOfStockError) {
            return { error: null, kvStatus: KvProductCatalogStatusEnum.ERROR };
        }
    }

    const miniShopsReview = capability_to_review_status?.find(review => review.key === CapabilityToReviewTypeEnum.MINI_SHOPS);
    if (miniShopsReview) {
        const { value } = miniShopsReview;
        switch (value) {
            case CapabilityToReviewStatusEnum.APPROVED:
                return { error: null, kvStatus: KvProductCatalogStatusEnum.FINISHED };
            case CapabilityToReviewStatusEnum.PENDING:
            case CapabilityToReviewStatusEnum.NO_REVIEW:
                return { error: null, kvStatus: KvProductCatalogStatusEnum.WAITING };
            case CapabilityToReviewStatusEnum.REJECTED:
                return {
                    error: {
                        error_type: ErrorTypeProductEnum.REVIEW_REJECT,
                        error_priority: ErrorPriorityProductEnum.HIGH,
                        title: 'Hàng hóa không phù hợp chính sách bán hàng của Meta',
                        description: 'Hàng hóa không phù hợp chính sách bán hàng của Meta'

                    }, kvStatus: KvProductCatalogStatusEnum.ERROR
                };
            case CapabilityToReviewStatusEnum.OUTDATED:
                return {
                    error: {
                        error_type: ErrorTypeProductEnum.REVIEW_OUTDATED,
                        error_priority: ErrorPriorityProductEnum.HIGH,
                        title: 'Hàng hóa hết hạn đồng bộ',
                        description: 'Hàng hóa hết hạn đồng bộ'

                    }, kvStatus: KvProductCatalogStatusEnum.ERROR
                };

        }
    }
    return { error: null, kvStatus: KvProductCatalogStatusEnum.WAITING };

}

export enum ProductValidationErrorCode {
    VALIDATION_ERROR = 'VALIDATION_ERROR',
    MISSING_REQUIRED_FIELD = 'MISSING_REQUIRED_FIELD',
    INVALID_PRICE = 'INVALID_PRICE',
    INVALID_INVENTORY = 'INVALID_INVENTORY',
    MISSING_IMAGE = 'MISSING_IMAGE',
    MISSING_DESCRIPTION = 'MISSING_DESCRIPTION'
}