import { IFacebookCatalogItemBatchRequest } from "@kiotviet-facebook-services/facebook-sdk";
import { ProductValidationErrorCode } from "../common/util";

export interface IProductValidationError {
    code: ProductValidationErrorCode;
    field?: string;
    message: string;
}

export interface IInvalidCatalogItem {
    item: IFacebookCatalogItemBatchRequest;
    errors: IProductValidationError[];
}

export interface IProductValidationResult {
    validCatalogItems: IFacebookCatalogItemBatchRequest[];
    invalidCatalogItems: IInvalidCatalogItem[];
}
