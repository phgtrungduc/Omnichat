import { CatalogItemMethodEnum } from "@kiotviet-facebook-services/facebook-sdk";
import { ICheckHandlesStatusJob, ISyncProductsCatalog } from "./sync-products-catalog.interface";

export interface IMessageBrokerService {
  publishFacebookCatalogIndexEvent(): void;
  publishAuditLog(payload: ISyncProductsCatalog): void;
  publishRetryEvent(payload: ISyncProductsCatalog): void;
  publishSyncProductsCatalog(payload: ISyncProductsCatalog): void;
  publishSuccessfullySendProductUpdatesCatalogNotification(payload: ICheckHandlesStatusJob, method: CatalogItemMethodEnum, totalProducts: number, totalSuccess: number): void;
  publishNotificationValidationProduct(payload: ISyncProductsCatalog, totalProducts: number, totalValidations: number);
}