import {
    IFacebookCatalogItemBatchRequest
} from "@kiotviet-facebook-services/facebook-sdk";

export interface ISyncProductsCatalog {
    catalogId: string;
    pageId: string;
    retailerId: number;
    retailerCode?: string;
    branchId?: number;
    data: IFacebookCatalogItemBatchRequest[];
    source?: string;
    retryTime?: number;

    userId?: number; // User KiotViet
    isNeedValidate?: boolean; // Is need validate product before sync to facebook catalog
    isAutoSync?: boolean; // Is auto sync product to facebook catalog
    totalProductsInBatch?: number; // Total products sync to facebook catalog
}

export interface ICheckHandlesStatusJob {
    catalogId: string;
    pageId: string;
    retailerId: number;
    handle: string;
}
