import { FacebookResponseException, KvLogger, } from '@kiotviet-facebook-services/common';
import {
    CatalogItemMethodEnum,
    ErrorPriorityProductEnum,
    ErrorTypeProductEnum,
    FacebookCatalogService,
    KvProductCatalogStatusEnum
} from "@kiotviet-facebook-services/facebook-sdk";
import { MongodbGroupService } from "@kiotviet-facebook-services/fbpos-master-repository";
import { Injectable } from '@nestjs/common';
import { pick } from 'lodash';
import { buildTextSearch, getKvStatusAndErrorProductCatalog } from '../common/util';
import { ISyncProductsCatalog } from '../interfaces/sync-products-catalog.interface';
import { IInvalidCatalogItem } from '../interfaces/catalog-validation.interface';

@Injectable()
export class CatalogUtilsService {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _facebookCatalogService: FacebookCatalogService,
        private readonly _mongodbGroupService: MongodbGroupService
    ) {
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async getAdditionalDataProductCatalog(
        catalogId: string,
        access_token: string,
        productCatalogs: any[],
        limit = 100,
        throwError = true,
    ): Promise<any[]> {
        try {
            if (!productCatalogs?.length) {
                return [];
            }

            const filter = {
                retailer_id: {
                    in: productCatalogs.filter(item => item.id).map(item => item.id)
                }
            };
            const res = await this._facebookCatalogService.getProducts({
                catalogId,
                access_token,
                fields: 'id,retailer_id,visibility,retailer_product_group_id,errors,capability_to_review_status,quantity_to_sell_on_facebook',
                filter: JSON.stringify(filter),
                limit
            });
            const productCatalogsMeta = res.data;
            return productCatalogs.map(item => {
                const mapping = productCatalogsMeta.find(x => x.retailer_id == item.id);
                if (mapping) {
                    const {
                        id,
                        visibility,
                        retailer_product_group_id,
                        errors,
                        capability_to_review_status,
                        quantity_to_sell_on_facebook
                    } = mapping;
                    item.visibility = visibility;
                    item.product_catalog_id = id;
                    item.retailer_product_group_id = retailer_product_group_id;
                    item.errors = errors || [];
                    item.capability_to_review_status = capability_to_review_status || [];
                    item.quantity_to_sell_on_facebook = quantity_to_sell_on_facebook || item.quantity_to_sell_on_facebook || item.inventory || 0;
                }

                return item;
            });
        } catch (err) {
            const prefixLog = this.prefixLog('_getAdditionalDataProductCatalog');
            this._logger.error({ MessageTemplate: { catalogId, productCatalogs }, Error: new FacebookResponseException(err.stack, { cause: err }) }, `${prefixLog} fail`);
            if (throwError) {
                throw err;
            }
        }
        return productCatalogs;

    }

    async bulkUpdateProductCatalogWithNewData(catalogId: string,
        productCatalogs: any,
        productCatalogsColl: any,
        handle = '',
        warnings = [],
        errors = []) {
        const bulkOps = productCatalogs.map((item) => {
            if (CatalogItemMethodEnum.DELETE === item.method) {
                return {
                    deleteMany: {
                        filter: {
                            catalogId,
                            id: item.id
                        },
                    },
                };
            }
            const { errors: errorsItem } = item;
            const warningsForItem = warnings.filter((warning) => warning?.id == item?.id) || [];
            const errorsForItem = errorsItem?.length ? errorsItem : errors.filter((error) => error?.id == item?.id);
            const { error, kvStatus } = getKvStatusAndErrorProductCatalog(item);
            if (error) {
                errorsForItem.push(error);
            }

            return {
                updateOne: {
                    filter: {
                        _id: item._id,
                    },
                    update: {
                        $set: {
                            ...pick(item,
                                ['visibility', 'product_catalog_id', 'retailer_product_group_id', 'errors', 'capability_to_review_status']),
                            kvStatus,
                            warnings: warningsForItem,
                            errors: errorsForItem,
                            updatedAt: Date.now(),
                        },
                        ...handle && {
                            $pull: {
                                handles: handle,
                            }
                        }
                    },
                    upsert: false,
                },
            };
        });
        if (bulkOps?.length) {
            await productCatalogsColl.bulkWrite(bulkOps);
            const hasDeleteMethod = productCatalogs.some(
                (item) => item.method === CatalogItemMethodEnum.DELETE
            );
            if (hasDeleteMethod) {
                const product = productCatalogs[0];
                await this.updateVariantProduct(catalogId, product.pageId, product.retailerId, productCatalogs);
            }
        }
    }

    async savingProductCatalog(payload: ISyncProductsCatalog, handles: string[]) {
        const { pageId, catalogId, retailerId, retailerCode, branchId, data, source } = payload;
        const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
        const productCatalogsColl = db.collection(this._mongodbGroupService.productCatalogsCollName);
        const startTimestamp = Date.now();
        const sources = ['fbpos-worker-catalog-resync-all', 'product-catalog-resync-all-product-change'];
        const isReSync = sources.includes(source);
        const bulkOps = data.map((item, index) => {
            const textSearch = buildTextSearch(item?.data);
            if (item?.data?.image_link == '') {
                delete item.data.image_link; // Không xóa được link ảnh trên catalog nên không update field này
            }
            return {
                updateOne: {
                    filter: {
                        pageId: pageId,
                        catalogId: catalogId,
                        retailerId: retailerId,
                        id: item?.data?.id
                    }, update: {
                        $set: {
                            ...item.data,
                            ...item.data?.kvProduct?.id && { kvProductId: item.data?.kvProduct?.id },
                            pageId,
                            catalogId,
                            retailerId,
                            ...retailerCode && { retailerCode },
                            ...branchId > 0 && { branchId },
                            kvStatus: KvProductCatalogStatusEnum.WAITING,
                            ...textSearch && { textSearch: buildTextSearch(item?.data) },
                            method: item?.method,
                            updatedAt: Date.now(),
                        },
                        $unset: {
                            validationErrors: "",
                            ...isReSync && {
                                kvProductChange: "",
                                kvProductChangeType: ""
                            }
                        },
                        $setOnInsert: {
                            createdAt: new Date(startTimestamp + index)
                        },
                        ...handles?.length && {
                            $addToSet: {
                                handles: handles[0]
                            }
                        },
                    },
                    upsert: true,
                },
            };
        });

        if (bulkOps.length > 0) {
            await productCatalogsColl.bulkWrite(bulkOps);

            await this.updateVariantProduct(payload.catalogId, payload.pageId, payload.retailerId, payload.data.map(item => item.data));
        }
    }

    async savingProductCatalogWithErrorAPI(payload: ISyncProductsCatalog) {
        const { pageId, catalogId, retailerId, retailerCode, branchId, data } = payload;
        const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
        const productCatalogsColl = db.collection(this._mongodbGroupService.productCatalogsCollName);
        const startTimestamp = Date.now();

        const bulkOps = data.map((item, index) => {
            const textSearch = buildTextSearch(item?.data);
            return {
                updateOne: {
                    filter: {
                        pageId: pageId,
                        catalogId: catalogId,
                        retailerId: retailerId,
                        id: item?.data?.id
                    },
                    update: {
                        $set: {
                            ...item.data,
                            ...item.data?.kvProduct?.id && { kvProductId: item.data?.kvProduct?.id },
                            pageId,
                            catalogId,
                            retailerId,
                            ...retailerCode && { retailerCode },
                            ...branchId > 0 && { branchId },
                            kvStatus: KvProductCatalogStatusEnum.ERROR,
                            ...textSearch && { textSearch: buildTextSearch(item?.data) },
                            method: item?.method,
                            updatedAt: Date.now(),
                        },
                        $setOnInsert: {
                            createdAt: new Date(startTimestamp + index)
                        },
                        $addToSet: {
                            errors: {
                                error_type: ErrorTypeProductEnum.OAUTH_ACCESS_TOKEN,
                                error_priority: ErrorPriorityProductEnum.HIGH,
                                title: 'Token đã hết hạn hoặc không có quyền truy cập. Vui lòng kết nối và đăng lại',
                                description: 'Token đã hết hạn hoặc không có quyền truy cập. Vui lòng kết nối và đăng lại'
                            }
                        },
                    },
                    upsert: true,
                },
            };
        });

        if (bulkOps.length > 0) {
            await productCatalogsColl.bulkWrite(bulkOps);
            await this.updateVariantProduct(payload.catalogId, payload.pageId, payload.retailerId, payload.data.map(item => item.data));
        }
    }

    async updateVariantProduct(catalogId: string,
        pageId: string,
        retailerId: number,
        updateProductCatalogs = []) {

        const itemGroupIds = [...new Set(
            updateProductCatalogs
                .map(item => item?.item_group_id)
        )];

        if (!itemGroupIds.length) {
            return;
        }
        const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
        const productCatalogsColl = db.collection(this._mongodbGroupService.productCatalogsCollName);

        const allProductCatalogsByItemGroupId = await productCatalogsColl
            .find({
                pageId,
                catalogId,
                retailerId,
                item_group_id: { $in: itemGroupIds },
            }, { lean: 1 })
            .limit(1000)
            .toArray();

        let bulkOps = allProductCatalogsByItemGroupId
            .map((item, index) => {

                const isMaster = item.item_group_id === `${item.kvProduct?.id}`;
                const variantCount = allProductCatalogsByItemGroupId.filter(product => product.item_group_id === item.item_group_id).length;
                const hasMaster = !!allProductCatalogsByItemGroupId.find(parent => parent.item_group_id === `${parent.kvProduct?.id}`);
                return {
                    updateOne: {
                        filter: {
                            pageId: pageId,
                            catalogId: catalogId,
                            retailerId: retailerId,
                            id: item?.id
                        },
                        update: {
                            $set: {
                                ...isMaster && {
                                    "kvProduct.variantCount": variantCount,
                                    "kvProduct.isMaster": true
                                },
                                ...!isMaster && {
                                    "kvProduct.hasMaster": hasMaster
                                },
                                updatedAt: Date.now(),
                            },
                        },
                        upsert: false,
                    },
                };
            });
        bulkOps = bulkOps.filter(ops => !!ops);
        if (bulkOps.length > 0) {
            await productCatalogsColl.bulkWrite(bulkOps);
        }
    }

    async savingInvalidProductCatalog(payload: ISyncProductsCatalog, invalidCatalogItems: IInvalidCatalogItem[]) {
        const { pageId, catalogId, retailerId, retailerCode, branchId, data } = payload;
        const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
        const productCatalogsColl = db.collection(this._mongodbGroupService.productCatalogsCollName);
        const startTimestamp = Date.now();

        const bulkOps = invalidCatalogItems.map((invalidCatalogItem, index) => {
            const { item, errors } = invalidCatalogItem;
            const textSearch = buildTextSearch(item?.data);
            const validationErrors = errors.map(error => ({
                error_type: error.code,
                error_priority: ErrorPriorityProductEnum.HIGH,
                title: error.message,
                description: error.message,
                field: error.field,
                createdAt: new Date()
            }));

            return {
                updateOne: {
                    filter: {
                        pageId,
                        catalogId,
                        retailerId,
                        id: item.data.id
                    },
                    update: {
                        $set: {
                            ...item.data,
                            ...item.data?.kvProduct?.id && { kvProductId: item.data?.kvProduct?.id },
                            pageId,
                            catalogId,
                            retailerId,
                            ...retailerCode && { retailerCode },
                            ...branchId > 0 && { branchId },
                            kvStatus: KvProductCatalogStatusEnum.VALIDATION_ERROR,
                            ...textSearch && { textSearch },
                            method: item.method,
                            updatedAt: Date.now(),
                            validationErrors
                        },
                        $setOnInsert: {
                            createdAt: new Date(startTimestamp + index)
                        }
                    },
                    upsert: true
                }
            };
        }).filter(op => op !== null);

        if (bulkOps.length > 0) {
            await productCatalogsColl.bulkWrite(bulkOps);
            await this.updateVariantProduct(
                payload.catalogId,
                payload.pageId,
                payload.retailerId,
                payload.data.map(item => item.data)
            );
        }
    }
}
