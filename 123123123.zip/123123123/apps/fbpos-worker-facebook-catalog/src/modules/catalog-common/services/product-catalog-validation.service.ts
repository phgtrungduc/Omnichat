import { Injectable } from '@nestjs/common';
import { KvLogger } from '@kiotviet-facebook-services/common';
import { IFacebookCatalogItemBatchRequest } from '@kiotviet-facebook-services/facebook-sdk';
import { ProductValidationErrorCode } from '../common/util';
import { IProductValidationResult, IInvalidCatalogItem, IProductValidationError } from '../interfaces/catalog-validation.interface';

@Injectable()
export class ProductCatalogValidatorService {
    constructor(private readonly _logger: KvLogger,
    ) { }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async validateProducts(productCatalogs: IFacebookCatalogItemBatchRequest[]): Promise<IProductValidationResult> {
        const validCatalogItems: IFacebookCatalogItemBatchRequest[] = [];
        const invalidCatalogItems: IInvalidCatalogItem[] = [];

        for (const item of productCatalogs) {
            try {
                const validationErrors = await this._validateProduct(item);

                if (!validationErrors.length) {
                    validCatalogItems.push(item);
                } else {
                    invalidCatalogItems.push({
                        item,
                        errors: validationErrors
                    });
                }
            } catch (error) {
                invalidCatalogItems.push({
                    item,
                    errors: [{
                        code: ProductValidationErrorCode.VALIDATION_ERROR,
                        message: error.message
                    }]
                });
            }
        }

        return { validCatalogItems, invalidCatalogItems };
    }

    private async _validateProduct(product: IFacebookCatalogItemBatchRequest): Promise<IProductValidationError[]> {
        const errors: IProductValidationError[] = [];

        const inventoryErrors = this._validateInventory(product);
        if (inventoryErrors) {
            errors.push(inventoryErrors);
        }

        const descriptionErrors = this._validateDescription(product);
        if (descriptionErrors) {
            errors.push(descriptionErrors);
        }

        const imageErrors = this._validateImages(product);
        if (imageErrors) {
            errors.push(imageErrors);
        }

        return errors;
    }


    private _validateInventory(item: IFacebookCatalogItemBatchRequest): IProductValidationError | null {
        const { data } = item;
        if (!data.inventory || data.inventory < 1) {
            return {
                code: ProductValidationErrorCode.INVALID_INVENTORY,
                field: 'inventory',
                message: 'Tồn nhỏ hơn 1'
            };
        }
        return null;
    }

    private _validateImages(item: IFacebookCatalogItemBatchRequest): IProductValidationError | null {
        const { data } = item;

        if (!data.image_link || !data.image_link?.trim().length) {
            return {
                code: ProductValidationErrorCode.MISSING_IMAGE,
                field: 'image_link',
                message: 'Thiểu ảnh'
            };
        }
        return null;
    }

    private _validateDescription(item: IFacebookCatalogItemBatchRequest): IProductValidationError | null {
        const { data } = item;

        if (!data.description || !data.description?.trim().length) {
            return {
                code: ProductValidationErrorCode.MISSING_DESCRIPTION,
                field: 'description',
                message: 'Thiếu mô tả'
            };
        }
        return null;
    }
}