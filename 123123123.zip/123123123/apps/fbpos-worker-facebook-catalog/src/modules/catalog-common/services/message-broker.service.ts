import { AmqpConnection } from '@golevelup/nestjs-rabbitmq';
import {
  EventTypes,
  KvLogger, KvRabbitMQException, RabbitMQConfigCatalogSendProductUpdates, RabbitMQConfigCheckProductCatalogUpdates, RabbitMQConfigKvAuditTrail,
  RabbitMQConfigKvReindexMongoDb, RabbitMqConfigNotification, RabbitMQConfigReSyncAllProductChange, sleep, SocialTypes
} from '@kiotviet-facebook-services/common';
import { Injectable } from '@nestjs/common';
import { pick } from 'lodash';
import { IMessageBrokerService } from '../interfaces/message-broker.interface';
import { ICheckHandlesStatusJob, ISyncProductsCatalog } from '../interfaces/sync-products-catalog.interface';
import { FbCatalogConnectionDocument, FbCatalogConnectionService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { CatalogItemMethodEnum } from '@kiotviet-facebook-services/facebook-sdk';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
const config = require('config');

@Injectable()
export class MessageBrokerService implements IMessageBrokerService {
  private readonly MAX_RETRY = 5;
  private readonly DELAY_MS = 5000;

  private readonly _rabbitMQConfig;

  constructor(
    private readonly _logger: KvLogger,
    private readonly _amqpConnection: AmqpConnection,
    private readonly _fbCatalogConnectionService: FbCatalogConnectionService,
  ) {
    this._rabbitMQConfig = config.get('rabbitMQ');
  }
  prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

  publishFacebookCatalogIndexEvent(): void {
    this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMQConfigKvReindexMongoDb.ROUTING_KEY, {
      SocialType: SocialTypes.FACEBOOK_CATALOG
    }).catch(err => {
      this._logger.error(`${this.prefixLog('publishIndexEvent')} fail`,
        new KvRabbitMQException(err.stack), {
        SourceContext: 'publishIndexEvent',
        ErrorContext: pick(err, ['message', 'stack'])
      });
    });
  }

  publishAuditLog(payload: ISyncProductsCatalog, catalogName = ''): void {
    this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMQConfigKvAuditTrail.ROUTING_KEY, {
      EventType: EventTypes.SendProductCatalog,
      SocialId: payload.pageId,
      RetailerInfo: {
        Id: payload.retailerId,
        UserId: payload.userId || -1,
        ...payload.retailerCode && { Code: payload.retailerCode }
      },
      Data: {
        catalogName,
        catalogId: payload.catalogId,
        isAutoSync: payload.isAutoSync
      },
      ProductData: payload.data
    }).catch(err => {
      this._logger.error(`${this.prefixLog('publishAuditLog')} fail`,
        new KvRabbitMQException(err.stack), {
        SourceContext: 'publishAuditLog',
        ErrorContext: pick(err, ['message', 'stack'])
      });
    });
  }

  publishRetryEvent(payload: ISyncProductsCatalog): void {
    if ((payload.retryTime || 0) > this.MAX_RETRY) {
      return;
    }
    sleep(this.DELAY_MS).then(res => {
      this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMQConfigCatalogSendProductUpdates.ROUTING_KEY,
        { ...payload, retryTime: (payload.retryTime || 0) + 1 }
      ).catch(err => {
        this._logger.error(`${this.prefixLog('publishRetryEvent')} fail`,
          new KvRabbitMQException(err.stack), {
          SourceContext: 'publishRetryEvent',
          ErrorContext: pick(err, ['message', 'stack'])
        });
      });
    });
  }

  publishSyncProductsCatalog(payload: ISyncProductsCatalog) {
    this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMQConfigCatalogSendProductUpdates.ROUTING_KEY, payload).catch(err => {
      this._logger.error(`${this.prefixLog('publishSyncProductsCatalog')} fail`,
        new KvRabbitMQException(err.stack), {
        SourceContext: 'publishSyncProductsCatalog',
        Context: { ...payload },
        ErrorContext: pick(err, ['message', 'stack'])
      });
    });
  }

  publishCheckProductCatalogUpdates(catalog: FbCatalogConnectionDocument) {
    this._amqpConnection.publish(this._rabbitMQConfig.mainExchange,
      `${RabbitMQConfigCheckProductCatalogUpdates.ROUTING_KEY}`,
      pick(catalog, ['catalogId', 'retailerId', 'pageId', 'branchId', 'businessName'])
    ).catch(err => {
      this._logger.error(`${this.prefixLog('publishCheckProductCatalogUpdates')} fail`,
        new KvRabbitMQException(err.stack), {
        SourceContext: 'publishCheckProductCatalogUpdates',
        Context: { catalog },
        ErrorContext: pick(err, ['message', 'stack'])
      });
    });
  }

  publishSuccessfullySendProductUpdatesCatalogNotification(payload: ICheckHandlesStatusJob, method: CatalogItemMethodEnum, totalProducts = 0, totalSuccess = 0) {
    this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigNotification.ROUTING_KEY, {
      PageId: payload.pageId,
      CatalogId: payload.catalogId,
      RetailerId: payload.retailerId,
      Handle: payload.handle,
      SocialType: SocialTypes.FACEBOOK_CATALOG,
      TotalSuccesses: totalSuccess,
      TotalProducts: totalProducts,
      Method: method,
      EventType: EventTypes.SuccessfullySendProductUpdatesCatalog
    }).catch(err => {
      this._logger.error(`${this.prefixLog('_sentEventMQToNotification')} fail`,
        new KvRabbitMQException(err.stack), {
        SourceContext: '_sentEventMQToNotification',
        Context: { ...payload, totalProducts },
        ErrorContext: pick(err, ['message', 'stack'])
      });
    });
  }

  publishNotificationValidationProduct(payload: ISyncProductsCatalog, totalProducts = 0, totalValidations = 0) {
    this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigNotification.ROUTING_KEY, {
      PageId: payload.pageId,
      CatalogId: payload.catalogId,
      RetailerId: payload.retailerId,
      SocialType: SocialTypes.FACEBOOK_CATALOG,
      TotalValidations: totalValidations,
      TotalProducts: totalProducts,
      EventType: EventTypes.SuccessfullySendProductUpdatesCatalogWithValidation
    }).catch(err => {
      this._logger.error(`${this.prefixLog('publishNotificationValidationProduct')} fail`,
        new KvRabbitMQException(err.stack), {
        SourceContext: 'publishNotificationValidationProduct',
        Context: { ...payload, totalProducts },
        ErrorContext: pick(err, ['message', 'stack'])
      });
    });
  }

  async publishReSyncAllProductChange(retailerId: number, catalogId: string, pageId: string, ids?: string[]): Promise<void> {
    const prefixLog = this.prefixLog('publishReSyncAllProductChange');
    const logInput: IKvLogInput = {
      MessageTemplate: { retailerId, catalogId, pageId, idsCount: ids?.length || 0 },
      Properties: {
        'Kv.SocialId': pageId,
        'Kv.SocialType': SocialTypes.FACEBOOK_CATALOG,
        SourceContext: prefixLog,
        _startTime: Date.now()
      }
    };

    this._logger.info(logInput, `${prefixLog} start processing`);

    try {
      const catalogConnection = await this._fbCatalogConnectionService.getCatalogConnection(retailerId, catalogId, pageId);
      
      if (!catalogConnection) {
        this._logger.warn(logInput, `${prefixLog} catalog connection not found`);
        return;
      }

      const payload = {
        ...catalogConnection,
        ...(ids && { ids }),
        isAutoSync: true
      };

      await this._amqpConnection.publish(
        this._rabbitMQConfig.mainExchange,
        RabbitMQConfigReSyncAllProductChange.ROUTING_KEY,
        payload
      );

      this._logger.info(logInput, `${prefixLog} success`);
    } catch (err) {
      this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
      throw err;
    }
  }

}