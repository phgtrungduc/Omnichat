import { CommonModule } from '@kiotviet-facebook-services/common';
import { FacebookSdkModule } from '@kiotviet-facebook-services/facebook-sdk';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { Module } from '@nestjs/common';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { CatalogUtilsService } from './services/catalog-utils.service';
import { MessageBrokerService } from './services/message-broker.service';
import { ProductCatalogValidatorService } from './services/product-catalog-validation.service';

@Module({
    imports: [
        CommonModule,
        KvRabbitMQModule,
        FacebookSdkModule,
        FbPosMasterRepositoryModule
    ],
    exports: [CatalogUtilsService, MessageBrokerService, ProductCatalogValidatorService],
    providers: [CatalogUtilsService, MessageBrokerService, ProductCatalogValidatorService],
})
export class CatalogCommonModule {
}
