import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRedisModule } from "@kiotviet-facebook-services/kv-redis";
import { KvKafkaModule } from "@kiotviet-facebook-services/kvkafka";
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { BullModule } from "@nestjs/bullmq";
import { Module } from '@nestjs/common';
import { CatalogCommonModule } from "../catalog-common/catalog-common.module";
import { PRODUCT_CATALOG_BULK_PRICE_SYNCES_PROCESSOR } from './constants';
import { BulkPriceSyncEsJobService } from './services/bulk-price-synces-job.service';
import { BulkPriceSyncesProcessor } from './services/bulk-price-synces.processor';
import { ProductCatalogPriceSyncEsService } from './services/product-catalog-price-synces.service';

@Module({
    imports: [
        CommonModule,
        KvRabbitMQModule,
        KvKafkaModule,
        CatalogCommonModule,
        KvRedisModule,
        BullModule.registerQueue({
            name: PRODUCT_CATALOG_BULK_PRICE_SYNCES_PROCESSOR,
        }),
    ],
    providers: [
        ProductCatalogPriceSyncEsService,
        BulkPriceSyncEsJobService,
        BulkPriceSyncesProcessor
    ],
})
export class ProductCatalogPriceSyncEsModule {
}
