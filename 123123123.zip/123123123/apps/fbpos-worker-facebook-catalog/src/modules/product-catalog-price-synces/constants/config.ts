export const PRODUCT_CATALOG_BULK_PRICE_SYNCES_PROCESSOR = 'product-catalog-bulk-price-synces-processor';
export const BULK_PRICE_SYNCES_QUEUE = 'bulk-price-synces';
export const REDIS_KEY_BULK_PRICE_SYNCES = 'synces-price-catalog:retailer:';