import { KvLogger, SocialTypes } from "@kiotviet-facebook-services/common";
import { CatalogItemMethodEnum, CatalogKvProductChangeEnum, KvProductCatalogStatusEnum } from "@kiotviet-facebook-services/facebook-sdk";
import { MongodbGroupService } from "@kiotviet-facebook-services/fbpos-master-repository";
import { KvRedisService } from "@kiotviet-facebook-services/kv-redis";
import { Processor, WorkerHost } from "@nestjs/bullmq";
import { Injectable } from "@nestjs/common";
import { Job } from "bullmq";
import { IKvLogInput } from "libs/shared/common/src/lib/logger/interfaces/logger.interface";
import moment from "moment";
import { MessageBrokerService } from "../../catalog-common/services/message-broker.service";
import { BULK_PRICE_SYNCES_QUEUE, PRODUCT_CATALOG_BULK_PRICE_SYNCES_PROCESSOR } from "../constants";
import { IPriceBookSyncEsEvent, IProductEsDto } from "../interfaces/kafka-payload.interface";
import { IBulkPriceSyncESQueuePayload } from "../interfaces/message-payload.interface";

const config = require('config');

@Processor(PRODUCT_CATALOG_BULK_PRICE_SYNCES_PROCESSOR)
@Injectable()
export class BulkPriceSyncesProcessor extends WorkerHost {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _kvRedisService: KvRedisService,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _messageBrokerService: MessageBrokerService
    ) {
        super();
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async process(job: Job<IBulkPriceSyncESQueuePayload, any, string>): Promise<any> {
        const { name, data } = job;
        const prefixLog = this.prefixLog('process');

        const logInput: IKvLogInput = {
            MessageTemplate: { data, queueName: name },
            Properties: {
                'Kv.RetailerId': data.retailerId,
                'Kv.SocialId': data.pageId,
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        switch (name) {
            case BULK_PRICE_SYNCES_QUEUE:
                await this._handlerBulkPriceSyncES(data);
                break;
            default:
                break;
        }
        this._logger.info(logInput, `${prefixLog} success`);
    }

    private async _handlerBulkPriceSyncES(data: IBulkPriceSyncESQueuePayload) {
        const prefixLog = this.prefixLog('_handlerBulkPriceSyncES');
        const baseInfoLog = { Context: { data }, SourceContext: '_handlerBulkPriceSyncES' };
        const { retailerId, catalogId, pageId, redisKey } = data;
        if (!catalogId || !retailerId || !pageId || !redisKey) {
            this._logger.warn(`${prefixLog} warning: pageId or retailerId or catalogId or redisKey is required`, baseInfoLog);
            return Promise.resolve();
        }

        const max = Date.now();
        const min = moment().startOf('days').valueOf();
        const delayValues = await this._kvRedisService.getListRangeByScore(redisKey, min, max);
        const payloads = delayValues.map(value => JSON.parse(value) as IPriceBookSyncEsEvent);
        await this._kvRedisService.removeRangeByScore(redisKey, min);
        if (payloads?.length) {
            const syncEsPricesProductUpdated = this._getLatestUniqueProducts(payloads);

            const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
            const productCatalogsColl = db.collection(this._mongodbGroupService.productCatalogsCollName);
            const productCatalogs = await productCatalogsColl
                .find({ pageId, catalogId, retailerId, id: { $in: syncEsPricesProductUpdated.map(x => x.Code) } })
                .toArray();

            const [publishProducts, invalidationProducts] = productCatalogs.reduce((acc, product) => {
                const hasValidationStatus = product.kvStatus === KvProductCatalogStatusEnum.VALIDATION_ERROR ||
                    product.kvStatus === KvProductCatalogStatusEnum.VALIDATION_SUCCESS;
                acc[hasValidationStatus ? 1 : 0].push(product);
                return acc;
            }, [[], []]);
            let data = syncEsPricesProductUpdated.map(item => {
                const price = item.ProductPriceBookDetail?.[0].Price || item.BasePrice || 0;
                const exists = publishProducts.find(product => product.id === item.Code);
                const isRequestDeletedInCatalog = CatalogItemMethodEnum.DELETE === exists?.method;
                const isChangeProductCode = exists?.kvProductChange?.code && exists?.kvProductChange?.code !== exists?.id;
                const productWasRemovedOrUnActive = exists?.kvProductChange?.isRemove || exists?.kvProductChange?.isActive === false || exists?.kvProductChange?.allowsSale === false;
                if (!exists || isChangeProductCode || isRequestDeletedInCatalog || productWasRemovedOrUnActive) {
                    return null;
                }
                return {
                    method: CatalogItemMethodEnum.UPDATE,
                    data: { id: item.Code, price: `${price} VND` }
                }
            })
            data = data.filter(item => !!item);
            if (data?.length) {
                this._messageBrokerService.publishSyncProductsCatalog({
                    branchId: 0,
                    catalogId,
                    data,
                    pageId,
                    retailerId,
                    source: 'product-catalog-price-synces'
                });
            }

            if (invalidationProducts.length > 0) {
                await this._handleValidationProducts(invalidationProducts, syncEsPricesProductUpdated, productCatalogsColl);
            }

            await this._kvRedisService.removeByValue(redisKey, delayValues);
        }
    }

    private _getLatestUniqueProducts(data: IPriceBookSyncEsEvent[]): IProductEsDto[] {
        const productMap: Map<number, any> = new Map();

        data.forEach(item => {
            item.Products.forEach(product => {
                if (!productMap.has(product.Id)) {
                    productMap.set(product.Id, { ...product, SentTime: item.SentTime });
                } else {
                    const existingProduct = productMap.get(product.Id);
                    if (new Date(existingProduct.SentTime).getTime() < new Date(item.SentTime).getTime()) {
                        productMap.set(product.Id, { ...product, SentTime: item.SentTime });
                    }
                }
            });
        });

        return Array.from(productMap.values());
    }

    private async _handleValidationProducts(
        productsToValidate: any[],
        syncEsPricesProductUpdated: IProductEsDto[],
        productCatalogsColl: any
    ) {
        const bulkOperations = [];
        for (const product of productsToValidate) {
            const updatedProduct = syncEsPricesProductUpdated.find(x => x.Code === product.id);
            if (updatedProduct) {
                const price = updatedProduct.ProductPriceBookDetail?.[0].Price || updatedProduct.BasePrice || 0;

                bulkOperations.push({
                    updateOne: {
                        filter: { _id: product._id },
                        update: {
                            $set: {
                                'kvProductChange.price': price,
                                'kvProductChange.isUpdate': true,
                                kvProductChangeType: CatalogKvProductChangeEnum.UPDATE
                            }
                        }
                    }
                });
            }
        }

        if (bulkOperations.length > 0) {
            await productCatalogsColl.bulkWrite(bulkOperations);
        }
    }

}
