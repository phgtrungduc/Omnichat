import { KvBaseException, KvLogger, SocialTypes } from '@kiotviet-facebook-services/common';
import { KvRedisService } from '@kiotviet-facebook-services/kv-redis';
import { KvKafkaService } from '@kiotviet-facebook-services/kvkafka';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject, Injectable } from '@nestjs/common';
import * as bfj from 'bfj';
import { EachMessagePayload } from 'kafkajs';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
import { REDIS_KEY_BULK_PRICE_SYNCES } from '../constants';
import { IPriceBookSyncEsEvent } from '../interfaces/kafka-payload.interface';
import { IBulkPriceSyncESQueuePayload } from '../interfaces/message-payload.interface';
import { BulkPriceSyncEsJobService } from './bulk-price-synces-job.service';

const config = require('config');

@Injectable()
export class ProductCatalogPriceSyncEsService {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _bulkPriceSyncEsJobService: BulkPriceSyncEsJobService,
        private readonly _kvKafkaService: KvKafkaService,
        private readonly _kvRedisService: KvRedisService,
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
    ) {
        this._kvKafkaService.init(
            'product-catalog-price-synces',
            `${config.get('kafka')?.kafkaGroupId}-price-synces`,
            config.get('kafka')?.kafkaPriceEsTopic || 'Fbpos-ProductPriceSync',
            this._processPriceSyncES,
        );
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    private readonly _processPriceSyncES = async (payload: EachMessagePayload) => {
        const prefixLog = this.prefixLog('_processPriceSyncES');
        const { topic, message } = payload;
        try {
            let pricebookSyncEsPayload: IPriceBookSyncEsEvent = !topic ? message.value : JSON.parse(message.value.toString());
            pricebookSyncEsPayload = pricebookSyncEsPayload as IPriceBookSyncEsEvent;
            const logInput: IKvLogInput = {
                MessageTemplate: { pricebookSyncEsPayload },
                Properties: {
                    'Kv.RetailerId': pricebookSyncEsPayload?.RetailerId,
                    'Kv.BranchId': pricebookSyncEsPayload?.BranchId,
                    'Kv.SocialId': pricebookSyncEsPayload?.PageId,
                    'Kv.SocialType': SocialTypes.FACEBOOK,
                    SourceContext: prefixLog,
                    _startTime: Date.now()
                }
            }
            this._logger.info(logInput, `${prefixLog} received payload`);
            await this._saveToDelayQueue(pricebookSyncEsPayload);
            this._logger.info(logInput, `${prefixLog} received payload`);
        } catch (err) {
            this._logger.error({ MessageTemplate: { message, topic }, Error: new KvBaseException(err.stack) }, `${prefixLog} fail`);
        }
    };

    private async _saveToDelayQueue(messageDelay: IPriceBookSyncEsEvent) {
        const { RetailerId, CatalogId, PageId } = messageDelay;
        const redisKey = `${REDIS_KEY_BULK_PRICE_SYNCES}${RetailerId}:${CatalogId}`;

        await this._kvRedisService.addToList(redisKey, await bfj.stringify(messageDelay));
        const notificationQueue: IBulkPriceSyncESQueuePayload = {
            retailerId: RetailerId,
            catalogId: CatalogId,
            pageId: PageId,
            redisKey,
        };
        return this._bulkPriceSyncEsJobService.addJobBulkUpdatePriceSyncES(notificationQueue, {
            jobId: redisKey,
            removeOnComplete: true,
            attempts: 3,
            backoff: 10000,
            stackTraceLimit: 1,
            delay: 12 * 1000,
        });
    }

}
