export interface IPriceBookSyncEsEvent {
    BranchId: number;
    RetailerId: number;
    Products: IProductEsDto[];
    CatalogId: string;
    PageId: string;
    Group: string;
    SentTimeCatalog: string;
    EventName: string;
    Ids: string;
    Type: number;
    Advice: number;
    SentTime: string;
    ConnectionString: string;
}

export interface IProductEsDto {
    Id: number;
    Code: string;
    BasePrice: number;
    ProductPriceBookDetail: IProductPriceBookDetailEsDto[];
}

export interface IProductPriceBookDetailEsDto {
    PriceBookId: number;
    ProductId: number;
    Price: number;
}
