export interface IDelayMessagePayload {
    retailerId: number;
    orderId: string;
    pageId: string;
    prefixKey: string;
    catalogId?: string;
}

export interface IBulkPriceSyncESQueuePayload {
    pageId?: string;
    retailerId?: number;
    catalogId?: string;
    redisKey?: string,
}
