import { KvLogger } from "@kiotviet-facebook-services/common";
import { InjectQueue } from '@nestjs/bullmq';
import { Injectable } from '@nestjs/common';
import { ConfigService } from "@nestjs/config";
import { Queue } from 'bullmq';

const SCAN_TO_SYNC_PRODUCT_CATALOG = 'scan-to-sync-product-catalog';
const ONE_MINUTE_TS = 60 * 1000;

@Injectable()
export class CatalogScheduleJobService {

    constructor(
        @InjectQueue('catalog-schedule') private catalogScheduleJobQueue: Queue,
        private readonly _logger: KvLogger,
        private readonly configService: ConfigService,
    ) {
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async initCatalogScheduleJob() {
        let jobs = await this.catalogScheduleJobQueue.getJobSchedulers();
        jobs = jobs.filter(job => job.name === SCAN_TO_SYNC_PRODUCT_CATALOG);
        this._logger.info({ MessageTemplate: { jobs }, Properties: { SourceContext: this.prefixLog('initCatalogScheduleJob') } }, `[${SCAN_TO_SYNC_PRODUCT_CATALOG}] Found ${jobs.length} old jobs`);
        if (jobs.length !== 0) {
            await Promise.all(jobs.map(job => this.catalogScheduleJobQueue.removeJobScheduler(job.key)));
        }
        await this.catalogScheduleJobQueue.add(SCAN_TO_SYNC_PRODUCT_CATALOG, {}, {
            repeat: {
                every: this.configService.get('syncProductCatalogSchedule')?.every || ONE_MINUTE_TS * 15
            },
            removeOnComplete: true,
            removeOnFail: 100,
        });
    }
}
