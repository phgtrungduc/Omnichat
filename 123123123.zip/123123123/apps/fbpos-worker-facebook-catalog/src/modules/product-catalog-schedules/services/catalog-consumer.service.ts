import {
    KvLogger
} from '@kiotviet-facebook-services/common';
import {
    FbCatalogConnectionService
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Injectable } from '@nestjs/common';
import { Job } from 'bullmq';
import { MessageBrokerService } from '../../catalog-common/services/message-broker.service';

@Processor('catalog-schedule')
@Injectable()
export class CatalogConsumerService extends WorkerHost {

    constructor(
        private readonly _fbCatalogConnectionService: FbCatalogConnectionService,
        private readonly _messageBrokerService: MessageBrokerService,
        private readonly _logger: KvLogger) {
        super();
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async process(job: Job<any, any, string>): Promise<any> {
        const { name, data } = job;
        const prefixLog = this.prefixLog('process');
        const baseInfoLog = { Context: { data, queueName: name }, SourceContext: 'process' };

        this._logger.info(`${prefixLog} received payload`, baseInfoLog);
        await this._processScanAndPublishRabbitMq();
        this._logger.info(`${prefixLog} success`, baseInfoLog);
    }

    private async _processScanAndPublishRabbitMq() {
        const allActiveCatalog = await this._fbCatalogConnectionService.getAllActivateCatalogConnection();
        if (allActiveCatalog.length) {
            allActiveCatalog.forEach(catalog => {
                this._messageBrokerService.publishCheckProductCatalogUpdates(catalog);
            })
        }
    }

}
