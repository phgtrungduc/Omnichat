import { Module } from "@nestjs/common";
import { CatalogScheduleJobService } from "./services/catalog-schedule-job.service";
import { BullModule } from '@nestjs/bullmq';
import { CommonModule } from "@kiotviet-facebook-services/common";
import { CatalogConsumerService } from "./services/catalog-consumer.service";
import { KvRabbitMQModule } from "@kiotviet-facebook-services/rabbitmq";
import { FbPosMasterRepositoryModule } from "@kiotviet-facebook-services/fbpos-master-repository";
import { CatalogCommonModule } from "../catalog-common/catalog-common.module";

@Module({
    imports: [
        CommonModule,
        KvRabbitMQModule,
        CatalogCommonModule,
        FbPosMasterRepositoryModule,
        BullModule.registerQueue({
            name: 'catalog-schedule',
            defaultJobOptions: {
                removeOnComplete: true,
                removeOnFail: 100,
            },
        })
    ],
    controllers: [],
    providers: [CatalogScheduleJobService, CatalogConsumerService],
    exports: []
})
export class ProductCatalogScheduleModule {
    constructor(private readonly _catalogScheduleJobService: CatalogScheduleJobService) {
        _catalogScheduleJobService.initCatalogScheduleJob();
    }
}
