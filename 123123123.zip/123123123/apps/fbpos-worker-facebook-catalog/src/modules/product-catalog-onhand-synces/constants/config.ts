export const PRODUCT_CATALOG_BULK_ONHAND_SYNCES_PROCESSOR = 'product-catalog-bulk-onhand-synces-processor';
export const BULK_ONHAND_SYNCES_QUEUE = 'bulk-onhand-synces';
export const REDIS_KEY_BULK_ONHAND_SYNCES = 'synces-onhand-catalog:retailer:';