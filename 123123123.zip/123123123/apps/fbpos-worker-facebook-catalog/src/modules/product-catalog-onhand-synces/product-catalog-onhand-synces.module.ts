import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRedisModule } from "@kiotviet-facebook-services/kv-redis";
import { KvKafkaModule } from "@kiotviet-facebook-services/kvkafka";
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { BullModule } from "@nestjs/bullmq";
import { Module } from '@nestjs/common';
import { CatalogCommonModule } from "../catalog-common/catalog-common.module";
import { PRODUCT_CATALOG_BULK_ONHAND_SYNCES_PROCESSOR } from './constants';
import { BulkOnHandSyncEsJobService } from './services/bulk-onhand-synces-job.service';
import { BulkOnHandSyncEsProcessor } from './services/bulk-onhand-synces.processor';
import { ProductCatalogOnHandSyncEsService } from './services/product-catalog-onhand-synces.service';

@Module({
    imports: [
        CommonModule,
        KvRabbitMQModule,
        KvKafkaModule,
        CatalogCommonModule,
        KvRedisModule,
        BullModule.registerQueue({
            name: PRODUCT_CATALOG_BULK_ONHAND_SYNCES_PROCESSOR,
        }),
    ],
    providers: [
        ProductCatalogOnHandSyncEsService,
        BulkOnHandSyncEsJobService,
        BulkOnHandSyncEsProcessor
    ],
})
export class ProductCatalogOnHandSyncEsModule {
}
