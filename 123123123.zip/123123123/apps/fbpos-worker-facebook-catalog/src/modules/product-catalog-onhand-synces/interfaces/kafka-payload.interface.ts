export interface IProductBranchOnHand {
    BranchId: number;
    Onhand: number;
    IsInStock: boolean;
}

export interface IProductOnHandSyncES {
    Id: number;
    Code: string;
    BranchOnhand: IProductBranchOnHand[];
}

export interface IProductOnHandEsPayload {
    Products: IProductOnHandSyncES[];
    RetailerId: number;
    CatalogId: string;
    PageId: string;
    Group: string;
    LogId: string;
    Source: string;
    SentTime: string;

}
