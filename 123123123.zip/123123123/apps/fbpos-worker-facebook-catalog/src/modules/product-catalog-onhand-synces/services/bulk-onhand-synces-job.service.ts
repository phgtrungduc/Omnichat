import { InjectQueue } from '@nestjs/bullmq';
import { Injectable } from '@nestjs/common';
import { Queue } from 'bullmq';
import { BULK_ONHAND_SYNCES_QUEUE, PRODUCT_CATALOG_BULK_ONHAND_SYNCES_PROCESSOR } from '../constants';

@Injectable()
export class BulkOnHandSyncEsJobService {
    constructor(@InjectQueue(PRODUCT_CATALOG_BULK_ONHAND_SYNCES_PROCESSOR) private readonly bulkPriceSyncESQueue: Queue) {
    }

    async addJobBulkUpdateOnHandyncES(data: any, jobOptions = {
        removeOnComplete: true,
        attempts: 3,
        backoff: 10000,
        stackTraceLimit: 1,
        delay: 10 * 1000
    } as any) {
        await this.bulkPriceSyncESQueue.add(
            BULK_ONHAND_SYNCES_QUEUE,
            data,
            jobOptions
        );
    }
}
