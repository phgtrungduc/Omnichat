
import { KvLogger, SocialTypes } from "@kiotviet-facebook-services/common";
import { CatalogAvailabilityEnum, CatalogItemMethodEnum, CatalogKvProductChangeEnum, KvProductCatalogStatusEnum } from "@kiotviet-facebook-services/facebook-sdk";
import { MongodbGroupService } from "@kiotviet-facebook-services/fbpos-master-repository";
import { KvRedisService } from "@kiotviet-facebook-services/kv-redis";
import { Processor, WorkerHost } from "@nestjs/bullmq";
import { Injectable } from "@nestjs/common";
import { Job } from "bullmq";
import { IKvLogInput } from "libs/shared/common/src/lib/logger/interfaces/logger.interface";
import moment from "moment";
import { ProductValidationErrorCode } from "../../catalog-common/common/util";
import { MessageBrokerService } from "../../catalog-common/services/message-broker.service";
import { BULK_ONHAND_SYNCES_QUEUE, PRODUCT_CATALOG_BULK_ONHAND_SYNCES_PROCESSOR } from "../constants";
import { IProductOnHandEsPayload, IProductOnHandSyncES } from "../interfaces/kafka-payload.interface";
import { IBulkOnHandSyncESQueuePayload } from "../interfaces/message-payload.interface";

const config = require('config');

@Processor(PRODUCT_CATALOG_BULK_ONHAND_SYNCES_PROCESSOR)
@Injectable()
export class BulkOnHandSyncEsProcessor extends WorkerHost {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _kvRedisService: KvRedisService,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _messageBroker: MessageBrokerService,
    ) {
        super();
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async process(job: Job<IBulkOnHandSyncESQueuePayload, any, string>): Promise<any> {
        const { name, data } = job;
        const prefixLog = this.prefixLog('process');
        const logInput: IKvLogInput = {
            MessageTemplate: { data, queueName: name },
            Properties: {
                'Kv.RetailerId': data.retailerId,
                'Kv.SocialId': data.pageId,
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);
        switch (name) {
            case BULK_ONHAND_SYNCES_QUEUE:
                await this._handlerBulkOnHandSyncES(data);
                break;
            default:
                break;
        }
        this._logger.info(logInput, `${prefixLog} success`);
    }

    private async _handlerBulkOnHandSyncES(data: IBulkOnHandSyncESQueuePayload) {
        const { retailerId, catalogId, pageId, redisKey } = data;

        if (!catalogId || !retailerId || !pageId || !redisKey) {
            return Promise.resolve();
        }

        const max = Date.now();
        const min = moment().startOf('days').valueOf();
        const delayValues = await this._kvRedisService.getListRangeByScore(redisKey, min, max);
        const payloads = delayValues.map(value => JSON.parse(value) as IProductOnHandEsPayload);
        await this._kvRedisService.removeRangeByScore(redisKey, min);
        if (payloads?.length) {
            const syncEsOnHandProductUpdated = this._getLatestUniqueProducts(payloads);

            const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
            const productCatalogsColl = db.collection(this._mongodbGroupService.productCatalogsCollName);
            const productCatalogs = await productCatalogsColl
                .find({ pageId, catalogId, retailerId, id: { $in: syncEsOnHandProductUpdated.map(x => x.Code) } })
                .toArray();
            const [publishProducts, invalidationProducts] = productCatalogs.reduce((acc, product) => {
                const hasValidationStatus = product.kvStatus === KvProductCatalogStatusEnum.VALIDATION_ERROR ||
                    product.kvStatus === KvProductCatalogStatusEnum.VALIDATION_SUCCESS;
                acc[hasValidationStatus ? 1 : 0].push(product);
                return acc;
            }, [[], []]);

            let data = syncEsOnHandProductUpdated.map(item => {
                const onHand = item.BranchOnhand?.[0];
                const exists = publishProducts.find(product => product.id === item.Code);
                const isRequestDeletedInCatalog = CatalogItemMethodEnum.DELETE === exists?.method;
                const isChangeProductCode = exists?.kvProductChange?.code && exists?.kvProductChange?.code !== exists?.id;
                const productWasRemovedOrUnActive = exists?.kvProductChange?.isRemove || exists?.kvProductChange?.isActive === false || exists?.kvProductChange?.allowsSale === false;
                if (!exists || isChangeProductCode || isRequestDeletedInCatalog || productWasRemovedOrUnActive) {
                    return null;
                }
                return {
                    method: CatalogItemMethodEnum.UPDATE,
                    data: {
                        id: item.Code,
                        inventory: onHand.Onhand,
                        quantity_to_sell_on_facebook: onHand.Onhand,
                        availability: onHand.Onhand > 0 ? CatalogAvailabilityEnum.IN_STOCK : CatalogAvailabilityEnum.OUT_OF_STOCK
                    }
                }
            })
            data = data.filter(item => !!item);
            if (data?.length) {
                this._messageBroker.publishSyncProductsCatalog({
                    branchId: 0,
                    catalogId,
                    data,
                    pageId,
                    retailerId,
                    source: 'product-catalog-onhand-synces'
                });
            }

            if (invalidationProducts.length > 0) {
                const productCodesForValidationSuccess = await this._handleValidationProducts(invalidationProducts, syncEsOnHandProductUpdated, productCatalogsColl);
                
                // Publish products that have VALIDATION_SUCCESS status for re-sync
                if (productCodesForValidationSuccess?.length) {
                    await this._messageBroker.publishReSyncAllProductChange(
                        retailerId,
                        catalogId,
                        pageId,
                        productCodesForValidationSuccess
                    );
                }
            }

            await this._kvRedisService.removeByValue(redisKey, delayValues);
        }
    }

    private _getLatestUniqueProducts(data: IProductOnHandEsPayload[]): IProductOnHandSyncES[] {
        const productMap: Map<number, any> = new Map();
        data.forEach(item => {
            item.Products.forEach(product => {
                if (!productMap.has(product.Id)) {
                    productMap.set(product.Id, { ...product, SentTime: item.SentTime });
                } else {
                    const existingProduct = productMap.get(product.Id);
                    if (new Date(existingProduct.SentTime).getTime() < new Date(item.SentTime).getTime()) {
                        productMap.set(product.Id, { ...product, SentTime: item.SentTime });
                    }
                }
            });
        });

        return Array.from(productMap.values());
    }

    private async _handleValidationProducts(
        productsToValidate: any[],
        syncEsOnHandProductUpdated: IProductOnHandSyncES[],
        productCatalogsColl: any
    ) {
        const bulkOperations = [];
        const productCodesToSync = [];

        for (const product of productsToValidate) {
            const updatedProduct = syncEsOnHandProductUpdated.find(x => x.Code === product.id);
            if (!updatedProduct) continue;

            const onHand = updatedProduct.BranchOnhand?.[0];
            const { updateFields, shouldSyncProduct } = this._buildValidationUpdateFields(product, onHand);

            if (shouldSyncProduct) {
                productCodesToSync.push(product.id);
            }

            bulkOperations.push({
                updateOne: {
                    filter: { _id: product._id },
                    update: { $set: updateFields }
                }
            });
        }

        if (bulkOperations.length > 0) {
            await productCatalogsColl.bulkWrite(bulkOperations);
        }

        return productCodesToSync;
    }

    private _buildValidationUpdateFields(product: any, onHand: any) {
        const updateFields: any = {
            'kvProductChange.onhand': onHand.Onhand,
            'kvProductChange.isUpdate': true,
            kvProductChangeType: CatalogKvProductChangeEnum.UPDATE
        };

        let shouldSyncProduct = false;

        if (product.validationErrors?.length) {
            const validationErrors = product.validationErrors.map(error => {
                if (error.error_type === ProductValidationErrorCode.INVALID_INVENTORY) {
                    return { ...error, isResolved: onHand.Onhand > 0 };
                }
                return error;
            });

            const allErrorsResolved = validationErrors.every(error => error.isResolved === true);
            updateFields.validationErrors = validationErrors;
            updateFields.kvStatus = allErrorsResolved
                ? KvProductCatalogStatusEnum.VALIDATION_SUCCESS
                : KvProductCatalogStatusEnum.VALIDATION_ERROR;
            
            if (allErrorsResolved) {
                shouldSyncProduct = true;
            }
        } else if (product.kvStatus === KvProductCatalogStatusEnum.VALIDATION_SUCCESS) {
            shouldSyncProduct = true;
        }

        return { updateFields, shouldSyncProduct };
    }



}
