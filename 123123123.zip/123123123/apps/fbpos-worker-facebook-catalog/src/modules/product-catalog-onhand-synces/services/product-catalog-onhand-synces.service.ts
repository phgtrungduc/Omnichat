import { KvBaseException, KvLogger, SocialTypes } from '@kiotviet-facebook-services/common';
import { KvRedisService } from '@kiotviet-facebook-services/kv-redis';
import { KvKafkaService } from '@kiotviet-facebook-services/kvkafka';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject, Injectable } from '@nestjs/common';
import * as bfj from 'bfj';
import { EachMessagePayload } from 'kafkajs';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
import { REDIS_KEY_BULK_ONHAND_SYNCES } from '../constants';
import { IProductOnHandEsPayload } from '../interfaces/kafka-payload.interface';
import { IBulkOnHandSyncESQueuePayload } from '../interfaces/message-payload.interface';
import { BulkOnHandSyncEsJobService } from './bulk-onhand-synces-job.service';

const config = require('config');

@Injectable()
export class ProductCatalogOnHandSyncEsService {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _bulkOnHandSyncEsJobService: BulkOnHandSyncEsJobService,
        private readonly _kvKafkaService: KvKafkaService,
        private readonly _kvRedisService: KvRedisService,
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
    ) {
        this._kvKafkaService.init(
            'product-catalog-onhand-synces',
            `${config.get('kafka')?.kafkaGroupId}-onhand-synces`,
            config.get('kafka')?.kafkaOnHandEsTopic || 'Fbpos-ProductOnhandSync',
            this._processOnHandES,
        );
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    private readonly _processOnHandES = async (payload: EachMessagePayload) => {
        const prefixLog = this.prefixLog('_processOnHandES');
        const { topic, message } = payload;


        try {
            let productOnHandEsPayload: IProductOnHandEsPayload = !topic ? message.value : JSON.parse(message.value.toString());
            productOnHandEsPayload = productOnHandEsPayload as IProductOnHandEsPayload;
            const logInput: IKvLogInput = {
                MessageTemplate: { productOnHandEsPayload },
                Properties: {
                    'Kv.RetailerId': productOnHandEsPayload.RetailerId,
                    'Kv.SocialId': productOnHandEsPayload.PageId,
                    'Kv.SocialType': SocialTypes.FACEBOOK,
                    SourceContext: prefixLog,
                    _startTime: Date.now()
                }
            }
            this._logger.info(logInput, `${prefixLog} received payload`);
            await this._saveToDelayQueue(productOnHandEsPayload);
            this._logger.info(logInput, `${prefixLog} success`);

        } catch (err) {
            this._logger.error({ MessageTemplate: { message, topic }, Error: new KvBaseException(err.stack) }, `${prefixLog} fail`);
        }
    };

    private async _saveToDelayQueue(messageDelay: IProductOnHandEsPayload) {
        const { RetailerId, CatalogId, PageId } = messageDelay;
        const redisKey = `${REDIS_KEY_BULK_ONHAND_SYNCES}${RetailerId}:${CatalogId}`;

        await this._kvRedisService.addToList(redisKey, await bfj.stringify(messageDelay));
        const notificationQueue: IBulkOnHandSyncESQueuePayload = {
            retailerId: RetailerId,
            catalogId: CatalogId,
            pageId: PageId,
            redisKey,
        };
        return this._bulkOnHandSyncEsJobService.addJobBulkUpdateOnHandyncES(notificationQueue, {
            jobId: redisKey,
            removeOnComplete: true,
            attempts: 3,
            backoff: 10000,
            stackTraceLimit: 1,
            delay: 10 * 1000,
        });
    }

}
