export * from "./catalog-product.interface";
export * from "./catalog-service.interface";