import {
    CapabilityToReviewStatusEnum
} from "@kiotviet-facebook-services/facebook-sdk";

export interface ICatalogUpdateProductReview {
    PageId: string;
    Product: IProductReview;
}

export interface IProductReview {
    product_item_id: string;
    status: CapabilityToReviewStatusEnum
}

