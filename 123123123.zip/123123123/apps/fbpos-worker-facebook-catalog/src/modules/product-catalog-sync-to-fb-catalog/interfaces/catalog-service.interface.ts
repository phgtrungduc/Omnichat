export interface ICatalogService {
    createOrUpdateProducts(catalogId: string, data: any): Promise<any>;
    getLatestCatalogUserToken(retailerId: string, catalogId: string): Promise<any>;
    getCatalogConnection(retailerId: string, catalogId: string, pageId: string): Promise<any>;
  }