import { CommonModule } from '@kiotviet-facebook-services/common';
import { FacebookSdkModule } from '@kiotviet-facebook-services/facebook-sdk';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { LockModule } from '@kiotviet-facebook-services/lock';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { BullModule } from "@nestjs/bullmq";
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { CatalogCommonModule } from '../catalog-common/catalog-common.module';
import { PRODUCT_CATALOG_PROCESSOR } from './constants';
import { ProductCatalogJobService } from './services/product-catalog-job.service';
import { ProductCatalogProcessor } from './services/product-catalog.processor';
import { ProductMapperService } from './services/product-mapper.service';
import { SyncProductsToFacebookCatalogService } from './services/sync-products-to-fb-catalog.service';

@Module({
    imports: [
        CommonModule,
        CatalogCommonModule,
        KvRabbitMQModule,
        FacebookSdkModule,
        LockModule,
        ConfigModule,
        FbPosMasterRepositoryModule,
        BullModule.registerQueue({
            name: PRODUCT_CATALOG_PROCESSOR,
            defaultJobOptions: {
                attempts: 6,
                backoff: 10000
            }
        }),
    ],
    providers: [
        ProductMapperService,
        ProductCatalogJobService,
        ProductCatalogProcessor,
        SyncProductsToFacebookCatalogService
    ]
})
export class ProductCatalogSyncToFbCatalogModule { }
