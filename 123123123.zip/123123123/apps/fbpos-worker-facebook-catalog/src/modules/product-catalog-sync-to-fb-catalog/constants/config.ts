import { HtmlToTextOptions } from 'html-to-text';

export const customHtmlTextOptions: HtmlToTextOptions = {
  wordwrap: false,
  uppercaseHeadings: false,
  selectors: [
    { selector: 'img', format: 'skip' },
    { selector: 'script', format: 'skip' },
    { selector: 'style', format: 'skip' },
    { selector: 'a', options: { hideLinkHrefIfSameAsText: true } },
  ],
  tags: {
    p: { format: 'block', lineBreaks: 1 },
    br: { format: 'block', lineBreaks: 1 },
    div: { format: 'block', lineBreaks: 1 },
    li: { format: 'block', lineBreaks: 1, prefix: '- ' },
    ul: { format: 'block', lineBreaks: 1 },
    ol: { format: 'block', lineBreaks: 1 },
    table: { format: 'block', lineBreaks: 1 },
    tr: { format: 'block', lineBreaks: 1 },
    td: { format: 'inline' },
    th: { format: 'inline' },
    b: { format: 'inline' },
    strong: { format: 'inline' },
    em: { format: 'inline' },
    i: { format: 'inline' },
    span: { format: 'inline' },
    a: { format: 'inline' },
  }
};

export const PRODUCT_CATALOG_PROCESSOR = 'product-catalog-processor';
export const CHECK_PRODUCT_HANDLE_STATUS_QUEUE = 'check-product-handle-status';
