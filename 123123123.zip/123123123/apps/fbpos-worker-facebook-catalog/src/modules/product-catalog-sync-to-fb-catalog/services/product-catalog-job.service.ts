import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { Injectable } from '@nestjs/common';
import { PRODUCT_CATALOG_PROCESSOR, CHECK_PRODUCT_HANDLE_STATUS_QUEUE } from '../constants';
import { ICheckHandlesStatusJob } from '../../catalog-common/interfaces/sync-products-catalog.interface';

@Injectable()
export class ProductCatalogJobService {
    constructor(@InjectQueue(PRODUCT_CATALOG_PROCESSOR) private readonly productCatalogQueue: Queue) {
    }

    async addCheckProductHandleStatusJob(data: ICheckHandlesStatusJob, jobOptions = {
        attempts: 6,
        backoff: 10000,
        removeOnComplete: true,
        removeOnFail: 1000
    }) {
        await this.productCatalogQueue.add(
            CHECK_PRODUCT_HANDLE_STATUS_QUEUE,
            data,
            jobOptions
        );
    }
}
