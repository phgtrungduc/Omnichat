import { RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    KvBaseException,
    KvLogger,
    RabbitMQConfigCatalogSendProductUpdates
} from '@kiotviet-facebook-services/common';
import { CatalogItemsTypeEnum, FacebookCatalogService } from "@kiotviet-facebook-services/facebook-sdk";
import {
    FbCatalogConnectionService,
    FbCatalogUserTokenService
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { Injectable } from '@nestjs/common';
import { pick } from 'lodash';
import { IInvalidCatalogItem } from '../../catalog-common/interfaces/catalog-validation.interface';
import { ISyncProductsCatalog } from '../../catalog-common/interfaces/sync-products-catalog.interface';
import { CatalogUtilsService } from '../../catalog-common/services/catalog-utils.service';
import { MessageBrokerService } from '../../catalog-common/services/message-broker.service';
import { ProductCatalogValidatorService } from '../../catalog-common/services/product-catalog-validation.service';
import { ProductCatalogJobService } from './product-catalog-job.service';
import { ProductMapperService } from './product-mapper.service';

const config = require('config');

@Injectable()
export class SyncProductsToFacebookCatalogService {
    constructor(
        private readonly _logger: KvLogger,
        private readonly _fbCatalogUserTokenService: FbCatalogUserTokenService,
        private readonly _facebookCatalogService: FacebookCatalogService,
        private readonly _catalogUtilsService: CatalogUtilsService,
        private readonly _fbCatalogConnectionService: FbCatalogConnectionService,
        private readonly _productMapper: ProductMapperService,
        private readonly _messageBroker: MessageBrokerService,
        private readonly _productJobService: ProductCatalogJobService,
        private readonly _productCatalogValidatorService: ProductCatalogValidatorService
    ) {
        this._messageBroker.publishFacebookCatalogIndexEvent();
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigCatalogSendProductUpdates.ROUTING_KEY,
        queue: `fbpos-worker-facebook-catalog:${RabbitMQConfigCatalogSendProductUpdates.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _syncProductsToFacebookCatalog(payload: ISyncProductsCatalog) {
        const context = this._createLogContext('handleProductSync', payload);
        this._logger.info(`${this.prefixLog('_syncProductsToFacebookCatalog')} received payload`, context);

        try {
            await this._processProductSync(payload);
        } catch (error) {
            await this._handleSyncError(error, payload, context);
        }

        return Promise.resolve();
    }
    private async _processProductSync(payload: ISyncProductsCatalog): Promise<void> {
        if (!this._isValidPayload(payload)) {
            return;
        }

        const token = await this._getCatalogUserToken(payload);
        if (!token) {
            await this._handleMissingToken(payload);
            return;
        }

        let productsToSync = payload.data;

        // Temporarily disabled validation
        // if (payload.isNeedValidate) {
        //     const validationResult = await this._productCatalogValidatorService.validateProducts(payload.data);

        //     if (validationResult.invalidCatalogItems?.length > 0) {
        //         this._logger.warn(
        //             `${this.prefixLog('_processProductSync')} Some products failed validation`,
        //             {
        //                 Context: {
        //                     retailerId: payload.retailerId,
        //                     totalProducts: payload.data.length,
        //                     invalidCount: validationResult.invalidCatalogItems.length,
        //                     invalidProducts: validationResult.invalidCatalogItems
        //                 }
        //             }
        //         );

        //         await this._handleInvalidProducts(payload, validationResult.invalidCatalogItems);
        //         this._messageBroker.publishNotificationValidationProduct(payload, payload.totalProductsInBatch > 0 ? payload.totalProductsInBatch : payload.data.length, validationResult.invalidCatalogItems.length);
        //     }

        //     if (validationResult.validCatalogItems.length === 0) {
        //         this._logger.warn(
        //             `${this.prefixLog('_processProductSync')} No valid products to sync`,
        //             { Context: { retailerId: payload.retailerId } }
        //         );
        //         return;
        //     }

        //     productsToSync = validationResult.validCatalogItems;
        // }

        const updatedPayload = {
            ...payload,
            data: productsToSync
        };

        const response = await this._syncProductsToCatalog(updatedPayload, token);
        if (response.handles?.length) {
            await this._handleSuccessfulSync(updatedPayload, response.handles);
        }
    }

    private _isValidPayload(payload: ISyncProductsCatalog): boolean {
        const { catalogId, data } = payload;
        if (!catalogId || !data?.length) {
            this._logger.warn(`${this.prefixLog('_syncProductsToFacebookCatalog')} warning: catalogId or data is required`, { Context: { payload } });
            return false;
        }
        return true;
    }

    private async _getCatalogUserToken(payload: ISyncProductsCatalog): Promise<string | null> {
        const { retailerId, catalogId } = payload;
        const tokenData = await this._fbCatalogUserTokenService.getLatestCatalogUserToken(retailerId, catalogId);
        return tokenData?.token || null;
    }

    private async _syncProductsToCatalog(payload: ISyncProductsCatalog, token: string): Promise<any> {
        const { catalogId, data } = payload;
        return this._facebookCatalogService.createOrUpdateProducts(catalogId, {
            item_type: CatalogItemsTypeEnum.PRODUCT_ITEM,
            requests: data.map(item => this._productMapper.mapProductData(item)),
            access_token: token
        });
    }

    private async _handleSuccessfulSync(payload: ISyncProductsCatalog, handles: any[]): Promise<void> {
        const { catalogId, pageId, retailerId } = payload;

        await Promise.all([
            this._catalogUtilsService.savingProductCatalog(payload, handles),
            this._productJobService.addCheckProductHandleStatusJob({
                catalogId, pageId, retailerId,
                handle: handles[0]
            }),
            this._publishAuditLog(payload)
        ]);
    }

    private async _handleMissingToken(payload: ISyncProductsCatalog): Promise<void> {
        this._logger.warn(`${this.prefixLog('_syncProductsToFacebookCatalog')} warning: catalog token not found`, { Context: { payload } });
        await this._catalogUtilsService.savingProductCatalogWithErrorAPI(payload);
    }

    private async _handleSyncError(error: any, payload: ISyncProductsCatalog, context: any): Promise<void> {
        const errorResponse = error?.response;
        if (errorResponse?.data?.error) {
            await this._catalogUtilsService.savingProductCatalogWithErrorAPI(payload);
        }

        this._logger.error(
            `${this.prefixLog('_syncProductsToFacebookCatalog')} failed`,
            new KvBaseException(error.stack),
            {
                ...context,
                ErrorContext: pick(error, ['message', 'stack']),
                ...(errorResponse && { ErrorResponse: pick(errorResponse, ['status', 'data']) })
            }
        );

        await this._messageBroker.publishRetryEvent(payload);

    }

    private async _handleInvalidProducts(payload: ISyncProductsCatalog, invalidCatalogItems: IInvalidCatalogItem[]): Promise<void> {
        return await this._catalogUtilsService.savingInvalidProductCatalog(payload, invalidCatalogItems);
    }

    private async _publishAuditLog(payload: ISyncProductsCatalog): Promise<void> {
        const { retailerId, catalogId, pageId } = payload;
        const catalogConnection = await this._fbCatalogConnectionService.getCatalogConnection(retailerId, catalogId, pageId);
        await this._messageBroker.publishAuditLog(payload, catalogConnection?.catalogName);
    }

    private _createLogContext(functionName: string, payload: any): any {
        return {
            Context: { payload },
            SourceContext: functionName
        };
    }
}
