import { Injectable } from '@nestjs/common';
import { htmlToText } from 'html-to-text';
import { customHtmlTextOptions } from '../constants';

const _ = require('lodash');

@Injectable()
export class ProductMapperService {
  private readonly DEFAULT_IMAGE = 'https://cdn-pos1.kiotviet.vn/saleonline/product-default-44.svg';
  private readonly DEFAULT_ATTRIBUTE_UNIT_NAME = 'ĐVT';

  mapProductData(item: any): any {
    const clonedItem = _.cloneDeep(item);

    // TODO: Đưa vào hàm validate
    // if (clonedItem.data?.image_link === '') {
    //   clonedItem.data.image_link = this.DEFAULT_IMAGE;
    // }

    this._addUnitAttribute(clonedItem.data);

    clonedItem.data.id = `${clonedItem.data.id}`;
    delete clonedItem.data['kvProduct'];

    if (clonedItem.data?.description) {
      clonedItem.data.description = this._formatDescription(clonedItem.data.description);
    }

    return clonedItem;
  }

  private _formatDescription(description: string): string {
    return htmlToText(description, customHtmlTextOptions);
  }

  private _addUnitAttribute(data: any): void {
    if (data?.kvProduct?.kvUnit) {
      const newAttrUnit = `${this.DEFAULT_ATTRIBUTE_UNIT_NAME}:${data.kvProduct.kvUnit}`;
      data.additional_variant_attribute = !data.additional_variant_attribute ?
        newAttrUnit : `${data.additional_variant_attribute},${newAttrUnit}`;
    }
  }
}