import {
    KvCheckBatchStatusException,
    KvLogger,
    KvValidateException,
    SocialTypes
} from '@kiotviet-facebook-services/common';
import {
    BatchStatusEnum,
    FacebookCatalogService
} from "@kiotviet-facebook-services/facebook-sdk";
import { FbCatalogUserTokenService, MongodbGroupService } from "@kiotviet-facebook-services/fbpos-master-repository";
import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Injectable } from '@nestjs/common';
import { Job } from 'bullmq';
import { IKvLogInput } from "libs/shared/common/src/lib/logger/interfaces/logger.interface";
import { pick } from 'lodash';
import { ICheckHandlesStatusJob } from "../../catalog-common/interfaces/sync-products-catalog.interface";
import { CatalogUtilsService } from "../../catalog-common/services/catalog-utils.service";
import { MessageBrokerService } from "../../catalog-common/services/message-broker.service";
import { CHECK_PRODUCT_HANDLE_STATUS_QUEUE, PRODUCT_CATALOG_PROCESSOR } from "../constants";


@Processor(PRODUCT_CATALOG_PROCESSOR)
@Injectable()
export class ProductCatalogProcessor extends WorkerHost {
    readonly COMPLETED_STATUES = [BatchStatusEnum.FINISHED, BatchStatusEnum.CANCELED, BatchStatusEnum.ERROR]

    constructor(
        private readonly _fbCatalogUserTokenService: FbCatalogUserTokenService,
        private readonly _facebookCatalogService: FacebookCatalogService,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _logger: KvLogger,
        private readonly _catalogUtilsService: CatalogUtilsService,
        private readonly _messageBrokerService: MessageBrokerService,
    ) {
        super();
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async process(job: Job<ICheckHandlesStatusJob, any, string>): Promise<any> {
        const { name, data } = job;
        const prefixLog = this.prefixLog('process');
        const logInput: IKvLogInput = {
            MessageTemplate: { data, queueName: name },
            Properties: {
                'Kv.RetailerId': data.retailerId,
                'Kv.SocialId': data.pageId,
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);
        switch (name) {
            case CHECK_PRODUCT_HANDLE_STATUS_QUEUE:
                await this._handlerCheckProductHandleStatus(job);
                break;
            default:
                break;
        }
        this._logger.info(logInput, `${prefixLog} success`);
    }

    private async _handlerCheckProductHandleStatus(job: Job<ICheckHandlesStatusJob, any, string>) {
        const { data } = job;
        const prefixLog = this.prefixLog('_handlerCheckProductHandleStatus');
        const baseInfoLog = { Context: { data, queueName: job.name }, SourceContext: 'process' };
        const validateBatchRequest = 'Batch request not completed';
        try {
            const { catalogId, pageId, retailerId, handle } = data;

            const fbCatalogUserToken = await this._fbCatalogUserTokenService.getLatestCatalogUserToken(retailerId, catalogId);
            if (!fbCatalogUserToken?.token) {
                this._logger.warn(`${prefixLog} warning: catalog token not found`, baseInfoLog);
                return;
            }

            const batchRequestStatusResponse = await this._facebookCatalogService.checkBatchRequestStatus({
                catalogId,
                access_token: fbCatalogUserToken.token,
                handle
            })
            const { status, errors, warnings, errors_total_count } = batchRequestStatusResponse.data[0];
            if (!this.COMPLETED_STATUES.includes(status)) {
                throw new KvValidateException(validateBatchRequest);
            }

            const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
            const productCatalogsColl = db.collection(this._mongodbGroupService.productCatalogsCollName);
            let productCatalogs = await productCatalogsColl
                .find({ pageId, catalogId, retailerId, handles: handle })
                // .project({id: 1, product_catalog_id: 1, method: 1})
                .toArray();
            productCatalogs = await this._catalogUtilsService.getAdditionalDataProductCatalog(catalogId, fbCatalogUserToken.token, productCatalogs, 100, false);
            await this._catalogUtilsService.bulkUpdateProductCatalogWithNewData(catalogId, productCatalogs, productCatalogsColl, handle, warnings, errors);
            if (productCatalogs.length > 0) {
                const method = productCatalogs[0].method;
                this._messageBrokerService.publishSuccessfullySendProductUpdatesCatalogNotification(data, method, productCatalogs.length, productCatalogs.length - (errors_total_count || 0))
            }
        } catch (e) {
            if (validateBatchRequest != e.message) {
                this._logger.error(`${prefixLog} fail`, new KvCheckBatchStatusException(e.stack), {
                    ...e,
                    ErrorContext: pick(e, ['message', 'stack']),
                });
            }

            throw e;
        }
    }
}
