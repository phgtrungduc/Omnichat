import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRedisModule } from "@kiotviet-facebook-services/kv-redis";
import { KvKafkaModule } from "@kiotviet-facebook-services/kvkafka";
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { BullModule } from "@nestjs/bullmq";
import { Module } from '@nestjs/common';
import { CatalogCommonModule } from "../catalog-common/catalog-common.module";
import { PRODUCT_CATALOG_BULK_PRODUCT_DELETE_SYNCES_PROCESSOR } from './constants';
import { BulkProductDeleteSyncesProcessor } from './services/bulk-product-delete-synces.processor';
import { BulkProductDeleteSyncEsJobService } from './services/bulk-product-delete-synces.service';
import { ProductCatalogProductDeleteSyncEsService } from './services/product-catalog-product-delete-synces.service';

@Module({
    imports: [
        CommonModule,
        KvRabbitMQModule,
        KvKafkaModule,
        CatalogCommonModule,
        KvRedisModule,
        BullModule.registerQueue({
            name: PRODUCT_CATALOG_BULK_PRODUCT_DELETE_SYNCES_PROCESSOR,
        }),
    ],
    providers: [
        ProductCatalogProductDeleteSyncEsService,
        BulkProductDeleteSyncEsJobService,
        BulkProductDeleteSyncesProcessor
    ],
})
export class ProductCatalogProductDeleteSyncEsModule {
}
