import { InjectQueue } from '@nestjs/bullmq';
import { Injectable } from '@nestjs/common';
import { Queue } from 'bullmq';
import { BULK_PRODUCT_DELETE_SYNCES_QUEUE, PRODUCT_CATALOG_BULK_PRODUCT_DELETE_SYNCES_PROCESSOR } from '../constants';

@Injectable()
export class BulkProductDeleteSyncEsJobService {
    constructor(@InjectQueue(PRODUCT_CATALOG_BULK_PRODUCT_DELETE_SYNCES_PROCESSOR) private readonly bulkProductDeleteSyncESQueue: Queue) {
    }

    async addJobBulkProductDeleteSyncES(data: any, jobOptions = {
        removeOnComplete: true,
        attempts: 3,
        backoff: 10000,
        stackTraceLimit: 1,
        delay: 10 * 1000
    } as any) {
        await this.bulkProductDeleteSyncESQueue.add(
            BULK_PRODUCT_DELETE_SYNCES_QUEUE,
            data,
            jobOptions
        );
    }
}
