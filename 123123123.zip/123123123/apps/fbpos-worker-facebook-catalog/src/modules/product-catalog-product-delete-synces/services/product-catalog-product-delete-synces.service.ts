import { KvBaseException, KvLogger, SocialTypes } from "@kiotviet-facebook-services/common";
import { KvRedisService } from "@kiotviet-facebook-services/kv-redis";
import { KvKafkaService } from "@kiotviet-facebook-services/kvkafka";
import { Cache, CACHE_MANAGER } from "@nestjs/cache-manager";
import { Inject, Injectable } from "@nestjs/common";
import { EachMessagePayload } from "@nestjs/microservices/external/kafka.interface";
import * as bfj from 'bfj';
import { IKvLogInput } from "libs/shared/common/src/lib/logger/interfaces/logger.interface";
import { REDIS_KEY_BULK_PRODUCT_DELETE_SYNCES } from "../constants";
import { IProductDeleteDto, IProductDeleteSyncEsEvent } from "../interfaces/kafka-payload.interface";
import { IBulkProductDeleteSyncESQueuePayload } from "../interfaces/message-payload.interface";
import { BulkProductDeleteSyncEsJobService } from "./bulk-product-delete-synces.service";


const config = require('config');

@Injectable()
export class ProductCatalogProductDeleteSyncEsService {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _bulkProductDeleteSyncEsJobService: BulkProductDeleteSyncEsJobService,
        private readonly _kvKafkaService: KvKafkaService,
        private readonly _kvRedisService: KvRedisService,
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
    ) {
        this._kvKafkaService.init(
            'product-catalog-product-delete-catalog-synces',
            `${config.get('kafka')?.kafkaGroupId}-delete-synces`,
            config.get('kafka')?.kafkaProductDeleteEsTopic || 'Fbpos-Product-Delete',
            this._processProductDeleteSyncES,
        );
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    private readonly _processProductDeleteSyncES = async (payload: EachMessagePayload) => {
        const prefixLog = this.prefixLog('_processProductDeleteSyncES');
        const { topic, message } = payload;
        try {
            let productDeleteSyncEsPayload: IProductDeleteSyncEsEvent = !topic ? message.value : JSON.parse(message.value.toString());
            productDeleteSyncEsPayload = productDeleteSyncEsPayload as IProductDeleteSyncEsEvent;

            const logInput: IKvLogInput = {
                MessageTemplate: { productDeleteSyncEsPayload },
                Properties: {
                    'Kv.RetailerId': productDeleteSyncEsPayload.RetailerId,
                    'Kv.SocialId': productDeleteSyncEsPayload?.Products?.[0]?.PageId,
                    'Kv.SocialType': SocialTypes.FACEBOOK,
                    SourceContext: prefixLog,
                    _startTime: Date.now()
                }
            }
            this._logger.info(logInput, `${prefixLog} received payload`);
            await this._saveToDelayQueue(productDeleteSyncEsPayload);
            this._logger.info(logInput, `${prefixLog} success`);
        } catch (err) {
            this._logger.error({ MessageTemplate: { message, topic }, Error: new KvBaseException(err.stack) }, `${prefixLog} fail`);
        }
    };

    private async _saveToDelayQueue(messageDelay: IProductDeleteSyncEsEvent) {
        const { RetailerId, Products } = messageDelay;

        const productsByCatalog = Products.reduce((acc, product) => {
            const key = `${product.CatalogId}:${product.PageId}`;
            if (!acc[key]) {
                acc[key] = {
                    catalogId: product.CatalogId,
                    pageId: product.PageId,
                    products: []
                };
            }
            acc[key].products.push(product);
            return acc;
        }, {} as Record<string, { catalogId: string; pageId: string; products: IProductDeleteDto[] }>);

        const promises = Object.values(productsByCatalog).map(async ({ catalogId, pageId, products }) => {
            const redisKey = `${REDIS_KEY_BULK_PRODUCT_DELETE_SYNCES}${RetailerId}:${catalogId}`;

            await this._kvRedisService.addToList(redisKey, await bfj.stringify({
                RetailerId,
                CatalogId: catalogId,
                PageId: pageId,
                Products: products
            }));

            const notificationQueue: IBulkProductDeleteSyncESQueuePayload = {
                retailerId: RetailerId,
                catalogId,
                pageId,
                redisKey,
            };

            return this._bulkProductDeleteSyncEsJobService.addJobBulkProductDeleteSyncES(notificationQueue, {
                jobId: redisKey,
                removeOnComplete: true,
                attempts: 3,
                backoff: 10000,
                stackTraceLimit: 1,
                delay: 10 * 1000,
            });
        });

        await Promise.all(promises);
    }

}
