import { KvLogger, SocialTypes } from "@kiotviet-facebook-services/common";
import { CatalogItemMethodEnum } from "@kiotviet-facebook-services/facebook-sdk";
import { MongodbGroupService } from "@kiotviet-facebook-services/fbpos-master-repository";
import { KvRedisService } from "@kiotviet-facebook-services/kv-redis";
import { Processor, WorkerHost } from "@nestjs/bullmq";
import { Injectable } from "@nestjs/common";
import { Job } from "bullmq";
import { IKvLogInput } from "libs/shared/common/src/lib/logger/interfaces/logger.interface";
import moment from "moment";
import { MessageBrokerService } from "../../catalog-common/services/message-broker.service";
import { BULK_PRODUCT_DELETE_SYNCES_QUEUE, PRODUCT_CATALOG_BULK_PRODUCT_DELETE_SYNCES_PROCESSOR } from "../constants";
import { IProductDeleteSyncEsEvent } from "../interfaces/kafka-payload.interface";
import { IBulkProductDeleteSyncESQueuePayload } from "../interfaces/message-payload.interface";

const config = require('config');

@Processor(PRODUCT_CATALOG_BULK_PRODUCT_DELETE_SYNCES_PROCESSOR)
@Injectable()
export class BulkProductDeleteSyncesProcessor extends WorkerHost {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _kvRedisService: KvRedisService,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _messageBrokerService: MessageBrokerService
    ) {
        super();
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async process(job: Job<IBulkProductDeleteSyncESQueuePayload, any, string>): Promise<any> {
        const { name, data } = job;
        const prefixLog = this.prefixLog('process');
        const logInput: IKvLogInput = {
            MessageTemplate: { data, queueName: name },
            Properties: {
                'Kv.RetailerId': data?.retailerId,
                'Kv.SocialId': data?.pageId,
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);
        switch (name) {
            case BULK_PRODUCT_DELETE_SYNCES_QUEUE:
                await this._handlerBulkProductDeleteSyncES(data);
                break;
            default:
                break;
        }
        this._logger.info(logInput, `${prefixLog} success`);
    }

    private async _handlerBulkProductDeleteSyncES(data: IBulkProductDeleteSyncESQueuePayload) {
        const prefixLog = this.prefixLog('_handlerBulkProductDeleteSyncES');
        const baseInfoLog = { Context: { data }, SourceContext: '_handlerBulkProductDeleteSyncES' };
        const { retailerId, catalogId, pageId, redisKey } = data;

        if (!catalogId || !retailerId || !pageId || !redisKey) {
            return Promise.resolve();
        }

        const max = Date.now();
        const min = moment().startOf('days').valueOf();
        const delayValues = await this._kvRedisService.getListRangeByScore(redisKey, min, max);
        const payloads = delayValues.map(value => JSON.parse(value) as IProductDeleteSyncEsEvent);
        await this._kvRedisService.removeRangeByScore(redisKey, min);
        if (payloads?.length) {
            const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
            const productCatalogsColl = db.collection(this._mongodbGroupService.productCatalogsCollName);

            const deletedProducts = payloads.flatMap(payload => payload.Products);
            const productCatalogs = await productCatalogsColl
                .find({ pageId, catalogId, retailerId, id: { $in: deletedProducts.map(x => x.ProductCode) } })
                .toArray();

            let data = deletedProducts.map(item => {
                const exists = productCatalogs.find(product => product.id === item.ProductCode);
                if (!exists) {
                    return null;
                }
                return {
                    method: CatalogItemMethodEnum.DELETE,
                    data: { id: item.ProductCode }
                }
            });

            data = data.filter(item => !!item);
            if (data?.length) {
                this._messageBrokerService.publishSyncProductsCatalog({
                    branchId: 0,
                    catalogId,
                    data,
                    pageId,
                    retailerId,
                    source: 'product-catalog-delete-synces'
                })
            }

            await this._kvRedisService.removeByValue(redisKey, delayValues);
        }
    }

}
