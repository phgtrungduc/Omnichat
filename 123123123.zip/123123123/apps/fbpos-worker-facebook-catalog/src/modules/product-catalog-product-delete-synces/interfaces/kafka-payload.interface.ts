export interface IProductDeleteSyncEsEvent {
    RetailerId: number;
    Products: IProductDeleteDto[];
}

export interface IProductDeleteDto {
    BranchId: number;
    CatalogId: string;
    PageId: string;
    ProductId: number;
    ProductCode: string;
}