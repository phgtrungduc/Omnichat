export const PRODUCT_CATALOG_BULK_PRODUCT_DELETE_SYNCES_PROCESSOR = 'product-catalog-bulk-product-delete-synces-processor';
export const BULK_PRODUCT_DELETE_SYNCES_QUEUE = 'bulk-product-delete-synces';
export const REDIS_KEY_BULK_PRODUCT_DELETE_SYNCES = 'synces-product-delete-catalog:retailer:';