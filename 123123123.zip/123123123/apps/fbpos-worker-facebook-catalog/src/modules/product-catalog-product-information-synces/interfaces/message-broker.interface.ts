export interface IProductInformationMessageBrokerService {
    publishReSyncAllProductChange(retailerId: number, catalogId: string, pageId: string, ids?: string[]): Promise<void>;
} 