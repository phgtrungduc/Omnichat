export interface IFbposProductInforSyncMessage {
    RetailerId: number;
    Products: IFbposProductInforDTO[];
}

export interface IFbposProductInforDTO {
    CatalogId: string;
    PageId: string;
    KvProductId: number;
    KvProductCode: string;
    BranchId: number;
    KvProductChangeType: number;
} 