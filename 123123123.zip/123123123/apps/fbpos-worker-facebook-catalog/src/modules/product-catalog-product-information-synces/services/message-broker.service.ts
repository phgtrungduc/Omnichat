import { AmqpConnection } from '@golevelup/nestjs-rabbitmq';
import {  KvLogger, KvRabbitMQException, RabbitMQConfigReSyncAllProductChange, SocialTypes } from '@kiotviet-facebook-services/common';
import { FbCatalogConnectionService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { Injectable } from '@nestjs/common';
import { IProductInformationMessageBrokerService } from '../interfaces/message-broker.interface';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class ProductInformationMessageBrokerService implements IProductInformationMessageBrokerService {
    private readonly _rabbitMQConfig;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _fbCatalogConnectionService: FbCatalogConnectionService
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async publishReSyncAllProductChange(retailerId: number, catalogId: string, pageId: string, ids?: string[]): Promise<void> {
        const prefixLog = this.prefixLog('publishReSyncAllProductChange');
        const logInput: IKvLogInput = {
            MessageTemplate: { retailerId, catalogId, pageId, idsCount: ids?.length || 0 },
            Properties: {
                'Kv.SocialId': pageId,
                'Kv.SocialType': SocialTypes.FACEBOOK_CATALOG,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        };

        this._logger.info(logInput, `${prefixLog} start processing`);

        try {
            const catalogConnection = await this._fbCatalogConnectionService.getCatalogConnection(retailerId, catalogId, pageId);
            
            if (!catalogConnection) {
                this._logger.warn(logInput, `${prefixLog} catalog connection not found`);
                return;
            }

            const payload = {
                ...catalogConnection,
                ...(ids && { ids }),
                isAutoSync: true
            };

            await this._amqpConnection.publish(
                this._rabbitMQConfig.mainExchange,
                RabbitMQConfigReSyncAllProductChange.ROUTING_KEY,
                payload
            );

            this._logger.info(logInput, `${prefixLog} success`);
        } catch (err) {
            this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
            throw err;
        }
    }
} 