import {  KvLogger, SocialTypes } from "@kiotviet-facebook-services/common";
import { KvRedisService } from "@kiotviet-facebook-services/kv-redis";
import { KvKafkaService } from "@kiotviet-facebook-services/kvkafka";
import { Cache, CACHE_MANAGER } from "@nestjs/cache-manager";
import { Inject, Injectable } from "@nestjs/common";
import { EachMessagePayload } from "@nestjs/microservices/external/kafka.interface";
import * as bfj from 'bfj';
import { BulkProductInformationSyncEsJobService } from "./bulk-product-information-synces.service";
import { IFbposProductInforDTO, IFbposProductInforSyncMessage } from "../interfaces/kafka-payload.interface";
import { IBulkProductInformationSyncESQueuePayload } from "../interfaces/message-payload.interface";
import { REDIS_KEY_BULK_PRODUCT_INFORMATION_SYNCES } from "../constants";
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class ProductCatalogProductInformationSyncEsService {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _bulkProductInformationSyncEsJobService: BulkProductInformationSyncEsJobService,
        private readonly _kvKafkaService: KvKafkaService,
        private readonly _kvRedisService: KvRedisService,
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
    ) {
        this._kvKafkaService.init(
            'product-catalog-product-information-catalog-synces',
            `${config.get('kafka')?.kafkaGroupId}-information-synces`,
            config.get('kafka')?.kafkaProductInformationEsTopic || 'Fbpos-Product-Information',
            this._processProductInformationSyncES,
        );
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    private readonly _processProductInformationSyncES = async (payload: EachMessagePayload) => {
        const prefixLog = this.prefixLog('_processProductInformationSyncES');
        const { topic, message } = payload;
        
        try {
            let productInformationSyncEsPayload: IFbposProductInforSyncMessage = !topic ? message.value : JSON.parse(message.value.toString());
            productInformationSyncEsPayload = productInformationSyncEsPayload as IFbposProductInforSyncMessage;
            
            const logInput: IKvLogInput = {
                MessageTemplate: { topic, payload: productInformationSyncEsPayload },
                Properties: {
                    'Kv.SocialId': productInformationSyncEsPayload?.Products?.[0]?.PageId,
                    'Kv.SocialType': SocialTypes.FACEBOOK_CATALOG,
                    SourceContext: prefixLog,
                    _startTime: Date.now()
                }
            };

            this._logger.info(logInput, `${prefixLog} received payload`);
            
            await this._saveToDelayQueue(productInformationSyncEsPayload);
            
            this._logger.info(logInput, `${prefixLog} success`);
        } catch (err) {
            const logInput: IKvLogInput = {
                MessageTemplate: { topic, messageValue: !topic ? message.value : JSON.parse(message.value.toString()) },
                Properties: {
                    SourceContext: prefixLog,
                    _startTime: Date.now()
                },
                Error: err
            };
            
            this._logger.error(logInput, `${prefixLog} fail`);
            throw err;
        }
    };

    private async _saveToDelayQueue(messageDelay: IFbposProductInforSyncMessage): Promise<void> {
        const prefixLog = this.prefixLog('_saveToDelayQueue');
        const { RetailerId, Products } = messageDelay;

        const logInput: IKvLogInput = {
            MessageTemplate: { RetailerId, productsCount: Products?.length || 0 },
            Properties: {
                'Kv.SocialId': Products?.[0]?.PageId,
                'Kv.SocialType': SocialTypes.FACEBOOK_CATALOG,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        };

        this._logger.info(logInput, `${prefixLog} start processing`);

        const productsByCatalog = Products.reduce((acc, product) => {
            const key = `${product.CatalogId}:${product.PageId}`;
            if (!acc[key]) {
                acc[key] = {
                    catalogId: product.CatalogId,
                    pageId: product.PageId,
                    products: []
                };
            }
            acc[key].products.push(product);
            return acc;
        }, {} as Record<string, { catalogId: string; pageId: string; products: IFbposProductInforDTO[] }>);

        const promises = Object.values(productsByCatalog).map(async ({ catalogId, pageId, products }) => {
            const redisKey = `${REDIS_KEY_BULK_PRODUCT_INFORMATION_SYNCES}${RetailerId}:${catalogId}`;

            await this._kvRedisService.addToList(redisKey, await bfj.stringify({
                RetailerId,
                CatalogId: catalogId,
                PageId: pageId,
                Products: products
            }));

            const notificationQueue: IBulkProductInformationSyncESQueuePayload = {
                retailerId: RetailerId,
                catalogId,
                pageId,
                redisKey,
            };

            return this._bulkProductInformationSyncEsJobService.addJobBulkProductInformationSyncES(notificationQueue, {
                jobId: redisKey,
                removeOnComplete: true,
                attempts: 3,
                backoff: 10000,
                stackTraceLimit: 1,
                delay: 1 * 1000,
            });
        });

        await Promise.all(promises);

        this._logger.info(logInput, `${prefixLog} success`);
    }
} 