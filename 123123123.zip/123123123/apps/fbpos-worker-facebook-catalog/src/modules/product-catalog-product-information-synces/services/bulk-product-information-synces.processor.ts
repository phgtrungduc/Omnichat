import {
    
    KvLogger,
    SocialTypes
} from '@kiotviet-facebook-services/common';
import { KvRedisService } from "@kiotviet-facebook-services/kv-redis";
import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Injectable } from '@nestjs/common';
import { Job } from 'bullmq';
import moment from "moment";
import { BULK_PRODUCT_INFORMATION_SYNCES_QUEUE, PRODUCT_CATALOG_BULK_PRODUCT_INFORMATION_SYNCES_PROCESSOR } from "../constants";
import { IFbposProductInforSyncMessage } from '../interfaces/kafka-payload.interface';
import { IBulkProductInformationSyncESQueuePayload } from "../interfaces/message-payload.interface";
import { BulkProductInformationSyncEsJobService } from "./bulk-product-information-synces.service";
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

@Processor(PRODUCT_CATALOG_BULK_PRODUCT_INFORMATION_SYNCES_PROCESSOR)
@Injectable()
export class BulkProductInformationSyncesProcessor extends WorkerHost {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _kvRedisService: KvRedisService,
        private readonly _bulkProductInformationSyncEsJobService: BulkProductInformationSyncEsJobService
    ) {
        super();
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async process(job: Job<IBulkProductInformationSyncESQueuePayload, any, string>): Promise<any> {
        const { name, data } = job;
        const prefixLog = this.prefixLog('process');
        const logInput: IKvLogInput = {
            MessageTemplate: { data, queueName: name },
            Properties: {
                'Kv.SocialId': data?.pageId,
                'Kv.SocialType': SocialTypes.FACEBOOK_CATALOG,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        };

        this._logger.info(logInput, `${prefixLog} received payload`);

        try {
            switch (name) {
                case BULK_PRODUCT_INFORMATION_SYNCES_QUEUE:
                    await this._handlerBulkProductInformationSyncES(data);
                    break;
                default:
                    break;
            }
            
            this._logger.info(logInput, `${prefixLog} success`);
        } catch (err) {
            this._logger.error({ ...logInput, Error: err }, `${prefixLog} fail`);
            throw err;
        }
    }

    private async _handlerBulkProductInformationSyncES(data: IBulkProductInformationSyncESQueuePayload): Promise<void> {
        const prefixLog = this.prefixLog('_handlerBulkProductInformationSyncES');
        const { retailerId, catalogId, pageId, redisKey } = data;
        const logInput: IKvLogInput = {
            MessageTemplate: { data },
            Properties: {
                'Kv.SocialId': pageId,
                'Kv.SocialType': SocialTypes.FACEBOOK_CATALOG,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        };

        this._logger.info(logInput, `${prefixLog} start processing`);

        if (!catalogId || !retailerId || !pageId || !redisKey) {
            this._logger.warn(logInput, `${prefixLog} missing required parameters`);
            return Promise.resolve();
        }

        const max = Date.now();
        const min = moment().startOf('days').valueOf();
        const delayValues = await this._kvRedisService.getListRangeByScore(redisKey, min, max);
        const payloads = delayValues.map(value => JSON.parse(value) as IFbposProductInforSyncMessage);
        await this._kvRedisService.removeRangeByScore(redisKey, min);

        if (payloads?.length) {
            const informationProducts = payloads.flatMap(payload => payload.Products);
            const productCodes = informationProducts.map(x => x.KvProductCode);
            
            const logWithProducts: IKvLogInput = {
                ...logInput,
                MessageTemplate: { 
                    ...logInput.MessageTemplate,
                    productCount: informationProducts.length,
                    productCodes: productCodes.slice(0, 10) // Log first 10 IDs
                }
            };
            
            this._logger.info(logWithProducts, `${prefixLog} processing ${informationProducts.length} products`);

            await this._bulkProductInformationSyncEsJobService.publishReSyncAllProductChange(
                retailerId,
                catalogId,
                pageId,
                productCodes
            );

            await this._kvRedisService.removeByValue(redisKey, delayValues);
            
            this._logger.info(logWithProducts, `${prefixLog} success`);
        } else {
            this._logger.info(logInput, `${prefixLog} no products to process`);
        }
    }
} 