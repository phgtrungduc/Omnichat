import {  KvLogger, SocialTypes } from '@kiotviet-facebook-services/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Injectable } from '@nestjs/common';
import { Queue } from 'bullmq';
import { BULK_PRODUCT_INFORMATION_SYNCES_QUEUE, PRODUCT_CATALOG_BULK_PRODUCT_INFORMATION_SYNCES_PROCESSOR } from '../constants';
import { ProductInformationMessageBrokerService } from './message-broker.service';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

@Injectable()
export class BulkProductInformationSyncEsJobService {
    constructor(
        @InjectQueue(PRODUCT_CATALOG_BULK_PRODUCT_INFORMATION_SYNCES_PROCESSOR) private readonly bulkProductInformationSyncESQueue: Queue,
        private readonly _logger: KvLogger,
        private readonly _productInformationMessageBrokerService: ProductInformationMessageBrokerService
    ) {}

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async addJobBulkProductInformationSyncES(data: any, jobOptions = {
        removeOnComplete: true,
        attempts: 3,
        backoff: 10000,
        stackTraceLimit: 1,
        delay: 1 * 1000
    } as any) {
        const prefixLog = this.prefixLog('addJobBulkProductInformationSyncES');
        const logInput: IKvLogInput = {
            MessageTemplate: { data, jobOptions },
            Properties: {
                'Kv.SocialId': data?.pageId,
                'Kv.SocialType': SocialTypes.FACEBOOK_CATALOG,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        };

        this._logger.info(logInput, `${prefixLog} adding job to queue`);

        await this.bulkProductInformationSyncESQueue.add(
            BULK_PRODUCT_INFORMATION_SYNCES_QUEUE,
            data,
            jobOptions
        );

        this._logger.info(logInput, `${prefixLog} success`);
    }

    async publishReSyncAllProductChange(retailerId: number, catalogId: string, pageId: string, ids?: string[]): Promise<void> {
        return this._productInformationMessageBrokerService.publishReSyncAllProductChange(retailerId, catalogId, pageId, ids);
    }
} 