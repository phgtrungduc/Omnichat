import { CommonModule } from '@kiotviet-facebook-services/common';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { KvRedisModule } from "@kiotviet-facebook-services/kv-redis";
import { KvKafkaModule } from "@kiotviet-facebook-services/kvkafka";
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { BullModule } from "@nestjs/bullmq";
import { Module } from '@nestjs/common';
import { CatalogCommonModule } from "../catalog-common/catalog-common.module";
import { PRODUCT_CATALOG_BULK_PRODUCT_INFORMATION_SYNCES_PROCESSOR } from './constants';
import { BulkProductInformationSyncesProcessor } from './services/bulk-product-information-synces.processor';
import { BulkProductInformationSyncEsJobService } from './services/bulk-product-information-synces.service';
import { ProductCatalogProductInformationSyncEsService } from './services/product-catalog-product-information-synces.service';
import { ProductInformationMessageBrokerService } from './services/message-broker.service';

@Module({
    imports: [
        CommonModule,
        FbPosMasterRepositoryModule,
        KvRabbitMQModule,
        KvKafkaModule,
        CatalogCommonModule,
        KvRedisModule,
        BullModule.registerQueue({
            name: PRODUCT_CATALOG_BULK_PRODUCT_INFORMATION_SYNCES_PROCESSOR,
        }),
    ],
    providers: [
        ProductCatalogProductInformationSyncEsService,
        BulkProductInformationSyncEsJobService,
        BulkProductInformationSyncesProcessor,
        ProductInformationMessageBrokerService
    ],
})
export class ProductCatalogProductInformationSyncEsModule {
} 