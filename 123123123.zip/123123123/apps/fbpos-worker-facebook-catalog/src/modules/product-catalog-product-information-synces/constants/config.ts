export const PRODUCT_CATALOG_BULK_PRODUCT_INFORMATION_SYNCES_PROCESSOR = 'product-catalog-bulk-product-information-synces-processor';
export const BULK_PRODUCT_INFORMATION_SYNCES_QUEUE = 'bulk-product-information-synces';
export const REDIS_KEY_BULK_PRODUCT_INFORMATION_SYNCES = 'synces-product-information-catalog:retailer:'; 