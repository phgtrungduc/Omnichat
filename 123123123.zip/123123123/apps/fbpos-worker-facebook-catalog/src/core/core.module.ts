import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { CacheModule } from '@kiotviet-facebook-services/cache';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';

process.env['NODE_CONFIG_DIR'] = `${__dirname}/config/`;
const config = require('config');
@Global()
@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [() => config],
    }),
    FbPosMasterRepositoryModule,
    CacheModule,
  ],
  providers: [],
  exports: [],
})
export class CoreModule {
}
