import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { KvAuthModule } from '@kiotviet-facebook-services/kv-auth';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { AlertNotificationModule } from '@kiotviet-facebook-services/alert-notification';
import { SocketStateModule } from '../adapters';
import { SocketGateway } from '../modules/websocket.gateway';

process.env['NODE_CONFIG_DIR'] = `${__dirname}/config/`;
const config = require('config');

@Global()
@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [() => config],
    }),
    KvAuthModule,
    KvRabbitMQModule,
    SocketStateModule,
    CommonModule,
    AlertNotificationModule
  ],
  providers: [SocketGateway],
  exports: [SocketStateModule],
})
export class CoreModule {
}
