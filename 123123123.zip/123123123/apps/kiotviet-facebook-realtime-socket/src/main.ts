import { AppModule } from './app.module';
import { NestFactory } from '@nestjs/core';
import { ConfigService } from '@nestjs/config';
import { Logger } from '@nestjs/common';
import { initAdapters } from './adapters.init';

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule);
  const configService = app.get(ConfigService);

  initAdapters(app);

  const port = configService.get('serve.port' as never) || 3000;
  await app.listen(port, () => Logger.log(`Server running on port ${port}`));
}

bootstrap();
