import { WebSocketGateway, WebSocketServer, SubscribeMessage, MessageBody } from '@nestjs/websockets';
import { Server } from 'socket.io';

@WebSocketGateway({
  cors: {
    origin: '*'
  }
})
export class SocketGateway {
  @WebSocketServer()
  public socketServer: Server;

  @SubscribeMessage('message')
  handleMessage(@MessageBody() data: string): string {
    // Handle incoming messages
    return 'Received: ' + data;
  }
}
