import { Module } from '@nestjs/common';
import { SocketGateway } from '../websocket.gateway';
import { UserRoomEmittingService } from './user-room-emitting.service';
import { CommonModule } from '@kiotviet-facebook-services/common';

@Module({
  imports: [CommonModule],
  providers: [SocketGateway, UserRoomEmittingService]
})
export class UserRoomEmittingModule {}
