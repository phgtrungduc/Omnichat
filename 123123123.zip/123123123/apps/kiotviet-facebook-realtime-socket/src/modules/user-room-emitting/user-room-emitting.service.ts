import { Injectable } from "@nestjs/common";
import { IWebSocketPayload } from "../../interfaces/websocket-payload.interface";
import { SocketGateway } from "../websocket.gateway";
import { KvLogger } from "@kiotviet-facebook-services/common";
import { RabbitSubscribe } from "@kiotviet-facebook-services/rabbitmq";

process.env['NODE_CONFIG_DIR'] = `${__dirname}/config/`;
const config = require('config');

@Injectable()
export class UserRoomEmittingService {

  constructor(
    private readonly logger: KvLogger,
    private readonly socketGateway: SocketGateway,
  ) {
  }

  @RabbitSubscribe({
    exchange: config.get('rabbitMQ.mainExchange'),
    routingKey: config.get('rabbitMQ.userRoomEmitting.routingKey'),
    queue: config.get('rabbitMQ.userRoomEmitting.queue'),
    queueOptions: {
      durable: true,
      arguments: { 'x-queue-type': 'quorum' },
    },
  })
  private async emitToUserRoom(payload: IWebSocketPayload) {
    const roomId = payload.headers?.userId || payload.headers?.retailerId;
    const event = config.get('websocketEvent') || payload.event;
    this.logger.info(`[Room emitting] Received message from rabbit and emit to room: ${roomId}, event: ${event}, data: ${JSON.stringify(payload)}`);

    if (!payload || !roomId || !event) {
      this.logger.warn('[Room emitting] Missing emit data');
      return Promise.resolve();
    }

    this.socketGateway.socketServer.sockets.in(roomId.toString()).emit(event, payload);
    return Promise.resolve();
  }
}
