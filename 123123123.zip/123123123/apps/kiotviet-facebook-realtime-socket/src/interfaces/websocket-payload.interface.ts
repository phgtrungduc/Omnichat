export interface IWebSocketPayload {
  headers: {
    userId: number;
    retailerId: number;
  };
  data: any;
  event: string;
}
