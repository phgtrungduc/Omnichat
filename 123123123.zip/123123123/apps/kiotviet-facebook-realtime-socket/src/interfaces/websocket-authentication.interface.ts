import { Socket } from 'socket.io';

export interface ITokenPayload {
  readonly userId: number;
  readonly retailerId: number;
}

export interface IAuthenticatedSocket extends Socket {
  auth: ITokenPayload;
}
