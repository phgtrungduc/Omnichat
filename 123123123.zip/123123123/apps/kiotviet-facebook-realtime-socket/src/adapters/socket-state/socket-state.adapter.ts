import { INestApplicationContext, WebSocketAdapter } from '@nestjs/common';
import { IoAdapter } from '@nestjs/platform-socket.io';
import { createAdapter } from "@socket.io/redis-adapter";
import { ServerOptions, Server } from 'socket.io';
import Redis from 'ioredis';
import { throttle } from 'lodash';
import { SocketStateService } from './socket-state.service';
import { IAuthenticatedSocket } from '../../interfaces/websocket-authentication.interface';
import { KvLogger } from '@kiotviet-facebook-services/common';
import { KvStrategy } from 'libs/auth/kv-auth/src/stragety/kv.strategy';
import { AlertNotificationService } from '@kiotviet-facebook-services/alert-notification';

process.env['NODE_CONFIG_DIR'] = `${__dirname}/config/`;
const config = require('config');
export class SocketStateAdapter extends IoAdapter implements WebSocketAdapter {
  public constructor(
    private readonly app: INestApplicationContext,
    private readonly socketStateService: SocketStateService,
    private readonly kvStrategy: KvStrategy,
    private readonly logger: KvLogger,
    private readonly alertNotificationService: AlertNotificationService,
  ) {
    super(app);
  }

  public create(port: number, options: ServerOptions): Server {
    const server = super.createIOServer(port, options);
    const throttledAlert = throttle(err => this.alertNotificationService.send(
      `[WEBSOCKET SERVICE] Redis adapter error: ${err}`,
      { destination: `${config.get('redis').name}` },
    ), 5000);

    const pubClient = new Redis(config.get('redis'));
    pubClient.on('error', err => {
      this.logger.error(`Socket redis adapter initial pub client error: ${err}`);
      throttledAlert(err);
    });

    const subClient = pubClient.duplicate();
    subClient.on('error', err => {
      this.logger.error(`Socket redis adapter initial sub client error: ${err}`);
      throttledAlert(err);
    });

    server.adapter(createAdapter(pubClient, subClient));

    server.use(async (socket: IAuthenticatedSocket, next) => {
      const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization;

      if (!token) {
        socket.auth = null;
        this.logger.warn('Socket forbidden');
        return next(new Error('FORBIDDEN'));
      }

      try {
        const { retailerId, userId } = await this.kvStrategy.validate(token);
        socket.auth = {
          userId: userId,
          retailerId: retailerId,
        };

        return next();
      } catch (e) {
        this.logger.error(`Socket authenticate error: ${e}`);
        return next(e);
      }
    });

    return server;
  }

  public bindClientConnect(server: Server, callback: Function): void {
    server.on('connection', (socket: IAuthenticatedSocket) => {
      if (socket.auth) {
        this.socketStateService.add(socket.auth?.userId, socket);

        socket.on('join', (room) => {
          socket.join(room);
          this.logger.info(`Join client of user id ${socket.auth?.userId} to room ${room}`);
          if (socket.auth.retailerId) {
            socket.join(socket.auth.retailerId.toString());
            this.logger.info(`Join client of retailer ${socket.auth?.retailerId} to room ${socket.auth.retailerId}`);
          }
        });

        socket.on('disconnect', () => {
          this.socketStateService.remove(socket.auth?.userId, socket);

          socket.removeAllListeners('disconnect');
        });
      }

      callback(socket);
    });
  }
}
