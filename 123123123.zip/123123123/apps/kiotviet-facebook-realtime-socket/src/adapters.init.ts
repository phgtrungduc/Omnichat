import { INestApplication } from '@nestjs/common';
import { KvLogger } from '@kiotviet-facebook-services/common';
import { KvStrategy } from 'libs/auth/kv-auth/src/stragety/kv.strategy';
import { AlertNotificationService } from '@kiotviet-facebook-services/alert-notification';
import { SocketStateAdapter, SocketStateService } from './adapters';

export const initAdapters = (app: INestApplication): INestApplication => {
  const socketStateService = app.get(SocketStateService);
  const kvStrategy = app.get(KvStrategy);
  const logger = app.get(KvLogger);
  const alertNotificationService = app.get(AlertNotificationService);

  app.useWebSocketAdapter(new SocketStateAdapter(app, socketStateService, kvStrategy, logger, alertNotificationService));

  return app;
};
