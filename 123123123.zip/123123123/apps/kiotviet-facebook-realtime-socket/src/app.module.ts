import { Module } from '@nestjs/common';
import { CoreModule } from './core/core.module';
import { UserRoomEmittingModule } from './modules/user-room-emitting/user-room-emitting.module';


@Module({
  imports: [
    CoreModule,
    UserRoomEmittingModule
  ],
  controllers: [],
  providers: [],
})
export class AppModule { }
