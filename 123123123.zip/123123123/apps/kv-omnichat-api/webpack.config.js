const { composePlugins, withNx } = require('@nx/webpack');
const path = require('path');

// Nx plugins for webpack.
module.exports = composePlugins(
  withNx({
    target: 'node',
  }),
  (config) => {
    // Add path mapping for TypeScript aliases
    config.resolve.alias = {
      ...config.resolve.alias,
      '@': path.resolve(__dirname, 'src'),
      '@/app': path.resolve(__dirname, 'src/app'),
      '@/modules': path.resolve(__dirname, 'src/app/modules'),
      '@/core': path.resolve(__dirname, 'src/app/core'),
      '@/entities': path.resolve(__dirname, 'src/app/entities'),
      '@/interfaces': path.resolve(__dirname, 'src/app/interfaces'),
      '@/common': path.resolve(__dirname, 'src/app/common'),
      '@/config': path.resolve(__dirname, 'src/app/config'),
      '@/database': path.resolve(__dirname, 'src/app/database'),
      '@/adapters': path.resolve(__dirname, 'src/app/adapters'),
    };
    
    return config;
  }
); 