# API Đánh Dấu Trạng Thái Hội Thoại Đa Nền Tảng

## 🎯 Tổng Quan

API thống nhất để đánh dấu trạng thái (đã đọc, đã xử lý) cho một hoặc nhiều hội thoại trên các nền tảng khác nhau (Facebook, Shopee, TikTok, v.v.).

### 📍 Endpoint
```
PATCH /conversations/mark-status
```

## 🏗️ Kiến Trúc

### Strategy Pattern Implementation
- **ConversationStatusService**: Service chính quản lý các platform strategies
- **IConversationStatusStrategy**: Interface cho các platform strategy
- **FacebookConversationStatusStrategy**: Xử lý FBPOS APIs
- **ShopeeConversationStatusStrategy**: Xử lý OmniChannel APIs

### Logic Xử Lý
1. **Single vs Bulk Operations**:
   - FBPOS: Nếu 1 conversation → gọi API single, nhiều conversation → gọi API bulk
   - OmniChannel: Không có API bulk → luôn gọi từng API một

2. **Platform-specific Handling**:
   - Facebook: Hỗ trợ cả `read` và `resolved` status
   - Shopee: Chỉ hỗ trợ `read` status (resolved sẽ trả lỗi)

## 📝 API Specification

### Request Body

```typescript
{
  "statusType": "read" | "resolved",
  "action": "mark" | "unmark",
  "conversations": [
    {
      "conversationId": "string",
      "channelId": "string", 
      "platform": "facebook" | "shopee" | "tiktok" | "zalo"
    }
  ],
  "fbName": "string", // Optional - chỉ cho Facebook
  "lastReadMessageId": "string" // Optional - chỉ cho OmniChannel
}
```

### Response Body

```typescript
{
  "success": boolean,
  "totalProcessed": number,
  "successCount": number, 
  "failureCount": number,
  "results": [
    {
      "conversationId": "string",
      "channelId": "string",
      "platform": "string",
      "success": boolean,
      "error": "string", // Optional
      "platformData": any // Optional - raw response từ platform
    }
  ],
  "message": "string"
}
```

## 🔧 Ví Dụ Sử Dụng

### 1. Đánh dấu đã đọc - Single Platform (Facebook)

```json
PATCH /conversations/mark-status
{
  "statusType": "read",
  "action": "mark",
  "conversations": [
    {
      "conversationId": "9909794635736161",
      "channelId": "752160271303963",
      "platform": "facebook"
    }
  ],
  "fbName": "Ly Nguyen"
}
```

### 2. Đánh dấu chưa đọc - Multi Platform

```json
PATCH /conversations/mark-status
{
  "statusType": "read", 
  "action": "unmark",
  "conversations": [
    {
      "conversationId": "9909794635736161",
      "channelId": "752160271303963", 
      "platform": "facebook"
    },
    {
      "conversationId": "986672366256386281",
      "channelId": "92487",
      "platform": "shopee"
    }
  ],
  "fbName": "Ly Nguyen",
  "lastReadMessageId": "2329591564150849906"
}
```

### 3. Đánh dấu đã xử lý - Bulk Facebook

```json
PATCH /conversations/mark-status
{
  "statusType": "resolved",
  "action": "mark", 
  "conversations": [
    {
      "conversationId": "9909794635736161",
      "channelId": "752160271303963",
      "platform": "facebook"
    },
    {
      "conversationId": "24104504305847563", 
      "channelId": "752160271303963",
      "platform": "facebook"
    },
    {
      "conversationId": "23973393762301049",
      "channelId": "752160271303963", 
      "platform": "facebook"
    }
  ]
}
```

## 🔄 Mapping với API Cũ

### FBPOS APIs
| New API | Old FBPOS API | HTTP Method | Description |
|---------|---------------|-------------|-------------|
| `statusType: "read", action: "mark/unmark"` | `/conversation/toggle` | POST | Đánh dấu đã đọc/chưa đọc |
| `statusType: "resolved", action: "mark/unmark"` | `/conversation/resolve` | POST | Đánh dấu đã xử lý/chưa xử lý |
| `statusType: "read"` (multiple conversations) | `/conversation/bulk-toggle` | POST | Đánh dấu hàng loạt |

### OmniChannel APIs
| New API | Old OmniChannel API | HTTP Method | Description |
|---------|---------------------|-------------|-------------|
| `statusType: "read", action: "mark"` | `/chat/shopee/{channelId}/conversation/{conversationId}/read` | PUT | Đánh dấu đã đọc |
| `statusType: "read", action: "unmark"` | `/chat/shopee/{channelId}/conversation/{conversationId}/unread` | POST | Đánh dấu chưa đọc |

## ⚠️ Lưu Ý Quan Trọng

1. **Platform Support**:
   - Facebook: Hỗ trợ đầy đủ `read` và `resolved`
   - Shopee: Chỉ hỗ trợ `read`, `resolved` sẽ trả lỗi
   - Các platform khác: Cần implement strategy mới

2. **Bulk Operations**:
   - Facebook: Có API bulk cho `read`, không có cho `resolved`
   - Shopee: Không có API bulk, luôn gọi từng cái một

3. **Error Handling**:
   - API sẽ cố gắng xử lý tất cả conversations
   - Lỗi ở một conversation không ảnh hưởng đến các conversation khác
   - Kết quả chi tiết được trả về trong `results` array

4. **Performance**:
   - Facebook bulk operations: Nhanh hơn cho nhiều conversation cùng page
   - Shopee: Sequential calls có thể chậm với số lượng lớn

## 🔧 Mở Rộng

Để thêm platform mới, cần:

1. Tạo interface cho platform APIs trong `interfaces/{platform}/`
2. Implement `IConversationStatusStrategy` 
3. Đăng ký strategy trong `ConversationStatusService`
4. Cập nhật module imports

## 🧪 Testing

```bash
# Build project
npm run build

# Run tests (nếu có)
npm run test

# Check TypeScript errors
npx tsc --noEmit --project apps/kv-omnichat-api/tsconfig.app.json
``` 