import { HttpException, HttpStatus } from '@nestjs/common';

export class KvValidateException extends HttpException {
  constructor(message: string) {
    super(
      {
        success: false,
        statusCode: HttpStatus.BAD_REQUEST,
        messageKey: 'VALIDATION_ERROR',
        message: message,
        data: null
      },
      HttpStatus.BAD_REQUEST
    );
  }
} 