import { Injectable } from '@nestjs/common';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { FeedpostItemDto } from '../../modules/feedpost/dto/feedpost.dto';
import { IFeedpostStrategy } from '../../composite/composite-feedpost.strategy';
import { IPlatformChannel } from '../../common/interfaces/platform-channel.interface';

@Injectable()
export class ShopeeFeedpostStrategy implements IFeedpostStrategy {
  public readonly platform = ChatPlatformEnum.Shopee;

  constructor() {}

  async getFeedposts(channels: IPlatformChannel[], query: any): Promise<FeedpostItemDto[]> {
    try {
      const shopeeChannels = channels.filter(channel => 
        channel.platform === ChatPlatformEnum.Shopee
      );

      if (shopeeChannels.length === 0) {
        return [];
      }

      // Return empty array as requested for Shopee
      return [];
    } catch (error) {
      console.error('Error in Shopee feedpost strategy:', error);
      return [];
    }
  }
} 