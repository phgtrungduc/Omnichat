import { Injectable } from '@nestjs/common';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { UserProfileDto, UserProfileResponseDto } from '../../modules/user/dto/user.dto';
import { IUserStrategy } from '../../composite/composite-user.strategy';

@Injectable()
export class ShopeeUserStrategy implements IUserStrategy {
  public readonly platform = ChatPlatformEnum.Shopee;

  async getUserProfile(dto: UserProfileDto): Promise<UserProfileResponseDto> {
    return {};
  }

  async getUserProfilePicture(dto: UserProfileDto): Promise<string> {
    // TODO: Implement Shopee user profile picture retrieval
    return null;
  }
}
