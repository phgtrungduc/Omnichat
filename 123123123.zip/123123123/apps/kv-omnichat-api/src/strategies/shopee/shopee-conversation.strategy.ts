import { Injectable } from '@nestjs/common';
import { ChatPlatformEnum, IChatConversation, KvLogger } from '@kiotviet-facebook-services/common';
import { IConversationStrategy, IConversationFilters, IConversationSearchByAccountFilters, IConversationSearchByMessageFilters, IMessageSearchAggregationResult } from '../../interfaces/conversation.interface';
import { OmniConversationsRepository, OmniMessageRepository, OmniConversations } from '@kiotviet-facebook-services/omnimongo-repository';
import { ConversationFilterService } from '../../services/conversation-filter.service';
import { OmniChannel } from '@kiotviet-facebook-services/omnichannel-repository';
import { In } from 'typeorm';
import { ChannelService } from '../../services/channel.service';
import { IChannelPaging } from '../../common/interfaces/platform-channel.interface';

@Injectable()
export class ShopeeConversationStrategy implements IConversationStrategy {
  public readonly platform = ChatPlatformEnum.Shopee;
  private projection = {
    ConversationId: 1,
    ShopId: 1,
    RetailerId: 1,
    ChannelId: 1,
    ToId: 1,
    ToName: 1,
    ToAvatar: 1,
    LatestMessageContent: 1,
    LatestMessageId: 1,
    LatestMessageType: 1,
    UnreadCount: 1,
    LastMessageTimestamp: 1,
    Pinned: 1,
    Mute: 1,
    CreatedDate: 1,
    ModifiedDate: 1,
    RawData: 1,
  }
  constructor(
    private readonly omniConversationsRepository: OmniConversationsRepository,
    private readonly omniMessageRepository: OmniMessageRepository,
    private readonly logger: KvLogger,
    private readonly conversationFilterService: ConversationFilterService,
    private readonly channelService: ChannelService
  ) { }


  async getConversations(filters?: IConversationFilters): Promise<IChatConversation[]> {
    try {
      const channels = filters?.channels
        .filter(channel => channel.platform === ChatPlatformEnum.Shopee)
        .flatMap(channel => channel.channelDetails);

      if (channels.length === 0) {
        return [];
      }

      const mapChannelId = new Map<string, string>();

      const activeChannels = await this.channelService.getActiveChatChannels({
        IdentityKey: In(channels.map(channel => channel.channelId))
      }) as OmniChannel[];

      activeChannels.forEach(channel => {
        mapChannelId.set(channel.IdentityKey, channel.id);
      });

      // Lọc ra những channel có id hợp lệ và cập nhật channelId
      const validChannels = channels
        .filter(channel => mapChannelId.has(channel.channelId))
        .map(channel => {
          channel.channelId = mapChannelId.get(channel.channelId)!;
          return channel;
        });

      if (validChannels.length === 0) {
        return [];
      }

      // Tạo filter mới với tất cả channelId đã được map
      const updatedFilters = {
        ...filters,
        channels: [{
          platform: ChatPlatformEnum.Shopee,
          channelDetails: validChannels
        }]
      };

      const conversations = await this.executeSearch(updatedFilters, this.projection);
      return conversations.map(conversation => this.mapToIChatConversation(conversation));
    } catch (error) {
      this.logger.error(`Error getting Shopee conversations: ${error.message}`, error.stack);
      throw error;
    }
  }

  private async executeSearch(filters: IConversationFilters, projection: any): Promise<any[]> {
    // Use filter service to build query and sort options
    const filterResult = this.conversationFilterService.buildShopeeFilter(filters);
    // Không có keyword - trả về conversation cơ bản với pagination
    const res = await this.omniConversationsRepository.find(filterResult.query, projection, {
      limit: filterResult.limit + 1, //for has more
      skip: filterResult.skip,
      sort: filterResult.sortOptions
    });
    return res;
  }


  private mapToIChatConversation(conversation: OmniConversations): IChatConversation {
    return {
      id: conversation.ConversationId,
      conversationId: conversation.ConversationId,
      pageId: conversation.ShopId?.toString() || '',
      retailerId: conversation.RetailerId || 0,
      channelId: conversation.ChannelId.toString(),
      platform: ChatPlatformEnum.Shopee,
      type: 'messenger',
      senderId: conversation.ToId?.toString() || '',
      senderName: conversation.ToName || '',
      senderPicture: conversation.ToAvatar || '',
      message: conversation.LatestMessageContent?.Text || '',
      latestMessageId: conversation.LatestMessageId || '',
      latestMessageType: conversation.LatestMessageType || 'text',
      state: conversation.UnreadCount > 0 ? 0 : 1,
      resolved: 0,
      unreadCount: conversation.UnreadCount || 0,
      lastMessageTimestamp: conversation.LastMessageTimestamp ? Number(conversation.LastMessageTimestamp / 1_000_000n) : 0,
      lastUnreadTimestamp: conversation.LastMessageTimestamp ? Number(conversation.LastMessageTimestamp / 1_000_000n) : 0,
      lastAssigned: 0,
      pinned: conversation.Pinned || false,
      mute: conversation.Mute || false,
      staff: [],
      hasPhone: false,
      hasEmail: false,
      source: 'GraphApi',
      version: 1,
      createdDate: conversation.CreatedDate,
      modifiedDate: conversation.ModifiedDate,
      rawData: conversation.RawData || {}
    } as IChatConversation;
  }

  /**
   * Map aggregation result từ message search thành IChatConversation
   */
  private mapAggregationResultToIChatConversation(result: IMessageSearchAggregationResult): IChatConversation {
    const conversation = result.Conversation;
    return {
      id: conversation.ConversationId,
      conversationId: conversation.ConversationId,
      pageId: conversation.ShopId?.toString() || '',
      retailerId: conversation.RetailerId || 0,
      channelId: conversation.ChannelId.toString(),
      platform: ChatPlatformEnum.Shopee,
      type: 'messenger',
      senderId: conversation.ToId?.toString() || '',
      senderName: conversation.ToName || '',
      senderPicture: conversation.ToAvatar || '',
      message: conversation.LatestMessageContent?.Text || '',
      latestMessageId: conversation.LatestMessageId || '',
      latestMessageType: conversation.LatestMessageType || 'text',
      state: conversation.UnreadCount > 0 ? 0 : 1,
      resolved: 0,
      unreadCount: conversation.UnreadCount || 0,
      lastMessageTimestamp: conversation.LastMessageTimestamp ? Number(conversation.LastMessageTimestamp / 1_000_000n) : 0,
      lastUnreadTimestamp: conversation.LastMessageTimestamp ? Number(conversation.LastMessageTimestamp / 1_000_000n) : 0,
      lastAssigned: 0,
      pinned: conversation.Pinned || false,
      mute: conversation.Mute || false,
      staff: [],
      hasPhone: false,
      hasEmail: false,
      source: 'GraphApi',
      version: 1,
      createdDate: conversation.CreatedDate,
      modifiedDate: conversation.ModifiedDate,
      rawData: conversation.RawData || {}
    } as IChatConversation;
  }


  public async getConversationsSearchByAccount(filters?: IConversationSearchByAccountFilters): Promise<IChatConversation[]> {
    const socials = filters?.channels?.filter(channel => channel.platform === ChatPlatformEnum.Shopee) || [];
    if (socials.length === 0) {
      return [];
    }

    // Flatten all channelIds from all socials
    const socialIds = socials
      .flatMap(channel => channel.channelId) || [];

    if (socialIds.length === 0) {
      return [];
    }

    const filter = {
      ToName: { $regex: filters.keyword, $options: 'i' },
      ChannelId: { $in: socialIds }
    }
    const baseConversations = await this.omniConversationsRepository.find(filter, this.projection, {
      sort: { LastMessageTimestamp: -1 },
      limit: filters.limit,
    });
    return baseConversations.map(conversation => this.mapToIChatConversation(conversation));
  }

  public async getConversationsSearchByMessage(filters?: IConversationSearchByMessageFilters): Promise<IChatConversation[]> {
    const socials = filters?.channels?.filter(channel => channel.platform === ChatPlatformEnum.Shopee) || [];
    if (socials.length === 0) {
      return [];
    }

    // Flatten all channelIds and convert to numbers
    const socialIds = socials
      .flatMap(channel => channel.channelId)
      .map(channelId => {
        // Chuyển đổi channelId từ string sang number một cách an toàn
        const channelIdNumber = parseInt(channelId, 10);
        if (isNaN(channelIdNumber)) {
          this.logger.warn(`Invalid channelId: ${channelId}, skipping...`);
          return null;
        }
        return channelIdNumber;
      })
      .filter(id => id !== null) || [];

    if (socialIds.length === 0) {
      return [];
    }

    try {
      const results = await this.omniMessageRepository.aggregate([
        {
          $match: {
            ChannelId: { $in: socialIds },
            Text: { $regex: filters.keyword, $options: 'i' }
          }
        },
        {
          $sort: { CreatedTimestamp: -1 }
        },
        {
          $limit: 1000
        },
        {
          $lookup: {
            from: 'Conversation',
            let: {
              convId: '$ConversationId',
              channelId: '$ChannelId'
            },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$ConversationId', '$$convId'] },
                      { $eq: ['$ChannelId', '$$channelId'] }
                    ]
                  }
                }
              }
            ],
            as: 'Conversation'
          }
        },
        {
          $unwind: {
            path: '$Conversation'
          }
        }
      ]) as IMessageSearchAggregationResult[];

      // Apply limit after aggregation
      const limitedResults = filters.limit ? results.slice(0, filters.limit) : results;

      return limitedResults.map(result => this.mapAggregationResultToIChatConversation(result));
    } catch (error) {
      this.logger.error(`Error in getMessageConversations: ${error.message}`, error.stack);
      return [];
    }
  }
} 