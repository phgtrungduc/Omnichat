import { Injectable } from '@nestjs/common';
import { ChatError, ChatPlatformEnum, KvLogger } from '@kiotviet-facebook-services/common';
import { IConversationMessagesFilters, IConversationMessagesResponse } from '../../interfaces/message.interface';
import { IMessageStrategy } from '../message/message-strategy.interface';
import { OmniChannelRepository } from '@kiotviet-facebook-services/omnichannel-repository';
import { OmniMessageRepository, OmniConversationsRepository } from '@kiotviet-facebook-services/omnimongo-repository';

@Injectable()
export class ShopeeMessageStrategy implements IMessageStrategy {
    readonly platform = ChatPlatformEnum.Shopee;

    constructor(private readonly omnichannelRepository: OmniChannelRepository,
        private readonly logger: KvLogger,
        private readonly messageRepository: OmniMessageRepository,
        private readonly conversationRepository: OmniConversationsRepository
    ) { }

    async getConversationMessages(
        filters: IConversationMessagesFilters
    ): Promise<IConversationMessagesResponse> {
        const where = {
            RetailerId: filters.retailerId,
            Type: 6,
            IdentityKey: filters.channelId,
        }
        const channel = await this.omnichannelRepository.getActiveChannel(where);
        if (!channel) {
            throw new ChatError('CHANNEL_NOT_FOUND').withAdditional({ 
                retailerId: filters.retailerId,
                channelId: filters.channelId,
                type: 6
            });
        }
        const conversation = await this.conversationRepository.findOne({
            RetailerId: filters.retailerId,
            ConversationId: filters.conversationId,
            ChannelId: Number(channel.id)
        });
        if (!conversation) {
            throw new ChatError('CONVERSATION_NOT_FOUND').withAdditional({ 
                retailerId: filters.retailerId,
                conversationId: filters.conversationId,
                channelId: Number(channel.id)
            });
        }
        const filter = {
            RetailerId: filters.retailerId,
            ConversationId: filters.conversationId,
            ChannelId: Number(channel.id)
        }
        const options = {
            limit: filters.limit,
            sort: {
                CreatedTimestamp: -1
            }
        }
        if (filters.afterTimestamp) {
            filter['CreatedTimestamp'] = { $lt: filters.afterTimestamp };
        }
        const messages = await this.messageRepository.find(filter, null, options);
        const more = messages.length === filters.limit;
        // Dummy implementation for now
        return {
            items: messages.map(mes => {
                return this.messageRepository.toInterface(mes, conversation, channel.IdentityKey)
            }),
            more
        };
    }
} 