import { Injectable } from '@nestjs/common';
import { ChatPlatformEnum, IChatStaff } from '@kiotviet-facebook-services/common';
import { IPlatformChannel } from '../../common/interfaces/platform-channel.interface';
import { IStaffStrategy } from '../../composite/composite-staff.strategy';
import { StaffAssignDto, StaffDisableDto, StaffBulkAssignDto, StaffBulkUnassignDto } from '../../modules/staff/dto/staff.dto';
import { Request } from 'express';

@Injectable()
export class ShopeeStaffStrategy implements IStaffStrategy {
  public readonly platform = ChatPlatformEnum.Shopee;

  async getStaffList(channels: IPlatformChannel[]): Promise<any[]> {
    // TODO: Implement Shopee staff strategy methods
    // Always return empty array for Shopee as requested
    // When implementing, should return data in IChatStaff format
    return [];
  }

  async getStaffByChannels(channels: IPlatformChannel[]): Promise<any[]> {
    // TODO: Implement Shopee staff strategy methods
    // Always return empty array for Shopee as requested
    // When implementing, should return data in IChatStaff format
    return [];
  }

  async assignStaff(assignData: StaffAssignDto, request: Request): Promise<boolean> {
    // TODO: Implement Shopee staff assignment
    // Currently not supported for Shopee
    console.log('Shopee staff assignment not yet implemented');
    return true;
  }

  async unassignStaff(assignData: StaffAssignDto, request: Request): Promise<boolean> {
    // TODO: Implement Shopee staff unassignment
    // Currently not supported for Shopee
    console.log('Shopee staff unassignment not yet implemented');
    return true;
  }

  async disableStaff(disableData: StaffDisableDto, request: Request): Promise<boolean> {
    // TODO: Implement Shopee staff disable
    // Currently not supported for Shopee
    console.log('Shopee staff disable not yet implemented');
    return true;
  }

  async bulkAssignStaff(bulkAssignData: StaffBulkAssignDto, request: Request): Promise<boolean> {
    return true;
  }

  async bulkUnassignStaff(bulkUnassignData: StaffBulkUnassignDto, request: Request): Promise<boolean> {
    return true;
  }
} 