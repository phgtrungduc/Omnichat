import { Injectable } from '@nestjs/common';
import { ChatPlatformEnum, KvLogger } from '@kiotviet-facebook-services/common';
import { OmniChannelApi } from '@kiotviet-facebook-services/external-platforms';
import { 
  IConversationStatusStrategy, 
  IConversationStatusRequest 
} from '../../interfaces/conversation-status.interface';
import {
  ConversationStatusTypeEnum,
  ConversationStatusActionEnum,
  ConversationStatusResultDto,
  ConversationIdentifierDto
} from '../../common/dto/conversation-status.dto';
import {
  IOmnichannelMarkReadResponse,
  IOmnichannelMarkUnreadResponse
} from '../../modules/conversation/interfaces/omnichannel';

@Injectable()
export class ShopeeConversationStatusStrategy implements IConversationStatusStrategy {
  public readonly platform = ChatPlatformEnum.Shopee;

  constructor(
    private readonly _omniChannelApi: OmniChannelApi,
    private readonly logger: KvLogger
  ) {}

  async markStatus(request: IConversationStatusRequest): Promise<ConversationStatusResultDto[]> {
    const shopeeConversations = request.conversations.filter(
      conv => conv.platform === ChatPlatformEnum.Shopee
    );

    if (shopeeConversations.length === 0) {
      return [];
    }

    try {
      if (request.statusType === ConversationStatusTypeEnum.READ) {
        return await this.handleReadStatus(shopeeConversations, request);
      } else if (request.statusType === ConversationStatusTypeEnum.RESOLVED) {
        // Shopee doesn't have resolved concept like Facebook, skip
        this.logger.warn('Shopee platform does not support resolved status - skipping');
        return shopeeConversations.map(conv => ({
          conversationId: conv.conversationId,
          channelId: conv.channelId,
          platform: conv.platform,
          success: true,
          platformData: { message: 'Shopee platform does not support resolved status - skipped' }
        }));
      } else {
        throw new Error(`Unsupported status type: ${request.statusType}`);
      }
    } catch (error) {
      this.logger.error(`Error marking Shopee conversation status: ${error.message}`, error.stack);
      
      // Return failed results for all conversations
      return shopeeConversations.map(conv => ({
        conversationId: conv.conversationId,
        channelId: conv.channelId,
        platform: conv.platform,
        success: false,
        error: error.message
      }));
    }
  }

  private async handleReadStatus(
    conversations: ConversationIdentifierDto[], 
    request: IConversationStatusRequest
  ): Promise<ConversationStatusResultDto[]> {
    // OmniChannel API doesn't have bulk API, use Promise.allSettled for parallel processing
    const promises = conversations.map(conversation => 
      this.markSingleReadStatus(conversation, request)
    );

    const results = await Promise.allSettled(promises);
    const allResults: ConversationStatusResultDto[] = [];

    results.forEach((result, index) => {
      const conversation = conversations[index];
      
      if (result.status === 'fulfilled') {
        allResults.push(result.value);
      } else {
        this.logger.error(`Error marking read status for conversation ${conversation.conversationId}: ${result.reason?.message || result.reason}`);
        allResults.push({
          conversationId: conversation.conversationId,
          channelId: conversation.channelId,
          platform: conversation.platform,
          success: false,
          error: result.reason?.message || String(result.reason)
        });
      }
    });

    return allResults;
  }

  private async markSingleReadStatus(
    conversation: ConversationIdentifierDto, 
    request: IConversationStatusRequest
  ): Promise<ConversationStatusResultDto> {
    const isMarkAsRead = request.action === ConversationStatusActionEnum.MARK;
    
    if (isMarkAsRead) {
      // Mark as read
      const queryParams = conversation.lastReadMessageId 
        ? `?LastReadMessageId=${conversation.lastReadMessageId}` 
        : '';
      
      const url = `/chat/shopee/${conversation.channelId}/conversation/${conversation.conversationId}/read${queryParams}`;
      const response = await this._omniChannelApi.post<IOmnichannelMarkReadResponse>(
        url,
        {},
        {
          headers: request.headers
        }
      );

      return {
        conversationId: conversation.conversationId,
        channelId: conversation.channelId,
        platform: conversation.platform,
        success: response.data.Success,
        platformData: response.data.Data
      };
    } else {
      // Mark as unread
      const url = `/chat/shopee/${conversation.channelId}/conversation/${conversation.conversationId}/unread`;
      
      const response = await this._omniChannelApi.post<IOmnichannelMarkUnreadResponse>(
        url,
        {},
        {
          headers: request.headers
        }
      );

      return {
        conversationId: conversation.conversationId,
        channelId: conversation.channelId,
        platform: conversation.platform,
        success: response.data.Success,
        platformData: response.data.Data
      };
    }
  }
} 