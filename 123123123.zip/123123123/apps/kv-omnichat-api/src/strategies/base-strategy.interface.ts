import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

export interface IBaseStrategy {
  readonly platform: ChatPlatformEnum;
}

export enum StrategyType {
  MESSAGE = 'message',
  FEEDPOST = 'feedpost',
  // Thêm các loại khác khi cần
} 