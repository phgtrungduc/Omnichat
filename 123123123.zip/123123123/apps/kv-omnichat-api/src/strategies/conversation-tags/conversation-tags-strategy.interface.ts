import { Request } from 'express';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { IChannelRequest } from '../../interfaces';

/**
 * Request data chung cho ConversationTags
 */
export interface IConversationTagsRequest {
  channels: IChannelRequest[];
  version?: number;
}

/**
 * Data item chung cho ConversationTag response
 */
export interface IConversationTagData {
  id: string;
  channelId: string;
  platform: ChatPlatformEnum;
  title: string;
  color: string;
  version: number;
  conversations: string[];
  timestamp: number;
}

/**
 * Response data chung cho ConversationTags
 */
export interface IConversationTagsResponse {
  success: boolean;
  data: IConversationTagData[];
  message?: string;
}

/**
 * Interface chung cho tất cả ConversationTags strategies
 */
export interface IConversationTagsStrategy {
  /**
   * Lấy danh sách conversation tags từ platform tương ứng
   * @param req Express request object chứa headers và auth info
   * @param data Dữ liệu conversation tags request
   * @returns Promise<IConversationTagsResponse> Response đã được format chung
   */
  getConversationTags(req: Request, data: IConversationTagsRequest): Promise<IConversationTagsResponse>;

  /**
   * Kiểm tra xem strategy có hỗ trợ platform này không
   * @param platform Platform cần kiểm tra
   * @returns boolean
   */
  supports(platform: ChatPlatformEnum): boolean;
} 