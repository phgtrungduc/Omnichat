import { Injectable, Logger } from '@nestjs/common';
import { Request } from 'express';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { 
  IConversationTagsStrategy, 
  IConversationTagsRequest, 
  IConversationTagsResponse
} from './conversation-tags-strategy.interface';

@Injectable()
export class ShopeeConversationTagsStrategy implements IConversationTagsStrategy {
  private readonly logger = new Logger(ShopeeConversationTagsStrategy.name);

  /**
   * Kiểm tra strategy có hỗ trợ platform Shopee không
   */
  supports(platform: ChatPlatformEnum): boolean {
    return platform === ChatPlatformEnum.Shopee;
  }

  /**
   * Lấy danh sách conversation tags từ Shopee/Omnichannel
   * TODO: Hiện tại trả về rỗng, cần implement khi có API thực tế
   */
  async getConversationTags(req: Request, data: IConversationTagsRequest): Promise<IConversationTagsResponse> {
    const shopeeChannels = data.channels.filter(c => c.platform === ChatPlatformEnum.Shopee);
    const channelIds = shopeeChannels.map(c => c.channelId);
    
    this.logger.log(`Getting conversation tags for ${shopeeChannels.length} Shopee channels: ${channelIds.join(', ')} - Currently not implemented`);

    // TODO: Implement khi có Omnichannel API cho Shopee conversation tags
    return {
      success: true,
      data: [],
      message: 'Shopee conversation tags not supported yet'
    };
  }
} 