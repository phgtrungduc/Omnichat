import { Injectable, Logger } from '@nestjs/common';
import { Request } from 'express';
import { ChatPlatformEnum, KvLogger } from '@kiotviet-facebook-services/common';
import { FbposApiService } from '@kiotviet-facebook-services/external-platforms';
import { 
  IConversationTagsStrategy, 
  IConversationTagsRequest, 
  IConversationTagsResponse,
  IConversationTagData
} from './conversation-tags-strategy.interface';
import { 
  IFbposConversationTagsRequest,
  IFbposConversationTagsResponse 
} from '../../modules/channel/interfaces/fbpos';

@Injectable()
export class FacebookConversationTagsStrategy implements IConversationTagsStrategy {

  constructor(
    private readonly logger: KvLogger,
    private readonly fbposApiService: FbposApiService
  ) {}

  /**
   * Kiểm tra strategy có hỗ trợ platform Facebook/Instagram không
   */
  supports(platform: ChatPlatformEnum): boolean {
    return platform === ChatPlatformEnum.Facebook || platform === ChatPlatformEnum.Instagram;
  }

  /**
   * Lấy danh sách conversation tags từ FBPOS
   */
  async getConversationTags(req: Request, data: IConversationTagsRequest): Promise<IConversationTagsResponse> {
    const facebookChannels = data.channels.filter(c => c.platform === ChatPlatformEnum.Facebook || c.platform === ChatPlatformEnum.Instagram);
    const channelIds = facebookChannels.map(c => c.channelId);
    
    this.logger.info(`Getting conversation tags for ${facebookChannels.length} Facebook channels: ${channelIds.join(', ')}`);

    try {
      // Map request data sang format FBPOS - FBPOS API hỗ trợ multiple pageids
      const fbposParams: IFbposConversationTagsRequest = {
        pageid: channelIds.join(','), // FBPOS API accept comma-separated pageids
        version: data.version
      };

      const response = await this.fbposApiService.get<IFbposConversationTagsResponse>(
        '/tag/list',
        {
          headers: req.headers,
          params: fbposParams
        }
      );

      const fbposData = response.data;
      
      // Map response từ FBPOS format sang common format
      const mappedData: IConversationTagData[] = fbposData.data?.map(item => {
        // Tìm platform tương ứng với PageId này
        const channel = facebookChannels.find(c => c.channelId === item.PageId);
        return {
          id: item._id,
          channelId: item.PageId,
          platform: channel?.platform || ChatPlatformEnum.Facebook,
          title: item.Detail.Title,
          color: item.Detail.Color,
          version: item.Version,
          conversations: item.Conversations || [],
          timestamp: item.TimeStamp
        };
      }) || [];

      const result: IConversationTagsResponse = {
        success: fbposData.status === 'success',
        data: mappedData,
        message: fbposData.status === 'success' 
          ? 'Get conversation tags successfully' 
          : 'Failed to get conversation tags'
      };

      this.logger.info(`Successfully retrieved ${mappedData.length} conversation tags for ${facebookChannels.length} Facebook channels`);
      return result;

    } catch (error) {
      console.log('error', error);
      // this.logger.error(`Error getting conversation tags for Facebook channels: ${channelIds.join(', ')}`, error);
      return {
        success: false,
        data: [],
        message: error.message || 'Error occurred while getting conversation tags'
      };
    }
  }
} 