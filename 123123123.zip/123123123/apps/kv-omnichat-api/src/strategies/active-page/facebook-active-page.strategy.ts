import { Injectable } from '@nestjs/common';
import { Request } from 'express';
import { ChatPlatformEnum, KvLogger } from '@kiotviet-facebook-services/common';
import { FbposApiService } from '@kiotviet-facebook-services/external-platforms';
import {
  IActivePageStrategy,
  IActivePageRequest,
  IActivePageResponse,
  IActivePageData
} from './active-page-strategy.interface';
import {
  IFbposActivePageRequest,
  IFbposActivePageResponse
} from '../../modules/channel/interfaces';

@Injectable()
export class FacebookActivePageStrategy implements IActivePageStrategy {

  constructor(
    private readonly _logger: KvLogger,
    private readonly _fbposApiService: FbposApiService
  ) { }

  /**
   * Kiểm tra platform hỗ trợ
   */
  supports(platform: ChatPlatformEnum): boolean {
    return platform === ChatPlatformEnum.Facebook || platform === ChatPlatformEnum.Instagram;
  }

  /**
   * Activate Facebook/Instagram pages with comma-separated pageIds
   */
  async activatePages(req: Request, data: IActivePageRequest): Promise<IActivePageResponse> {
    const facebookChannels = data.channels.filter(c =>
      c.platform === ChatPlatformEnum.Facebook || c.platform === ChatPlatformEnum.Instagram
    );
    const channelIds = facebookChannels.map(c => c.channelId);
    const pageIdsJoined = channelIds.join(',');
    const accessTokenJoined = facebookChannels.map(c => c.accessToken).join(',');
    const isAdminJoined = facebookChannels.map(c => c.isAdmin ? 'true' : 'false').join(',');
    this._logger.info(`Activating ${facebookChannels.length} Facebook channels with pageIds: ${pageIdsJoined}`);

    try {
      const retailerId = (req as any)?.kvretail?.retailerId as number;
      if (!retailerId) {
        throw new Error('Retailer ID not found in request');
      }

      const fbposRequest: IFbposActivePageRequest = {
        retailerid: retailerId,
        pageid: pageIdsJoined,
        access_token: accessTokenJoined,
        isRoleAdmin: isAdminJoined,
        fbuser: data.fbposParams.fbUser ? {
          Name: data.fbposParams.fbUser.name,
          Picture: data.fbposParams.fbUser.picture,
          AppUserId: data.fbposParams.fbUser.appUserId
        } : undefined
      };

      const response = await this._fbposApiService.post<IFbposActivePageResponse>(
        '/activepage',
        fbposRequest,
        {
          headers: req.headers,
          params: {
            pageid: pageIdsJoined
          }
        }
      );

      const fbposData = response.data;

      if (fbposData.status === 'success') {
        const channelIdsJoined = channelIds.join(',');
        const fbposItems = fbposData.data;
        const mappedData: IActivePageData[] = [{
          channelId: channelIdsJoined, // Single item with all channelIds joined
          platform: ChatPlatformEnum.Facebook,
          message: 'success',
          success: true,
          jwt: fbposData.jwt,
          expire: fbposData.expire
        }];

        if (fbposData.data && fbposData.data.length > 0) {
          mappedData[0].isRoleAdmin = fbposItems.map(item => item.isRoleAdmin).join(',');
          mappedData[0].extendedToken = fbposItems.map(item => item.extendedToken).join(',');
        }

        const result: IActivePageResponse = {
          success: true,
          data: mappedData,
          totalCount: facebookChannels.length,
          successCount: facebookChannels.length,
          failureCount: 0,
          message: `Successfully activated ${facebookChannels.length} Facebook channels`,
          statistics: {
            'Facebook': {
              total: facebookChannels.length,
              success: facebookChannels.length,
              failed: 0
            }
          }
        };
        this._logger.info(`Facebook activation completed: ${mappedData.length}/${facebookChannels.length} channels successful`);
        return result;

      } else {
        // FBPOS returned failure status
        const channelIdsJoined = channelIds.join(',');
        const failedResults: IActivePageData[] = [{
          channelId: channelIdsJoined,
          platform: ChatPlatformEnum.Facebook,
          message: fbposData.message || 'Activation failed',
          success: false
        }];

        const result: IActivePageResponse = {
          success: false,
          data: failedResults,
          totalCount: facebookChannels.length,
          successCount: 0,
          failureCount: facebookChannels.length,
          message: fbposData.message || 'Facebook activation failed',
          statistics: {
            'Facebook': {
              total: facebookChannels.length,
              success: 0,
              failed: facebookChannels.length
            }
          }
        };

        return result;
      }

    } catch (error) {
      this._logger.error(`Error in Facebook activation for channels: ${channelIds.join(', ')}`, error);

      // Add failed results for all channels
      const channelIdsJoined = channelIds.join(',');
      const failedResults: IActivePageData[] = [{
        channelId: channelIdsJoined,
        platform: ChatPlatformEnum.Facebook,
        message: error.message || 'Activation failed',
        success: false
      }];

      return {
        success: false,
        data: failedResults,
        totalCount: facebookChannels.length,
        successCount: 0,
        failureCount: facebookChannels.length,
        message: error.message || 'Error occurred during Facebook activation',
        statistics: {
          'Facebook': {
            total: facebookChannels.length,
            success: 0,
            failed: facebookChannels.length
          }
        }
      };
    }
  }
} 