import { Request } from 'express';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { IChannelRequest } from '../../interfaces';

/**
 * FBPOS specific parameters for activation
 */
export interface IFbposActivePageParams {
  fbUser?: {
    name: string;
    picture: string;
    appUserId: string;
  };
}

/**
 * Request data for batch ActivePage
 */
export interface IActivePageRequest {
  channels: IChannelRequest[];
  fbposParams: IFbposActivePageParams;
}

/**
 * Response data for batch ActivePage
 */
export interface IActivePageResponse {
  success: boolean;
  data: IActivePageData[];
  totalCount: number;
  successCount: number;
  failureCount: number;
  message?: string;
  statistics?: Record<string, {
    total: number;
    success: number;
    failed: number;
  }>;
}

export interface IActivePageData {
  channelId: string;
  platform: ChatPlatformEnum;
  message: string;
  success: boolean;
  isRoleAdmin?: string;
  extendedToken?: string;
  jwt?: string;
  expire?: string;
}

export interface IActivePageStrategy {
  activatePages(req: Request, data: IActivePageRequest): Promise<IActivePageResponse>;
  supports(platform: ChatPlatformEnum): boolean;
} 