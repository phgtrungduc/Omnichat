export * from './active-page-strategy.interface';
export * from './facebook-active-page.strategy';
export * from './shopee-active-page.strategy'; 