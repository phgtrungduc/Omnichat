import { ChatPlatformEnum, KvLogger } from '@kiotviet-facebook-services/common';
import { Injectable } from '@nestjs/common';
import { Request } from 'express';
import {
  IActivePageRequest,
  IActivePageResponse,
  IActivePageStrategy
} from './active-page-strategy.interface';

@Injectable()
export class ShopeeActivePageStrategy implements IActivePageStrategy {

  constructor(
    private readonly _logger: KvLogger,
  ) { }

  supports(platform: ChatPlatformEnum): boolean {
    return platform === ChatPlatformEnum.Shopee;
  }

  async activatePages(req: Request, data: IActivePageRequest): Promise<IActivePageResponse> {
    const shopeeChannels = data.channels.filter(c =>
      c.platform === ChatPlatformEnum.Shopee || c.platform === ChatPlatformEnum.Zalo
    );
    const channelIds = shopeeChannels.map(c => c.channelId);

    try {
      return {
        success: true,
        data: [],
        totalCount: 0,
        successCount: 0,
        failureCount: 0,
        message: 'Shopee activation not implemented yet',
        statistics: {
          'Shopee': {
            total: 0,
            success: 0,
            failed: 0
          }
        }
      } as IActivePageResponse;

    } catch (error) {
      this._logger.error(`Error in Shopee activation for channels: ${channelIds.join(', ')}`, error);

      // Return empty failed response
      return {
        success: false,
        data: [],
        totalCount: 0,
        successCount: 0,
        failureCount: 0,
        message: error.message || 'Error occurred during Shopee activation',
        statistics: {
          'Shopee': {
            total: 0,
            success: 0,
            failed: 0
          }
        }
      };
    }
  }
} 