import { Injectable } from '@nestjs/common';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { FeedPostService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { FeedpostItemDto, FeedpostListRequestDto, FeedpostListResponseDto } from '../../modules/feedpost/dto/feedpost.dto';
import { IFeedpostStrategy } from '../../composite/composite-feedpost.strategy';  
import { buildChannelIds } from '../../common/utils/social.utils';
import { IPlatformChannel } from '../../common/interfaces/platform-channel.interface';

@Injectable()
export class FacebookFeedpostStrategy implements IFeedpostStrategy {
  public readonly platform = ChatPlatformEnum.Facebook;

  constructor(
    private readonly feedPostService: FeedPostService
  ) {}

  async getFeedposts(channels: IPlatformChannel[], query: FeedpostListRequestDto): Promise<FeedpostItemDto[]> {
    try {
      const facebookChannels = buildChannelIds(channels);

      if (facebookChannels.length === 0) {
        return [];
      }

      const queryParams = {
        limit: query.limit + 1,
        skip: query.skip,
        sort: { createdTime: -1 },
        find: {
          pageId: { $in: facebookChannels },
          ... query.searchMessage ? { message: { $regex: query.searchMessage, $options: "i" } } : {},
          published: 1
        }
      };

      const posts = await this.feedPostService.getListByPageIds(queryParams);
      
      const result = posts.map(post => ({
        _id: post._id,
        channelId: post.pageId,
        message: post.message,
        statusType: post.statusType,
        createdTime: post.createdTime,
        platform: ChatPlatformEnum.Facebook,
        isFromLivestream: post.statusType === 'added_video'
      }));


      return result;
    } catch (error) {
      console.error('Error in Facebook feedpost strategy:', error);
      return [];
    }
  }
} 