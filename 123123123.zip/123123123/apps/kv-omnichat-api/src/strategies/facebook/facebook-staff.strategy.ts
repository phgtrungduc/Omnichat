import { Injectable } from '@nestjs/common';
import { ChatError, ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { ConversationService, PageStaffRepository, PageStaffService, PageSubscriptionService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { IPlatformChannel } from '../../common/interfaces/platform-channel.interface';
import { IStaffStrategy } from '../../composite/composite-staff.strategy';
import { StaffAssignDto, StaffDisableDto, StaffBulkAssignDto, StaffBulkUnassignDto } from '../../modules/staff/dto/staff.dto';
import { IStaffTask } from '../../interfaces/staff-task.interface';
import { StaffEventType, AuditTrailActionEnum } from '../../common/enums/staff.enum';
import { buildLinkFacebook, buildLinkInstagram } from '../../common/utils/social.utils';
import { AuditTrailService } from '../../common/services/audit-trail.service';
import { IAuditTrailRequest } from '../../common/interfaces/audit-trail.interface';
import { Request } from 'express';
import { AuditLogFunctions } from '@kiotviet-facebook-services/kv-audit-trail-adapter';
import { ConfigService } from '@nestjs/config';
import { AmqpConnection } from '@golevelup/nestjs-rabbitmq';
const staffRoutingKey = 'kvfb.notification.staff.';
@Injectable()
export class FacebookStaffStrategy implements IStaffStrategy {
  public readonly platform = ChatPlatformEnum.Facebook;
  private readonly _rabbitMQConfig;
  constructor(
    private readonly pageStaffRepository: PageStaffRepository,
    private readonly pageStaffService: PageStaffService,
    private readonly pageSubscriptionService: PageSubscriptionService,
    private readonly auditTrailService: AuditTrailService,
    private readonly amqpConnection: AmqpConnection,
    private readonly configService: ConfigService,
    private readonly conversationService: ConversationService,
  ) {
    this._rabbitMQConfig = configService.get('rabbitMQ');
  }

  async getStaffList(channels: IPlatformChannel[]): Promise<any[]> {
    try {
      const facebookChannels = channels.filter(channel => channel.platform === ChatPlatformEnum.Facebook);
      // Flatten all channelIds from all Facebook channels
      const channelIds = facebookChannels.flatMap(channel => channel.channelId);
      // Build filter based on pageIds
      const filter = channelIds.length > 1
        ? { pageId: { $in: channelIds } }
        : { pageId: channelIds[0] };

      // Query staff from database using repository
      const staffs = await this.pageStaffRepository.find(filter, {
        selectedKeys: 'staffId pageId timestamp name picture appUserId state socketIds lastAssigned assignmentTurn',
        lean: true
      });

      // Filter staffs with name and map to response format
      return staffs
        .filter(item => item.name)
        .map(item => ({
          staffId: item.staffId,
          channelId: [item.pageId], // Convert to array
          name: item.name,
          picture: item.picture || '',
          appUserId: item.appUserId || '',
          state: item.state || 0,
          lastAssigned: item.lastAssigned || 0,
          assignmentTurn: item.assignmentTurn || 0,
          socketIds: item.socketIds || [],
          timestamp: item.timestamp || Date.now(),
          isRoleAdmin: false,
          platform: ChatPlatformEnum.Facebook,
          retailerId: 0,
          _id: item.staffId,
        })) as any[];

    } catch (error) {
      // TODO: Add proper error handling and logging
      console.error('Error getting Facebook staff list:', error);
      return [];
    }
  }

  async getStaffByChannels(channels: IPlatformChannel[]): Promise<any[]> {
    try {
      const facebookChannels = channels.filter(channel => channel.platform === ChatPlatformEnum.Facebook);
      const channelIds = facebookChannels.flatMap(channel => channel.channelId);

      if (channelIds.length === 0) {
        return [];
      }
      const filter: any = { state: 1 };

      // Build filter based on pageIds
      if (channelIds.length > 1) {
        filter.pageId = { $in: channelIds };
      } else {
        filter.pageId = channelIds[0];
      }

      // Lấy tất cả staff từ các pageId được cung cấp
      const allStaffs = await this.pageStaffRepository.find(
        filter,
        {
          selectedKeys: 'staffId pageId timestamp name picture appUserId state socketIds lastAssigned assignmentTurn',
          lean: true
        }
      );

      // Nhóm staff theo staffId để kiểm tra xem staff nào có mặt ở tất cả pageId
      const staffByPageId = new Map<string, Set<string>>();
      const staffData = new Map<string, any>();

      allStaffs.forEach(staff => {
        if (!staff.name) return; // Bỏ qua staff không có tên

        const staffId = staff.staffId;
        if (!staffByPageId.has(staffId)) {
          staffByPageId.set(staffId, new Set());
          staffData.set(staffId, staff);
        }
        staffByPageId.get(staffId)!.add(staff.pageId);
      });

      // Lọc ra những staff có mặt ở tất cả pageId
      const staffInAllChannels = Array.from(staffByPageId.entries())
        .filter(([staffId, pageIds]) => {
          // Kiểm tra xem staff có mặt ở tất cả channelIds không
          return channelIds.every(channelId => pageIds.has(channelId));
        })
        .map(([staffId, pageIds]) => {
          const staff = staffData.get(staffId);
          return {
            staffId: staff.staffId,
            channelId: channelIds, // Trả về tất cả channelId mà staff có mặt
            name: staff.name,
            picture: staff.picture || '',
            appUserId: staff.appUserId || '',
            state: staff.state || 0,
            lastAssigned: staff.lastAssigned || 0,
            assignmentTurn: staff.assignmentTurn || 0,
            socketIds: staff.socketIds || [],
            timestamp: staff.timestamp || Date.now(),
            isRoleAdmin: false,
            platform: ChatPlatformEnum.Facebook,
            retailerId: 0,
            _id: staff.staffId,
          };
        });

      return staffInAllChannels;
    } catch (error) {
      console.error('Error getting Facebook staff by channels:', error);
      return [];
    }
  }

  async assignStaff(assignData: StaffAssignDto, request: Request): Promise<boolean> {
    try {
      await this.validateConversation(assignData.channelId, assignData.conversationId);
      // Logic tạo task object cho Facebook (logic riêng của Facebook)
      const task: IStaffTask = {
        EventType: StaffEventType.StaffAssigned,
        PageId: assignData.channelId,
        Field: 'staff',
        Request: request,
        Data: {
          Id: assignData.staff.Id,
          Name: assignData.staff.Name,
          Picture: assignData.staff.Picture,
          AppUserId: assignData.staff.AppUserId,
          conversationId: assignData.conversationId,
          lastAssignStaff: assignData.lastAssignStaff,
          Type: assignData.type?.toString(),
          conversationCustomerName: assignData.conversationCustomerName,
          conversationMessage: assignData.conversationMessage,
          fbStaffName: assignData.fbStaffName,
          assignmentTurn: assignData.assignmentTurn,
        }
      };

      const result = await this.processTask(task, request);
      delete task.Request;
      this.publishEvent(staffRoutingKey + StaffEventType.StaffAssigned, task);
      return result;
    } catch (error) {
      throw new ChatError('STAFF_ASSIGNMENT_ERROR').withAdditional({
        originalError: error.message,
        context: 'Facebook staff assignment'
      });
    }
  }

  async unassignStaff(assignData: StaffAssignDto, request: Request): Promise<boolean> {
    try {
      await this.validateConversation(assignData.channelId, assignData.conversationId);
      // Logic tạo task object cho Facebook (logic riêng của Facebook)
      const task: IStaffTask = {
        EventType: StaffEventType.StaffUnassigned,
        PageId: assignData.channelId,
        Field: 'staff',
        Request: request,
        Data: {
          Id: assignData.staff.Id,
          Name: assignData.staff.Name,
          Picture: assignData.staff.Picture,
          AppUserId: assignData.staff.AppUserId,
          conversationId: assignData.conversationId,
          lastAssignStaff: assignData.lastAssignStaff,
          Type: assignData.type?.toString(),
          conversationCustomerName: assignData.conversationCustomerName,
          conversationMessage: assignData.conversationMessage,
          fbStaffName: assignData.fbStaffName,
          assignmentTurn: assignData.assignmentTurn,
        }
      };

      const result = await this.processTask(task, request);
      delete task.Request;
      this.publishEvent(staffRoutingKey + StaffEventType.StaffUnassigned, task);
      return result;
    } catch (error) {
      throw new ChatError('STAFF_UNASSIGNMENT_ERROR').withAdditional({
        originalError: error.message,
        context: 'Facebook staff unassignment'
      });
    }
  }

  async disableStaff(disableData: StaffDisableDto, request: Request): Promise<boolean> {
    try {
      const task: IStaffTask = {
        EventType: StaffEventType.StaffDisabled,
        PageId: disableData.channelId,
        Field: "staff",
        Data: {
          Id: disableData.staffId,
          RemoveAssignedStaff: disableData.removeAssignedStaff,
          RetailerId: disableData.retailerId,
        },
      };
      const result = await this.processTask(task, request);
      this.publishEvent(staffRoutingKey + StaffEventType.StaffDisabled, task);
      return result;
    } catch (error) {
      console.error('Error disabling Facebook staff:', error);
      return false;
    }
  }

  private async getSocialInfoForAuditLog(socialId: string): Promise<any> {
    try {
      const socialInfo = await this.pageSubscriptionService.getSubscriptionBySocialId(socialId);
      if (!socialInfo) {
        return {};
      }

      const socialName = socialInfo && ((socialInfo.PageInfo as any)?.name || (socialInfo.InstagramInfo as any)?.username) || '';
      const socialType = socialInfo.SocialType || (socialInfo.InstagramId ? ChatPlatformEnum.Instagram : ChatPlatformEnum.Facebook);

      const isInstagram = ChatPlatformEnum.Instagram === socialType;
      return {
        pageText: isInstagram ? 'Tài khoản Instagram' : 'Trang Facebook',
        socialType,
        linkPage: isInstagram ? buildLinkInstagram(socialName, socialName) :
          buildLinkFacebook(socialId, socialName),
        functionType: isInstagram ? AuditLogFunctions.InstagramFanpageSettings : AuditLogFunctions.FacebookFanpageSettings
      };
    } catch (error) {
      console.error('Error getting social info for audit log:', error);
      return {};
    }
  }

  private async writeConversationAssignmentAuditTrail(task: IStaffTask, socialInfo: any, request: Request): Promise<void> {
    let content = "";
    const conversationMessage = task.Data.Type === "2" ? ` {${task.Data.conversationMessage}}` : "";

    switch (task.EventType) {
      case StaffEventType.StaffAssigned: {
        content += parseInt(task.Data.Type || "1") === 1 ? "Tin nhắn " : "Bình luận ";
        content += `${task.Data.conversationCustomerName}${conversationMessage}`;
        if (task.Data.lastAssignStaff) {
          content += ` - ${task.Data.lastAssignStaff.Name} → ${content} - ${task.Data.Name}`;
        } else {
          content += ` - ${task.Data.Name}`;
        }
        content = `${task.Data.fbStaffName} - Phân công hội thoại ${socialInfo.socialType}: ${content}`;

        // Pass request object from controller
        const auditRequest: IAuditTrailRequest = { headers: request.headers };
        await this.auditTrailService.publishEvent(
          auditRequest,
          content,
          AuditTrailActionEnum.Updated,
          AuditLogFunctions.FacebookConversationAssignment,
        );
        break;
      }

      case StaffEventType.StaffUnassigned: {
        content += parseInt(task.Data.Type || "1") === 1 ? "Tin nhắn " : "Bình luận ";
        content += `${task.Data.conversationCustomerName}${conversationMessage} - ${task.Data.Name} → Chưa phân công`;
        content = `${task.Data.fbStaffName} - Phân công hội thoại ${socialInfo.socialType}: ${content}`;

        // Pass request object from controller
        const auditRequest2: IAuditTrailRequest = { headers: request.headers };
        await this.auditTrailService.publishEvent(
          auditRequest2,
          content,
          AuditTrailActionEnum.Updated,
          AuditLogFunctions.FacebookConversationAssignment,
        );
        break;
      }
    }
  }

  private async processTask(task: IStaffTask, request: Request): Promise<boolean> {
    const pageId = task.PageId;
    const staffId = task.Data?.Id || `staff_${task.Data?.AppUserId}`;
    const staff: any = {
      pageId,
      staffId,
      appUserId: task.Data?.AppUserId,
      name: task.Data?.Name,
      picture: task.Data?.Picture,
      state: 1,
      timestamp: Date.now(),
    };

    if (task.IsRoleAdmin != undefined) {
      staff.isRoleAdmin = task.IsRoleAdmin;
    }

    const conversationId = task.Data?.conversationId;
    let socialInfo;

    if ([StaffEventType.StaffAssigned, StaffEventType.StaffUnassigned].includes(task.EventType as StaffEventType)) {
      socialInfo = await this.getSocialInfoForAuditLog(task.PageId);
    }

    try {
      switch (task.EventType) {
        case StaffEventType.StaffAssigned:
          await this.pageStaffService.assignStaff(pageId, staffId, conversationId);
          await this.writeConversationAssignmentAuditTrail(task, socialInfo, request);
          break;

        case StaffEventType.StaffUnassigned:
          await this.pageStaffService.unassign(pageId, staffId, conversationId);
          await this.writeConversationAssignmentAuditTrail(task, socialInfo, request);
          break;

        case StaffEventType.StaffDisabled:
          await this.pageStaffService.updatePageStaff(pageId, staffId, {
            state: 0,
            keepForFilter: !task.Data?.RemoveAssignedStaff
          });
          await this.pageStaffService.removeStaff(pageId, staffId);
          if (task.Data?.RemoveAssignedStaff) {
            await this.pageStaffService.removeAssignedStaff(pageId, staffId);
          }
          break;
      }
    } catch (e) {
      console.error("[staff.controller.processTask] error", e);
      return false;
    }

    return true;
  }
  private async validateConversation(channelId: string, conversationId: string): Promise<boolean> {
    const conversation = await this.conversationService.getById(channelId, conversationId);
    if (!conversation) throw new ChatError('CONVERSATION_NOT_FOUND').withAdditional({
      channelId,
      conversationId
    });
    return true;
  }

  private publishEvent(routingKey: string, event: any) {
    this.amqpConnection.publish(this._rabbitMQConfig.mainExchange, routingKey, event);
  }

  async bulkAssignStaff(bulkAssignData: StaffBulkAssignDto, request: Request): Promise<boolean> {
    try {
      const { channels, staffId, conversations } = bulkAssignData;

      // Filter only Facebook channels
      const facebookChannels = channels.filter(channel => channel.platform === ChatPlatformEnum.Facebook || channel.platform === ChatPlatformEnum.Instagram);
      const facebookChannelIds = facebookChannels.flatMap(channel => channel.channelId);

      if (!facebookChannelIds || facebookChannelIds.length === 0) {
        throw new ChatError('CHANNEL_NOT_FOUND').withAdditional({
          context: 'Bulk assign staff'
        });
      }
      // Filter conversations for Facebook channels only
      const facebookConversations = conversations.filter(conv =>
        facebookChannelIds.includes(conv.channelId)
      );

      if (!facebookConversations || facebookConversations.length === 0) {
        throw new ChatError('CONVERSATION_NOT_FOUND').withAdditional({
          context: 'Bulk assign staff'
        });
      }

      // Convert conversations to the format expected by PageStaffService
      const conversationsForService = facebookConversations.map(conv => ({
        Id: conv.id,
        PageId: conv.channelId
      }));

      // Call PageStaffService bulkAssign method only for Facebook channels
      if (facebookChannelIds.length > 0) {
        await this.pageStaffService.bulkAssign(facebookChannelIds, staffId, conversationsForService);
      }

      return true;
    } catch (error) {
      console.error('Error in bulk assign staff:', error);
      return false;
    }
  }

  async bulkUnassignStaff(bulkUnassignData: StaffBulkUnassignDto, request: Request): Promise<boolean> {
    try {
      const { channels, staffId, conversations } = bulkUnassignData;

      // Filter only Facebook channels
      const facebookChannels = channels.filter(channel => channel.platform === ChatPlatformEnum.Facebook || channel.platform === ChatPlatformEnum.Instagram);
      const facebookChannelIds = facebookChannels.flatMap(channel => channel.channelId);

      if (!facebookChannelIds || facebookChannelIds.length === 0) {
        throw new ChatError('CHANNEL_NOT_FOUND').withAdditional({
          context: 'Bulk unassign staff'
        });
      }
      // Filter conversations for Facebook channels only
      const facebookConversations = conversations.filter(conv =>
        facebookChannelIds.includes(conv.channelId)
      );

      if (!facebookConversations || facebookConversations.length === 0) {
        throw new ChatError('CONVERSATION_NOT_FOUND').withAdditional({
          context: 'Bulk unassign staff'
        });
      }

      // Convert conversations to the format expected by PageStaffService
      const conversationsForService = facebookConversations.map(conv => ({
        Id: conv.id,
        PageId: conv.channelId,
        AssignedStaff: [staffId] // Add assigned staff for unassign operation
      }));

      // Call PageStaffService bulkUnassign method only for Facebook channels
      if (facebookChannelIds.length > 0) {
        await this.pageStaffService.bulkUnassign(facebookChannelIds, conversationsForService);
      }

      return true;
    } catch (error) {
      console.error('Error in bulk unassign staff:', error);
      return false;
    }
  }
} 