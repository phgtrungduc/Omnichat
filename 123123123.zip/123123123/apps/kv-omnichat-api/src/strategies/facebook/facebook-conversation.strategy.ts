import { Injectable } from '@nestjs/common';
import { IConversationStrategy, IConversationFilters, IConversationSearchByAccountFilters, IConversationSearchByMessageFilters } from '../../interfaces/conversation.interface';
import { ChatPlatformEnum, IChatConversation, KvLogger } from '@kiotviet-facebook-services/common';
import { ConversationService, IGetConversationParams, PageSubscriptionService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { ConversationFilterService } from '../../services/conversation-filter.service';
import { ConversationResolvedState, ConversationStateFilterEnum } from '../../common/enums/chat-search-type.enum';

@Injectable()
export class FacebookConversationStrategy implements IConversationStrategy {
  constructor(
    private readonly _conversationService: ConversationService,
    private readonly _pageSubscriptionService: PageSubscriptionService,
    private readonly _conversationFilterService: ConversationFilterService,
    private readonly logger: KvLogger
  ) { }
  public readonly platform = ChatPlatformEnum.Facebook;
  private retailerId: number;
  private projection = {
    _id: 1,
    SenderId: 1,
    SenderName: 1,
    SenderUserName: 1,
    PageId: 1,
    InstagramId: 1,
    Message: 1,
    TimeStamp: 1,
    Type: 1,
    State: 1,
    Source: 1,
    ThreadId: 1,
    AppUserId: 1,
    HasPhone: 1,
    HasEmail: 1,
    Resolved: 1,
    Staff: 1,
    PostId: 1,
    LastSenderId: 1,
    CommentFromLiveVideo: 1,
    IsValidateFormula: 1,
    Tags: 1,
    TimeRead: 1,
    PhoneNumberFound: 1,
    UnreadMessageCount: 1,
    LastUnreadTimestamp: 1,
  }

  async getConversations(filters?: IConversationFilters): Promise<IChatConversation[]> {
    // Use filters directly without conversion
    const conversations = await this.search(filters); // TODO: Get retailerId from context

    // Convert legacy results to IChatConversation format
    return conversations.map(conv => this.mapToIChatConversation(conv));
  }



  private async search(filters?: IConversationFilters): Promise<IChatConversation[]> {
    const retailerId = filters.retailerId;
    this.retailerId = retailerId;
    const channels = filters?.channels
      .filter(channel => channel.platform === ChatPlatformEnum.Facebook || channel.platform === ChatPlatformEnum.Instagram)
      .flatMap(channel => channel.channelDetails);

    if (channels.length === 0) {
      return [];
    }

    // Process each channelId separately
    const allConversations: any[] = [];

    for (const channel of channels) {
      const filterResult = await this._conversationFilterService.buildFacebookFilter(filters, retailerId, channel);

      // Add staff filter if needed
      if (filters?.staff) {
        const pageSetting = await this._pageSubscriptionService.getPageSetting(channel.channelId);
        const hideAssignedConversationsToOtherEmployees = pageSetting.Setting["HideAssignedConversationsToOtherEmployees"] || false;
        const staffFilter = this._conversationFilterService.buildFacebookStaffFilter(filters, channel.channelId, hideAssignedConversationsToOtherEmployees);
        filterResult.moreFilters.push(...staffFilter);
      }

      // Execute database query for this channelId
      const conversations = await this.executeDatabaseQuery(filterResult, this.projection);

      // Validate conversation parameters and normalize data
      this.getConversationsCheckNullParams(conversations);

      // Add to all conversations
      allConversations.push(...conversations);
    }

    // Merge and sort all conversations
    const mergedConversations = this.mergeAndSortConversations(allConversations, filters);

    return mergedConversations;
  }


  private async executeDatabaseQuery(filterResult: any, projection: any): Promise<any[]> {
    if (!filterResult.socialId) {
      return [];
    }

    const searchParams: IGetConversationParams = {
      socialId: filterResult.socialId,
      moreFilters: filterResult.moreFilters,
      limit: filterResult.limit + 1, //for has more
      projection: projection
    };

    return await this._conversationService.getConversations(searchParams) as any[];
  }



  private getConversationsCheckNullParams(conversations: any[]) {
    (conversations || []).forEach(conversation => {
      conversation.HasPhone = !!conversation.HasPhone;
      conversation.HasEmail = !!conversation.HasEmail;
      conversation.PostId = conversation.PostId || '';
      conversation.PhoneNumberFound = conversation.PhoneNumberFound || '';
      conversation.ThreadId = conversation.ThreadId || '';
      conversation.UnreadMessageCount = conversation.UnreadMessageCount || 0;
      conversation.LastSenderId = conversation.LastSenderId || '';
    });
  }

  private mapToIChatConversation(conversation: any): IChatConversation {
    const isInstagram = conversation.InstagramId ? true : false;
    return {
      // IChatBase fields
      retailerId: this.retailerId, // TODO: Get from context
      platform: isInstagram ? ChatPlatformEnum.Instagram : ChatPlatformEnum.Facebook,
      channelId: isInstagram ? conversation.InstagramId : conversation.PageId,

      // IChatConversation fields - only map fields that exist in projection
      id: conversation._id,
      conversationId: isInstagram ? conversation.ThreadId : conversation._id,
      type: conversation.Type as "messenger" | "feed" | 'chat',

      // Sender information
      senderId: conversation.SenderId,
      senderName: conversation.SenderUserName || conversation.SenderName,
      lastSenderId: conversation.LastSenderId,

      // Message information
      message: conversation.Message,

      // Conversation state
      state: conversation.State as ConversationStateFilterEnum,
      resolved: conversation.Resolved as ConversationResolvedState,
      unreadCount: conversation.UnreadMessageCount || 0,
      lastMessageTimestamp: conversation.TimeStamp,

      // Configuration
      staff: conversation.Staff || [],

      // Additional info
      hasPhone: conversation.HasPhone || false,
      hasEmail: conversation.HasEmail || false,

      // Related information
      threadId: conversation.ThreadId,
      postId: conversation.PostId,
      commentFromLiveVideo: conversation.CommentFromLiveVideo || false,
      isValidateFormula: conversation.IsValidateFormula || false,

      // Other fields
      source: conversation.Source as "GraphApi" | undefined,
    } as IChatConversation;
  }

  private mergeAndSortConversations(conversations: any[], filters?: IConversationFilters): any[] {
    // Remove duplicates based on conversation ID
    const uniqueConversations = this.removeDuplicateConversations(conversations);
    return uniqueConversations
  }

  private removeDuplicateConversations(conversations: any[]): any[] {
    const seen = new Set();
    return conversations.filter(conv => {
      const duplicate = seen.has(conv._id);
      seen.add(conv.Id);
      return !duplicate;
    });
  }

  public async getConversationsSearchByAccount(filters?: IConversationSearchByAccountFilters): Promise<IChatConversation[]> {
    const socials = filters?.channels?.filter(channel => channel.platform === ChatPlatformEnum.Facebook || channel.platform === ChatPlatformEnum.Instagram);
    if (socials.length === 0) {
      return [];
    }
    const allConversations: any[] = [];
    for (const social of socials) {
      const facebookFilter = {
        socialId: social.channelId,
        moreFilters: [
          { SenderName: { $regex: filters.keyword, $options: 'i' } }
        ],
        limit: filters.limit,
        sort: { TimeStamp: -1 }
      }
      const conversations = await this.executeDatabaseQuery(facebookFilter, this.projection);

      this.getConversationsCheckNullParams(conversations);
      allConversations.push(...conversations);
    }

    return allConversations.map(conversation => this.mapToIChatConversation(conversation));
  }

  public async getConversationsSearchByMessage(filters?: IConversationSearchByMessageFilters): Promise<IChatConversation[]> {
    const allConversations: any[] = [];
    const socials = filters?.channels?.filter(channel => channel.platform === ChatPlatformEnum.Facebook || channel.platform === ChatPlatformEnum.Instagram) || [];
    if (socials.length === 0) {
      return [];
    }

    // Flatten all channelIds and convert to numbers
    const socialIds = socials
      .flatMap(channel => channel.channelId)
      .map(channelId => channelId.toString())
      .filter(id => id !== null) || [];

    if (socialIds.length === 0) {
      return [];
    }

    for (const socialId of socialIds) {
      const conversations = await this._conversationService.getMessagesByKeyword(socialId, filters.keyword, filters.limit);
      allConversations.push(...conversations);
    }
    return allConversations.map(conversation => this.mapToIChatConversation(conversation));
  }

} 