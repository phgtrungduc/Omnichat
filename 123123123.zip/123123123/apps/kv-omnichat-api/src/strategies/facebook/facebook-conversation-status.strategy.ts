import { Injectable } from '@nestjs/common';
import { ChatPlatformEnum, KvLogger } from '@kiotviet-facebook-services/common';
import { FbposApiService } from '@kiotviet-facebook-services/external-platforms';
import { 
  IConversationStatusStrategy, 
  IConversationStatusRequest 
} from '../../interfaces/conversation-status.interface';
import {
  ConversationStatusTypeEnum,
  ConversationStatusActionEnum,
  ConversationStatusResultDto,
  ConversationIdentifierDto
} from '../../common/dto/conversation-status.dto';
import {
  IFbposToggleConversationRequest,
  IFbposResolveConversationRequest,
  IFbposBulkToggleConversationRequest,
  IFbposConversationStatusResponse
} from '../../modules/conversation/interfaces/fbpos';

@Injectable()
export class FacebookConversationStatusStrategy implements IConversationStatusStrategy {
     readonly platform = ChatPlatformEnum.Facebook;

  constructor(
    private readonly _fbposApiService: FbposApiService,
    private readonly logger: KvLogger
  ) {}

  async markStatus(request: IConversationStatusRequest): Promise<ConversationStatusResultDto[]> {
    const facebookConversations = request.conversations.filter(
      conv => conv.platform === ChatPlatformEnum.Facebook
    );

    if (facebookConversations.length === 0) {
      return [];
    }

    try {
      if (request.statusType === ConversationStatusTypeEnum.READ) {
        return await this._handleReadStatus(facebookConversations, request);
      } else if (request.statusType === ConversationStatusTypeEnum.RESOLVED) {
        return await this._handleResolvedStatus(facebookConversations, request);
      } else {
        throw new Error(`Unsupported status type: ${request.statusType}`);
      }
    } catch (error) {
      this.logger.error(`Error marking Facebook conversation status: ${error.message}`, error.stack);
      
      return facebookConversations.map(conv => ({
        conversationId: conv.conversationId,
        channelId: conv.channelId,
        platform: conv.platform,
        success: false,
        error: error.message
      }));
    }
  }

  private async _handleReadStatus(
    conversations: ConversationIdentifierDto[], 
    request: IConversationStatusRequest
  ): Promise<ConversationStatusResultDto[]> {
    const state = request.action === ConversationStatusActionEnum.MARK ? 0 : 1;

    // If only 1 conversation, call single API
    if (conversations.length === 1) {
      return await this._markSingleReadStatus(conversations[0], state, conversations[0].fbName, request);
    }
    
    // If multiple conversations, call bulk API
    return await this._markBulkReadStatus(conversations, state, conversations[0].fbName, request);
  }

  private async _handleResolvedStatus(
    conversations: ConversationIdentifierDto[], 
    request: IConversationStatusRequest
  ): Promise<ConversationStatusResultDto[]> {
    const state = request.action === ConversationStatusActionEnum.MARK ? 0 : 1;

    // FBPOS doesn't have bulk API for resolved, use Promise.allSettled for parallel processing
    const promises = conversations.map(conversation => 
      this._markSingleResolvedStatus(conversation, state, request)
    );

    const results = await Promise.allSettled(promises);
    const allResults: ConversationStatusResultDto[] = [];

    results.forEach((result, index) => {
      const conversation = conversations[index];
      
      if (result.status === 'fulfilled') {
        allResults.push(...result.value);
      } else {
        this.logger.error(`Error marking resolved status for conversation ${conversation.conversationId}: ${result.reason?.message || result.reason}`);
        allResults.push({
          conversationId: conversation.conversationId,
          channelId: conversation.channelId,
          platform: conversation.platform,
          success: false,
          error: result.reason?.message || String(result.reason)
        });
      }
    });

    return allResults;
  }

  private async _markSingleReadStatus(
    conversation: ConversationIdentifierDto, 
    state: number, 
    fbName?: string,
    request?: IConversationStatusRequest
  ): Promise<ConversationStatusResultDto[]> {
    const requestBody: IFbposToggleConversationRequest = {
      type: 'messenger',
      pageid: conversation.channelId,
      socialType: 'facebook',
      conversationid: conversation.conversationId,
      state,
      fbName
    };

    const response = await this._fbposApiService.post<IFbposConversationStatusResponse>(
      '/conversation/toggle',
      requestBody,
      {
        headers: request?.headers
      }
    );

    return [{
      conversationId: conversation.conversationId,
      channelId: conversation.channelId,
      platform: conversation.platform,
      success: response.data.status === 'success',
      platformData: response.data.data
    }];
  }

  private async _markBulkReadStatus(
    conversations: ConversationIdentifierDto[], 
    state: number, 
    fbName?: string,
    request?: IConversationStatusRequest
  ): Promise<ConversationStatusResultDto[]> {
    // Group conversations by pageId
    const conversationsByPage = conversations.reduce((acc, conv) => {
      if (!acc[conv.channelId]) {
        acc[conv.channelId] = [];
      }
      acc[conv.channelId].push(conv.conversationId);
      return acc;
    }, {} as Record<string, string[]>);

    const results: ConversationStatusResultDto[] = [];

    // Process each page separately
    for (const [pageId, conversationIds] of Object.entries(conversationsByPage)) {
      try {
        const requestBody: IFbposBulkToggleConversationRequest = {
          type: 'messenger',
          pageid: pageId,
          conversationids: { [pageId]: conversationIds },
          state,
          fbName
        };

        const response = await this._fbposApiService.post<IFbposConversationStatusResponse>(
          '/conversation/bulk-toggle',
          requestBody,
          {
            headers: request?.headers
          }
        );

        // Map response to results
        conversationIds.forEach(conversationId => {
          results.push({
            conversationId,
            channelId: pageId,
            platform: ChatPlatformEnum.Facebook,
            success: response.data.status === 'success',
            platformData: response.data.data
          });
        });

      } catch (error) {
        this.logger.error(`Error bulk marking read status for page ${pageId}: ${error.message}`);
        
        // Add failed results for this page
        conversationIds.forEach(conversationId => {
          results.push({
            conversationId,
            channelId: pageId,
            platform: ChatPlatformEnum.Facebook,
            success: false,
            error: error.message
          });
        });
      }
    }

    return results;
  }

  private async _markSingleResolvedStatus(
    conversation: ConversationIdentifierDto, 
    state: number,
    request?: IConversationStatusRequest
  ): Promise<ConversationStatusResultDto[]> {
    const requestBody: IFbposResolveConversationRequest = {
      type: 'messenger',
      pageid: conversation.channelId,
      socialType: 'facebook',
      conversationid: conversation.conversationId,
      state
    };

    const response = await this._fbposApiService.post<IFbposConversationStatusResponse>(
      '/conversation/resolve',
      requestBody,
      {
        headers: request?.headers
      }
    );

    return [{
      conversationId: conversation.conversationId,
      channelId: conversation.channelId,
      platform: conversation.platform,
      success: response.data.status === 'success',
      platformData: response.data.data
    }];
  }
} 