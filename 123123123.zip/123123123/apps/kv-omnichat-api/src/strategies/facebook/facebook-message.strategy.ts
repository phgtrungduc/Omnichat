import { Injectable } from '@nestjs/common';
import { ChatPlatformEnum, KvLogger, IChatMessage, ChatMessageTypeEnum, ChatMessageStateEnum, ChatMessageSourceEnum } from '@kiotviet-facebook-services/common';
import { IConversationMessagesFilters, IConversationMessagesResponse } from '../../interfaces/message.interface';
import { IMessageStrategy } from '../message/message-strategy.interface';
import { FbposApiService } from '@kiotviet-facebook-services/external-platforms';

interface FacebookMessagesResponse {
  status: string;
  data: any[];
  hasMore: boolean;
}

interface FacebookMessageItem {
  _id: string;
  ApiVersion: string;
  PageId: string;
  Field: string;
  TimeStamp: number;
  GroupId: string;
  SenderName: string;
  SenderId: string;
  payload: {
    sender: { id: string };
    recipient: { id: string };
    timestamp: number;
    message: {
      mid: string;
      text?: string;
      is_echo?: boolean;
      app_id?: number;
      metadata?: string;
      is_deleted?: boolean;
      attachments?: Array<{
        type: string;
        title?: string;
        payload?: {
          url?: string;
          template_type?: string;
          buttons?: Array<any>;
          elements?: Array<any>;
        }
      }>;
    };
  };
}

@Injectable()
export class FacebookMessageStrategy implements IMessageStrategy {
  constructor(
    private readonly logger: KvLogger,
    private readonly fbposApiService: FbposApiService,
  ) { }
  readonly platform = ChatPlatformEnum.Facebook;
  
  async getConversationMessages(
    filters: IConversationMessagesFilters
  ): Promise<IConversationMessagesResponse> {
    try {
      const { conversationId, platformUserId, pageAccessToken, limit = 20, conversationType, afterTimestamp, channelId } = filters;
      
      const queryParams = {
        pageid: channelId,
        conversationid: conversationId,
        type: conversationType,
        limit: limit,
        ...platformUserId ? { appuserid: platformUserId } : {},
        ...afterTimestamp ? { timestamp: afterTimestamp } : {},
        ...pageAccessToken ? { page_access_token: pageAccessToken } : {},
      };
      
      const response = await this.fbposApiService.get<FacebookMessagesResponse>('/conversation/detail', { params: queryParams, headers: { 'Content-Type': 'application/json', 'Authorization': filters.authorization }   });
      
      if (response && response.data && response.data.status === 'success' && Array.isArray(response.data.data)) {
        const formattedMessages = response.data.data.map(item => this.formatFacebookMessageToIChatMessage(item, filters));
        return {
          items: formattedMessages,
          more: response.data.hasMore || false
        };
      }
      
      return {
        items: [],
        more: false
      };
    } catch (error) {
      this.logger.error(`Error fetching Facebook conversation messages: ${error.message}`, error.stack);
      return {
        items: [],
        more: false
      };
    }
  }
  
  private formatFacebookMessageToIChatMessage(fbMessage: FacebookMessageItem, filters: IConversationMessagesFilters): IChatMessage {
    // Extract message content
    const messageData = fbMessage.payload.message;
    const hasAttachments = messageData.attachments && messageData.attachments.length > 0;
    
    // Determine message type
    let messageType = ChatMessageTypeEnum.TEXT;
    if (hasAttachments) {
      const attachmentType = messageData.attachments[0].type;
      switch (attachmentType) {
        case 'image':
          messageType = ChatMessageTypeEnum.IMAGE;
          break;
        case 'video':
          messageType = ChatMessageTypeEnum.VIDEO;
          break;
        case 'audio':
          messageType = ChatMessageTypeEnum.AUDIO;
          break;
        case 'file':
          messageType = ChatMessageTypeEnum.FILE;
          break;
        case 'template':
          messageType = ChatMessageTypeEnum.TEMPLATE;
          break;
        default:
          messageType = ChatMessageTypeEnum.TEXT; // Default to TEXT for unknown types
      }
    }
    
    // Determine if message is from customer or page
    const isFromPage = fbMessage.SenderId === fbMessage.PageId;
    
    // Format attachments if present
    const formattedAttachments = hasAttachments ? messageData.attachments.map(attachment => {
      const result: any = {
        type: attachment.type === 'template' ? ChatMessageTypeEnum.TEMPLATE : (
          attachment.type === 'image' ? ChatMessageTypeEnum.IMAGE : (
            attachment.type === 'video' ? ChatMessageTypeEnum.VIDEO : (
              attachment.type === 'audio' ? ChatMessageTypeEnum.AUDIO : ChatMessageTypeEnum.FILE
            )
          )
        ),
      };
      
      if (attachment.payload && attachment.payload.url) {
        result.url = attachment.payload.url;
      }
      
      if (attachment.type === 'template') {
        result.templateType = attachment.payload?.template_type || 'generic';
        result.title = attachment.title || '';
        result.buttons = attachment.payload?.buttons || [];
        result.elements = attachment.payload?.elements || [];
      }
      
      return result;
    }) : [];
    
    // Parse metadata if present
    let metadata: any = {};
    if (messageData.metadata) {
      try {
        metadata = JSON.parse(messageData.metadata);
      } catch (e) {
        this.logger.warn(`Failed to parse message metadata: ${messageData.metadata}`);
      }
    }
    
    // Format the final IChatMessage object
    return {
      id: fbMessage._id,
      messageId: messageData.mid,
      conversationId: fbMessage.GroupId,
      platform: ChatPlatformEnum.Facebook,
      retailerId: parseInt(filters.retailerId as unknown as string) || 0,
      channelId: filters.channelId || '',
      
      type: messageType,
      content: messageData.text || '',
      timestamp: fbMessage.TimeStamp,
      
      sender: {
        id: fbMessage.SenderId,
        // name: fbMessage.SenderName || '',
        // type: isFromPage ? MessageSource.STAFF : MessageSource.CUSTOMER,
        platformId: fbMessage.SenderId
      },
      
      recipient: {
        id: fbMessage.PageId,
        // name: '',
        // type: isFromPage ? MessageSource.CUSTOMER : MessageSource.STAFF,
        platformId: fbMessage.PageId
      },
      
      state: messageData.is_deleted ? ChatMessageStateEnum.DELETED : ChatMessageStateEnum.SENT,
      source: isFromPage ? ChatMessageSourceEnum.STAFF : ChatMessageSourceEnum.CUSTOMER,
      
      attachments: formattedAttachments,
      
      metadata: {
        isAutoReply: metadata.SentAuto === 1,
        customFields: {
          isEcho: !!messageData.is_echo,
          appId: messageData.app_id,
          ...metadata
        }
      },
      
      createdDate: new Date(fbMessage.TimeStamp),
      modifiedDate: null,
      
      rawData: fbMessage
    };
  }
} 