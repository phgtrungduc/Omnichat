import { Injectable } from '@nestjs/common';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { FbUserProfileService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { UserProfileDto, UserProfileResponseDto } from '../../modules/user/dto/user.dto';
import { IUserStrategy } from '../../composite/composite-user.strategy';

@Injectable()
export class FacebookUserStrategy implements IUserStrategy {
  public readonly platform = ChatPlatformEnum.Facebook;

  constructor(
    private readonly fbUserProfileService: FbUserProfileService
  ) {}

  async getUserProfile(dto: UserProfileDto): Promise<UserProfileResponseDto> {
    try {
      if (dto.platform !== ChatPlatformEnum.Facebook) {
        return {};
      }

      const rawProfile = await this.fbUserProfileService.handleReadFbUserProfile(dto.userId);
      
      if (!rawProfile) {
        return {};
      }

      // Transform Facebook profile data to camelCase
      const transformedProfile: UserProfileResponseDto = {
        id: rawProfile.id,
        firstName: rawProfile.first_name,
        lastName: rawProfile.last_name,
        name: rawProfile.name,
        username: rawProfile.username,
        profilePic: rawProfile.profile_pic,
        gender: rawProfile.gender,
        channelId: rawProfile.socialId,
        phoneNumber: rawProfile.phoneNumber,
        kvCustomers: rawProfile.kvCustomers,
        updatedAt: rawProfile.updatedAt,
        platform: ChatPlatformEnum.Facebook,
      };

      // Remove undefined values
      Object.keys(transformedProfile).forEach(key => {
        if (transformedProfile[key] === undefined) {
          delete transformedProfile[key];
        }
      });

      return transformedProfile;
    } catch (error) {
      console.error('Error getting Facebook user profile:', error);
      return null;
    }
  }

  async getUserProfilePicture(dto: UserProfileDto): Promise<string> {
    try {
      if (dto.platform !== ChatPlatformEnum.Facebook) {
        return null;
      }

      const rawProfile = await this.fbUserProfileService.handleReadFbUserProfile(dto.userId);
      
      if (!rawProfile) {
        return null;
      }

      // Return only the profile picture URL
      return rawProfile.profile_pic || null;
    } catch (error) {
      console.error('Error getting Facebook user profile picture:', error);
      return null;
    }
  }
}
