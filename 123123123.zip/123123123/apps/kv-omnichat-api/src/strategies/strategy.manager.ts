import { Injectable } from '@nestjs/common';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { IBaseStrategy, StrategyType } from './base-strategy.interface';

@Injectable()
export class StrategyManager {
  // Map 2 chiều: strategyType -> platform -> strategy
  private strategies: Map<StrategyType, Map<ChatPlatformEnum, IBaseStrategy>> = new Map();
  
  constructor() {
    // Khởi tạo map cho từng loại strategy
    Object.values(StrategyType).forEach(type => {
      this.strategies.set(type as StrategyType, new Map());
    });
  }
  
  // Đăng ký một strategy
  registerStrategy<T extends IBaseStrategy>(
    type: StrategyType, 
    strategy: T
  ): void {
    if (!this.strategies.has(type)) {
      this.strategies.set(type, new Map());
    }
    this.strategies.get(type).set(strategy.platform, strategy);
  }
  
  // Đăng ký nhiều strategy cùng loại
  registerStrategies<T extends IBaseStrategy>(
    type: StrategyType, 
    strategies: T[]
  ): void {
    strategies.forEach(strategy => this.registerStrategy(type, strategy));
  }
  
  // Lấy strategy theo loại và platform với type safety
  getStrategy<T extends IBaseStrategy>(
    type: StrategyType, 
    platform: ChatPlatformEnum
  ): T {
    const strategyMap = this.strategies.get(type);
    if (!strategyMap) {
      throw new Error(`Strategy type ${type} not registered`);
    }
    
    const strategy = strategyMap.get(platform) as T;
    if (!strategy) {
        // Handle Instagram fallback to Facebook for certain strategy types
        if(platform === ChatPlatformEnum.Instagram) {
            const facebookStrategy = strategyMap.get(ChatPlatformEnum.Facebook) as T;
            if (facebookStrategy) {
                return facebookStrategy;
            }
        }
      throw new Error(`Strategy for platform ${platform} and type ${type} not found`);
    }
    
    return strategy;
  }

} 