import { Request } from 'express';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

/**
 * Channel request với filter customer tags
 */
export interface IChannelWithCustomerTagsFilter {
  channelId: string;
  platform: ChatPlatformEnum;
  filter: {
    SenderId: string[];
  };
}

/**
 * Request data chung cho Customer Tags
 */
export interface ICustomerTagsRequest {
  channels: IChannelWithCustomerTagsFilter[];
}

/**
 * Data item chung cho Customer Tag response
 */
export interface ICustomerTagData {
  id: string;
  channelId: string;
  platform: ChatPlatformEnum;
  senderId: string;
  customerTagId: string | null;
  createdTime: number;
  isActive?: boolean;
}

/**
 * Response chung cho Customer Tags
 */
export interface ICustomerTagsResponse {
  success: boolean;
  data: ICustomerTagData[];
  message?: string;
}

/**
 * Interface chung cho tất cả Customer Tags strategies
 */
export interface ICustomerTagsStrategy {
  /**
   * Lấy danh sách customer tags mapping từ platform tương ứng
   * @param req Express request object chứa headers và auth info
   * @param data Dữ liệu customer tags request
   * @returns Promise<ICustomerTagsResponse> Response đã được format chung
   */
  getCustomerTags(req: Request, data: ICustomerTagsRequest): Promise<ICustomerTagsResponse>;

  /**
   * Kiểm tra xem strategy có hỗ trợ platform này không
   * @param platform Platform cần kiểm tra
   * @returns boolean
   */
  supports(platform: ChatPlatformEnum): boolean;
} 