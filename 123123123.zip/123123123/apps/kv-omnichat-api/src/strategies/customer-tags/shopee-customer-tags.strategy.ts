import { Injectable, Logger } from '@nestjs/common';
import { Request } from 'express';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { 
  ICustomerTagsStrategy, 
  ICustomerTagsRequest, 
  ICustomerTagsResponse
} from './customer-tags-strategy.interface';

@Injectable()
export class ShopeeCustomerTagsStrategy implements ICustomerTagsStrategy {
  private readonly logger = new Logger(ShopeeCustomerTagsStrategy.name);

  /**
   * Kiểm tra strategy có hỗ trợ platform Shopee không
   */
  supports(platform: ChatPlatformEnum): boolean {
    return platform === ChatPlatformEnum.Shopee;
  }

  /**
   * Lấy danh sách customer tags mapping từ Omnichannel
   * TODO: Implement khi có yêu cầu từ Shopee platform
   */
  async getCustomerTags(req: Request, data: ICustomerTagsRequest): Promise<ICustomerTagsResponse> {
    this.logger.warn('Shopee customer tags mapping is not implemented yet');
    
    return {
      success: false,
      data: [],
      message: 'Shopee platform is not supported for customer tags mapping yet'
    };
  }
} 