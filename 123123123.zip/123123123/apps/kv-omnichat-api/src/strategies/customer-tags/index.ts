export * from './customer-tags-strategy.interface';
export * from './facebook-customer-tags.strategy';
export * from './shopee-customer-tags.strategy'; 