import { Injectable } from '@nestjs/common';
import { Request } from 'express';
import { ChatPlatformEnum, KvLogger } from '@kiotviet-facebook-services/common';
import { FbposApiService } from '@kiotviet-facebook-services/external-platforms';
import { 
  ICustomerTagsStrategy, 
  ICustomerTagsRequest, 
  ICustomerTagsResponse,
  ICustomerTagData
} from './customer-tags-strategy.interface';
import { 
  IFbposCustomerTagsRequest,
  IFbposCustomerTagsResponse 
} from '../../modules/customer-tags/interfaces/fbpos';

@Injectable()
export class FacebookCustomerTagsStrategy implements ICustomerTagsStrategy {

  constructor(
    private readonly logger: KvLogger,
    private readonly fbposApiService: FbposApiService
  ) {}

  /**
   * Kiểm tra strategy có hỗ trợ platform Facebook/Instagram không
   */
  supports(platform: ChatPlatformEnum): boolean {
    return platform === ChatPlatformEnum.Facebook || platform === ChatPlatformEnum.Instagram;
  }

  /**
   * Lấy danh sách customer tags mapping từ FBPOS
   */
  async getCustomerTags(req: Request, data: ICustomerTagsRequest): Promise<ICustomerTagsResponse> {
    const facebookChannels = data.channels.filter(c => 
      c.platform === ChatPlatformEnum.Facebook || c.platform === ChatPlatformEnum.Instagram
    );
    const channelIds = facebookChannels.map(c => c.channelId);
    
    this.logger.info(`Getting customer tags mapping for ${facebookChannels.length} Facebook channels: ${channelIds.join(', ')}`);

    try {
      // Tạo filter object từ channels với format FBPOS yêu cầu
      const filterObject: Record<string, { SenderId: string[] }> = {};
      
      facebookChannels.forEach(channel => {
        filterObject[channel.channelId] = {
          SenderId: channel.filter.SenderId
        };
      });

      // Map request data sang format FBPOS
      const fbposData: IFbposCustomerTagsRequest = {
        pageid: channelIds.join(','), // FBPOS API accept comma-separated pageids
        filter: filterObject
      };

      const response = await this.fbposApiService.post<IFbposCustomerTagsResponse>(
        '/customer-tag/find',
        fbposData,
        {
          headers: req.headers
        }
      );

      const fbposResponseData = response.data;
      
      // Map response từ FBPOS format sang common format
      const mappedData: ICustomerTagData[] = [];
      
      if (fbposResponseData?.data) {
        for (const [mappingKey, item] of Object.entries(fbposResponseData.data)) {
          // Parse mapping key để lấy channelId
          const [channelId] = mappingKey.split('/');
          
          // Tìm platform tương ứng với channelId này
          const channel = facebookChannels.find(c => c.channelId === channelId);
          
          mappedData.push({
            id: item._id,
            channelId: channelId,
            platform: channel?.platform || ChatPlatformEnum.Facebook,
            senderId: item.SenderId,
            customerTagId: item.CustomerTagId,
            createdTime: item.created_time,
            isActive: true
          });
        }
      }

      const result: ICustomerTagsResponse = {
        success: true,
        data: mappedData,
        message: `Successfully retrieved ${mappedData.length} customer tags mapping from ${facebookChannels.length} Facebook channels`
      };

      this.logger.info(`Retrieved ${mappedData.length} customer tags mapping from FBPOS for channels: ${channelIds.join(', ')}`);
      
      return result;

    } catch (error) {
      const errorMessage = `Error getting customer tags mapping from FBPOS for channels: ${channelIds.join(', ')} - ${error.message}`;
      this.logger.error(errorMessage, error);
      
      return {
        success: false,
        data: [],
        message: errorMessage
      };
    }
  }
} 