import { IBaseStrategy } from '../base-strategy.interface';
import { IConversationMessagesFilters, IConversationMessagesResponse } from '../../interfaces/message.interface';

export interface IMessageStrategy extends IBaseStrategy {
  getConversationMessages(
    filters: IConversationMessagesFilters
  ): Promise<IConversationMessagesResponse>;
  
  // Thêm các phương thức khác liên quan đến message nếu cần
} 