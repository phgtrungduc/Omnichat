import { Injectable } from '@nestjs/common';

@Injectable()
export class BaseStaffStrategy {
  // TODO: Implement base staff strategy methods
} 