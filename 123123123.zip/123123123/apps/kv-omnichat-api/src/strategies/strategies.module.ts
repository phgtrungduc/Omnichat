import { Global, Module, OnModuleInit } from '@nestjs/common';
import { ModuleRef } from '@nestjs/core';
import { StrategyManager } from './strategy.manager';
import { StrategyType } from './base-strategy.interface';
import { FacebookMessageStrategy } from './facebook/facebook-message.strategy';
import { ShopeeMessageStrategy } from './shopee/shopee-message.strategy';
import { FacebookFeedpostStrategy } from './facebook/facebook-feedpost.strategy';
import { ShopeeFeedpostStrategy } from './shopee/shopee-feedpost.strategy';
import { OmniChannelRepositoryModule } from '@kiotviet-facebook-services/omnichannel-repository';
import { OmnimongoRepositoryModule } from '@kiotviet-facebook-services/omnimongo-repository';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';

@Module({
  imports:[
    OmniChannelRepositoryModule, 
    OmnimongoRepositoryModule,
    FbPosMasterRepositoryModule,
  ],
  providers: [
    StrategyManager,
    // Message strategies
    FacebookMessageStrategy,
    ShopeeMessageStrategy,
    // Feedpost strategies
    FacebookFeedpostStrategy,
    ShopeeFeedpostStrategy
    // Thêm các strategy khác nếu có
  ],
  exports: [StrategyManager]
})
export class StrategiesModule implements OnModuleInit {
  constructor(
    private readonly moduleRef: ModuleRef,
    private readonly strategyManager: StrategyManager
  ) {}
  
  onModuleInit() {
    // Đăng ký message strategies
    const facebookMessageStrategy = this.moduleRef.get(FacebookMessageStrategy);
    const shopeeMessageStrategy = this.moduleRef.get(ShopeeMessageStrategy);
    
    this.strategyManager.registerStrategies(StrategyType.MESSAGE, [
      facebookMessageStrategy,
      shopeeMessageStrategy,
      // Thêm các strategy khác nếu có
    ]);

    // Đăng ký feedpost strategies
    const facebookFeedpostStrategy = this.moduleRef.get(FacebookFeedpostStrategy);
    const shopeeFeedpostStrategy = this.moduleRef.get(ShopeeFeedpostStrategy);
    
    this.strategyManager.registerStrategies(StrategyType.FEEDPOST, [
      facebookFeedpostStrategy,
      shopeeFeedpostStrategy,
      // Thêm các strategy khác nếu có
    ]);
    
    // Đăng ký các loại strategy khác nếu cần
    // this.strategyManager.registerStrategies(StrategyType.CONVERSATION, [...]);
  }
} 