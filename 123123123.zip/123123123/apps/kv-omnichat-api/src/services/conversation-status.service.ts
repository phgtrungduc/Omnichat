import { ChatPlatformEnum, KvLogger } from '@kiotviet-facebook-services/common';
import { Injectable } from '@nestjs/common';
import { Request } from 'express';
import {
  ConversationStatusResultDto,
  MarkConversationStatusDto,
  MarkConversationStatusResponseDto
} from '../common/dto/conversation-status.dto';
import {
  IConversationStatusRequest,
  IConversationStatusStrategy
} from '../interfaces/conversation-status.interface';
import { FacebookConversationStatusStrategy } from '../strategies/facebook/facebook-conversation-status.strategy';
import { ShopeeConversationStatusStrategy } from '../strategies/shopee/shopee-conversation-status.strategy';

@Injectable()
export class ConversationStatusService {
  private readonly strategies = new Map<ChatPlatformEnum, IConversationStatusStrategy>();

  constructor(
    private readonly _logger: KvLogger,
    private readonly _facebookStrategy: FacebookConversationStatusStrategy,
    private readonly _shopeeStrategy: ShopeeConversationStatusStrategy
  ) {
    this._registerStrategies();
  }

  async markConversationStatus(
    request: MarkConversationStatusDto,
    req?: Request
  ): Promise<MarkConversationStatusResponseDto> {
    this._logger.info(`Marking conversation status: ${request.statusType} ${request.action} for ${request.conversations.length} conversations`);
    
    const allResults: ConversationStatusResultDto[] = [];
    
    // Group conversations by platform
    const conversationsByPlatform = this._groupConversationsByPlatform(request.conversations);
    
    // Process each platform
    for (const [platform, conversations] of conversationsByPlatform.entries()) {
      try {
        const strategy = this.strategies.get(platform);
        
        if (!strategy) {
          this._logger.warn(`No strategy found for platform: ${platform}`);
          
          // Add failed results for unsupported platform
          const failedResults = conversations.map(conv => ({
            conversationId: conv.conversationId,
            channelId: conv.channelId,
            platform: conv.platform,
            success: false,
            error: `No strategy found for platform: ${platform}`
          }));
          
          allResults.push(...failedResults);
          continue;
        }

        // Execute strategy for this platform
        const strategyRequest: IConversationStatusRequest = {
          statusType: request.statusType,
          action: request.action,
          conversations,
          headers: req?.headers as Record<string, string>
        };

        const platformResults = await strategy.markStatus(strategyRequest);
        allResults.push(...platformResults);

      } catch (error) {
        this._logger.error(`Error processing platform ${platform}: ${error.message}`, error.stack);
        
        // Add failed results for this platform
        const failedResults = conversations.map(conv => ({
          conversationId: conv.conversationId,
          channelId: conv.channelId,
          platform: conv.platform,
          success: false,
          error: error.message
        }));
        
        allResults.push(...failedResults);
      }
    }

    // Calculate summary statistics
    const totalProcessed = allResults.length;
    const successCount = allResults.filter(result => result.success).length;
    const failureCount = totalProcessed - successCount;
    const overallSuccess = failureCount === 0;

    const response: MarkConversationStatusResponseDto = {
      success: overallSuccess,
      totalProcessed,
      successCount,
      failureCount,
      results: allResults,
      message: this._generateSummaryMessage(overallSuccess, successCount, failureCount)
    };

    this._logger.info(`Conversation status marking completed: ${successCount}/${totalProcessed} successful`);
    
    return response;
  }

  getSupportedPlatforms(): ChatPlatformEnum[] {
    return Array.from(this.strategies.keys());
  }

  isPlatformSupported(platform: ChatPlatformEnum): boolean {
    return this.strategies.has(platform);
  }

  private _groupConversationsByPlatform(conversations: any[]) {
    return conversations.reduce((acc, conv) => {
      if (!acc.has(conv.platform)) {
        acc.set(conv.platform, []);
      }
      acc.get(conv.platform)!.push(conv);
      return acc;
    }, new Map<ChatPlatformEnum, any[]>());
  }

  private _generateSummaryMessage(overallSuccess: boolean, successCount: number, failureCount: number): string {
    if (overallSuccess) {
      return `Successfully updated status for all ${successCount} conversations`;
    } else if (successCount > 0) {
      return `Successfully updated ${successCount} conversations, ${failureCount} failed`;
    } else {
      return `Failed to update status for all ${failureCount} conversations`;
    }
  }

  private _registerStrategies(): void {
    this.strategies.set(ChatPlatformEnum.Facebook, this._facebookStrategy);
    this.strategies.set(ChatPlatformEnum.Shopee, this._shopeeStrategy);
  }

} 