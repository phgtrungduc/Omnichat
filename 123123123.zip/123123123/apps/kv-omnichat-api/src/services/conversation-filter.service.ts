import { Injectable } from '@nestjs/common';
import { IConversationFilters } from '../interfaces/conversation.interface';
import { ConversationSortEnum } from '../common/enums/conversation-sort.enum';
import { ConversationStateFilterEnum, ConversationReadState, ConversationResolvedState, ChatConversationType } from '../common/enums/chat-search-type.enum';
import { PageCustomerTagService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { IChannelPaging } from '../common/interfaces/platform-channel.interface';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

const MAX_MONTHS_CONVERSATION = 3;
export interface IFacebookFilterResult {
  socialId: string;
  moreFilters: any[];
  limit?: number;
  sort?: any;
}

export interface IShopeeFilterResult {
  query: any;
  sortOptions: any;
  limit: number;
  skip: number;
}

@Injectable()
export class ConversationFilterService {
  constructor(
    private readonly pageCustomerTagService: PageCustomerTagService
  ) { }

  /**
   * Build Facebook conversation filter
   */
  async buildFacebookFilter(
    filters: IConversationFilters | undefined,
    retailerId: number,
    channel: IChannelPaging
  ): Promise<IFacebookFilterResult> {
    const moreFilters = await this.buildFacebookComprehensiveFilter(filters, retailerId, channel);

    return {
      socialId: channel.channelId,
      moreFilters,
      limit: filters?.limit,
      ...(channel.beforeTimestamp || channel.afterTimestamp) ? { sort: this.buildFacebookSort(filters?.sortBy) } : {}
    };
  }

  /**
   * Build Shopee conversation filter
   */
  buildShopeeFilter(filters: IConversationFilters): IShopeeFilterResult {
    const query = this.buildShopeeQuery(filters);
    const sortOptions = this.buildShopeeSort(filters?.sortBy);
    const limit = filters?.limit || 30;
    const skip = filters?.skip || 0;

    return {
      query,
      sortOptions,
      limit,
      skip
    };
  }

  /**
   * Build Facebook comprehensive filter
   */
  private async buildFacebookComprehensiveFilter(
    filters: IConversationFilters | undefined,
    retailerId: number,
    channel: IChannelPaging
  ): Promise<any[]> {
    const filter: any[] = [];

    // Message filters
    if (filters?.hasPhone) {
      filter.push({ HasPhone: true });
    }

    // Conversation type filter
    if (filters?.conversationType) {
      const conversationTypeFilter = this.buildFacebookConversationTypeFilter(filters.conversationType);
      if (Object.keys(conversationTypeFilter).length > 0) {
        filter.push(conversationTypeFilter);
      }
    }

    // Tags filter 
    if (filters?.tags && filters.tags.length > 0) {
      if (filters.includeNoTags) {
        filter.push({
          $or: [
            { Tags: { $exists: false } },
            { Tags: { $in: filters.tags } },
          ]
        });
      } else {
        filter.push({ Tags: { $in: filters.tags } });
      }
    }

    // Customer tags filter
    if (filters?.customerTags && filters.customerTags.length > 0) {
      const customerFiltes = await this.buildFacebookCustomerTagFilter(filters, channel.channelId);
      filter.push(customerFiltes);
    }

    // Correct syntax filter (Facebook specific)
    if (filters?.correctSyntax === 1) {
      filter.push({ IsValidateFormula: true });
    }

    // State filter for specific socialId
    if (filters?.state) {
      const stateFilter = this.buildFacebookStateFilter(filters, channel.channelId);
      if (stateFilter.length > 0) {
        filter.push(...stateFilter);
      }
    }

    if (filters?.source && filters.source.length > 0) {
      filter.push({ PostId: { $in: filters.source } });
    }

    // Time filters
    const toDate = filters?.to || (new Date()).getTime();
    const fromDate = filters?.from || this.getTimeSpanFilter(toDate);

    const filterTime = [
      { TimeStamp: { $lt: toDate } },
      { TimeStamp: { $gte: fromDate } }];

    if (channel.beforeTimestamp) {
      filterTime.push({ TimeStamp: { $lt: channel.beforeTimestamp } });
    }

    if (channel.afterTimestamp) {
      filterTime.push({ TimeStamp: { $gte: channel.afterTimestamp } });
    }
    filter.push({ $and: filterTime });

    return filter;
  }

  private async buildFacebookCustomerTagFilter(filters: IConversationFilters, socialId: string): Promise<any> {
    const filter: any[] = [];
    if (!filters.customerTags || filters.customerTags.length === 0) return [];

    const customerTags = await this.pageCustomerTagService.findByCustomerTagId(socialId, filters.customerTags);

    filter.push({ SenderId: { $in: customerTags.map(tag => tag.senderId) } });
    return filter;
  }

  /**
   * Build Facebook conversation type filter
   */
  private buildFacebookConversationTypeFilter(conversationType: ChatConversationType): any {
    switch (conversationType) {
      case ChatConversationType.MESSENGER:
        return { Type: ChatConversationType.MESSENGER };
      case ChatConversationType.FEED:
        return { Type: ChatConversationType.FEED };
      default:
        return { Type: { $in: [ChatConversationType.MESSENGER, ChatConversationType.FEED] } };
    }
  }

  /**
   * Build Facebook state filter
   */
  private buildFacebookStateFilter(filters: IConversationFilters, socialId: string): any[] {
    const filterByPage: any[] = [];
    const state = filters?.state;

    switch (state) {
      case ConversationStateFilterEnum.NotReplied:
        filterByPage.push({
          $and: [
            { LastSenderId: { $exists: true } },
            { LastSenderId: { $ne: socialId } },
          ],
        });
        break;
      case ConversationStateFilterEnum.Replied:
        filterByPage.push({
          $or: [
            { LastSenderId: { $exists: false } },
            { LastSenderId: socialId },
          ],
        });
        break;
      case ConversationStateFilterEnum.ReadButNotReplied:
        filterByPage.push({
          $and: [
            { LastSenderId: { $exists: true } },
            { LastSenderId: { $ne: socialId } },
            { State: ConversationReadState.Readed },
            { Resolved: { $ne: ConversationResolvedState.Resolved } },
          ],
        });
        break;
      case ConversationStateFilterEnum.Resolved:
        filterByPage.push({ Resolved: ConversationResolvedState.Resolved });
        break;
      case ConversationStateFilterEnum.Unread:
        filterByPage.push({ State: { $ne: ConversationReadState.Readed }, Resolved: { $ne: ConversationResolvedState.Resolved } });
        break;
    }

    if (state === ConversationStateFilterEnum.NotReplied || state === ConversationStateFilterEnum.Replied) {
      filterByPage.push({ "Resolved": { $ne: ConversationResolvedState.Resolved } });
    }

    return filterByPage;
  }

  /**
   * Build Facebook sort
   */
  private buildFacebookSort(sortBy?: ConversationSortEnum): any {
    const sortOptions: any = {};
    switch (sortBy) {
      case ConversationSortEnum.Unread:
        sortOptions.UnreadMessageCount = 1;
        break;
      case ConversationSortEnum.Oldest:
        sortOptions.TimeStamp = 1;
        break;
      case ConversationSortEnum.Newest:
      default:
        sortOptions.TimeStamp = -1;
        break;
    }

    return sortOptions;
  }


  /**
   * Get Facebook from time span - returns timestamp before startTime by MAX_MONTHS_CONVERSATION months
   */
  private getTimeSpanFilter(startTime: number): number {
    const fromDate = new Date(startTime);
    fromDate.setMonth(fromDate.getMonth() - MAX_MONTHS_CONVERSATION);
    return fromDate.getTime();
  }

  /**
   * Build Shopee query
   */
  private buildShopeeQuery(filters: IConversationFilters): any {
    const query: any = {};

    const shopeeChannels = filters?.channels
      .filter(channel => channel.platform === ChatPlatformEnum.Shopee).flatMap(channel => channel.channelDetails);

      const channelIds  = shopeeChannels.map(channel => channel.channelId);


    query.ChannelId = { $in: channelIds };

    // Type filter - maps to Type in GetChatConversationList (0: all, 1: unread, 2: read)
    if (filters?.state !== undefined) {
      switch (filters.state) {
        case 1: // Unread
          query.UnreadCount = { $gt: 0 };
          break;
        case 2: // Read
          query.UnreadCount = 0;
          break;
        case 0: // All
        default:
          // No filter for all
          break;
      }
    }

    const toDate = (filters?.to || (new Date()).getTime());
    const fromDate = (filters?.from || this.getTimeSpanFilter(toDate));

    const filterTime = [
      { LastMessageTimestamp: { $lt: BigInt(toDate) * 1_000_000n } },
      { LastMessageTimestamp: { $gte: BigInt(fromDate) * 1_000_000n } }];

    const beforeTimestamp = shopeeChannels.map(channel => channel.beforeTimestamp).sort((a, b) => a - b)[0];
    const afterTimestamp = shopeeChannels.map(channel => channel.afterTimestamp).sort((a, b) => b - a)[0];

    if (beforeTimestamp) {
      filterTime.push({ LastMessageTimestamp: { $lt: BigInt(beforeTimestamp) * 1_000_000n } });
    }

    if (afterTimestamp) {
      filterTime.push({ LastMessageTimestamp: { $gte: BigInt(afterTimestamp) * 1_000_000n } });
    }
    query.$and = filterTime;

    return query;
  }

  /**
   * Build Shopee sort
   */
  private buildShopeeSort(sortBy?: ConversationSortEnum): any {
    const sortOptions: any = {};

    switch (sortBy) {
      case ConversationSortEnum.Oldest:
        sortOptions.LastMessageTimestamp = 1; // Time asc (oldest first)
        break;
      case ConversationSortEnum.Newest:
        sortOptions.LastMessageTimestamp = -1; // Time desc (newest first)
        break;
      default:
        sortOptions.UnreadCount = -1; // Time desc (newest first)
        break;
    }

    return sortOptions;
  }

  /**
   * Build Facebook staff filter
   */
  buildFacebookStaffFilter(
    filters: IConversationFilters,
    socialId: string,
    hideAssignedConversationsToOtherEmployees: boolean
  ): any[] {
    const filter: any[] = [];

    const isRoleAdmin = filters.isRoleAdmin || false;
    const appUserId = filters.appUserId || '';
    const unassigned = filters.unassigned || false;

    if (hideAssignedConversationsToOtherEmployees) {
      if (isRoleAdmin) {
        this.buildFacebookStaffFilterForAdmin(filter, filters, unassigned);
      } else {
        this.buildFacebookStaffFilterForNonAdmin(filter, filters, unassigned, appUserId);
      }
    } else {
      this.buildFacebookStaffFilterForAdmin(filter, filters, unassigned);
    }

    return filter;
  }

  /**
   * Build Facebook staff filter for admin
   */
  private buildFacebookStaffFilterForAdmin(filter: any[], filters: IConversationFilters, unassigned: boolean): void {
    if (unassigned && filters.staff && filters.staff.length > 0) {
      filter.push({
        $or: [
          { Staff: { $exists: false } },
          { Staff: { $eq: [] } },
          { Staff: { $in: filters.staff.map(staff => staff.staffId) } },
        ],
      });
      return;
    }

    if (unassigned) {
      filter.push({
        $or: [
          { Staff: { $exists: false } },
          { Staff: { $eq: [] } },
        ],
      });
    } else if (filters.staff && filters.staff.length > 0) {
      filter.push({ Staff: { $in: filters.staff.map(staff => staff.staffId) } });
    }
  }

  /**
   * Build Facebook staff filter for non-admin
   */
  private buildFacebookStaffFilterForNonAdmin(filter: any[], filters: IConversationFilters, unassigned: boolean, appUserId: string): void {
    const staffId = `staff_${appUserId}`;

    if (unassigned) {
      filter.push({
        $or: [
          { Staff: { $exists: false } },
          { Staff: { $eq: [] } },
        ],
      });
    } else if (filters.staff && filters.staff.length > 0) {
      if (filters.staff.some(staff => staff.staffId === staffId)) {
        filter.push({ Staff: { $in: [staffId] } });
      } else {
        filter.push({ Staff: "staff_99999999999" });
      }
    } else {
      filter.push({
        $or: [
          { Staff: { $exists: false } },
          { Staff: { $eq: [] } },
          { Staff: { $in: [staffId] } },
        ],
      });
    }
  }
} 