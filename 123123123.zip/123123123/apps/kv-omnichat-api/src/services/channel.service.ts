import { Injectable } from "@nestjs/common";
import { OmniChannel, OmniChannelRepository } from "@kiotviet-facebook-services/omnichannel-repository";

@Injectable()
export class ChannelService {
  constructor(
    private readonly omnichannelRepository: OmniChannelRepository
  ) {}

  async getActiveChatChannels(where: Partial<OmniChannel> | Record<string, any>): Promise<OmniChannel[]> {
    return this.omnichannelRepository.getActiveChatChannels(where);
  }
}
