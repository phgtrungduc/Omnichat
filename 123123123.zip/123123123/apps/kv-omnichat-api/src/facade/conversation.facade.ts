import { Injectable } from '@nestjs/common';
import { IChatConversation } from '@kiotviet-facebook-services/common';
import {
  IConversationFilters,
  IConversationSearchByAccountFilters,
  IConversationSearchByMessageFilters
} from '../interfaces/conversation.interface';
import { CompositeConversationStrategy } from '../composite/composite-conversation.strategy';
import { BasePagingDto } from '../common/dto/base-paging.dto';

@Injectable()
export class ConversationFacade {
  constructor(
    private readonly compositeConversationStrategy: CompositeConversationStrategy
  ) {}

  async getConversations(filters?: IConversationFilters): Promise<BasePagingDto<IChatConversation>> {
    return this.compositeConversationStrategy.getConversations(filters);
  }

  async getAccountConversations(filters?: IConversationSearchByAccountFilters): Promise<BasePagingDto<IChatConversation>> {
    return this.compositeConversationStrategy.getConversationsSearchByAccount(filters);
  }

  async getMessageConversations(filters?: IConversationSearchByMessageFilters): Promise<BasePagingDto<IChatConversation>> {
    return this.compositeConversationStrategy.getConversationsSearchByMessage(filters);
  }
} 