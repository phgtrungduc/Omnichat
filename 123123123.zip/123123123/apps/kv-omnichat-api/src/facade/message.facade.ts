import { Injectable } from '@nestjs/common';
import { IConversationMessagesFilters, IConversationMessagesResponse } from '../interfaces/message.interface';
import { StrategyManager } from '../strategies/strategy.manager';
import { StrategyType } from '../strategies/base-strategy.interface';
import { IMessageStrategy } from '../strategies/message/message-strategy.interface';

@Injectable()
export class MessageFacade {
  constructor(private readonly strategyManager: StrategyManager) {}

  async getConversationMessages(
    filters: IConversationMessagesFilters
  ): Promise<IConversationMessagesResponse> {
    // Sử dụng StrategyManager để lấy strategy phù hợp
    const messageStrategy = this.strategyManager
      .getStrategy<IMessageStrategy>(StrategyType.MESSAGE, filters.platform);
    
    return messageStrategy.getConversationMessages(filters);
  }
} 