import { Injectable } from '@nestjs/common';
import { CompositeStaffStrategy } from '../composite/composite-staff.strategy';
import { IChatStaff } from '@kiotviet-facebook-services/common';
import { IPlatformChannel } from '../common/interfaces/platform-channel.interface';
import { StaffAssignDto, StaffDisableDto, StaffBulkAssignDto, StaffBulkUnassignDto, StaffByChannelsDto } from '../modules/staff/dto/staff.dto';
import { Request } from 'express';

@Injectable()
export class StaffFacade {
  constructor(
    private readonly compositeStaffStrategy: CompositeStaffStrategy
  ) {}

  async getStaffList(channels: IPlatformChannel[]): Promise<any[]> {
    // Use composite strategy to get staff list
    return await this.compositeStaffStrategy.getStaffList(channels);
  }

  async assignStaff(assignData: StaffAssignDto, request: Request): Promise<boolean> {
    // Use composite strategy to assign staff
    return await this.compositeStaffStrategy.assignStaff(assignData, request);
  }

  async unassignStaff(assignData: StaffAssignDto, request: Request): Promise<boolean> {
    // Use composite strategy to unassign staff
    return await this.compositeStaffStrategy.unassignStaff(assignData, request);
  }

  async disableStaff(disableData: StaffDisableDto, request: Request): Promise<boolean> {
    // Use composite strategy to disable staff
    return await this.compositeStaffStrategy.disableStaff(disableData, request);
  }

  async bulkAssignStaff(bulkAssignData: StaffBulkAssignDto, request: Request): Promise<boolean> {
    // Use composite strategy to bulk assign staff
    return await this.compositeStaffStrategy.bulkAssignStaff(bulkAssignData, request);
  }

  async bulkUnassignStaff(bulkUnassignData: StaffBulkUnassignDto, request: Request): Promise<boolean> {
    // Use composite strategy to bulk unassign staff
    return await this.compositeStaffStrategy.bulkUnassignStaff(bulkUnassignData, request);
  }

  async getStaffByChannels(channels: IPlatformChannel[]): Promise<any[]> {
    // Use composite strategy to get staff by channels
    return await this.compositeStaffStrategy.getStaffByChannels(channels);
  }
} 