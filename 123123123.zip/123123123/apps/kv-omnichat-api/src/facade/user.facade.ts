import { Injectable } from '@nestjs/common';
import { CompositeUserStrategy } from '../composite/composite-user.strategy';
import { UserProfileDto, UserProfileResponseDto } from '../modules/user/dto/user.dto';

@Injectable()
export class UserFacade {
  constructor(
    private readonly compositeUserStrategy: CompositeUserStrategy
  ) {}

  async getUserProfile(dto: UserProfileDto): Promise<UserProfileResponseDto> {
    return await this.compositeUserStrategy.getUserProfile(dto);
  }

  async getUserProfilePicture(dto: UserProfileDto): Promise<string> {
    return await this.compositeUserStrategy.getUserProfilePicture(dto);
  }
}
