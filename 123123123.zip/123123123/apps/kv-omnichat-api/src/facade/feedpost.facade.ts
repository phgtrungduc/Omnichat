import { Injectable } from '@nestjs/common';
import { FeedpostListRequestDto, FeedpostListResponseDto } from '../modules/feedpost/dto/feedpost.dto';
import { CompositeFeedpostStrategy } from '../composite/composite-feedpost.strategy';
import { IPlatformChannel } from '../common/interfaces/platform-channel.interface';

@Injectable()
export class FeedpostFacade {
  constructor(
    private readonly compositeFeedpostStrategy: CompositeFeedpostStrategy
  ) {}

  async getFeedposts(channels: IPlatformChannel[], query: FeedpostListRequestDto): Promise<FeedpostListResponseDto> {
    // Chỉ gọi composite strategy
    const posts = await this.compositeFeedpostStrategy.getFeedposts(channels, query);

    return {
      data: posts.data,
      hasMore: posts.hasMore
    };
  }
} 