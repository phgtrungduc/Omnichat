import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

export interface IChannelRequest {
  channelId: string;
  platform: ChatPlatformEnum;
  accessToken?: string;
  isAdmin?: boolean
}


export interface IChannelInfo extends IChannelRequest {
  name?: string;
  isActive?: boolean;
  lastActivity?: Date;
}

export interface IChannelFilter extends IChannelRequest {
  includeInactive?: boolean;
  dateFrom?: Date;
  dateTo?: Date;
} 