/**
 * Core interfaces for Conversation Strategy + Composite + Facade architecture
 */

import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { IChatConversation } from '@kiotviet-facebook-services/common';
import { ConversationSortEnum } from '../common/enums/conversation-sort.enum';
import { PageStaff } from '@kiotviet-facebook-services/fbpos-master-repository';
import { ChatConversationType, ConversationStateFilterEnum } from '../common/enums/chat-search-type.enum';
import { IChannelPagination, IPlatformChannel } from '../common/interfaces/platform-channel.interface';
import { BasePagingDto } from '../common/dto/base-paging.dto';

// ========================================
// CORE INTERFACES
// ========================================

/**
 * Base conversation strategy interface
 */
export interface IBaseConversationStrategy {
  platform: ChatPlatformEnum;
}

/**
 * Conversation strategy interface
 */
export interface IConversationStrategy extends IBaseConversationStrategy {
    getConversations(filters?: IConversationFilters): Promise<IChatConversation[]>;
    getConversationsSearchByAccount(filters?: IConversationSearchByAccountFilters): Promise<IChatConversation[]>;
    getConversationsSearchByMessage(filters?: IConversationSearchByMessageFilters): Promise<IChatConversation[]>;
}

/**
 * Composite conversation strategy interface
 */
export interface ICompositeConversationStrategy {
  getConversations(filters?: IConversationFilters): Promise<BasePagingDto<IChatConversation>>;
  getConversationsSearchByAccount(filters?: IConversationSearchByAccountFilters): Promise<BasePagingDto<IChatConversation>>;
  getConversationsSearchByMessage(filters?: IConversationSearchByMessageFilters): Promise<BasePagingDto<IChatConversation>>;
}

// ========================================
// REQUEST INTERFACES
// ========================================

/**
 * Unified conversation filters - Based on ConversationSearchDto
 */
export interface IConversationFilters {
  // Common fields for all platforms
  sortBy?: ConversationSortEnum;
  channels?: Array<IChannelPagination>;
  keyword?: string;
  skip?: number;
  limit?: number;
  state?: ConversationStateFilterEnum;
  
  // Date filters
  from?: number;
  to?: number;
  
  // Conversation type (currently only for Facebook)
  conversationType?: ChatConversationType;
  
  // Phone filter
  hasPhone?: boolean;
  
  includeNoTags?: boolean;

  // Tags filter
  tags?: string[];
  
  // Customer tags filter
  customerTags?: string[];
  
  // Source filter
  source?: string[];
  
  // Staff filter
  staff?: PageStaff[];
  
  // Staff filter options
  unassigned?: boolean; // Filter for unassigned conversations
  isRoleAdmin?: boolean; // Is user role admin
  appUserId?: string; // Current user ID for staff filtering
  
  // Correct syntax filter (only for Facebook, not implemented yet)
  correctSyntax?: number;

  lastTimestamp?: number;
  retailerId?: number;
}

/**
 * Shopee conversation filters - based on chat/get_conversation_list API
 */
export interface IShopeeConversationFilters {
  channelIds?: number[];
  channelId?: number;
  type?: number; // 0: all, 1: unread, 2: read - maps to Type
  searchType?: number; // 0: all, 1: unread, 2: read - maps to SearchType
  direction?: string; // "in" or "out"
  keyword?: string;
  sortType?: number; // 0: time desc, 1: time asc - maps to SortType
  page?: number; // maps to Page
  limit?: number; // maps to Limit
}

export interface IConversationSearchByAccountFilters {
  channels: Array<IPlatformChannel>;
  keyword: string;
  limit?: number;
  retailerId?: number;
}

export interface IConversationSearchByMessageFilters {
  channels: Array<IPlatformChannel>;
  keyword: string;
  limit?: number;
  retailerId?: number;
}

// ========================================
// AGGREGATION RESULT INTERFACES
// ========================================

/**
 * Interface cho kết quả aggregation từ message search
 * Kết hợp OmniMessage + OmniConversations thông qua $lookup
 */
export interface IMessageSearchAggregationResult {
  // OmniMessage fields
  conversationId: string;
  messageId: string;
  messageType: string;
  fromId: number;
  fromShopId: number;
  toId: number;
  toShopId: number;
  createdTimestamp: number;
  status: string;
  text: string;
  url: string;
  thumbUrl: string;
  thumbHeight?: number | null;
  thumbWidth?: number | null;
  fileServerId?: number | null;
  shopId?: number | null;
  stickerId: string;
  stickerPackageId: string;
  orderSn: string;
  itemId?: number | null;
  dataInfo: any;
  chatProductInfos?: any[];
  quotedMessage?: any;
  videoUrl: string;
  durationSeconds?: number | null;
  imageUrl: string;
  caption: string;
  linkUrl: string;
  source: string;
  id?: string;
  retailerId: number;
  channelId: number;
  createdDate: Date;
  modifiedDate?: Date | null;
  rawData?: any;
  userKvId?: number | null;
  usernameKv?: string;
  userKvGivenName?: string;

  // OmniConversations fields (từ $lookup)
  Conversation: {
    RetailerId: number;
    ChannelId: number;
    EventType: string | null;
    PlatformType: number;
    ConversationId: string;
    ToId: number;
    ToName: string;
    ToAvatar: string;
    ShopId: number;
    UnreadCount: number;
    Pinned: boolean;
    Mute: boolean;
    LastReadMessageId: string;
    LatestMessageId: string;
    LatestMessageType: string;
    LatestMessageContent: any;
    LatestMessageFromId: number;
    LastMessageTimestamp: bigint;
    LastMessageOption: number;
    MaxGeneralOptionHideTime: string;
    CreatedDate: Date;
    ModifiedDate: Date | null;
    Source: string;
    RawData: any;
  };
}