import { IChatBase } from "@kiotviet-facebook-services/common";
import { IChatMessage } from "@kiotviet-facebook-services/common";

export interface IConversationMessagesFilters extends IChatBase {
  conversationId: string;
  conversationType: string;
  source?: string;// postid ,...
  limit?: number;
  platformUserId?: string;
  pageAccessToken?: string;
  afterTimestamp?: string;
}

export interface IConversationMessagesResponse {
  items: IChatMessage[];
  more: boolean;
} 