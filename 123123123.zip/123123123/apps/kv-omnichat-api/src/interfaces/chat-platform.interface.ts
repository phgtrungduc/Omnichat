export interface IBaseForwarderAPIRequest {
  headers?: Record<string, string>;
}