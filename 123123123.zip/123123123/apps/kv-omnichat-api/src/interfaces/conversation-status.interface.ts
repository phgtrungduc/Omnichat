import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import {
  ConversationIdentifierDto,
  ConversationStatusActionEnum,
  ConversationStatusResultDto,
  ConversationStatusTypeEnum
} from '../common/dto/conversation-status.dto';
import { IBaseForwarderAPIRequest } from './chat-platform.interface';

export interface IConversationStatusRequest extends IBaseForwarderAPIRequest {
  statusType: ConversationStatusTypeEnum;
  action: ConversationStatusActionEnum;
  conversations: ConversationIdentifierDto[];
}

export interface IConversationStatusStrategy {
  readonly platform: ChatPlatformEnum;
  markStatus(request: IConversationStatusRequest): Promise<ConversationStatusResultDto[]>;
} 