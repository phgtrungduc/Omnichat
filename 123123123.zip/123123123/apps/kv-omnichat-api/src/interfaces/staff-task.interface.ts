import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { Request } from 'express';

export interface IStaffTask {
  EventType: string;
  PageId: string;
  Field: 'staff';
  IsRoleAdmin?: boolean;
  Data?: IStaffAssignmentData;
  Request?: Request;
} 

export interface IStaffAssignmentData  {
  Id: string;
  Name?: string;
  Picture?: string;
  AppUserId?: string;
  conversationId?: string;
  lastAssignStaff?: any;
  Type?: string;
  conversationCustomerName?: string;
  conversationMessage?: string;
  fbStaffName?: string;
  assignmentTurn?: number;

  //disable
  RemoveAssignedStaff?: boolean;
  RetailerId?: number;
}