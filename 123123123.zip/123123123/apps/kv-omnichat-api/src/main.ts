import { Logger, ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { ConfigService } from '@nestjs/config';

import { AppModule } from './app.module';
import { ApiTransformInterceptor, ChatPlatformEnum, HttpExceptionFilter, UnknownExceptionFilter, UnprocessableEntityExceptionFilter, KvLogger } from '@kiotviet-facebook-services/common';

async function bootstrap() {
  const app = await NestFactory.create(AppModule,{cors:true});
  const configService = app.get(ConfigService);
  const kvLogger = app.get(KvLogger);
  const globalPrefix = 'api';
  app.setGlobalPrefix(globalPrefix);
  
  // Swagger Configuration - Only enable if configured
  const enableSwagger = configService.get<boolean>('swagger.enabled');
  
  if (enableSwagger) {
    const config = new DocumentBuilder()
      .setTitle('KiotViet OmniChat API')
      .setDescription(`API for managing multi-platform chat integrations using Strategy + Composite + Facade Pattern (${ChatPlatformEnum.Facebook}, ${ChatPlatformEnum.Shopee})`)
      .setVersion('1.0')
      .addTag('Omni Chat API', 'Multi-platform chat management endpoints with cross-platform support')
      .addTag('Health Check', 'Application health monitoring')
      .addBearerAuth()
      .build();
    
    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup('api/docs', app, document, {
      swaggerOptions: {
        persistAuthorization: true,
      },
      customSiteTitle: 'KiotViet OmniChat API Documentation',
      customCss: `
        .swagger-ui .topbar { display: none }
        .swagger-ui .info .title { color: #2c3e50; font-size: 36px; }
        .swagger-ui .info .description { font-size: 16px; }
      `,
    });
    
    Logger.log(
      `📚 Swagger documentation available at: http://localhost:${configService.get('serve.port') || 3000}/api/docs`
    );
  } else {
    Logger.log('📚 Swagger documentation is disabled');
  }

  const port = configService.get('serve.port') || process.env.PORT || 3000;
  app.useGlobalInterceptors(new ApiTransformInterceptor());
  app.useGlobalFilters(
    new UnknownExceptionFilter(kvLogger),
    new HttpExceptionFilter(),
    new UnprocessableEntityExceptionFilter(),
  );
  app.useGlobalPipes(
    new ValidationPipe({
      transform: true,
      transformOptions: {
        exposeUnsetFields: false,
      },
    }),
  );
  await app.listen(port);
  Logger.log(
    `🚀 Omni Chat API is running on: http://localhost:${port}/${globalPrefix}`
  );
  Logger.log(
    `🎯 Strategy + Composite + Facade Pattern Architecture`
  );
}

bootstrap(); 