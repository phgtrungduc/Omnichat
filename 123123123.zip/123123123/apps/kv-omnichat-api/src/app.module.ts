// Đặt đường dẫn config
process.env['NODE_CONFIG_DIR'] = `${__dirname}/config/`;

// Import config
import * as config from 'config';

// Import
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { CacheModule } from '@nestjs/cache-manager';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { LockModule } from '@kiotviet-facebook-services/lock';
import { ConversationModule } from './modules/conversation/conversation.module';
import { StaffModule } from './modules/staff/staff.module';
import { PingModule } from './modules/ping/ping.module';
import { ChannelModule } from './modules/channel/channel.module';
import { ConversationTagsModule } from './modules/conversation-tags/conversation-tags.module';
import { CustomerTagsModule } from './modules/customer-tags/customer-tags.module';
import { KvAuthModule } from '@kiotviet-facebook-services/kv-auth';
import { StrategiesModule } from './strategies/strategies.module';
import { CommonServicesModule } from './common/common-services.module';
import { FeedpostModule } from './modules/feedpost/feedpost.module';
import { UserModule } from './modules/user/user.module';


@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [() => config],
    }),
    CacheModule.register({
      isGlobal: true,
    }),
    CommonModule,
    CommonServicesModule,
    KvAuthModule,
    LockModule,
    ConversationModule,
    StaffModule,
    UserModule,
    PingModule,
    ChannelModule,
    ConversationTagsModule,
    CustomerTagsModule,
    FeedpostModule,
    StrategiesModule
  ],
  controllers: [],
  providers: [],
})
export class AppModule {} 