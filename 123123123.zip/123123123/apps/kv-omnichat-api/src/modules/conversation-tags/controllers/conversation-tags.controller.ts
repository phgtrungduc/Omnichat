import { Auth } from '@kiotviet-facebook-services/kv-auth';
import { Controller, Post, Body, Req, HttpException, HttpStatus } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Request } from 'express';
import {
  GetConversationTagsRequestDto,
  GetConversationTagsResponseDto
} from '../dto';
import { ConversationTagsService } from '../services';

@ApiTags('Conversation Tags')
@Controller('conversation-tags')
@ApiBearerAuth()
@Auth()
export class ConversationTagsController {
  constructor(private readonly conversationTagsService: ConversationTagsService) {}

  @Post('/list')
  @ApiOperation({ 
    summary: 'Get conversation tags list',
    description: 'API to get conversation tags from multiple channels and platforms (Facebook, Shopee, etc.). Supports multiple channels in a single request, grouped by platform. Uses POST to support large channel arrays in request body.'
  })
  @ApiResponse({ 
    status: 200, 
    description: 'Conversation tags list returned successfully',
    type: GetConversationTagsResponseDto
  })
  async getConversationTags(
    @Req() req: Request, 
    @Body() body: GetConversationTagsRequestDto
  ): Promise<GetConversationTagsResponseDto> {
    try {
      const result = await this.conversationTagsService.getConversationTags(req, body);
      
      if (!result.success) {
        throw new HttpException(result.message, HttpStatus.BAD_REQUEST);
      }
      
      return result;
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }
      throw new HttpException(
        error.message || 'Error getting conversation tags', 
        HttpStatus.INTERNAL_SERVER_ERROR
      );
    }
  }
} 