import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsArray, ArrayNotEmpty, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { ChannelRequestDto } from '../../../common/dto';

export class GetConversationTagsRequestDto {
  @ApiProperty({
    description: 'Array of Facebook channels to get tags (only Facebook platform supported)',
    example: [
      { channelId: '790976900758321', platform: 'Facebook' },
      { channelId: '752160271303963', platform: 'Facebook' }
    ],
    type: [ChannelRequestDto]
  })
  @IsNotEmpty({ message: 'Channels cannot be empty' })
  @IsArray({ message: 'Channels must be an array' })
  @ArrayNotEmpty({ message: 'Channels array cannot be empty' })
  @ValidateNested({ each: true })
  @Type(() => ChannelRequestDto)
  channels: ChannelRequestDto[];
} 