import { ApiProperty } from '@nestjs/swagger';
import { 
  IsString, 
  IsNotEmpty, 
  IsEnum, 
  IsNumber, 
  IsArray, 
  IsOptional, 
  Matches, 
  IsPositive,
  Min,
  Max,
  ArrayNotEmpty,
  IsUUID,
  IsDateString
} from 'class-validator';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

export class ConversationTagDto {
  @ApiProperty({
    description: 'Conversation tag ID (UUID format)',
    example: '7943c05b-1b44-4289-8952-909a30d0457d',
    format: 'uuid'
  })
  @IsNotEmpty({ message: 'Tag ID cannot be empty' })
  @IsString({ message: 'Tag ID must be a string' })
  @IsUUID('4', { message: 'Tag ID must be a valid UUID v4' })
  id: string;

  @ApiProperty({
    description: 'Channel ID where this tag belongs',
    example: '109533272097318'
  })
  @IsNotEmpty({ message: 'Channel ID cannot be empty' })
  @IsString({ message: 'Channel ID must be a string' })
  channelId: string;

  @ApiProperty({
    description: 'Channel platform',
    enum: ChatPlatformEnum,
    example: ChatPlatformEnum.Facebook
  })
  @IsNotEmpty({ message: 'Platform cannot be empty' })
  @IsEnum(ChatPlatformEnum, { message: 'Invalid platform' })
  platform: ChatPlatformEnum;

  @ApiProperty({
    description: 'Tag title (1-50 characters)',
    example: 'VIP Customer',
    minLength: 1,
    maxLength: 50
  })
  @IsNotEmpty({ message: 'Tag title cannot be empty' })
  @IsString({ message: 'Tag title must be a string' })
  @Min(1, { message: 'Tag title must be at least 1 character' })
  @Max(50, { message: 'Tag title must not exceed 50 characters' })
  title: string;

  @ApiProperty({
    description: 'Tag color in hex format (#RRGGBB)',
    example: '#7362D4',
    pattern: '^#[0-9A-Fa-f]{6}$'
  })
  @IsNotEmpty({ message: 'Tag color cannot be empty' })
  @IsString({ message: 'Tag color must be a string' })
  @Matches(/^#[0-9A-Fa-f]{6}$/, { 
    message: 'Color must be a valid hex color format (#RRGGBB)' 
  })
  color: string;

  @ApiProperty({
    description: 'Tag version for data versioning',
    example: 1,
    minimum: 1
  })
  @IsNotEmpty({ message: 'Version cannot be empty' })
  @IsNumber({}, { message: 'Version must be a number' })
  @IsPositive({ message: 'Version must be a positive number' })
  version: number;

  @ApiProperty({
    description: 'List of conversation IDs that have this tag applied',
    type: [String],
    example: ['24344959245133645', '9173343479403625'],
    isArray: true
  })
  @IsArray({ message: 'Conversations must be an array' })
  @IsString({ each: true, message: 'Each conversation ID must be a string' })
  conversations: string[];

  @ApiProperty({
    description: 'Tag creation/last update timestamp (Unix timestamp in milliseconds)',
    example: 1753341593760
  })
  @IsNotEmpty({ message: 'Timestamp cannot be empty' })
  @IsNumber({}, { message: 'Timestamp must be a number' })
  @IsPositive({ message: 'Timestamp must be a positive number' })
  timestamp: number;

  @ApiProperty({
    description: 'Tag description (optional)',
    example: 'Tag for high-value customers who require special attention',
    required: false,
    maxLength: 200
  })
  @IsOptional()
  @IsString({ message: 'Description must be a string' })
  @Max(200, { message: 'Description must not exceed 200 characters' })
  description?: string;

  @ApiProperty({
    description: 'Number of conversations currently using this tag',
    example: 2,
    minimum: 0
  })
  @IsOptional()
  @IsNumber({}, { message: 'Conversation count must be a number' })
  @Min(0, { message: 'Conversation count cannot be negative' })
  conversationCount?: number;

  @ApiProperty({
    description: 'Tag creation date in ISO format',
    example: '2024-01-15T10:30:00.000Z',
    required: false
  })
  @IsOptional()
  @IsDateString({}, { message: 'Created date must be a valid ISO date string' })
  createdAt?: string;

  @ApiProperty({
    description: 'Tag last update date in ISO format',
    example: '2024-01-20T14:45:00.000Z',
    required: false
  })
  @IsOptional()
  @IsDateString({}, { message: 'Updated date must be a valid ISO date string' })
  updatedAt?: string;

  @ApiProperty({
    description: 'User ID who created this tag',
    example: 'user-123',
    required: false
  })
  @IsOptional()
  @IsString({ message: 'Created by must be a string' })
  createdBy?: string;

  @ApiProperty({
    description: 'Whether this tag is active and can be used',
    example: true,
    default: true,
    required: false
  })
  @IsOptional()
  isActive?: boolean;
} 