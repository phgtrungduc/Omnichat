import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ConversationTagDto } from './conversation-tag.dto';

export class GetConversationTagsResponseDto {
  @ApiProperty({
    description: 'Success status',
    example: true
  })
  success: boolean;

  @ApiProperty({
    description: 'List of conversation tags',
    type: [ConversationTagDto]
  })
  data: ConversationTagDto[];

  @ApiPropertyOptional({
    description: 'Result message',
    example: 'Get conversation tags successfully'
  })
  message?: string;
} 