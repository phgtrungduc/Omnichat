import { Injectable, BadRequestException } from '@nestjs/common';
import { Request } from 'express';
import { KvLogger } from '@kiotviet-facebook-services/common';
import {
  IConversationTagsStrategy,
  IConversationTagsRequest,
  FacebookConversationTagsStrategy,
  ShopeeConversationTagsStrategy
} from '../../../strategies/conversation-tags';
import { IChannelRequest } from '../../../interfaces';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import {
  GetConversationTagsRequestDto,
  GetConversationTagsResponseDto,
  ConversationTagDto
} from '../dto';

@Injectable()
export class ConversationTagsService {
  private readonly VERSION = 2;
  private readonly conversationTagsStrategies: IConversationTagsStrategy[];

  constructor(
    private readonly facebookStrategy: FacebookConversationTagsStrategy,
    private readonly shopeeStrategy: ShopeeConversationTagsStrategy,
    private readonly logger: KvLogger
  ) {
    this.conversationTagsStrategies = [
      this.facebookStrategy,
      this.shopeeStrategy
    ];
  }

  /**
   * Lấy danh sách conversation tags từ Facebook platform
   */
  async getConversationTags(req: Request, query: GetConversationTagsRequestDto): Promise<GetConversationTagsResponseDto> {
    try {
      // Validate chỉ hỗ trợ Facebook platform
      const nonFacebookChannels = query.channels.filter(channel => channel.platform !== ChatPlatformEnum.Facebook);
      if (nonFacebookChannels.length > 0) {
        const invalidPlatforms = [...new Set(nonFacebookChannels.map(c => c.platform))];
        throw new BadRequestException(`Only Facebook platform is supported for conversation tags. Found: ${invalidPlatforms.join(', ')}`);
      }

      const channelIds = query.channels.map(c => c.channelId).join(', ');
      this.logger.info(`Getting conversation tags for ${query.channels.length} Facebook channels: ${channelIds}`);

      // Group channels by platform (chỉ có Facebook)
      const channelsByPlatform = query.channels.reduce((acc, channel) => {
        if (!acc[channel.platform]) {
          acc[channel.platform] = [];
        }
        acc[channel.platform].push(channel);
        return acc;
      }, {} as Record<ChatPlatformEnum, IChannelRequest[]>);

      const allResults: ConversationTagDto[] = [];
      let hasErrors = false;
      let errorMessage = '';

      // Process Facebook platform
      for (const [platform, channels] of Object.entries(channelsByPlatform)) {
        const strategy = this.conversationTagsStrategies.find(s => s.supports(platform as ChatPlatformEnum));
        
        if (!strategy) {
          hasErrors = true;
          errorMessage = `Platform ${platform} is not supported for conversation tags`;
          this.logger.error(errorMessage);
          break;
        }

        try {
          const conversationTagsRequest: IConversationTagsRequest = {
            channels,
            version: this.VERSION
          };

          const result = await strategy.getConversationTags(req, conversationTagsRequest);

          if (!result.success) {
            hasErrors = true;
            errorMessage = result.message || `Failed to get tags from ${platform}`;
            break;
          }

          const conversationTags: ConversationTagDto[] = result.data.map(item => ({
            id: item.id,
            channelId: item.channelId,
            platform: item.platform,
            title: item.title,
            color: item.color,
            version: item.version,
            conversations: item.conversations,
            timestamp: item.timestamp
          }));

          allResults.push(...conversationTags);

        } catch (error) {
          hasErrors = true;
          const platformChannelIds = channels.map(c => c.channelId).join(', ');
          errorMessage = `Error getting tags for platform ${platform}, channels: ${platformChannelIds} - ${error.message}`;
          this.logger.error(errorMessage, error);
          break;
        }
      }

      const response: GetConversationTagsResponseDto = {
        success: !hasErrors,
        data: allResults,
        message: hasErrors 
          ? errorMessage
          : `Successfully retrieved ${allResults.length} conversation tags from ${query.channels.length} Facebook channels`
      };

      if (hasErrors) {
        this.logger.error(`Failed getting conversation tags: ${errorMessage}`);
      } else {
        this.logger.info(`Successfully retrieved ${allResults.length} tags from ${query.channels.length} Facebook channels`);
      }
      
      return response;

    } catch (error) {
      this.logger.error(`Error getting conversation tags for Facebook channels`, error);
      
      if (error instanceof BadRequestException) {
        throw error;
      }
      
      return {
        success: false,
        data: [],
        message: error.message || 'Error occurred while getting conversation tags'
      };
    }
  }
} 