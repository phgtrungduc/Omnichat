import { Module } from '@nestjs/common';
import { ConversationTagsController } from './controllers';
import { ConversationTagsService } from './services';
import { 
  FacebookConversationTagsStrategy, 
  ShopeeConversationTagsStrategy
} from '../../strategies/conversation-tags';
import { FbPosMasterRepositoryModule } from 'libs/repositories/fbpos-master-repository/src/lib/fbpos-master-repository.module';
import { OmnimongoRepositoryModule } from '@kiotviet-facebook-services/omnimongo-repository';
import { ForwarderModule } from '@kiotviet-facebook-services/external-platforms';
import { CommonModule } from '@kiotviet-facebook-services/common';
  
@Module({
  imports: [
    FbPosMasterRepositoryModule,
    OmnimongoRepositoryModule,
    ForwarderModule,
    CommonModule
  ],
  controllers: [ConversationTagsController],
  providers: [
    ConversationTagsService,
    FacebookConversationTagsStrategy,
    ShopeeConversationTagsStrategy
  ],
  exports: [ConversationTagsService],
})
export class ConversationTagsModule {} 