import { Controller, Get } from '@nestjs/common';
import { ApiResponse, ApiTags } from '@nestjs/swagger';

@Controller('ping')
@ApiTags('Health Check')
export class PingController {
    @Get('')
    @ApiResponse({status: 200})
    healthPing() {
        return 'pong';
    }
} 