import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

export class ActivePageDataDto {
  @ApiProperty({
    description: 'Channel ID',
    example: '109533272097318'
  })
  channelId: string;

  @ApiProperty({
    description: 'Platform of the channel',
    enum: ChatPlatformEnum,
    example: ChatPlatformEnum.Facebook
  })
  platform: ChatPlatformEnum;

  @ApiProperty({
    description: 'Activation result message',
    example: 'success'
  })
  message: string;

  @ApiProperty({
    description: 'Whether activation was successful',
    example: true
  })
  success: boolean;

  @ApiPropertyOptional({
    description: 'Whether user is admin (Facebook only)',
    example: 'true'
  })
  isRoleAdmin?: string;

  @ApiPropertyOptional({
    description: 'Extended token (Facebook only)',
    example: 'xxx'
  })
  extendedToken?: string;

  @ApiPropertyOptional({
    description: 'JWT token for this channel',
    example: 'xxx'
  })
  jwt?: string;

  @ApiPropertyOptional({
    description: 'JWT expiration time for this channel',
    example: '2025-08-27T02:17:27.578Z'
  })
  expire?: string;
}

export class ActivePageResponseDto {
  @ApiProperty({
    description: 'Overall success status',
    example: true
  })
  success: boolean;

  @ApiProperty({
    description: 'Results for each channel activation',
    type: [ActivePageDataDto]
  })
  data: ActivePageDataDto[];

  @ApiProperty({
    description: 'Total number of channels processed',
    example: 2
  })
  totalCount: number;

  @ApiProperty({
    description: 'Number of successful activations',
    example: 2
  })
  successCount: number;

  @ApiProperty({
    description: 'Number of failed activations',
    example: 0
  })
  failureCount: number;

  @ApiPropertyOptional({
    description: 'Overall result message',
    example: 'Successfully activated 2 out of 2 channels'
  })
  message?: string;

  @ApiPropertyOptional({
    description: 'Statistics by platform',
    example: {
      'Facebook': {
        'total': 2,
        'success': 2,
        'failed': 0
      }
    }
  })
  statistics?: Record<string, {
    total: number;
    success: number;
    failed: number;
  }>;
} 