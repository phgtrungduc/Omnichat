import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsString, IsOptional, IsBoolean, ValidateNested, IsArray, ArrayNotEmpty } from 'class-validator';
import { Type } from 'class-transformer';
import { ChannelRequestDto } from '../../../common/dto/base-channel.dto';

export class ActivePageFbUserDto {
  @ApiProperty({
    description: 'Name of Facebook user',
    example: 'Hồng Hồng'
  })
  @IsNotEmpty({ message: 'Facebook user name cannot be empty' })
  @IsString({ message: 'Facebook user name must be a string' })
  name: string;

  @ApiProperty({
    description: 'Avatar URL of Facebook user',
    example: 'https://platform-lookaside.fbsbx.com/platform/profilepic/?asid=122112497660768457&height=50&width=50&ext=1756261041&hash=AT-FFg5gmDebCwX1HrNTqM8G'
  })
  @IsNotEmpty({ message: 'Picture URL cannot be empty' })
  @IsString({ message: 'Picture URL must be a string' })
  picture: string;

  @ApiProperty({
    description: 'App User ID of Facebook user',
    example: '122112497660768457'
  })
  @IsNotEmpty({ message: 'App User ID cannot be empty' })
  @IsString({ message: 'App User ID must be a string' })
  appUserId: string;
}

export class ActivePageFbposParamsDto {
  @ApiPropertyOptional({
    description: 'Facebook user information (Facebook only)',
    type: ActivePageFbUserDto
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => ActivePageFbUserDto)
  fbUser?: ActivePageFbUserDto;
}



export class ActivePageRequestDto {
  @ApiProperty({
    description: 'List of channels to activate (channelId and platform only)',
    example: [
      {
        channelId: '109533272097318',
        platform: 'facebook'
      },
      {
        channelId: '252083544658502',
        platform: 'facebook'
      }
    ],
    type: [ChannelRequestDto]
  })
  @IsNotEmpty({ message: 'Channels cannot be empty' })
  @IsArray({ message: 'Channels must be an array' })
  @ArrayNotEmpty({ message: 'Channels array cannot be empty' })
  @ValidateNested({ each: true })
  @Type(() => ChannelRequestDto)
  channels: ChannelRequestDto[];

  @ApiProperty({
    description: 'FBPOS specific parameters for activation',
    example: {
      accessToken: 'xxx',
      isRoleAdmin: true,
      fbUser: {
        name: 'Hồng Hồng',
        picture: 'https://platform-lookaside.fbsbx.com/platform/profilepic/?asid=122112497660768457&height=50&width=50&ext=1756261041&hash=AT-FFg5gmDebCwX1HrNTqM8G',
        appUserId: '122112497660768457'
      }
    },
    type: ActivePageFbposParamsDto
  })
  @IsNotEmpty({ message: 'FBPOS params cannot be empty' })
  @ValidateNested()
  @Type(() => ActivePageFbposParamsDto)
  fbposParams: ActivePageFbposParamsDto;
} 