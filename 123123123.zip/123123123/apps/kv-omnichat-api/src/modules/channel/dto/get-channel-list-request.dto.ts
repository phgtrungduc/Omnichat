import { ApiPropertyOptional } from "@nestjs/swagger";

export class GetChannelListRequestDto {
  @ApiPropertyOptional({
    description: 'Facebook ID',
    example: '1234567890'
  })
  fbid?: string;
} 