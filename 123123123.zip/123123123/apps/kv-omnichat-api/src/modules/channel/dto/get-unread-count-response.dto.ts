import { ApiProperty } from '@nestjs/swagger';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

export class ChannelUnreadCountItem {
  @ApiProperty({
    description: 'Channel ID của channel',
    example: '123456789'
  })
  channelId: string;

  @ApiProperty({
    description: 'Platform của channel',
    example: ChatPlatformEnum.Facebook,
    enum: Object.values(ChatPlatformEnum)
  })
  platform: ChatPlatformEnum;

  @ApiProperty({
    description: 'Số lượng hội thoại chưa đọc',
    example: 5
  })
  unreadCount: number;
}

export class GetUnreadCountResponseDto {
  @ApiProperty({
    description: 'Trạng thái thành công',
    example: true
  })
  success: boolean;

  @ApiProperty({
    description: 'Danh sách số lượng hội thoại chưa đọc của từng channel',
    type: [ChannelUnreadCountItem]
  })
  data: ChannelUnreadCountItem[];

  @ApiProperty({
    description: 'Thông báo kết quả (nếu có)',
    example: 'Lấy dữ liệu thành công',
    required: false
  })
  message?: string;
} 