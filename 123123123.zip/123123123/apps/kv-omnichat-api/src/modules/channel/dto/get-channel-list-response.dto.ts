import { ApiProperty } from '@nestjs/swagger';
import { ChannelDto } from './channel.dto';

export class GetChannelListResponseDto {
  @ApiProperty({
    description: 'Danh sách channel',
    type: [ChannelDto]
  })
  channels: ChannelDto[];
} 