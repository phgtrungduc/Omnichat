import { ApiProperty } from '@nestjs/swagger';
import { ChannelStatusEnum, ChatPlatformEnum } from '@kiotviet-facebook-services/common';

export class ChannelDto {
  @ApiProperty({
    description: 'ID của retailer',
    example: 12345
  })
  retailerId: number;

  @ApiProperty({
    description: 'Platform của channel',
    enum: ChatPlatformEnum,
    example: ChatPlatformEnum.Facebook
  })
  platform: ChatPlatformEnum;

  @ApiProperty({
    description: 'ID của page/shop',
    example: 'page_123456'
  })
  channelId: string;

  @ApiProperty({
    description: 'Trạng thái của channel',
    enum: ChannelStatusEnum,
    example: ChannelStatusEnum.ACTIVE
  })
  status: ChannelStatusEnum;

  @ApiProperty({
    description: 'Avatar URL của channel',
    example: 'https://example.com/avatar.jpg'
  })
  avatar: string;

  @ApiProperty({
    description: 'Tên của channel',
    example: 'My Facebook Page'
  })
  name: string;
} 