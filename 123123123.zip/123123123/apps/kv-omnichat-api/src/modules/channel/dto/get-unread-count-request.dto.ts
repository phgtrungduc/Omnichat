import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsArray, ValidateNested, IsIn, IsString } from 'class-validator';
import { Type } from 'class-transformer';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

export class ChannelUnreadItem {
  @ApiProperty({
    description: 'Channel ID của channel',
    example: '123456789'
  })
  @IsNotEmpty({ message: 'Channel ID không được để trống' })
  @IsString({ message: 'Channel ID phải là chuỗi' })
  channelId: string;

  @ApiProperty({
    description: 'Platform của channel',
    example: ChatPlatformEnum.Facebook,
    enum: Object.values(ChatPlatformEnum)
  })
  @IsNotEmpty({ message: 'Platform không được để trống' })
  @IsIn(Object.values(ChatPlatformEnum), { message: 'Platform không hợp lệ' })
  platform: ChatPlatformEnum;
}

export class GetUnreadCountRequestDto {
  @ApiProperty({
    description: 'Danh sách channels cần lấy unread count',
    type: [ChannelUnreadItem],
    example: [
      { channelId: '123456', platform: 'facebook' },
      { channelId: '789012', platform: 'omnichannel' }
    ]
  })
  @IsNotEmpty({ message: 'Channels không được để trống' })
  @IsArray({ message: 'Channels phải là mảng' })
  @ValidateNested({ each: true })
  @Type(() => ChannelUnreadItem)
  channels: ChannelUnreadItem[];
} 