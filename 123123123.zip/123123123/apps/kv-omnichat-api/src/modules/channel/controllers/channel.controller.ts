import { Auth } from '@kiotviet-facebook-services/kv-auth';
import { Body, Controller, Get, Post, Query, Req } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Request } from 'express';
import {
  ActivePageRequestDto,
  ActivePageResponseDto,
  GetChannelListRequestDto,
  GetChannelListResponseDto,
  GetUnreadCountRequestDto,
  GetUnreadCountResponseDto
} from '../dto';
import { ChannelService } from '../services/channel.service';

@ApiTags('Channel')
@Controller('channel')
@ApiBearerAuth()
@Auth()
export class ChannelController {
  constructor(private readonly channelService: ChannelService) { }

  @Get()
  @ApiOperation({
    summary: 'Lấy danh sách channel',
    description: 'API để lấy danh sách tất cả channel kết nối'
  })
  @ApiResponse({
    status: 200,
    description: 'Danh sách channel được trả về thành công',
    type: GetChannelListResponseDto
  })
  async getChannelList(@Req() req: Request, @Query() query: GetChannelListRequestDto): Promise<GetChannelListResponseDto> {
    const channels = await this.channelService.getChannelList(req, query);
    return { channels };
  }

  @Post('unread-count')
  @ApiOperation({
    summary: 'Lấy số lượng hội thoại chưa đọc của từng channel',
    description: 'API để lấy số lượng hội thoại chưa đọc từ đa nền tảng (Facebook và Omnichannel). Sử dụng POST để hỗ trợ lượng channels lớn.'
  })
  @ApiResponse({
    status: 200,
    description: 'Danh sách số lượng hội thoại chưa đọc được trả về thành công',
    type: GetUnreadCountResponseDto
  })
  async getUnreadCount(@Req() req: Request, @Body() body: GetUnreadCountRequestDto): Promise<GetUnreadCountResponseDto> {
    try {
      const { channels } = body;

      if (!channels || channels.length === 0) {
        return {
          success: false,
          data: [],
          message: 'Danh sách channels không hợp lệ hoặc rỗng'
        };
      }

      const unreadCounts = await this.channelService.getUnreadCount(req, channels);

      return {
        success: true,
        data: unreadCounts,
        message: 'Lấy dữ liệu thành công'
      };
    } catch (error) {
      return {
        success: false,
        data: [],
        message: error.message || 'Có lỗi xảy ra khi lấy dữ liệu'
      };
    }
  }

  @Post('active-page')
  @ApiOperation({
    summary: 'Active page Facebook',
    description: 'API active fanpage Facebook. Return JWT token'
  })
  @ApiResponse({
    status: 200,
    description: 'Page was active success',
    type: ActivePageResponseDto
  })
  async activatePage(@Req() req: Request, @Body() body: ActivePageRequestDto): Promise<ActivePageResponseDto> {
    return await this.channelService.activatePage(req, body);
  }
} 