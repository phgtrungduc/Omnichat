import { ForwarderModule } from '@kiotviet-facebook-services/external-platforms';
import { Module } from '@nestjs/common';
import { ChannelController } from './controllers/channel.controller';
import { ChannelMapperService, ChannelService } from './services';
import { FacebookActivePageStrategy } from '../../strategies/active-page/facebook-active-page.strategy';
import { ShopeeActivePageStrategy } from '../../strategies/active-page/shopee-active-page.strategy';

@Module({
  imports: [ForwarderModule],
  controllers: [ChannelController],
  providers: [
    ChannelService, 
    ChannelMapperService,
    FacebookActivePageStrategy,
    ShopeeActivePageStrategy
  ],
  exports: [ChannelService],
})
export class ChannelModule {} 