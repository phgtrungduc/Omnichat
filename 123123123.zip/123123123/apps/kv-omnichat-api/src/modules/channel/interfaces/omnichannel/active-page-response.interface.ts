/**
 * Interface cho request gửi đến OmniChannel API activepage
 * TODO: Cần cập nhật theo API thực tế của OmniChannel
 */
export interface IOmnichannelActivePageRequest {
  channelId: string;
  accessToken: string;
  platform: string;
  // Thêm các field khác theo yêu cầu của omnichannel API
}

/**
 * Interface cho response từ OmniChannel API activepage
 * TODO: Cần cập nhật theo response thực tế của OmniChannel
 */
export interface IOmnichannelActivePageResponse {
  success: boolean;
  jwt?: string;
  data?: any;
  message?: string;
  expire?: string;
} 