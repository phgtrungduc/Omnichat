/**
 * Interface cho request gửi đến Omnichannel API conversation-tags
 * TODO: Cập nhật khi có API thực tế
 */
export interface IOmnichannelConversationTagsRequest {
  pageId: string;
  platform: string;
  version?: number;
}

/**
 * Interface cho response từ Omnichannel API conversation-tags
 * TODO: Cập nhật khi có API thực tế
 */
export interface IOmnichannelConversationTagsResponse {
  success: boolean;
  data: IOmnichannelConversationTagData[];
  message?: string;
}

/**
 * Interface cho data item trong Omnichannel response
 * TODO: Cập nhật khi có API thực tế
 */
export interface IOmnichannelConversationTagData {
  id: string;
  pageId: string;
  title: string;
  color: string;
  version: number;
  conversations: string[];
  timestamp: number;
} 