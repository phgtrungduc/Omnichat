export interface IFbposGraphApiResponseWrapper {
  data: IFbposGraphApiResponse[];
}

export interface IFbposGraphApiResponse {
  id: string;
  name: string;
  link: string;
  access_token: string;
  is_published: boolean;
  picture: {
    data: {
      url: string;
    };
  };
  has_transitioned_to_new_page_experience: boolean;
  tasks: string[];
  connected_instagram_account?: {
    ig_id: number;
    name: string;
    profile_picture_url: string;
    username: string;
    id: string;
  };
} 