/**
 * Interface cho request gửi đến FBPOS API /activepage
 */
export interface IFbposActivePageRequest {
  retailerid: number;
  pageid: string;
  access_token: string;
  isRoleAdmin?: string;
  fbuser?: IFbposActivePageFbUser;
}

/**
 * Interface cho thông tin Facebook user
 */
export interface IFbposActivePageFbUser {
  Name: string;
  Picture: string;
  AppUserId: string;
}

/**
 * Interface cho response từ FBPOS API /activepage
 */
export interface IFbposActivePageResponse {
  status: string;
  jwt: string;
  data: IFbposActivePageData[];
  expire: string;
  message?: string;
}

/**
 * Interface cho data item trong response
 */
export interface IFbposActivePageData {
  pageId: string;
  isRoleAdmin: string;
  message: string;
  extendedToken: string;
} 