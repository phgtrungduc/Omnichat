/**
 * Interface cho response từ FBPOS API /api/v2.0/conversation/unread
 */
export interface IFbposUnreadConversationItem {
  _id: string;
  InstagramId: string;
  TimeStamp: number;
  Type: string;
  SocialType: string;
  SocialId: string;
}

export type IFbposUnreadConversationResponse = IFbposUnreadConversationItem[]; 