export interface IFbposWebhookManagementResponse {
  _id: string;
  RetailerId: number;
  PageId: string;
  State: number;
  TimeStamp: number;
  SocialType: 'instagram' | 'facebook';
  InstagramId?: string;
  InstagramInfo?: {
    ig_id: number;
    name: string;
    profile_picture_url: string;
    username: string;
    id: string;
    picture: string;
    link: string;
    shortLink: string;
  };
  PageInfo?: {
    ig_id: number;
    name: string;
    profile_picture_url: string;
    username: string;
    id: string;
    picture: string;
    link: string;
    shortLink: string;
  };
} 