export interface IOmnichannelConnectionResponse {
  Total: number;
  Data: IOmnichannelConnection[];
}

export interface IOmnichannelConnection {
  Id: number;
  Name: string;
  IsActive: boolean;
  CreatedDate: string;
  ModifiedDate: string;
  CreateBy: number;
  Type: number;
  Status: number;
  BranchId: number;
  RetailerId: number;
  IsSyncMessage: boolean;
  BranchName: string;
  IsDeleted: boolean;
  IdentityKey: string;
  RegisterDate: string;
  OmniChannelAuth?: {
    Id: number;
    ShopId: number;
  };
  IsExpireWarning: boolean;
  PlatformId: number;
  Logo: string;
  TotalUnreadCount: number;
} 