/**
 * Interface cho request gửi đến FBPOS API /tag/list
 */
export interface IFbposConversationTagsRequest {
  version?: number;
  pageid: string;
}

/**
 * Interface cho detail của tag
 */
export interface IFbposConversationTagDetail {
  Title: string;
  Color: string;
}

/**
 * Interface cho data item trong response từ FBPOS
 */
export interface IFbposConversationTagData {
  _id: string;
  PageId: string;
  Detail: IFbposConversationTagDetail;
  Version: number;
  Conversations: string[];
  TimeStamp: number;
}

/**
 * Interface cho response từ FBPOS API /tag/list
 */
export interface IFbposConversationTagsResponse {
  status: string;
  data: IFbposConversationTagData[];
} 