import { Injectable, Logger } from '@nestjs/common';
import { ChannelStatusEnum, ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { ChannelDto } from '../dto';
import { IFbposWebhookManagementResponse, IFbposGraphApiResponse, IOmnichannelConnection } from '../interfaces';

@Injectable()
export class ChannelMapperService {
  private readonly logger = new Logger(ChannelMapperService.name);

  /**
   * Map dữ liệu từ FBPOS webhook và graph API về ChannelDto
   */
  mapFbposToChannelDto(
    webhook: IFbposWebhookManagementResponse,
    graphData?: IFbposGraphApiResponse | null
  ): ChannelDto {
    try {
      //console.log("🚀 ~ ChannelMapperService ~ mapFbposToChannelDto ~ graphData:", graphData)
      if(!graphData){
        return null;
      }
      // Kiểm tra nếu có connected Instagram account
      const hasInstagramAccount = graphData?.connected_instagram_account;
      
      if (webhook.SocialType === 'instagram') {
        // Map về Instagram platform
        return {
          retailerId: webhook.RetailerId,
          platform: ChatPlatformEnum.Instagram,
          channelId: String(webhook.InstagramId),
          status: webhook.State === 1 ? ChannelStatusEnum.ACTIVE : ChannelStatusEnum.INACTIVE,
          avatar: hasInstagramAccount?.profile_picture_url || webhook.InstagramInfo?.picture || '',
          name: hasInstagramAccount?.name || hasInstagramAccount?.username || 'Unknown Instagram Account'
        };
      } else {
        // Map về Facebook platform
        return {
          retailerId: webhook.RetailerId,
          platform: ChatPlatformEnum.Facebook,
          channelId: String(webhook.PageId),
          status: webhook.State === 1 ? ChannelStatusEnum.ACTIVE : ChannelStatusEnum.INACTIVE,
          avatar: graphData?.picture?.data?.url || '',
          name: webhook.PageInfo?.name || graphData?.name || 'Unknown Facebook Page'
        };
      }
    } catch (error) {
      console.log("🚀 ~ ChannelMapperService ~ mapFbposToChannelDto ~ error:", error)
      this.logger.error(`Error mapping FBPOS data for PageId ${webhook.PageId}`, error);
      return null;
    }
  }

  /**
   * Map dữ liệu từ Omnichannel API về ChannelDto
   */
  mapOmnichannelToChannelDto(connection: IOmnichannelConnection): ChannelDto {
    try {
      return {
        retailerId: connection.RetailerId,
        platform: this.mapOmnichannelTypeToPlatform(connection.Type),
        channelId: connection.IdentityKey,
        status: connection.IsActive && !connection.IsDeleted 
          ? ChannelStatusEnum.ACTIVE 
          : ChannelStatusEnum.INACTIVE,
        avatar: connection.Logo || '',
        name: connection.Name
      };
    } catch (error) {
      this.logger.error(`Error mapping Omnichannel data for connection ${connection.Id}`, error);
      return {
        retailerId: connection.RetailerId,
        platform: ChatPlatformEnum.Shopee,
        channelId: connection.IdentityKey,
        status: ChannelStatusEnum.INACTIVE,
        avatar: '',
        name: connection.Name || `Channel ${connection.Id}`
      };
    }
  }

  /**
   * Map loại channel từ Omnichannel về ChatPlatformEnum
   */
  private mapOmnichannelTypeToPlatform(type: number): ChatPlatformEnum {
    switch (type) {
      case 6: 
        return ChatPlatformEnum.Shopee;
      // Có thể thêm các platform khác ở đây theo business logic
      default: 
        return ChatPlatformEnum.Shopee;
    }
  }
} 