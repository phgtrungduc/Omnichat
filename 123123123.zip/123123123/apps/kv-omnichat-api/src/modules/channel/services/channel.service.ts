import { ChatPlatformEnum, KvLogger } from '@kiotviet-facebook-services/common';
import { FbposApiService, OmniChannelApi } from '@kiotviet-facebook-services/external-platforms';
import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { Request } from 'express';
import { IActivePageRequest, IActivePageStrategy } from '../../../strategies/active-page/active-page-strategy.interface';
import { IChannelRequest } from '../../../interfaces';
import { FacebookActivePageStrategy } from '../../../strategies/active-page/facebook-active-page.strategy';
import { ShopeeActivePageStrategy } from '../../../strategies/active-page/shopee-active-page.strategy';
import {
  ActivePageRequestDto,
  ActivePageResponseDto,
  ActivePageDataDto,
  ChannelDto,
  ChannelUnreadCountItem,
  ChannelUnreadItem,
  GetChannelListRequestDto
} from '../dto';
import {
  IFbposGraphApiResponse,
  IFbposGraphApiResponseWrapper,
  IFbposUnreadConversationResponse,
  IFbposWebhookManagementResponse,
  IOmnichannelConnectionResponse
} from '../interfaces';
import { ChannelMapperService } from './channel-mapper.service';

@Injectable()
export class ChannelService {
  private readonly _activePageStrategies: IActivePageStrategy[];

  constructor(
    private readonly _logger: KvLogger,
    private readonly _fbposApiService: FbposApiService,
    private readonly _omniChannelApi: OmniChannelApi,
    private readonly _channelMapper: ChannelMapperService,
    private readonly _facebookActivePageStrategy: FacebookActivePageStrategy,
    private readonly _shopeeActivePageStrategy: ShopeeActivePageStrategy
  ) {
    // Initialize strategies array
    this._activePageStrategies = [
      this._facebookActivePageStrategy,
      this._shopeeActivePageStrategy
    ];
  }

  /**
   * Lấy danh sách tất cả channel từ FBPOS và Omnichannel
   * Sắp xếp theo ưu tiên: FBPOS -> Omnichannel
   */
  async getChannelList(req: Request, query: GetChannelListRequestDto): Promise<ChannelDto[]> {
    this._logger.info('Getting channel list from both FBPOS and Omnichannel APIs');

    try {
      // Parallel calls để tối ưu performance
      const [fbposChannels, omniChannels] = await Promise.allSettled([
        this._getFbposChannels(req, query),
        this._getOmnichannelChannels(req)
      ]);

      const allChannels: ChannelDto[] = [];

      // Xử lý kết quả FBPOS
      if (fbposChannels.status === 'fulfilled') {
        allChannels.push(...fbposChannels.value);
        this._logger.info(`Successfully fetched ${fbposChannels.value.length} FBPOS channels`);
      } else {
        this._logger.error('Failed to fetch FBPOS channels', fbposChannels.reason);
      }

      // Xử lý kết quả Omnichannel
      if (omniChannels.status === 'fulfilled') {
        allChannels.push(...omniChannels.value);
        this._logger.info(`Successfully fetched ${omniChannels.value.length} Omnichannel channels`);
      } else {
        this._logger.error('Failed to fetch Omnichannel channels', omniChannels.reason);
      }

      // Sort theo ưu tiên: FBPOS -> Omnichannel
      const sortedChannels = this._sortChannelsByPriority(allChannels);

      this._logger.info(`Successfully returned ${sortedChannels.length} total channels`);
      return sortedChannels;

    } catch (error) {
      this._logger.error('Error getting channel list', error);
      throw new InternalServerErrorException('Failed to get channel list');
    }
  }

  /**
   * Lấy danh sách channel từ FBPOS (Facebook)
   */
  private async _getFbposChannels(req: Request, query: GetChannelListRequestDto): Promise<ChannelDto[]> {
    try {
      if (!query.fbid) {
        this._logger.info('No Facebook ID provided');
        return [];
      }
      // Gọi đồng thời cả 2 APIs
      const [webhookResponse, graphResponse] = await Promise.allSettled([
        this._fbposApiService.get<IFbposWebhookManagementResponse[]>(
          '/webhook_management/list',
          {
            headers: req.headers,
            params: {
              version: 2,
              retailerid: (req as any)?.kvretail?.retailerId as number
            }
          }
        ),
        this._fbposApiService.get<IFbposGraphApiResponseWrapper>('/graph-api', {
          headers: req.headers,
          params: {
            fields: 'id,name,link,access_token,is_published,picture{url},tasks,has_transitioned_to_new_page_experience,connected_instagram_account{ig_id,name,profile_picture_url,username}',
            type: 2,
            fbid: query.fbid
          }
        })
      ]);

      // Xử lý webhook response
      let webhookList: IFbposWebhookManagementResponse[] = [];
      if (webhookResponse.status === 'fulfilled') {
        webhookList = webhookResponse.value.data || [];
      } else {
        this._logger.error('Failed to get webhook list', webhookResponse.reason);
      }

      // Xử lý graph response  
      let graphData: IFbposGraphApiResponse[] = [];
      if (graphResponse.status === 'fulfilled') {
        graphData = graphResponse.value.data?.data || [];
      } else {
        this._logger.warn('Failed to get graph data', graphResponse.reason);
      }

      if (webhookList.length === 0) {
        this._logger.info('No FBPOS webhook pages found');
        return [];
      }

      // Map về ChannelDto - sử dụng graphData cho page khớp PageId
      const fbposChannels = webhookList.map(webhook => {
        const matchedGraphData = graphData.find(g => g.id === webhook.PageId);
        return this._channelMapper.mapFbposToChannelDto(webhook, matchedGraphData);
      }).filter(channel => channel !== null);

      this._logger.info(`Mapped ${fbposChannels.length} FBPOS channels successfully`);
      return fbposChannels;

    } catch (error) {
      this._logger.error('Error fetching FBPOS channels', error);
      throw error;
    }
  }

  /**
   * Lấy danh sách channel từ Omnichannel (Shopee, etc.)
   */
  private async _getOmnichannelChannels(req: Request): Promise<ChannelDto[]> {
    try {
      const response = await this._omniChannelApi.get<IOmnichannelConnectionResponse>(
        'chat/connection/retailer',
        {
          headers: req.headers,
          params: {
            channelType: 6 // Shopee channel type
          }
        }
      );

      const responseData = response.data;
      if (!responseData?.Data || responseData.Data.length === 0) {
        this._logger.info('No Omnichannel connections found');
        return [];
      }
      // filter IsDeleted
      const omniChannels = responseData.Data.filter(connection => !connection.IsDeleted).map(connection =>
        this._channelMapper.mapOmnichannelToChannelDto(connection)
      );

      this._logger.info(`Mapped ${omniChannels.length} Omnichannel channels successfully`);
      return omniChannels;

    } catch (error) {
      this._logger.error('Error fetching Omnichannel channels', error);
      throw error;
    }
  }

  /**
   * Sắp xếp channel theo ưu tiên: FBPOS -> Omnichannel
   */
  private _sortChannelsByPriority(channels: ChannelDto[]): ChannelDto[] {
    return channels.sort((a, b) => {
      // Định nghĩa độ ưu tiên platform (số càng nhỏ càng ưu tiên)
      const platformPriority = {
        [ChatPlatformEnum.Facebook]: 1,
        [ChatPlatformEnum.Instagram]: 2, // Instagram sau Facebook vì cùng ecosystem
        [ChatPlatformEnum.Shopee]: 3,
        [ChatPlatformEnum.Zalo]: 4
      };

      const priorityA = platformPriority[a.platform] || 999;
      const priorityB = platformPriority[b.platform] || 999;

      // Sắp xếp theo platform priority trước
      if (priorityA !== priorityB) {
        return priorityA - priorityB;
      }

      // Cùng platform thì sắp xếp theo tên
      return a.name.localeCompare(b.name);
    });
  }

  /**
   * Lấy số lượng hội thoại chưa đọc của từng channel từ đa nền tảng
   */
  async getUnreadCount(req: Request, channels: ChannelUnreadItem[]): Promise<ChannelUnreadCountItem[]> {
    this._logger.info(`Getting unread count for ${channels.length} channels`);

    try {
      // Phân loại channels theo platform - FBPOS handles Facebook và Instagram
      const fbposChannels = channels.filter(c =>
        c.platform === ChatPlatformEnum.Facebook || c.platform === ChatPlatformEnum.Instagram
      );
      const omnichannelChannels = channels.filter(c =>
        c.platform === ChatPlatformEnum.Shopee || c.platform === ChatPlatformEnum.Zalo
      );

      // Parallel calls để tối ưu performance
      const [fbposResults, omniResults] = await Promise.allSettled([
        this._getFbposUnreadCount(req, fbposChannels),
        this._getOmnichannelUnreadCount(req, omnichannelChannels)
      ]);

      const allResults: ChannelUnreadCountItem[] = [];

      // Xử lý kết quả FBPOS
      if (fbposResults.status === 'fulfilled') {
        allResults.push(...fbposResults.value);
        this._logger.info(`Successfully fetched unread count for ${fbposResults.value.length} FBPOS channels`);
      } else {
        this._logger.error('Failed to fetch FBPOS unread count', fbposResults.reason);
        // Thêm kết quả mặc định cho các FBPOS channels bị lỗi
        fbposChannels.forEach(channel => {
          allResults.push({
            channelId: channel.channelId,
            platform: channel.platform,
            unreadCount: 0
          });
        });
      }

      // Xử lý kết quả Omnichannel
      if (omniResults.status === 'fulfilled') {
        allResults.push(...omniResults.value);
        this._logger.info(`Successfully fetched unread count for ${omniResults.value.length} Omnichannel channels`);
      } else {
        this._logger.error('Failed to fetch Omnichannel unread count', omniResults.reason);
        // Thêm kết quả mặc định cho các Omnichannel channels bị lỗi
        omnichannelChannels.forEach(channel => {
          allResults.push({
            channelId: channel.channelId,
            platform: channel.platform,
            unreadCount: 0
          });
        });
      }

      this._logger.info(`Successfully returned unread count for ${allResults.length} total channels`);
      return allResults;

    } catch (error) {
      this._logger.error('Error getting unread count', error);
      throw new InternalServerErrorException('Failed to get unread count');
    }
  }

  /**
   * Lấy số lượng hội thoại chưa đọc từ FBPOS (Facebook/Instagram)
   */
  private async _getFbposUnreadCount(req: Request, channels: ChannelUnreadItem[]): Promise<ChannelUnreadCountItem[]> {
    if (channels.length === 0) {
      return [];
    }

    try {
      const socialIds = channels.map(c => c.channelId).join(',');

      const response = await this._fbposApiService.get<IFbposUnreadConversationResponse>(
        '/api/v2.0/conversation/unread',
        {
          headers: req.headers,
          params: {
            socialIds
          }
        }
      );

      const responseData = response.data || [];

      // Map kết quả theo SocialId và SocialType để phân biệt Facebook/Instagram
      const resultMap = new Map<string, { count: number; platform: ChatPlatformEnum }>();

      // Count unread conversations by SocialId và xác định platform từ SocialType
      responseData.forEach(item => {
        const existing = resultMap.get(item.SocialId) || { count: 0, platform: ChatPlatformEnum.Facebook };
        const platform = item.SocialType === 'instagram' ? ChatPlatformEnum.Instagram : ChatPlatformEnum.Facebook;

        resultMap.set(item.SocialId, {
          count: existing.count + 1,
          platform: platform
        });
      });

      // Map về format cuối cùng
      return channels.map(channel => {
        const result = resultMap.get(channel.channelId);
        return {
          channelId: channel.channelId,
          platform: result?.platform || channel.platform, // Fallback về platform từ request nếu không có data
          unreadCount: result?.count || 0
        };
      });

    } catch (error) {
      this._logger.error('Error fetching FBPOS unread count', error);
      throw error;
    }
  }

  /**
   * Lấy số lượng hội thoại chưa đọc từ Omnichannel
   */
  private async _getOmnichannelUnreadCount(req: Request, channels: ChannelUnreadItem[]): Promise<ChannelUnreadCountItem[]> {
    if (channels.length === 0) {
      return [];
    }

    try {
      const response = await this._omniChannelApi.get<IOmnichannelConnectionResponse>(
        'chat/connection/retailer',
        {
          headers: req.headers,
          params: {
            channelType: 6 // Shopee channel type
          }
        }
      );

      const responseData = response.data;
      if (!responseData?.Data) {
        return channels.map(channel => ({
          channelId: channel.channelId,
          platform: channel.platform,
          unreadCount: 0
        }));
      }

      // Map kết quả về format chung - tìm theo IdentityKey (channelId)
      const resultMap = new Map<string, number>();
      responseData.Data.forEach(connection => {
        resultMap.set(connection.IdentityKey, connection.TotalUnreadCount || 0);
      });

      // Map về format cuối cùng
      return channels.map(channel => ({
        channelId: channel.channelId,
        platform: channel.platform,
        unreadCount: resultMap.get(channel.channelId) || 0
      }));

    } catch (error) {
      this._logger.error('Error fetching Omnichannel unread count', error);
      throw error;
    }
  }

  /**
   * Batch activate pages/channels on multiple platforms
   */
  async activatePage(req: Request, body: ActivePageRequestDto): Promise<ActivePageResponseDto> {

    try {
      // Validate channels not empty
      if (!body.channels || body.channels.length === 0) {
        throw new Error('Channels list cannot be empty');
      }

      const channelIds = body.channels.map(c => c.channelId).join(', ');
      this._logger.info(`Activating ${body.channels.length} channels: ${channelIds}`);

      // Group channels by platform
      const channelsByPlatform = body.channels.reduce((acc, channel) => {
        if (!acc[channel.platform]) {
          acc[channel.platform] = [];
        }
        acc[channel.platform].push(channel);
        return acc;
      }, {} as Record<ChatPlatformEnum, IChannelRequest[]>);

      const allResults: ActivePageDataDto[] = [];
      let hasErrors = false;
      let errorMessage = '';

      // Process each platform
      for (const [platform, channels] of Object.entries(channelsByPlatform)) {
        const strategy = this._activePageStrategies.find(s => s.supports(platform as ChatPlatformEnum));

        if (!strategy) {
          hasErrors = true;
          errorMessage = `Platform ${platform} is not supported for activation`;
          this._logger.error(errorMessage);

          // Add failed results for unsupported platform
          channels.forEach(channel => {
            allResults.push({
              channelId: channel.channelId,
              platform: channel.platform,
              message: `Platform ${platform} is not supported`,
              success: false
            });
          });
          continue;
        }

        try {
          const activePageRequest: IActivePageRequest = {
            channels,
            fbposParams: {
              fbUser: body.fbposParams.fbUser ? {
                name: body.fbposParams.fbUser.name,
                picture: body.fbposParams.fbUser.picture,
                appUserId: body.fbposParams.fbUser.appUserId
              } : undefined
            }
          };

          const result = await strategy.activatePages(req, activePageRequest);

          // Add results from this platform
          allResults.push(...result.data);

        } catch (error) {
          hasErrors = true;
          const platformChannelIds = channels.map(c => c.channelId).join(', ');
          errorMessage = `Error activating channels for platform ${platform}, channels: ${platformChannelIds} - ${error.message}`;
          this._logger.error(errorMessage, error);

          // Add failed results for error case
          channels.forEach(channel => {
            allResults.push({
              channelId: channel.channelId,
              platform: channel.platform,
              message: error.message || 'Activation failed',
              success: false
            });
          });
        }
      }

      // Calculate statistics
      const totalCount = allResults.length;
      const successCount = allResults.filter(r => r.success).length;
      const failureCount = totalCount - successCount;

      // Generate statistics by platform
      const statistics = this._generateActivationStatistics(allResults, channelsByPlatform);

      const response: ActivePageResponseDto = {
        success: successCount > 0, // Success if at least one channel activated
        data: allResults,
        totalCount,
        successCount,
        failureCount,
        message: hasErrors && successCount === 0
          ? errorMessage
          : `Successfully activated ${successCount} out of ${totalCount} channels`,
        statistics
      };

      this._logger.info(`Activation completed: ${successCount}/${totalCount} channels successful`);

      return response;

    } catch (error) {
      this._logger.error(`Error in batch activation`, error);
      return {
        success: false,
        data: [],
        totalCount: 0,
        successCount: 0,
        failureCount: 0,
        message: error.message || 'Error occurred during batch activation'
      };
    }
  }

  /**
   * Generate activation statistics by platform
   */
  private _generateActivationStatistics(
    results: ActivePageDataDto[],
    channelsByPlatform: Record<ChatPlatformEnum, IChannelRequest[]>
  ): Record<string, { total: number; success: number; failed: number }> {
    const statistics: Record<string, { total: number; success: number; failed: number }> = {};

    for (const [platform, channels] of Object.entries(channelsByPlatform)) {
      const platformResults = results.filter(r => r.platform.toString() === platform);
      const successCount = platformResults.filter(r => r.success).length;

      statistics[platform] = {
        total: channels.length,
        success: successCount > 0 ? channels.length : 0,
        failed: successCount > 0 ? 0 : 1,
      };
    }

    return statistics;
  }
} 