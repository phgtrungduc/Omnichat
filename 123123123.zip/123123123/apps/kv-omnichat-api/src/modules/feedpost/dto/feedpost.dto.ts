import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, IsNumber, IsArray, IsObject, IsOptional, IsEnum, Min, Max, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { IPlatformChannel } from '../../../common/interfaces/platform-channel.interface';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

/**
 * DTO for feedpost fields selection
 */
export class FeedpostFieldsDto {
  @ApiProperty({
    description: 'Include message field',
    example: 1,
    required: false
  })
  @IsOptional()
  @IsNumber()
  message?: number;

  @ApiProperty({
    description: 'Include status_type field',
    example: 1,
    required: false
  })
  @IsOptional()
  @IsNumber()
  statusType?: number;

  @ApiProperty({
    description: 'Include created_time field',
    example: 1,
    required: false
  })
  @IsOptional()
  @IsNumber()
  createdTime?: number;
}

/**
 * DTO for feedpost list request
 */
export class FeedpostListRequestDto {

  @ApiProperty({
    description: 'Maximum number of posts to return',
    example: 10,
    minimum: 1,
    maximum: 1000,
    required: false
  })

  @ApiProperty({
    description: 'Channels to fetch feedposts from',
    required: true
  })
  @IsNotEmpty()
  @IsArray()
  @ValidateNested({ each: true })
  channels: IPlatformChannel[];

  @ApiProperty({
    description: 'Skip for pagination',
    example: 10,
    required: false
  })
  @IsOptional()
  @IsNumber()
  skip?: number;

  @ApiProperty({
    description: 'Limit for pagination',
    example: 10,
    required: false
  })
  @IsOptional()
  @IsNumber()
  limit?: number;

  @ApiProperty({
    description: 'Search message',
    example: 'promotion',
    required: false
  })
  @IsOptional()
  searchMessage?: string;
}

/**
 * DTO for feedpost item response
 */
export class FeedpostItemDto {
  @ApiProperty({
    description: 'Post ID',
    example: '123456789_987654321'
  })
  _id: string;

  @ApiProperty({
    description: 'Page ID',
    example: '790976900758321'
  })
  channelId: string;

  @ApiProperty({
    description: 'Post message content',
    example: 'Check out our latest promotion!',
    required: false
  })
  message?: string;

  @ApiProperty({
    description: 'Post status type',
    example: 'published_story',
    required: false
  })
  statusType?: string;

  @ApiProperty({
    description: 'Post creation time',
    example: 1640995200,
    required: false
  })
  createdTime?: number;

  @ApiProperty({
    description: 'Is from live stream',
    example: false,
    required: false
  })
  isFromLivestream?: boolean;

  @ApiProperty({
    description: 'Platform source',
    enum: ChatPlatformEnum,
    example: ChatPlatformEnum.Facebook
  })
  platform: ChatPlatformEnum;
}

/**
 * DTO for feedpost list response
 */
export class FeedpostListResponseDto {
  @ApiProperty({
    description: 'List of feedposts',
    type: [FeedpostItemDto],
    isArray: true
  })
  data: FeedpostItemDto[];

  @ApiProperty({
    description: 'Has more posts',
    example: true
  })
  hasMore: boolean;

}
