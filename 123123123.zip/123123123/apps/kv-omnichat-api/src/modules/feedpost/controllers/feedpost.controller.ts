import { Controller, Post, Body, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBody } from '@nestjs/swagger';
import { 
  FeedpostListRequestDto,
  FeedpostListResponseDto
} from '../dto/feedpost.dto';
import { FeedpostFacade } from '../../../facade/feedpost.facade';
import { ConfigService } from '@nestjs/config';
const DEFAULT_LIMIT = 20;
@ApiTags('Feedpost')
@Controller('feedpost')
export class FeedpostController {
  constructor(
    private readonly feedpostFacade: FeedpostFacade,
    private readonly configService: ConfigService
  ) {}

  @Post('list')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Get feedposts from multiple platforms',
    description: 'Retrieve feedposts from Facebook and Shopee platforms with optional insights'
  })
  @ApiBody({
    type: FeedpostListRequestDto,
    description: 'Request parameters for fetching feedposts'
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved feedposts',
    type: FeedpostListResponseDto
  })
  @ApiResponse({
    status: 400,
    description: 'Bad request - invalid parameters'
  })
  @ApiResponse({
    status: 500,
    description: 'Internal server error'
  })
  async getFeedposts(@Body() query: FeedpostListRequestDto): Promise<FeedpostListResponseDto> {
    const limit = this.configService.get('feedpost.limit') || DEFAULT_LIMIT;
    query.limit = limit;
    // Chỉ gọi facade, KHÔNG có business logic
    return await this.feedpostFacade.getFeedposts(query.channels, query);
  }
} 