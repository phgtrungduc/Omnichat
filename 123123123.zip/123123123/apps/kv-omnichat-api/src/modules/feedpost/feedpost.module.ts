import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { FeedpostController } from './controllers/feedpost.controller';
import { FeedpostFacade } from '../../facade/feedpost.facade';
import { CompositeFeedpostStrategy } from '../../composite/composite-feedpost.strategy';
import { FacebookFeedpostStrategy } from '../../strategies/facebook/facebook-feedpost.strategy';
import { ShopeeFeedpostStrategy } from '../../strategies/shopee/shopee-feedpost.strategy';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { OmnimongoRepositoryModule } from '@kiotviet-facebook-services/omnimongo-repository';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { CommonServicesModule } from '../../common/common-services.module';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';

@Module({
  imports: [
    CommonModule,
    CommonServicesModule,
    FbPosMasterRepositoryModule,
    OmnimongoRepositoryModule,
    KvRabbitMQModule,
    ConfigModule
  ],
  controllers: [FeedpostController],
  providers: [
    // Facade
    FeedpostFacade,
    
    // Composite Strategy
    CompositeFeedpostStrategy,
    
    // Individual Strategies
    FacebookFeedpostStrategy,
    ShopeeFeedpostStrategy
  ],
  exports: [FeedpostFacade]
})
export class FeedpostModule {} 