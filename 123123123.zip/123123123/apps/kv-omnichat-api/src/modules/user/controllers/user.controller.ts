import { Controller, Get, Query } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { UserFacade } from '../../../facade/user.facade';
import { UserProfileDto, UserProfileResponseDto, UserProfilePictureResponseDto } from '../dto/user.dto';
import { Auth } from '@kiotviet-facebook-services/kv-auth';

@ApiTags('User')
@Controller('user')
@Auth()
export class UserController {
  constructor(private readonly userFacade: UserFacade) {}

  @Get('profile')
  @ApiOperation({
    summary: 'Get user profile',
    description: 'Get user profile from specified platform'
  })
  @ApiResponse({
    status: 200,
    description: 'User profile retrieved successfully',
    type: UserProfileResponseDto
  })
  async getUserProfile(@Query() dto: UserProfileDto): Promise<UserProfileResponseDto> {
    return await this.userFacade.getUserProfile(dto);
  }

  @Get('profile-picture')
  @ApiOperation({
    summary: 'Get user profile picture',
    description: 'Get user profile picture URL from specified platform'
  })
  @ApiResponse({
    status: 200,
    description: 'User profile picture URL retrieved successfully',
    type: UserProfilePictureResponseDto
  })
  async getUserProfilePicture(@Query() dto: UserProfileDto): Promise<UserProfilePictureResponseDto> {
    const profilePicUrl = await this.userFacade.getUserProfilePicture(dto);
    return { profilePic: profilePicUrl };
  }
}
