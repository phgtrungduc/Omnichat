import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { CommonServicesModule } from '../../common/common-services.module';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { OmnimongoRepositoryModule } from '@kiotviet-facebook-services/omnimongo-repository';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { ConfigModule } from '@nestjs/config';

import { UserController } from './controllers/user.controller';
import { UserFacade } from '../../facade/user.facade';
import { CompositeUserStrategy } from '../../composite/composite-user.strategy';
import { FacebookUserStrategy } from '../../strategies/facebook/facebook-user.strategy';
import { ShopeeUserStrategy } from '../../strategies/shopee/shopee-user.strategy';


@Module({
  imports: [
    CommonModule,
    CommonServicesModule,
    FbPosMasterRepositoryModule,
    OmnimongoRepositoryModule,
    KvRabbitMQModule,
    ConfigModule
  ],
  controllers: [UserController],
  providers: [
    // Facade
    UserFacade,
    
    // Composite Strategy
    CompositeUserStrategy,
    
    // Individual Strategies
    FacebookUserStrategy,
    ShopeeUserStrategy
  ],
  exports: [UserFacade]
})
export class UserModule {}
