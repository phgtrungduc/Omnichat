import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

export class UserProfileDto {
  @ApiProperty({
    description: 'Platform to get user profile from',
    enum: ChatPlatformEnum,
    example: ChatPlatformEnum.Facebook
  })
  @IsNotEmpty()
  platform: ChatPlatformEnum;

  @ApiProperty({
    description: 'User ID to get profile for',
    example: '123456789'
  })
  @IsNotEmpty()
  @IsString()
  userId: string;
}

export class UserProfileResponseDto {
  @ApiProperty({
    description: 'User ID',
    example: '123456789'
  })
  id?: string;

  @ApiProperty({
    description: 'User first name',
    example: 'John'
  })
  firstName?: string;

  @ApiProperty({
    description: 'User last name',
    example: 'Doe'
  })
  lastName?: string;

  @ApiProperty({
    description: 'User full name',
    example: 'John Doe'
  })
  name?: string;

  @ApiProperty({
    description: 'User username',
    example: 'johndoe'
  })
  username?: string;

  @ApiProperty({
    description: 'User profile picture URL',
    example: 'https://example.com/profile.jpg'
  })
  profilePic?: string;

  @ApiProperty({
    description: 'User gender',
    example: 'male'
  })
  gender?: string;

  @ApiProperty({
    description: 'Channel ID',
    example: '987654321'
  })
  channelId?: string;

  @ApiProperty({
    description: 'User phone number',
    example: '+1234567890'
  })
  phoneNumber?: string;


  @ApiProperty({
    description: 'KiotViet customers associated with this user',
    type: [Object]
  })
  kvCustomers?: any[];

  @ApiProperty({
    description: 'Last updated timestamp',
    example: '2024-01-01T00:00:00.000Z'
  })
  updatedAt?: Date;

  
  platform?: ChatPlatformEnum;
}

export class UserProfilePictureResponseDto {
  @ApiProperty({
    description: 'User profile picture URL',
    example: 'https://example.com/profile.jpg'
  })
  profilePic?: string;
}
