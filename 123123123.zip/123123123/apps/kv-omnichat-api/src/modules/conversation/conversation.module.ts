import { Module } from '@nestjs/common';
import { ConversationController } from './controllers/conversation.controller';
import { ConversationMessageController } from './controllers/conversation-message.controller';
import { ConversationFacade } from '../../facade/conversation.facade';
import { CompositeConversationStrategy } from '../../composite/composite-conversation.strategy';
import { FacebookConversationStrategy } from '../../strategies/facebook/facebook-conversation.strategy';
import { ShopeeConversationStrategy } from '../../strategies/shopee/shopee-conversation.strategy';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { OmnimongoRepositoryModule } from '@kiotviet-facebook-services/omnimongo-repository';
import { OmniChannelRepositoryModule } from '@kiotviet-facebook-services/omnichannel-repository';
import { ForwarderModule } from '@kiotviet-facebook-services/external-platforms';

// Import new conversation status services and strategies
import { ConversationStatusService } from '../../services/conversation-status.service';
import { FacebookConversationStatusStrategy } from '../../strategies/facebook/facebook-conversation-status.strategy';
import { ShopeeConversationStatusStrategy } from '../../strategies/shopee/shopee-conversation-status.strategy';
import { ConversationFilterService } from '../../services/conversation-filter.service';

// Import message related components
import { MessageFacade } from '../../facade/message.facade';
import { StrategiesModule } from '../../strategies/strategies.module';
import { ChannelService } from '../../services/channel.service';

@Module({
  imports: [
    FbPosMasterRepositoryModule,
    OmnimongoRepositoryModule,
    OmniChannelRepositoryModule,
    ForwarderModule,
    StrategiesModule
  ],
  controllers: [
    ConversationController,
    ConversationMessageController
  ],
  providers: [
    // Facade
    ConversationFacade,
    MessageFacade,
    
    // Composite Strategy
    CompositeConversationStrategy,
    
    // Individual Strategies
    FacebookConversationStrategy,
    ShopeeConversationStrategy,
    
    // Conversation Status Services
    ConversationStatusService,
    FacebookConversationStatusStrategy,
    ShopeeConversationStatusStrategy,
    
    // Filter Service
    ConversationFilterService,
    ChannelService
  ],
  exports: [ConversationFacade, ConversationStatusService, MessageFacade]
})
export class ConversationModule {} 