import { Controller, Get, Param, Query, Req } from '@nestjs/common';
import { ApiOperation, ApiParam, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Request } from 'express';
import { Auth, AuthData, IRetailAuth } from '@kiotviet-facebook-services/kv-auth';
import { GetConversationMessagesRequestDto } from '../dto/get-conversation-messages-request.dto';
import { GetConversationMessagesResponseDto, MessageDto } from '../dto/get-conversation-messages-response.dto';
import { MessageFacade } from '../../../facade/message.facade';
import { IConversationMessagesFilters } from '../../../interfaces/message.interface';
import { plainToInstance } from 'class-transformer';
import { dtoToInterface } from '@kiotviet-facebook-services/common';

@ApiTags('Conversation Messages')
@Controller('conversation')
@Auth()
export class ConversationMessageController {
  constructor(
    private readonly messageFacade: MessageFacade
  ) { }

  @Get(':conversationId/messages')
  @ApiOperation({
    summary: 'Get messages from a conversation',
    description: 'Retrieves all messages from a specific conversation'
  })
  @ApiParam({
    name: 'conversationId',
    description: 'The ID of the conversation to get messages from',
    required: true
  })
  @ApiResponse({
    status: 200,
    description: 'Messages retrieved successfully',
    type: GetConversationMessagesResponseDto
  })
  @ApiResponse({
    status: 400,
    description: 'Bad request'
  })
  @ApiResponse({
    status: 404,
    description: 'Conversation not found'
  })
  async getConversationMessages(
    @Param('conversationId') conversationId: string,
    @Query() queryParams: GetConversationMessagesRequestDto,
    @AuthData() authData: IRetailAuth
  ): Promise<GetConversationMessagesResponseDto> {
    const filters = dtoToInterface<GetConversationMessagesRequestDto, IConversationMessagesFilters>(queryParams, {
      conversationId: conversationId,
      retailerId: authData.retailerId,
      authorization: authData.authorization
    });

    // Call facade service to get messages
    const messagesResponse = await this.messageFacade.getConversationMessages(filters);
    
    // Return response
    return {
      items: messagesResponse.items as MessageDto[],
      more: messagesResponse.more
    };
  }
} 