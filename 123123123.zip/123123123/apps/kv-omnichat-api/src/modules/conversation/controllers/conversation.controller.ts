import { Body, Controller, Post, Req } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { ConversationSearchByAccountDto, ConversationSearchDto, ConversationSearchByMessageDto } from '../dto/conversation-search.dto';
import { ConversationFacade } from '../../../facade/conversation.facade';
import { ConversationStatusService } from '../../../services/conversation-status.service';
import { ConversationResponseDto } from '../dto/conversation-response.dto';
import { MarkConversationStatusDto, MarkConversationStatusResponseDto } from '../../../common/dto/conversation-status.dto';
import { Request } from 'express';
import { ConfigService } from '@nestjs/config';
import { Auth, AuthData, IRetailAuth } from '@kiotviet-facebook-services/kv-auth';
import { IConversationSearchByAccountFilters, IConversationSearchByMessageFilters } from '../../../interfaces/conversation.interface';
import { BasePagingDto } from '../../../common/dto/base-paging.dto';

@ApiTags('Conversation')
@Controller('conversation')
@Auth()
export class ConversationController {
  constructor(
    private readonly conversationFacade: ConversationFacade,
    private readonly conversationStatusService: ConversationStatusService,
    private readonly configService: ConfigService
  ) { }



  @Post('list')
  @ApiOperation({
    summary: 'Search conversations across all platforms',
    description: 'Search conversations using unified filters'
  })
  @ApiResponse({
    type: ConversationResponseDto,
  })
  async listConversations(@Body() searchDto: ConversationSearchDto, @AuthData() authData: IRetailAuth) : Promise<BasePagingDto<ConversationResponseDto>> {

    searchDto.retailerId = authData.retailerId;
    searchDto.limit = searchDto.limit || this.configService.get('pagingLimit.conversation');
    const conversations = await this.conversationFacade.getConversations(searchDto);

    console.log(conversations);
    return conversations;
  }

  @Post('mark-status')
  @ApiOperation({
    summary: 'Mark conversation status',
    description: 'API to mark conversation status (read, resolved) for one or more conversations on different platforms'
  })
  @ApiResponse({
    status: 200,
    description: 'Update success',
    type: MarkConversationStatusResponseDto
  })
  @ApiResponse({
    status: 400,
    description: 'Validation error'
  })
  @ApiResponse({
    status: 500,
    description: 'Internal server error'
  })
  async markConversationStatus(
    @Body() markStatusDto: MarkConversationStatusDto,
    @Req() request: Request
  ): Promise<MarkConversationStatusResponseDto> {
    return await this.conversationStatusService.markConversationStatus(markStatusDto, request);
  }



  @Post('search-by-account')
  @ApiOperation({
    summary: 'Search conversations across all platforms',
    description: 'Search conversations using unified filters'
  })
  @ApiResponse({
    type: ConversationResponseDto,
  })
  async searchAccountConversation(@Body() searchDto: ConversationSearchByAccountDto, @AuthData() authData: IRetailAuth) : Promise<BasePagingDto<ConversationResponseDto>> {
    const limitGetAccountConversation = this.configService.get('pagingLimit.searchByAccount') || 3;
    const searchData: IConversationSearchByAccountFilters = {
      ...searchDto,
      retailerId: authData.retailerId,
      limit: searchDto.limit || limitGetAccountConversation,
    };
    const conversations = await this.conversationFacade.getAccountConversations(searchData);
    return conversations;
  }

  @Post('search-by-message')
  @ApiOperation({
    summary: 'Search conversations by message content across all platforms',
    description: 'Search conversations using message content filters'
  })
  @ApiResponse({
    type: ConversationResponseDto,
  })
  async searchMessageConversation(@Body() searchDto: ConversationSearchByMessageDto, @AuthData() authData: IRetailAuth) : Promise<BasePagingDto<ConversationResponseDto>> {
    const limitGetMessageConversation = this.configService.get('pagingLimit.searchByMessage') || 5;
    const searchData: IConversationSearchByMessageFilters = {
      ...searchDto,
      retailerId: authData.retailerId,
      limit: searchDto.limit || limitGetMessageConversation,
    };
    const conversations = await this.conversationFacade.getMessageConversations(searchData);
    return conversations;
  }
}