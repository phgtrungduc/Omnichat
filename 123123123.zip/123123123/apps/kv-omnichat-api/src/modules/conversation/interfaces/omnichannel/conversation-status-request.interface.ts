export interface IOmnichannelMarkReadRequest {
  // Body is empty, using query params LastReadMessageId
}

export interface IOmnichannelMarkUnreadRequest {
  // Body is empty, no query params needed
} 