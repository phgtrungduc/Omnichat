export interface IFbposConversationStatusResponse {
  status: string;         // "success"
  data: {
    _id?: string;
    ConversationId: string;
    PageId: string;
    Field: string;        // "messenger"
    EventType: string;    // "ConversationReadChanged" | "ConversationResolveChanged" | "BulkConversationReadChanged"
    State: number;        // 0 or 1
    FacebookName?: string;
    SocialType: string;   // "facebook"
    ConversationIds?: string[]; // For bulk operations
  } | Array<{
    ConversationIds: string[];
    PageId: string;
    Field: string;
    EventType: string;
    State: number;
    FacebookName?: string;
  }>;
} 