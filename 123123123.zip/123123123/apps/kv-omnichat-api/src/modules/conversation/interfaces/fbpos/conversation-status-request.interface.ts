export interface IFbposToggleConversationRequest {
  type: string;           // "messenger"
  pageid: string;         // Page ID
  socialType: string;     // "facebook"
  conversationid: string; // Conversation ID
  state: number;          // 0 = mark, 1 = unmark
  fbName?: string;        // Facebook user name
}

export interface IFbposResolveConversationRequest {
  type: string;           // "messenger"
  pageid: string;         // Page ID
  socialType: string;     // "facebook"
  conversationid: string; // Conversation ID
  state: number;          // 0 = mark resolved, 1 = unmark resolved
}

export interface IFbposBulkToggleConversationRequest {
  type: string;           // "messenger"
  pageid: string;         // Page ID
  conversationids: Record<string, string[]>; // { "pageId": ["conv1", "conv2"] }
  state: number;          // 0 = mark read, 1 = mark unread
  fbName?: string;        // Facebook user name
} 