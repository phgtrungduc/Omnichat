export interface IOmnichannelMarkReadResponse {
  Success: boolean;
  Data: {
    RetailerId: number;
    ChannelId: number;
    PlatformType: number;
    ConversationId: string;
    ToId: number;
    ToName: string;
    ToAvatar: string;
    ShopId: number;
    UnreadCount: number;
    Pinned: boolean;
    Mute: boolean;
    LastReadMessageId: string;
    LatestMessageId: string;
    LatestMessageType: string;
    LatestMessageFromId: number;
    LastMessageTimestamp: number;
    LastMessageOption: number;
    MaxGeneralOptionHideTime: string;
    CreatedDate: string;
    Source: string;
    Id: string;
  };
}

export interface IOmnichannelMarkUnreadResponse {
  Success: boolean;
  Data: {
    RetailerId: number;
    ChannelId: number;
    PlatformType: number;
    ConversationId: string;
    ToId: number;
    ToName: string;
    ToAvatar: string;
    ShopId: number;
    UnreadCount: number;
    Pinned: boolean;
    Mute: boolean;
    LastReadMessageId: string;
    LatestMessageId: string;
    LatestMessageType: string;
    LatestMessageFromId: number;
    LastMessageTimestamp: number;
    LastMessageOption: number;
    MaxGeneralOptionHideTime: string;
    CreatedDate: string;
    Source: string;
    Id: string;
  };
} 