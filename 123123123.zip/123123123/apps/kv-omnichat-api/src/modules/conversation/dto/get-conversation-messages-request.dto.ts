import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNumber, IsOptional, IsString } from 'class-validator';
import { BaseParamsDto } from '../../../common/dto/base-params.dto';
import { Type } from 'class-transformer';
import { ChatConversationType } from '../../../common/enums/chat-search-type.enum';

export class GetConversationMessagesRequestDto extends BaseParamsDto {

    @IsEnum(ChatConversationType)
    @ApiProperty({
        description: 'Conversation Type',
        enum: ChatConversationType,
        example: ChatConversationType.MESSENGER
    })
    conversationType: ChatConversationType;

    @IsString()
    @IsOptional()
    @ApiProperty({
        description: 'Source',
        example: 'postid',
        required: false,
    })
    source?: string;

    @IsNumber()
    @IsOptional()
    @Type(() => Number)
    @ApiProperty({
        description: 'Maximum number of messages to return',
        example: 20,
        required: false,
    })
    limit?: number = 20;

    @IsString()
    @IsOptional()
    @ApiProperty({
        description: 'Platform User ID for filtering messages',
        example: '123456789',
        required: false,
    })
    platformUserId?: string;

    @IsString()
    @IsOptional()
    @ApiProperty({
        description: 'Page access token for authentication',
        required: false,
    })
    pageAccessToken?: string;

    //   @IsString()
    //   @IsOptional()
    //   @ApiProperty({
    //     description: 'Timestamp to get messages before this time',
    //     example: '1625097600000',
    //     required: false,
    //   })
    //   beforeTimestamp?: string;

    @IsString()
    @IsOptional()
    @ApiProperty({
        description: 'Timestamp to get messages after this time',
        example: '1625097600000',
        required: false,
    })
    afterTimestamp?: string;
} 