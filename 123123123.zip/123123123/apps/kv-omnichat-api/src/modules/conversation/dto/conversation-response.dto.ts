import { ApiProperty } from '@nestjs/swagger';
import { ChatPlatformEnum, IChatConversation } from '@kiotviet-facebook-services/common';

export class ConversationResponseDto implements IChatConversation {
  @ApiProperty({
    description: 'ID của retailer',
    example: 12345
  })
  retailerId: number;

  @ApiProperty({
    description: 'Platform của conversation',
    enum: ChatPlatformEnum,
    example: ChatPlatformEnum.Facebook
  })
  platform: ChatPlatformEnum;

  @ApiProperty({
    description: 'ID của channel (Page ID cho Facebook, Shop ID cho Shopee)',
    example: 'page_123456'
  })
  channelId: string;

  @ApiProperty({
    description: 'ID duy nhất của conversation',
    example: 'conv_123456789'
  })
  id: string;

  @ApiProperty({
    description: 'ID của conversation trên nền tảng gốc',
    example: 'thread_123456'
  })
  conversationId: string;

  @ApiProperty({
    description: 'Loại hội thoại: messenger, feed, hoặc chat',
    example: 'messenger',
    enum: ['messenger', 'feed', 'chat']
  })
  type: 'messenger' | 'feed' | 'chat';

  @ApiProperty({
    description: 'ID của người gửi tin nhắn',
    example: 'sender_123456'
  })
  senderId: string;

  @ApiProperty({
    description: 'Tên của người gửi tin nhắn',
    example: 'Nguyễn Văn A'
  })
  senderName: string;

  @ApiProperty({
    description: 'URL ảnh đại diện của người gửi',
    example: 'https://example.com/avatar.jpg'
  })
  senderPicture: string;

  @ApiProperty({
    description: 'Email của người gửi (nếu có)',
    example: 'sender@example.com',
    required: false
  })
  senderEmail?: string;

  @ApiProperty({
    description: 'Page-scoped ID của người gửi',
    example: 'psid_123456',
    required: false
  })
  psid?: string;

  @ApiProperty({
    description: 'ID của người gửi tin nhắn cuối cùng',
    example: 'last_sender_123456',
    required: false
  })
  lastSenderId?: string;

  @ApiProperty({
    description: 'Tên của người gửi tin nhắn cuối cùng',
    example: 'Nguyễn Văn B',
    required: false
  })
  lastSenderName?: string;

  @ApiProperty({
    description: 'Nội dung tin nhắn cuối cùng',
    example: 'Xin chào, tôi muốn hỏi về sản phẩm'
  })
  message: string;

  @ApiProperty({
    description: 'ID của tin nhắn mới nhất',
    example: 'msg_123456789'
  })
  latestMessageId: string;

  @ApiProperty({
    description: 'Loại tin nhắn mới nhất (text, image, video, v.v.)',
    example: 'text'
  })
  latestMessageType: string;

  @ApiProperty({
    description: 'ID của tin nhắn cuối cùng đã đọc',
    example: 'msg_123456',
    required: false
  })
  lastReadMessageId?: string;

  @ApiProperty({
    description: 'Tùy chọn tin nhắn cuối cùng',
    example: 1,
    required: false
  })
  lastMessageOption?: number;

  @ApiProperty({
    description: 'Thời gian ẩn tùy chọn chung tối đa',
    example: '2024-01-01T00:00:00Z',
    required: false
  })
  maxGeneralOptionHideTime?: string;

  @ApiProperty({
    description: 'Tin nhắn xác thực',
    example: 'Tin nhắn đã được xác thực',
    required: false
  })
  messageValidate?: string;

  @ApiProperty({
    description: 'Trạng thái hội thoại: 0 = chưa xem, 1 = đã xem',
    example: 0,
    enum: [0, 1]
  })
  state: 0 | 1;

  @ApiProperty({
    description: 'Trạng thái xử lý: 0 = chưa xử lý, 1 = đã xử lý',
    example: 0,
    enum: [0, 1]
  })
  resolved: 0 | 1;

  @ApiProperty({
    description: 'Số lượng tin nhắn chưa đọc',
    example: 5
  })
  unreadCount: number;

  @ApiProperty({
    description: 'Timestamp của tin nhắn cuối cùng',
    example: 1704067200000
  })
  lastMessageTimestamp: number;

  @ApiProperty({
    description: 'Thời gian cuối cùng chưa xem hội thoại',
    example: 1704067200000
  })
  lastUnreadTimestamp: number;

  @ApiProperty({
    description: 'Thời gian phân công cuối cùng',
    example: 1704067200000
  })
  lastAssigned: number;

  @ApiProperty({
    description: 'Cuộc trò chuyện có được ghim lên đầu danh sách hay không',
    example: false
  })
  pinned: boolean;

  @ApiProperty({
    description: 'Cuộc trò chuyện có bị tắt tiếng thông báo hay không',
    example: false
  })
  mute: boolean;

  @ApiProperty({
    description: 'Mảng nhân viên được phân công cho hội thoại',
    example: ['staff_1', 'staff_2'],
    type: [String]
  })
  staff: string[];

  @ApiProperty({
    description: 'Hội thoại có số điện thoại không',
    example: true
  })
  hasPhone: boolean;

  @ApiProperty({
    description: 'Hội thoại có email không',
    example: false
  })
  hasEmail: boolean;

  @ApiProperty({
    description: 'ID hội thoại messenger của Facebook',
    example: 'thread_123456',
    required: false
  })
  threadId?: string;

  @ApiProperty({
    description: 'ID bài đăng (nếu type là feed)',
    example: 'post_123456',
    required: false
  })
  postId?: string;

  @ApiProperty({
    description: 'Comment trong livestream không',
    example: false,
    required: false
  })
  commentFromLiveVideo?: boolean;

  @ApiProperty({
    description: 'Cú pháp livestream',
    example: 'FORMULA_123',
    required: false
  })
  formulaLiveStream?: string;

  @ApiProperty({
    description: 'Hội thoại có comment đúng cú pháp không',
    example: true,
    required: false
  })
  isValidateFormula?: boolean;

  @ApiProperty({
    description: 'Nguồn dữ liệu',
    example: 'GraphApi',
    required: false
  })
  source?: 'GraphApi';

  @ApiProperty({
    description: 'Phiên bản',
    example: 1,
    required: false
  })
  version?: number;

  @ApiProperty({
    description: 'Ngày tạo cuộc trò chuyện',
    example: '2024-01-01T00:00:00Z',
    required: false
  })
  createdDate?: Date;

  @ApiProperty({
    description: 'Ngày chỉnh sửa cuộc trò chuyện lần cuối',
    example: '2024-01-01T00:00:00Z',
    required: false
  })
  modifiedDate?: Date | null;

  @ApiProperty({
    description: 'Dữ liệu thô từ nền tảng gốc',
    example: {},
    required: false
  })
  rawData?: any;
} 