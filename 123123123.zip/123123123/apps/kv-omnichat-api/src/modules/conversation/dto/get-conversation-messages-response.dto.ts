import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ChatMessageSourceEnum, ChatMessageStateEnum, ChatMessageTypeEnum, ChatPlatformEnum, IChatMessage, IMessageAttachment } from '@kiotviet-facebook-services/common';
import { Type } from 'class-transformer';
import { IsEnum } from 'class-validator';

class MessageAttachmentDto implements IMessageAttachment {
  @ApiProperty({
    description: 'Attachment type',
    example: ChatMessageTypeEnum.IMAGE,
    enum: ChatMessageTypeEnum
  })
  @IsEnum(ChatMessageTypeEnum)
  type: ChatMessageTypeEnum;

  @ApiProperty({
    description: 'Attachment URL',
    example: 'https://example.com/image.jpg',
  })
  url: string;

  @ApiPropertyOptional({
    description: 'Attachment thumbnail URL',
    example: 'https://example.com/image-thumbnail.jpg',
  })
  thumbnailUrl?: string;

  @ApiPropertyOptional({
    description: 'Attachment payload'
  })
  payload: any;

}

class MessageParticipantDto {
  @ApiProperty({
    description: 'ID of the participant',
    example: '123456789',
  })
  id: string;
}
export class MessageDto implements IChatMessage {
  @ApiProperty({
    description: 'Unique ID for the message',
    example: '60f7b8a8c8e8f80012345678',
  })
  id: string;

  @ApiProperty({
    description: 'Platform message ID',
    example: 'm_123456789012345',
  })
  messageId: string;

  @ApiProperty({
    description: 'Conversation ID',
    example: '60f7b8a8c8e8f80012345679',
  })
  conversationId: string;

  @ApiProperty({
    description: 'Platform type',
    example: ChatPlatformEnum.Facebook,
    enum: ChatPlatformEnum
  })
  @IsEnum(ChatPlatformEnum)
  platform: ChatPlatformEnum; // ChatPlatformEnum

  @ApiProperty({
    description: 'Message type',
    example: 'text',
    enum: ChatMessageTypeEnum
  })
  @IsEnum(ChatMessageTypeEnum)
  type: ChatMessageTypeEnum; // MessageType

  @ApiProperty({
    description: 'Message content',
    example: 'Hello, how can I help you?',
  })
  content: string;

  @ApiProperty({
    description: 'Message timestamp',
    example: 1625097600000,
  })
  timestamp: number;

  @ApiProperty({
    description: 'Message sender information',
    example: {
      id: '123456789',
    },
  })
  sender: MessageParticipantDto; // IMessageParticipant

  @ApiProperty({
    description: 'Message recipient information',
    example: {
      id: '987654321',
      name: 'Store Page',
      avatar: 'https://example.com/avatar-page.jpg',
      type: 'page'
    },
  })
  recipient: MessageParticipantDto; // IMessageParticipant

  @ApiProperty({
    description: 'Message state',
    example: ChatMessageStateEnum.SENT,
    enum: ChatMessageStateEnum
  })
  state: ChatMessageStateEnum; // MessageState

  @ApiProperty({
    description: 'Message source',
    example: ChatMessageSourceEnum.CUSTOMER,
    enum: ChatMessageSourceEnum
  })
  @IsEnum(ChatMessageSourceEnum)
  source: ChatMessageSourceEnum; // MessageSource

  @ApiProperty({
    description: 'Message attachments',
    type: [MessageAttachmentDto],
    required: false,
  })
  attachments?: MessageAttachmentDto[]; // IMessageAttachment[]

  @ApiProperty({
    description: 'Quoted message (if this is a reply)',
    required: false,
  })
  quotedMessage?: any; // IQuotedMessage

  @ApiProperty({
    description: 'Product information',
    required: false,
  })
  productInfo?: any[]; // IProductInfo[]

  @ApiProperty({
    description: 'Order information',
    required: false,
  })
  orderInfo?: any; // IOrderInfo

  @ApiProperty({
    description: 'Template message',
    required: false,
  })
  templateMessage?: any; // ITemplateMessage

  @ApiProperty({
    description: 'Message metadata',
    example: {
      isAutoReply: false
    },
  })
  metadata: {
    isAutoReply?: boolean;
    reactionType?: string;
    customFields?: Record<string, any>;
  };

  @ApiProperty({
    description: 'Retailer ID',
    example: 12345,
  })
  retailerId: number;

  @ApiProperty({
    description: 'Channel ID',
    example: '101077151865360',
  })
  channelId: string;

  @ApiProperty({
    description: 'Created date',
    example: '2021-07-01T00:00:00.000Z',
  })
  createdDate: Date;

  @ApiProperty({
    description: 'Modified date',
    example: '2021-07-01T00:00:00.000Z',
    required: false,
  })
  modifiedDate?: Date | null;

  @ApiProperty({
    description: 'Raw data from platform',
    required: false,
  })
  rawData?: any;
}

export class GetConversationMessagesResponseDto {
  @ApiProperty({
    description: 'List of messages in the conversation',
    type: [MessageDto],
  })
  @Type(() => MessageDto)
  items: MessageDto[];

  @ApiProperty({
    description: 'Whether there are more messages to load',
    example: true,
  })
  more: boolean;
} 