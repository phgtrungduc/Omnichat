import { ApiProperty } from "@nestjs/swagger";
import { Type } from "class-transformer";
import { IsArray, IsBoolean, IsEnum, IsNotEmpty, IsNumber, IsOptional, IsString } from "class-validator";
import { ChatConversationType, ConversationStateFilterEnum } from "../../../common/enums/chat-search-type.enum";
import { ConversationSortEnum } from "../../../common/enums/conversation-sort.enum";
import { IConversationFilters,   IConversationSearchByMessageFilters, IConversationSearchByAccountFilters } from "../../../interfaces/conversation.interface";
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { PageStaff } from '@kiotviet-facebook-services/fbpos-master-repository';
import { IChannelPagination, IPlatformChannel } from '../../../common/interfaces/platform-channel.interface';

export class ConversationSearchDto implements IConversationFilters {


    @IsOptional()
    @IsEnum(ConversationSortEnum)
    @ApiProperty({
        description: 'Sort by field - unified for all platforms',
        example: ConversationSortEnum.Newest,
        enum: ConversationSortEnum,
        required: false
    })
    sortBy?: ConversationSortEnum;

    @IsOptional()
    @IsArray()
    @ApiProperty({
        description: 'Channels to filter by - includes platform and channelId',
        example: [
            {
                platform: ChatPlatformEnum.Facebook,
                channelDetails: [
                    {
                        channelId: '101077151865360',
                        beforeTimestamp: 1717000000,
                        afterTimestamp: 1717000000
                    }
                ]
            },
            {
                platform: ChatPlatformEnum.Shopee,
                channelDetails: [
                    {
                        channelId: '12345',
                        beforeTimestamp: 1717000000
                    }
                ]
            }
        ],
        required: false
    })
    channels: Array<IChannelPagination>;

    @IsOptional()
    @IsString()
    @ApiProperty({
        description: 'Keyword for searching conversations',
        example: 'hello',
        required: false
    })
    keyword?: string;

    @IsOptional()
    @Type(() => Number)
    @IsNumber()
    @ApiProperty({
        description: 'Limit number of results',
        example: 30,
        default: 30,
        required: false
    })
    limit?: number;

    @IsOptional()
    @Type(() => Number)
    @IsNumber()
    @ApiProperty({
        description: 'Conversation state',
        example: ConversationStateFilterEnum.Unread,
        enum: ConversationStateFilterEnum,
        required: false
    })
    state?: ConversationStateFilterEnum;


    @IsOptional()
    @IsNumber()
    @ApiProperty({
        description: 'From date (timestamp)',
        example: 1717000000,
        required: false
    })
    from?: number;

    @IsOptional()
    @IsNumber()
    @ApiProperty({
        description: 'To date (timestamp)',
        example: 1717000000,
        required: false
    })
    to?: number;


    //Hiện chỉ đáp ứng cho facebook
    @IsOptional()
    @IsEnum(ChatConversationType)
    @ApiProperty({
        description: 'Conversation type',
        example: ChatConversationType.MESSENGER,
        enum: ChatConversationType,
        required: false
    })
    conversationType?: ChatConversationType;

    @IsOptional()
    @IsBoolean()
    @ApiProperty({
        description: 'Has phone number',
        example: true,
        required: false
    })
    hasPhone?: boolean;

    @IsOptional()
    @IsBoolean()
    @ApiProperty({
        description: 'Include conversations with no tags (customer and conversation tags)',
        example: true,
        required: false
    })
    includeNoTags?: boolean;

    @IsOptional()
    @IsArray()
    @IsString({ each: true })
    @ApiProperty({
        description: 'Tags to filter by (tagId)',
        example: ['tag1', 'tag2'],
        required: false
    })
    tags?: string[];

    @IsOptional()
    @IsArray()
    @IsString({ each: true })
    @ApiProperty({
        description: 'Customer tags to filter by (customerTagId)',
        example: ['customerTag1', 'customerTag2'],
        required: false
    })
    customerTags?: string[];

    @IsOptional()
    @IsArray()
    @IsString({ each: true })
    @ApiProperty({
        description: 'Source to filter by (postId)',
        example: ['1234567890', '1234567891'],
        required: false
    })
    source?: string[];



    @IsOptional()
    @IsArray()
    @ApiProperty({
        description: 'Filter by staff IDs',
        example: [
            {
                _id: 'staff_id_1',
                name: 'Staff 1',
                email: 'staff1@example.com'
            },
        ],
        type: [PageStaff],
        required: false
    })
    staff?: PageStaff[];



    @IsOptional()
    @Type(() => Number)
    @IsNumber()
    @ApiProperty({
        description: 'Filter by correct syntax (only for facebook, still not implement)',
        example: 0,
        default: 0,
        required: false
    })
    correctSyntax?: number;

    @IsOptional()
    @IsBoolean()
    @ApiProperty({
        description: 'Is role admin',
        example: true,
        required: false
    })
    isRoleAdmin?: boolean;

    @IsOptional()
    @IsBoolean()
    @ApiProperty({
        description: 'Filter for unassigned conversations',
        example: false,
        required: false
    })
    unassigned?: boolean;

    @IsOptional()
    @IsString()
    @ApiProperty({
        description: 'Current user ID for staff filtering',
        example: 'user123',
        required: false
    })
    appUserId?: string;

    @IsOptional()
    @IsNumber()
    @ApiProperty({
        description: 'Last timestamp for filtering conversations',
        example: 1717000000,
        required: false
    })
    lastTimestamp?: number;

    

    @IsOptional()
    @IsNumber()
    @ApiProperty({
        description: 'Retailer ID',
        example: 1,
        required: false
    })
    retailerId?: number;

} 

export class ConversationSearchByAccountDto implements IConversationSearchByAccountFilters {
    @IsNotEmpty()
    @IsString()
    @ApiProperty({
        description: 'Keyword for searching conversations',
        example: 'hello',
        required: true
    })
    keyword: string;

    @IsNotEmpty()
    @IsArray()
    @ApiProperty({
        description: 'Channels to filter by - includes platform and channelId',
        example: [
            {
                platform: ChatPlatformEnum.Facebook,
                channelId: ['101077151865360']
            },
            {
                platform: ChatPlatformEnum.Shopee,
                channelId: ['12345']
            }
        ],
        required: true
    })
    channels: Array<IPlatformChannel>;

    @IsOptional()
    @Type(() => Number)
    @IsNumber()
    @ApiProperty({
        description: 'Limit number of results',
        example: 30,
        default: 30,
        required: false
    })
    limit?: number;
}

export class ConversationSearchByMessageDto implements IConversationSearchByMessageFilters {
    @IsNotEmpty()
    @IsString()
    @ApiProperty({
        description: 'Keyword for searching messages',
        example: 'hello',
        required: true
    })
    keyword: string;

    @IsNotEmpty()
    @IsArray()
    @ApiProperty({
        description: 'Channels to filter by - includes platform and channelId',
        example: [
            {
                platform: ChatPlatformEnum.Facebook,
                channelId: ['101077151865360']
            },
            {
                platform: ChatPlatformEnum.Shopee,
                channelId: ['12345']
            }
        ],
        required: true
    })
    channels: Array<IPlatformChannel>;

    @IsOptional()
    @Type(() => Number)
    @IsNumber()
    @ApiProperty({
        description: 'Limit number of results',
        example: 30,
        default: 30,
        required: false
    })
    limit?: number;
}