import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNotEmpty, IsString, IsOptional, IsNumber, IsBoolean } from 'class-validator';
import { ChatPlatformEnum, IChatStaff } from '@kiotviet-facebook-services/common';
import { IPlatformChannel } from '../../../common/interfaces/platform-channel.interface';
import { StaffConversationTypeEnum } from '../../../common/enums/staff.enum';

export class StaffSearchDto {
  @IsNotEmpty()
  @IsArray()
  @ApiProperty({
    description: 'Channels to filter by - includes platform and channelId',
    example: [
      {
        platform: ChatPlatformEnum.Facebook,
        channelId: ['101077151865360', '101077151865361']
      },
      {
        platform: ChatPlatformEnum.Shopee,
        channelId: ['12345', '12346']
      }
    ],
    required: true
  })
  channels: Array<IPlatformChannel>;
}

export class StaffDisableDto {
  @ApiProperty({
    description: 'Channel ID',
    example: '109533272097318'
  })
  @IsNotEmpty()
  @IsString()
  channelId: string;

  @ApiProperty({
    description: 'Staff ID',
    example: 'staff_122122752560699614'
  })
  @IsNotEmpty()
  @IsString()
  staffId: string;

  @ApiProperty({
    description: 'Whether to remove assigned staff from conversations',
    example: false
  })
  @IsOptional()
  @IsBoolean()
  removeAssignedStaff?: boolean;

  @ApiProperty({
    description: 'Retailer ID',
    example: 12799
  })
  @IsNotEmpty()
  @IsNumber()
  retailerId: number;
}

export class StaffAssignDto {
  @ApiProperty({
    description: 'Platform type',
    enum: ChatPlatformEnum,
    example: ChatPlatformEnum.Facebook
  })
  @IsNotEmpty()
  platform: ChatPlatformEnum;

  @ApiProperty({
    description: 'Channel ID (Page ID for Facebook, Shop ID for Shopee)',
    example: '101077151865360'
  })
  @IsNotEmpty()
  @IsString()
  channelId: string;

  @ApiProperty({
    description: 'Staff information',
    example: {
      Id: 'staff-123',
      Name: 'John Doe',
      Picture: 'https://example.com/avatar.jpg',
      AppUserId: 'app-user-123'
    }
  })
  @IsNotEmpty()
  staff: {
    Id: string;
    Name: string;
    Picture?: string;
    AppUserId?: string;
  };

  @ApiProperty({
    description: 'Conversation ID to assign staff to',
    example: 'conv-123'
  })
  @IsNotEmpty()
  @IsString()
  conversationId: string;

  @ApiProperty({
    description: 'Last assigned staff (optional)',
    required: false,
    example: {
      id: 'staff-456',
      name: 'Jane Smith'
    }
  })
  @IsOptional()
  lastAssignStaff?: {
    id: string;
    name: string;
  };

  @ApiProperty({
    description: 'Type of conversation (1: Message, 2: Comment)',
    example: StaffConversationTypeEnum.Message
  })
  @IsOptional()
  @IsNumber()
  type?: StaffConversationTypeEnum;

  @ApiProperty({
    description: 'Conversation customer name',
    example: 'Customer Name'
  })
  @IsOptional()
  @IsString()
  conversationCustomerName?: string;

  @ApiProperty({
    description: 'Conversation message',
    example: 'Hello, I need help'
  })
  @IsOptional()
  @IsString()
  conversationMessage?: string;

  @ApiProperty({
    description: 'Facebook staff name',
    example: 'FB Staff Name'
  })
  @IsOptional()
  @IsString()
  fbStaffName?: string;

  @ApiProperty({
    description: 'Assignment turn (optional)',
    example: 1,
    required: false
  })
  @IsOptional()
  @IsNumber()
  assignmentTurn?: number;
}

export class StaffResponseDto implements Omit<IChatStaff, 'channelId'> {
  @ApiProperty({
    description: 'Staff ID',
    example: 'staff-123'
  })
  staffId: string;

  @ApiProperty({
    description: 'Staff name',
    example: 'John Doe'
  })
  name: string;

  @ApiProperty({
    description: 'Staff picture URL',
    example: 'https://example.com/avatar.jpg'
  })
  picture: string;

  @ApiProperty({
    description: 'App user ID',
    example: 'app-user-123'
  })
  appUserId: string;

  @ApiProperty({
    description: 'Staff state',
    example: 1
  })
  state: number;

  @ApiProperty({
    description: 'Last assigned timestamp',
    example: 1640995200000
  })
  lastAssigned: number;

  @ApiProperty({
    description: 'Assignment turn',
    example: 1
  })
  assignmentTurn: number;

  @ApiProperty({
    description: 'Socket IDs',
    example: ['socket-1', 'socket-2'],
    type: [String]
  })
  socketIds: string[];

  @ApiProperty({
    description: 'Timestamp',
    example: 1640995200000
  })
  timestamp: number;

  @ApiProperty({
    description: 'Staff is role admin',
    example: false
  })
  isRoleAdmin: boolean;

  @ApiProperty({
    description: 'Platform type',
    enum: ChatPlatformEnum,
    example: ChatPlatformEnum.Facebook
  })
  platform: ChatPlatformEnum;

  @ApiProperty({
    description: 'Retailer ID',
    example: 1
  })
  retailerId: number;

  @ApiProperty({
    description: 'Staff channel IDs',
    example: ['channel-123', 'channel-124'],
    type: [String]
  })
  channelId: string[];

  @ApiProperty({
    description: 'Staff ID (alias for staffId)',
    example: 'staff-123'
  })
  _id: string;
}

export class StaffBulkAssignDto {
  @ApiProperty({
    description: 'Channels',
    example: [
      {
        platform: ChatPlatformEnum.Facebook,
        channelId: ['101077151865360', '101077151865361']
      },
    ]
  })
  @IsNotEmpty()
  @IsArray()
  channels: IPlatformChannel[];

  @ApiProperty({
    description: 'Staff ID',
    example: 'staff_122112497660768457'
  })
  @IsNotEmpty()
  @IsString()
  staffId: string;

  @ApiProperty({
    description: 'Conversations to assign staff to',
    example: [
      {
        id: '8578658388853283',
        channelId: '252083544658502'
      },
      {
        id: '5274960905940736',
        channelId: '109533272097318'
      }
    ],
    type: [Object]
  })
  @IsNotEmpty()
  @IsArray()
  conversations: Array<{
    id: string;
    channelId: string;
  }>;
}

export class StaffBulkUnassignDto {
  @ApiProperty({
    description: 'Channels',
    example: [
      {
        platform: ChatPlatformEnum.Facebook,
        channelId: ['101077151865360', '101077151865361']
      },
    ]
  })
  @IsNotEmpty()
  @IsArray()
  channels: IPlatformChannel[];

  @ApiProperty({
    description: 'Staff ID',
    example: 'staff_122112497660768457'
  })
  @IsNotEmpty()
  staffId: string;

  @ApiProperty({
    description: 'Conversations to unassign staff from',
    example: [
      {
        id: '8578658388853283',
        channelId: '252083544658502'
      },
      {
        id: '5274960905940736',
        channelId: '109533272097318'
      }
    ],
    type: [Object]
  })
  @IsNotEmpty()
  @IsArray()
  conversations: Array<{
    id: string;
    channelId: string;
    platform: ChatPlatformEnum;
  }>;
}

export class StaffByChannelsDto {
  @ApiProperty({
    description: 'Channels to get staff from',
    example: [
      {
        platform: ChatPlatformEnum.Facebook,
        channelId: ['101077151865360', '101077151865361']
      },
      {
        platform: ChatPlatformEnum.Instagram,
        channelId: ['17841411323433721', '17841459730429893']
      }
    ],
    required: true
  })
  @IsNotEmpty()
  @IsArray()
  channels: Array<IPlatformChannel>;
} 