import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { StaffController } from './controllers/staff.controller';
import { StaffFacade } from '../../facade/staff.facade';
import { StaffService } from '../../services/staff.service';
import { CompositeStaffStrategy } from '../../composite/composite-staff.strategy';
import { FacebookStaffStrategy } from '../../strategies/facebook/facebook-staff.strategy';
import { ShopeeStaffStrategy } from '../../strategies/shopee/shopee-staff.strategy';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { OmnimongoRepositoryModule } from '@kiotviet-facebook-services/omnimongo-repository';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { CommonServicesModule } from '../../common/common-services.module';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';

@Module({
  imports: [
    CommonModule,
    CommonServicesModule,
    FbPosMasterRepositoryModule,
    OmnimongoRepositoryModule,
    KvRabbitMQModule,
    ConfigModule
  ],
  controllers: [StaffController],
  providers: [
    // Facade
    StaffFacade,
    
    // Composite Strategy
    CompositeStaffStrategy,
    
    // Individual Strategies
    FacebookStaffStrategy,
    ShopeeStaffStrategy,
    
    // Services
    StaffService
  ],
  exports: [StaffFacade]
})
export class StaffModule {} 