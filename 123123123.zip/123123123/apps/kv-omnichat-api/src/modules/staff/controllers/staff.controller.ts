import { Controller, Post, Body, Req } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiQuery } from '@nestjs/swagger';
import { StaffSearchDto, StaffResponseDto, StaffAssignDto, StaffDisableDto, StaffBulkAssignDto, StaffBulkUnassignDto, StaffByChannelsDto } from '../dto/staff.dto';
import { StaffFacade } from '../../../facade/staff.facade';
import { Request } from 'express';
import { ChatError } from '@kiotviet-facebook-services/common';

@ApiTags('Staff')
@Controller('staff')
export class StaffController {
  constructor(
    private readonly staffFacade: StaffFacade
  ) {}

  @Post('list')
  @ApiOperation({
    summary: 'Get staff list',
    description: 'Get staff list by page IDs'
  })
  @ApiQuery({
    name: 'pageId',
    description: 'Page IDs separated by comma',
    example: 'page1,page2,page3'
  })
  @ApiResponse({
    status: 200,
    description: 'Staff list retrieved successfully',
    type: [StaffResponseDto]
  })
  async getStaffList(@Body() query: StaffSearchDto): Promise<any[]> {
    // Use facade to get staff list
    return await this.staffFacade.getStaffList(query.channels);
  }

  @Post('by-channels')
  @ApiOperation({
    summary: 'Get staff by channels',
    description: 'Get staff list for specific channels across different platforms'
  })
  @ApiResponse({
    status: 200,
    description: 'Staff list retrieved successfully',
    type: [StaffResponseDto]
  })
  async getStaffByChannels(@Body() query: StaffByChannelsDto): Promise<any[]> {
    // Use facade to get staff by channels
    return await this.staffFacade.getStaffByChannels(query.channels);
  }

  @Post('assign')
  @ApiOperation({
    summary: 'Assign staff to conversation',
    description: 'Assign a staff member to a specific conversation'
  })
  @ApiResponse({
    status: 200,
    description: 'Staff assigned successfully',
    schema: {
      type: 'object',
      properties: {
        success: { type: 'boolean', example: true },
        message: { type: 'string', example: 'Staff assigned successfully' }
      }
    }
  })
  @ApiResponse({
    status: 400,
    description: 'Bad request - invalid data provided'
  })
  async assignStaff(@Body() assignData: StaffAssignDto, @Req() request: Request): Promise<{ success: boolean; message: string }> {
    try {
      // Truyền assignData và request xuống facade, logic tạo task sẽ được xử lý trong strategy
      const result = await this.staffFacade.assignStaff(assignData, request);
      
      if (result) {
        return {
          success: true,
          message: 'Staff assigned successfully'
        };
      } else {
        return {
          success: false,
          message: 'Failed to assign staff'
        };
      }
    } catch (error) {
      throw new ChatError('STAFF_ASSIGNMENT_ERROR').withAdditional({ 
        stack: error.stack,
        originalError: error.message 
      });
    }
  }

  @Post('unassign')
  @ApiOperation({
    summary: 'Unassign staff from conversation',
    description: 'Unassign a staff member from a specific conversation'
  })
  @ApiResponse({
    status: 200,
    description: 'Staff unassigned successfully',
    schema: {
      type: 'object',
      properties: {
        success: { type: 'boolean', example: true },
        message: { type: 'string', example: 'Staff unassigned successfully' }
      }
    }
  })
  @ApiResponse({
    status: 400,
    description: 'Bad request - invalid data provided'
  })
  async unassignStaff(@Body() assignData: StaffAssignDto, @Req() request: Request): Promise<{ success: boolean; message: string }> {
    try {
      // Truyền assignData và request xuống facade, logic tạo task sẽ được xử lý trong strategy
      const result = await this.staffFacade.unassignStaff(assignData, request);
      
      if (result) {
        return {
          success: true,
          message: 'Staff unassigned successfully'
        };
      } else {
        return {
          success: false,
          message: 'Failed to unassign staff'
        };
      }
    } catch (error) {
      console.error('Error unassigning staff:', error);
      return {
        success: false,
        message: 'Internal server error while unassigning staff'
      };
    }
  }

  @Post('disable')
  @ApiOperation({
    summary: 'Disable staff',
    description: 'Disable a staff member'
  })
  @ApiResponse({
    status: 200,
    description: 'Staff disabled successfully',
    schema: {
      type: 'object',
      properties: {
        success: { type: 'boolean', example: true },
        message: { type: 'string', example: 'Staff disabled successfully' }
      }
    }
  })
  @ApiResponse({
    status: 400,
    description: 'Bad request - invalid data provided'
  })
  async disableStaff(@Body() disableData: StaffDisableDto, @Req() request: Request): Promise<{ success: boolean; message: string }> {
    try {
      // Truyền disableData và request xuống facade, logic tạo task sẽ được xử lý trong strategy
      const result = await this.staffFacade.disableStaff(disableData, request);
      
      if (result) {
        return {
          success: true,
          message: 'Staff disabled successfully'
        };
      } else {
        return {
          success: false,
          message: 'Failed to disable staff'
        };
      }
    } catch (error) {
      console.error('Error disabling staff:', error);
      return {
        success: false,
        message: 'Internal server error while disabling staff'
      };
    }
  }

  @Post('bulk-assign')
  @ApiOperation({
    summary: 'Bulk assign staff to conversations',
    description: 'Assign a staff member to multiple conversations across different channels'
  })
  @ApiResponse({
    status: 200,
    description: 'Staff bulk assigned successfully',
    schema: {
      type: 'object',
      properties: {
        success: { type: 'boolean', example: true },
        message: { type: 'string', example: 'Staff bulk assigned successfully' }
      }
    }
  })
  @ApiResponse({
    status: 400,
    description: 'Bad request - invalid data provided'
  })
  async bulkAssignStaff(@Body() bulkAssignData: StaffBulkAssignDto, @Req() request: Request): Promise<{ success: boolean; message: string }> {
    try {
      const result = await this.staffFacade.bulkAssignStaff(bulkAssignData, request);
      
      if (result) {
        return {
          success: true,
          message: 'Staff bulk assigned successfully'
        };
      } else {
        return {
          success: false,
          message: 'Failed to bulk assign staff'
        };
      }
    } catch (error) {
      console.error('Error bulk assigning staff:', error);
      return {
        success: false,
        message: 'Internal server error while bulk assigning staff'
      };
    }
  }

  @Post('bulk-unassign')
  @ApiOperation({
    summary: 'Bulk unassign staff from conversations',
    description: 'Unassign a staff member from multiple conversations across different channels'
  })
  @ApiResponse({
    status: 200,
    description: 'Staff bulk unassigned successfully',
    schema: {
      type: 'object',
      properties: {
        success: { type: 'boolean', example: true },
        message: { type: 'string', example: 'Staff bulk unassigned successfully' }
      }
    }
  })
  @ApiResponse({
    status: 400,
    description: 'Bad request - invalid data provided'
  })
  async bulkUnassignStaff(@Body() bulkUnassignData: StaffBulkUnassignDto, @Req() request: Request): Promise<{ success: boolean; message: string }> {
    try {
      const result = await this.staffFacade.bulkUnassignStaff(bulkUnassignData, request);
      
      if (result) {
        return {
          success: true,
          message: 'Staff bulk unassigned successfully'
        };
      } else {
        return {
          success: false,
          message: 'Failed to bulk unassign staff'
        };
      }
    } catch (error) {
      console.error('Error bulk unassigning staff:', error);
      return {
        success: false,
        message: 'Internal server error while bulk unassigning staff'
      };
    }
  }
} 