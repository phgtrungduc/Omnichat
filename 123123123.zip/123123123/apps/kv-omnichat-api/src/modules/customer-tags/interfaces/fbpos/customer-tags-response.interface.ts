/**
 * Interface cho FBPOS Customer Tags response
 * Response từ API: /customer-tag/find
 */
export interface IFbposCustomerTagItem {
  _id: string;
  SenderId: string;
  Type: string;
  CustomerTagId: string | null;
  created_time: number;
}

export interface IFbposCustomerTagsResponse {
  data: Record<string, IFbposCustomerTagItem>;
} 