export * from './customer-tags-request.interface';
export * from './customer-tags-response.interface'; 