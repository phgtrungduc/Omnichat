/**
 * Interface cho Omnichannel Customer Tags response
 * Placeholder cho tương lai
 */
export interface IOmnichannelCustomerTagsResponse {
  success: boolean;
  data: IOmnichannelCustomerTagItem[];
  message?: string;
}

export interface IOmnichannelCustomerTagItem {
  id: string;
  channelId: string;
  senderId: string;
  customerTagId: string | null;
  tagType: string;
  createdTime: number;
} 