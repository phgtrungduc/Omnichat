/**
 * Interface cho Omnichannel Customer Tags request
 * Placeholder cho tương lai
 */
export interface IOmnichannelCustomerTagsRequest {
  channelId: string;
  platform: string;
  filter?: {
    senderIds?: string[];
  };
} 