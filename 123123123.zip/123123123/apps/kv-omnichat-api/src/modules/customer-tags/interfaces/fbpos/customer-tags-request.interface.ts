/**
 * Interface cho FBPOS Customer Tags request
 * Mapping từ API: /customer-tag/find
 */
export interface IFbposCustomerTagsRequest {
  pageid: string;
  filter: Record<string, {
    SenderId: string[];
  }>;
} 