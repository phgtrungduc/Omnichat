import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { ColorConstants } from './color.constants';
import { CustomerTagTemplateDto } from '../dto/customer-tag-template.dto';

/**
 * Default customer tags templates for platforms
 */
export class CustomerTagTemplatesConstants {
  
  /**
   * Facebook customer tags templates
   */
  public static readonly FACEBOOK_TEMPLATES: CustomerTagTemplateDto[] = [
    {
      id: null,
      title: 'Chọn cảnh báo',
      color: ColorConstants.LAVENDER,
      colorText: ColorConstants.NIGHT_RIDER,
      platform: ChatPlatformEnum.Facebook,
      description: 'Remove tag assignment for customer',
      isDefault: true,
      sortOrder: 0
    },
    {
      id: 'defaultcustomertag_bomhang',
      title: 'Bom hàng',
      color: ColorConstants.RED_ORANGE,
      colorText: ColorConstants.WHITE,
      platform: ChatPlatformEnum.Facebook,
      description: 'Customer who frequently cancels orders',
      isDefault: true,
      sortOrder: 1
    },
    {
      id: 'defaultcustomertag_canhbao',
      title: 'Cần chú ý',
      color: ColorConstants.CARROT_ORANGE,
      colorText: ColorConstants.WHITE,
      platform: ChatPlatformEnum.Facebook,
      description: 'Customer who requires special attention',
      isDefault: true,
      sortOrder: 2
    },
    {
      id: 'defaultcustomertag_khongnghemay',
      title: 'Không nghe máy',
      color: ColorConstants.MEDIUM_RED_VIOLET,
      colorText: ColorConstants.WHITE,
      platform: ChatPlatformEnum.Facebook,
      description: 'Customer who does not answer phone calls',
      isDefault: true,
      sortOrder: 3
    }
  ];

  /**
   * Shopee customer tags templates (placeholder for future)
   */
  public static readonly SHOPEE_TEMPLATES: CustomerTagTemplateDto[] = [
    {
      id: null,
      title: 'Chọn nhãn',
      color: ColorConstants.LAVENDER,
      colorText: ColorConstants.NIGHT_RIDER,
      platform: ChatPlatformEnum.Shopee,
      description: 'Remove tag assignment for customer',
      isDefault: true,
      sortOrder: 0
    }
    // TODO: Add more templates for Shopee when required
  ];

  /**
   * Get templates by platform
   */
  public static getTemplatesByPlatform(platform: ChatPlatformEnum): CustomerTagTemplateDto[] {
    switch (platform) {
      case ChatPlatformEnum.Facebook:
      case ChatPlatformEnum.Instagram:
        return this.FACEBOOK_TEMPLATES;
      case ChatPlatformEnum.Shopee:
        return this.SHOPEE_TEMPLATES;
      default:
        return [];
    }
  }

  /**
   * Get all templates
   */
  public static getAllTemplates(): CustomerTagTemplateDto[] {
    return [
      ...this.FACEBOOK_TEMPLATES,
      ...this.SHOPEE_TEMPLATES
    ];
  }
} 