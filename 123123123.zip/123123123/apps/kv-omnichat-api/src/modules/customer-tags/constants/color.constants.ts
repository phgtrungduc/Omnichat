/**
 * Constants for customer tags colors
 */
export class ColorConstants {
  public static readonly LAVENDER = '#efefef';
  public static readonly NIGHT_RIDER = '#333333';
  public static readonly RED_ORANGE = '#f33636';
  public static readonly CARROT_ORANGE = '#f3991b';
  public static readonly MEDIUM_RED_VIOLET = '#bc35a4';
  public static readonly WHITE = '#ffffff';
} 