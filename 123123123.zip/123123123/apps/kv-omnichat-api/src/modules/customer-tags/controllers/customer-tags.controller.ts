import { Auth } from '@kiotviet-facebook-services/kv-auth';
import { Controller, Post, Body, Req, HttpException, HttpStatus } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Request } from 'express';
import {
  GetCustomerTagsRequestDto,
  GetCustomerTagsResponseDto,
  GetCustomerTagTemplatesRequestDto,
  GetCustomerTagTemplatesResponseDto
} from '../dto';
import { CustomerTagsService } from '../services';

@ApiTags('Customer Tags')
@Controller('customer-tags')
@ApiBearerAuth()
@Auth()
export class CustomerTagsController {
  constructor(private readonly customerTagsService: CustomerTagsService) {}

  @Post('/mapping')
  @ApiOperation({ 
    summary: 'Get customer tags mapping',
    description: 'API to get customer tags mapping from multiple channels and platforms (Facebook, Shopee, etc.). Returns mapping between SenderId and CustomerTagId for specified channels. Supports multiple channels in a single request with filtering by SenderId.'
  })
  @ApiResponse({ 
    status: 200, 
    description: 'Customer tags mapping returned successfully',
    type: GetCustomerTagsResponseDto
  })
  @ApiResponse({ 
    status: 400, 
    description: 'Bad request - Invalid input parameters' 
  })
  @ApiResponse({ 
    status: 500, 
    description: 'Internal server error' 
  })
  async getCustomerTagsMapping(
    @Req() req: Request, 
    @Body() body: GetCustomerTagsRequestDto
  ): Promise<GetCustomerTagsResponseDto> {
    try {
      const result = await this.customerTagsService.getCustomerTagsMapping(req, body);
      
      if (!result.success) {
        throw new HttpException(result.message, HttpStatus.BAD_REQUEST);
      }
      
      return result;
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }
      throw new HttpException(
        error.message || 'Error getting customer tags mapping', 
        HttpStatus.INTERNAL_SERVER_ERROR
      );
    }
  }

  @Post('/templates')
  @ApiOperation({ 
    summary: 'Get customer tag templates',
    description: 'API to get available customer tag templates from multiple platforms (Facebook, Shopee, etc.). Returns predefined tag templates that can be used to assign tags to customers. Each platform may have different sets of templates.'
  })
  @ApiResponse({ 
    status: 200, 
    description: 'Customer tag templates returned successfully',
    type: GetCustomerTagTemplatesResponseDto
  })
  @ApiResponse({ 
    status: 400, 
    description: 'Bad request - Invalid input parameters' 
  })
  @ApiResponse({ 
    status: 500, 
    description: 'Internal server error' 
  })
  async getCustomerTagTemplates(
    @Req() req: Request, 
    @Body() body: GetCustomerTagTemplatesRequestDto
  ): Promise<GetCustomerTagTemplatesResponseDto> {
    try {
      const result = await this.customerTagsService.getCustomerTagTemplates(req, body);
      
      if (!result.success) {
        throw new HttpException(result.message, HttpStatus.BAD_REQUEST);
      }
      
      return result;
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }
      throw new HttpException(
        error.message || 'Error getting customer tag templates', 
        HttpStatus.INTERNAL_SERVER_ERROR
      );
    }
  }
} 