import { Module } from '@nestjs/common';
import { CustomerTagsController } from './controllers';
import { CustomerTagsService } from './services';
import { 
  FacebookCustomerTagsStrategy, 
  ShopeeCustomerTagsStrategy
} from '../../strategies/customer-tags';
import { FbPosMasterRepositoryModule } from 'libs/repositories/fbpos-master-repository/src/lib/fbpos-master-repository.module';
import { OmnimongoRepositoryModule } from '@kiotviet-facebook-services/omnimongo-repository';
import { ForwarderModule } from '@kiotviet-facebook-services/external-platforms';
import { CommonModule } from '@kiotviet-facebook-services/common';
  
@Module({
  imports: [
    FbPosMasterRepositoryModule,
    OmnimongoRepositoryModule,
    ForwarderModule,
    CommonModule
  ],
  controllers: [CustomerTagsController],
  providers: [
    CustomerTagsService,
    FacebookCustomerTagsStrategy,
    ShopeeCustomerTagsStrategy
  ],
  exports: [CustomerTagsService],
})
export class CustomerTagsModule {} 