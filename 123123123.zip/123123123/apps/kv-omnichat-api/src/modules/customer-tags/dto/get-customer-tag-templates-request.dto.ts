import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsArray, ValidateNested, ArrayNotEmpty } from 'class-validator';
import { Type } from 'class-transformer';
import { ChannelRequestDto } from '../../../common/dto/base-channel.dto';

/**
 * DTO for customer tag templates request
 */
export class GetCustomerTagTemplatesRequestDto {
  @ApiProperty({
    description: 'List of channels to get customer tag templates for',
    example: [
      { channelId: '109533272097318', platform: 'Facebook' },
      { channelId: '252083544658502', platform: 'Facebook' }
    ],
    type: [ChannelRequestDto]
  })
  @IsNotEmpty({ message: 'Channels cannot be empty' })
  @IsArray({ message: 'Channels must be an array' })
  @ArrayNotEmpty({ message: 'Channels array cannot be empty' })
  @ValidateNested({ each: true })
  @Type(() => ChannelRequestDto)
  channels: ChannelRequestDto[];
} 