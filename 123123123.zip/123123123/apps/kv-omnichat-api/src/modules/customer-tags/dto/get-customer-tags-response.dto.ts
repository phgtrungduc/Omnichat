import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { CustomerTagDto } from './customer-tag.dto';

/**
 * DTO for customer tags mapping response
 */
export class GetCustomerTagsResponseDto {
  @ApiProperty({
    description: 'Success status',
    example: true
  })
  success: boolean;

  @ApiProperty({
    description: 'List of customer tags mapping',
    type: [CustomerTagDto]
  })
  data: CustomerTagDto[];

  @ApiProperty({
    description: 'Total number of customer tags returned',
    example: 6
  })
  totalCount: number;

  @ApiPropertyOptional({
    description: 'Response message',
    example: 'Successfully retrieved customer tags mapping'
  })
  message?: string;

  @ApiPropertyOptional({
    description: 'Statistics by platform',
    example: {
      'Facebook': {
        'channelCount': 2,
        'tagCount': 6
      }
    }
  })
  statistics?: Record<string, {
    channelCount: number;
    tagCount: number;
  }>;
} 