import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsOptional, IsNumber, IsBoolean } from 'class-validator';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

/**
 * DTO for Customer Tag response
 */
export class CustomerTagDto {
  @ApiProperty({
    description: 'Customer tag ID from database',
    example: '684f8443a0c3780018f7741e'
  })
  @IsNotEmpty({ message: 'Customer tag ID cannot be empty' })
  @IsString({ message: 'Customer tag ID must be a string' })
  id: string;

  @ApiProperty({
    description: 'Channel ID (Page ID for Facebook)',
    example: '109533272097318'
  })
  @IsNotEmpty({ message: 'Channel ID cannot be empty' })
  @IsString({ message: 'Channel ID must be a string' })
  channelId: string;

  @ApiProperty({
    description: 'Platform of the channel',
    enum: ChatPlatformEnum,
    example: ChatPlatformEnum.Facebook
  })
  @IsNotEmpty({ message: 'Platform cannot be empty' })
  platform: ChatPlatformEnum;

  @ApiProperty({
    description: 'Sender ID of the user',
    example: '7465386236906756'
  })
  @IsNotEmpty({ message: 'Sender ID cannot be empty' })
  @IsString({ message: 'Sender ID must be a string' })
  senderId: string;

  @ApiProperty({
    description: 'Customer tag ID that is assigned',
    example: 'defaultcustomertag_bomhang',
    nullable: true
  })
  @IsOptional()
  @IsString({ message: 'Customer tag ID must be a string' })
  customerTagId: string | null;

  @ApiProperty({
    description: 'Tag creation time (Unix timestamp in milliseconds)',
    example: 1750041667507
  })
  @IsNotEmpty({ message: 'Created time cannot be empty' })
  @IsNumber({}, { message: 'Created time must be a number' })
  createdTime: number;

  @ApiPropertyOptional({
    description: 'Active status of the tag',
    example: true,
    default: true
  })
  @IsOptional()
  @IsBoolean({ message: 'Is active must be a boolean' })
  isActive?: boolean;
} 