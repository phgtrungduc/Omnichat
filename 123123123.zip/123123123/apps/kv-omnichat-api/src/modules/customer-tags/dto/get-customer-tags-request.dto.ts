import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsArray, ValidateNested, ArrayNotEmpty } from 'class-validator';
import { Type } from 'class-transformer';
import { ChannelRequestDto } from '../../../common/dto/base-channel.dto';

/**
 * Filter for customer tags by channel
 */
export class CustomerTagsFilterDto {
  @ApiProperty({
    description: 'List of SenderId to get customer tags for',
    example: [
      '7465386236906756',
      '9976498469134129',
      '9173343479403625'
    ],
    type: [String]
  })
  @IsNotEmpty({ message: 'SenderId list cannot be empty' })
  @IsArray({ message: 'SenderId must be an array' })
  @ArrayNotEmpty({ message: 'SenderId array cannot be empty' })
  SenderId: string[];
}

/**
 * DTO for channel request with customer tags filter
 */
export class ChannelWithCustomerTagsFilterDto extends ChannelRequestDto {
  @ApiProperty({
    description: 'Filter for customer tags of this channel',
    example: {
      'SenderId': [
        '7465386236906756',
        '9976498469134129',
        '9173343479403625'
      ]
    },
    type: CustomerTagsFilterDto
  })
  @IsNotEmpty({ message: 'Filter cannot be empty' })
  @ValidateNested()
  @Type(() => CustomerTagsFilterDto)
  filter: CustomerTagsFilterDto;
}

/**
 * DTO for customer tags mapping request
 */
export class GetCustomerTagsRequestDto {
  @ApiProperty({
    description: 'List of channels to get customer tags with individual filters for each channel',
    example: [
      {
        channelId: '109533272097318',
        platform: 'Facebook',
        filter: {
          'SenderId': [
            '7465386236906756',
            '9976498469134129',
            '9173343479403625'
          ]
        }
      },
      {
        channelId: '252083544658502',
        platform: 'Facebook',
        filter: {
          'SenderId': [
            '24025722287109399',
            '7321960574526011'
          ]
        }
      }
    ],
    type: [ChannelWithCustomerTagsFilterDto]
  })
  @IsNotEmpty({ message: 'Channels cannot be empty' })
  @IsArray({ message: 'Channels must be an array' })
  @ArrayNotEmpty({ message: 'Channels array cannot be empty' })
  @ValidateNested({ each: true })
  @Type(() => ChannelWithCustomerTagsFilterDto)
  channels: ChannelWithCustomerTagsFilterDto[];
} 