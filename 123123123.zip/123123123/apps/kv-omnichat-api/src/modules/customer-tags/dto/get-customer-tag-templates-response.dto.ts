import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { CustomerTagTemplateDto } from './customer-tag-template.dto';

/**
 * DTO for customer tag templates response
 */
export class GetCustomerTagTemplatesResponseDto {
  @ApiProperty({
    description: 'Success status',
    example: true
  })
  success: boolean;

  @ApiProperty({
    description: 'List of customer tag templates',
    type: [CustomerTagTemplateDto]
  })
  data: CustomerTagTemplateDto[];

  @ApiProperty({
    description: 'Total number of tag templates',
    example: 4
  })
  totalCount: number;

  @ApiPropertyOptional({
    description: 'Response message',
    example: 'Successfully retrieved customer tag templates'
  })
  message?: string;

  @ApiPropertyOptional({
    description: 'Statistics by platform',
    example: {
      'Facebook': {
        'templateCount': 4
      }
    }
  })
  statistics?: Record<string, {
    templateCount: number;
  }>;
} 