import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsOptional, IsBoolean, IsNumber } from 'class-validator';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

/**
 * DTO for Customer Tag Template
 */
export class CustomerTagTemplateDto {
  @ApiProperty({
    description: 'Tag template ID (null for "Select warning" option)',
    example: 'defaultcustomertag_bomhang',
    nullable: true
  })
  @IsOptional()
  @IsString({ message: 'Tag ID must be a string' })
  id: string | null;

  @ApiProperty({
    description: 'Display title of the tag',
    example: 'Bom hàng'
  })
  @IsNotEmpty({ message: 'Title cannot be empty' })
  @IsString({ message: 'Title must be a string' })
  title: string;

  @ApiProperty({
    description: 'Background color of the tag (hex format)',
    example: '#f33636'
  })
  @IsNotEmpty({ message: 'Color cannot be empty' })
  @IsString({ message: 'Color must be a string' })
  color: string;

  @ApiPropertyOptional({
    description: 'Text color of the tag (hex format)',
    example: '#ffffff'
  })
  @IsOptional()
  @IsString({ message: 'Color text must be a string' })
  colorText?: string;

  @ApiProperty({
    description: 'Platform of the tag template',
    enum: ChatPlatformEnum,
    example: ChatPlatformEnum.Facebook
  })
  @IsNotEmpty({ message: 'Platform cannot be empty' })
  platform: ChatPlatformEnum;

  @ApiPropertyOptional({
    description: 'Detailed description of the tag usage',
    example: 'For customers who frequently cancel orders'
  })
  @IsOptional()
  @IsString({ message: 'Description must be a string' })
  description?: string;

  @ApiPropertyOptional({
    description: 'Whether this tag is a default template',
    example: true
  })
  @IsOptional()
  @IsBoolean({ message: 'Is default must be a boolean' })
  isDefault?: boolean;

  @ApiPropertyOptional({
    description: 'Sort order for template display',
    example: 1
  })
  @IsOptional()
  @IsNumber({}, { message: 'Sort order must be a number' })
  sortOrder?: number;
} 