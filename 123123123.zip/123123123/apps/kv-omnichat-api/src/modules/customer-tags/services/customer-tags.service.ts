import { Injectable, BadRequestException } from '@nestjs/common';
import { Request } from 'express';
import { KvLogger } from '@kiotviet-facebook-services/common';
import {
  ICustomerTagsStrategy,
  ICustomerTagsRequest,
  IChannelWithCustomerTagsFilter,
  FacebookCustomerTagsStrategy,
  ShopeeCustomerTagsStrategy
} from '../../../strategies/customer-tags';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import {
  GetCustomerTagsRequestDto,
  GetCustomerTagsResponseDto,
  GetCustomerTagTemplatesRequestDto,
  GetCustomerTagTemplatesResponseDto,
  CustomerTagDto,
  CustomerTagTemplateDto
} from '../dto';
import { CustomerTagTemplatesConstants } from '../constants';

@Injectable()
export class CustomerTagsService {
  private readonly customerTagsStrategies: ICustomerTagsStrategy[];

  constructor(
    private readonly facebookStrategy: FacebookCustomerTagsStrategy,
    private readonly shopeeStrategy: ShopeeCustomerTagsStrategy,
    private readonly logger: KvLogger
  ) {
    this.customerTagsStrategies = [
      this.facebookStrategy,
      this.shopeeStrategy
    ];
  }

  /**
   * Lấy danh sách customer tags mapping từ các platforms
   */
  async getCustomerTagsMapping(req: Request, query: GetCustomerTagsRequestDto): Promise<GetCustomerTagsResponseDto> {
    
    // Validate channels không rỗng
    if (!query.channels || query.channels.length === 0) {
      throw new BadRequestException('Channels list cannot be empty');
    }

    // Validate filter cho từng channel
    const invalidChannels = query.channels.filter(channel => 
      !channel.filter || 
      !channel.filter.SenderId || 
      channel.filter.SenderId.length === 0
    );

    if (invalidChannels.length > 0) {
      const invalidChannelIds = invalidChannels.map(c => c.channelId).join(', ');
      throw new BadRequestException(`Missing or empty SenderId filter for channels: ${invalidChannelIds}`);
    }

    const channelIds = query.channels.map(c => c.channelId).join(', ');
    this.logger.info(`Getting customer tags mapping for ${query.channels.length} channels: ${channelIds}`);

    // Group channels by platform
    const channelsByPlatform = query.channels.reduce((acc, channel) => {
      if (!acc[channel.platform]) {
        acc[channel.platform] = [];
      }
      acc[channel.platform].push(channel);
      return acc;
    }, {} as Record<ChatPlatformEnum, IChannelWithCustomerTagsFilter[]>);

    const allResults: CustomerTagDto[] = [];
    let hasErrors = false;
    let errorMessage = '';

    // Process each platform
    for (const [platform, channels] of Object.entries(channelsByPlatform)) {
      const strategy = this.customerTagsStrategies.find(s => s.supports(platform as ChatPlatformEnum));
      
      if (!strategy) {
        hasErrors = true;
        errorMessage = `Platform ${platform} is not supported for customer tags mapping`;
        this.logger.error(errorMessage);
        break;
      }

      try {
        const customerTagsRequest: ICustomerTagsRequest = {
          channels: channels
        };

        const result = await strategy.getCustomerTags(req, customerTagsRequest);

        if (!result.success) {
          hasErrors = true;
          errorMessage = result.message || `Failed to get customer tags from ${platform}`;
          break;
        }

        const customerTags: CustomerTagDto[] = result.data.map(item => ({
          id: item.id,
          channelId: item.channelId,
          platform: item.platform,
          senderId: item.senderId,
          customerTagId: item.customerTagId,
          createdTime: item.createdTime,
          isActive: item.isActive
        }));

        allResults.push(...customerTags);

      } catch (error) {
        hasErrors = true;
        const platformChannelIds = channels.map(c => c.channelId).join(', ');
        errorMessage = `Error getting customer tags for platform ${platform}, channels: ${platformChannelIds} - ${error.message}`;
        this.logger.error(errorMessage, error);
        break;
      }
    }

    // Tạo statistics theo platform
    const statistics = this._generateStatistics(allResults, channelsByPlatform);

    const response: GetCustomerTagsResponseDto = {
      success: !hasErrors,
      data: allResults,
      totalCount: allResults.length,
      message: hasErrors 
        ? errorMessage
        : `Successfully retrieved ${allResults.length} customer tags mapping from ${query.channels.length} channels`,
      statistics
    };

    if (hasErrors) {
      this.logger.error(`Failed to get customer tags mapping: ${errorMessage}`);
    } else {
      this.logger.info(`Successfully retrieved ${allResults.length} customer tags mapping from ${query.channels.length} channels`);
    }

    return response;
  }

  /**
   * Lấy danh sách customer tag templates cho các platforms
   */
  async getCustomerTagTemplates(req: Request, query: GetCustomerTagTemplatesRequestDto): Promise<GetCustomerTagTemplatesResponseDto> {
    
    // Validate channels không rỗng
    if (!query.channels || query.channels.length === 0) {
      throw new BadRequestException('Channels list cannot be empty');
    }

    const channelIds = query.channels.map(c => c.channelId).join(', ');
    this.logger.info(`Getting customer tag templates for ${query.channels.length} channels: ${channelIds}`);

    try {
      // Group channels by platform
      const platformsRequested = [...new Set(query.channels.map(c => c.platform))];
      
      const allTemplates: CustomerTagTemplateDto[] = [];

      // Lấy templates cho từng platform được yêu cầu
      platformsRequested.forEach(platform => {
        const platformTemplates = CustomerTagTemplatesConstants.getTemplatesByPlatform(platform);
        allTemplates.push(...platformTemplates);
      });

      // Sắp xếp theo sortOrder
      allTemplates.sort((a, b) => {
        if (a.platform !== b.platform) {
          return a.platform.localeCompare(b.platform);
        }
        return (a.sortOrder || 0) - (b.sortOrder || 0);
      });

      // Tạo statistics theo platform
      const statistics = this._generateTemplateStatistics(allTemplates);

      const response: GetCustomerTagTemplatesResponseDto = {
        success: true,
        data: allTemplates,
        totalCount: allTemplates.length,
        message: `Successfully retrieved ${allTemplates.length} customer tag templates for platforms: ${platformsRequested.join(', ')}`,
        statistics
      };

      this.logger.info(`Successfully retrieved ${allTemplates.length} customer tag templates for ${query.channels.length} channels`);
      
      return response;

    } catch (error) {
      const errorMessage = `Error getting customer tag templates for channels: ${channelIds} - ${error.message}`;
      this.logger.error(errorMessage, error);
      
      return {
        success: false,
        data: [],
        totalCount: 0,
        message: errorMessage
      };
    }
  }

  /**
   * Tạo thống kê theo platform cho customer tags mapping
   */
  private _generateStatistics(
    results: CustomerTagDto[], 
    channelsByPlatform: Record<ChatPlatformEnum, IChannelWithCustomerTagsFilter[]>
  ): Record<string, { channelCount: number; tagCount: number }> {
    const statistics: Record<string, { channelCount: number; tagCount: number }> = {};

    for (const [platform, channels] of Object.entries(channelsByPlatform)) {
      const tagCount = results.filter(r => r.platform.toString() === platform).length;
      
      statistics[platform] = {
        channelCount: channels.length,
        tagCount: tagCount
      };
    }

    return statistics;
  }

  /**
   * Tạo thống kê cho customer tag templates
   */
  private _generateTemplateStatistics(
    templates: CustomerTagTemplateDto[]
  ): Record<string, { templateCount: number }> {
    const statistics: Record<string, { templateCount: number }> = {};

    // Group by platform
    const templatesByPlatform = templates.reduce((acc, template) => {
      const platform = template.platform.toString();
      if (!acc[platform]) {
        acc[platform] = 0;
      }
      acc[platform]++;
      return acc;
    }, {} as Record<string, number>);

    // Convert to expected format
    for (const [platform, count] of Object.entries(templatesByPlatform)) {
      statistics[platform] = {
        templateCount: count
      };
    }

    return statistics;
  }
} 