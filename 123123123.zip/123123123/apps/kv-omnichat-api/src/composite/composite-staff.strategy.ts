import { Injectable } from '@nestjs/common';
import { IChatStaff, ChatPlatformEnum, KvLogger, ChatError } from '@kiotviet-facebook-services/common';
import { FacebookStaffStrategy } from '../strategies/facebook/facebook-staff.strategy';
import { ShopeeStaffStrategy } from '../strategies/shopee/shopee-staff.strategy';
import { IPlatformChannel } from '../common/interfaces/platform-channel.interface';
import { BaseCompositeStrategy } from './base-composite.strategy';
import { StaffAssignDto, StaffDisableDto, StaffBulkAssignDto, StaffBulkUnassignDto } from '../modules/staff/dto/staff.dto';
import { Request } from 'express';

export interface IStaffStrategy {
  getStaffList(channels: IPlatformChannel[]): Promise<any[]>;
  getStaffByChannels(channels: IPlatformChannel[]): Promise<any[]>;
  assignStaff(assignData: StaffAssignDto, request: Request): Promise<boolean>;
  unassignStaff(assignData: StaffAssignDto, request: Request): Promise<boolean>;
  disableStaff(disableData: StaffDisableDto, request: Request): Promise<boolean>;
  bulkAssignStaff(bulkAssignData: StaffBulkAssignDto, request: Request): Promise<boolean>;
  bulkUnassignStaff(bulkUnassignData: StaffBulkUnassignDto, request: Request): Promise<boolean>;
}

export interface ICompositeStaffStrategy {
  getStaffList(channels: IPlatformChannel[]): Promise<any[]>;
  getStaffByChannels(channels: IPlatformChannel[]): Promise<any[]>;
  assignStaff(assignData: StaffAssignDto, request: Request): Promise<boolean>;
  unassignStaff(assignData: StaffAssignDto, request: Request): Promise<boolean>;
  disableStaff(disableData: StaffDisableDto, request: Request): Promise<boolean>;
  bulkAssignStaff(bulkAssignData: StaffBulkAssignDto, request: Request): Promise<boolean>;
  bulkUnassignStaff(bulkUnassignData: StaffBulkUnassignDto, request: Request): Promise<boolean>;
}

@Injectable()
export class CompositeStaffStrategy extends BaseCompositeStrategy<IStaffStrategy> implements ICompositeStaffStrategy {
  protected logger: KvLogger;

  constructor(
    private readonly facebookStaffStrategy: FacebookStaffStrategy,
    private readonly shopeeStaffStrategy: ShopeeStaffStrategy,
    logger: KvLogger
  ) {
    super();
    this.logger = logger;
    this.strategies.set(ChatPlatformEnum.Facebook, facebookStaffStrategy);
    this.strategies.set(ChatPlatformEnum.Instagram, facebookStaffStrategy);
    this.strategies.set(ChatPlatformEnum.Shopee, shopeeStaffStrategy);
  }

  async getStaffList(channels: IPlatformChannel[]): Promise<any[]> {
    try {
      // Detect platforms from channels using base class method
      const platforms = this.detectPlatforms(channels);

      // Execute for all platforms using base class method
      return await this.executeForAllPlatforms(platforms, async (strategy, platform) => {
        return await strategy.getStaffList(channels);
      });
    } catch (error) {
      this.logger.error(`Error in composite staff strategy: ${error.message}`, error.stack);
      return [];
    }
  }

  async getStaffByChannels(channels: IPlatformChannel[]): Promise<any[]> {
    try {
      // Detect platforms from channels using base class method
      const platforms = this.detectPlatforms(channels);

      // Execute for all platforms using base class method
      return await this.executeForAllPlatforms(platforms, async (strategy, platform) => {
        return await strategy.getStaffByChannels(channels);
      });
    } catch (error) {
      this.logger.error(`Error in composite getStaffByChannels: ${error.message}`, error.stack);
      return [];
    }
  }

  async assignStaff(assignData: StaffAssignDto, request: Request): Promise<boolean> {
    try {
      const strategy = this.getStrategyForPlatform(assignData.platform);
      if (strategy) {
        return await strategy.assignStaff(assignData, request);
      }
    } catch (error) {
      throw new ChatError('COMPOSITE_STAFF_ERROR').withAdditional({ 
        stack: error.stack,
        originalError: error.message 
      });
    }
  }

  async unassignStaff(assignData: StaffAssignDto, request: Request): Promise<boolean> {
    try {
      const strategy = this.getStrategyForPlatform(assignData.platform);
      if (strategy) {
        return await strategy.unassignStaff(assignData, request);
      } else {
        this.logger.error(`No strategy found for platform: ${assignData.platform}`);
        return false;
      }
    } catch (error) {
      this.logger.error(`Error in composite unassignStaff: ${error.message}`, error.stack);
      return false;
    }
  }

  async disableStaff(disableData: StaffDisableDto, request: Request): Promise<boolean> {
    try {
      // For disable, we need to determine platform from the data or use a default
      // Since disableData doesn't have platform, we'll use Facebook as default for now
      const strategy = this.getStrategyForPlatform(ChatPlatformEnum.Facebook);
      if (strategy) {
        return await strategy.disableStaff(disableData, request);
      } else {
        this.logger.error(`No strategy found for platform: ${ChatPlatformEnum.Facebook}`);
        return false;
      }
    } catch (error) {
      this.logger.error(`Error in composite disableStaff: ${error.message}`, error.stack);
      return false;
    }
  }

  async bulkAssignStaff(bulkAssignData: StaffBulkAssignDto, request: Request): Promise<boolean> {
    try {
      const { channels } = bulkAssignData;

      const platforms = this.detectPlatforms(channels);

      // Execute for all platforms (each platform appears only once in channelIds)
      const results = await Promise.all(
        platforms.map(async (platform) => {
          const strategy = this.getStrategyForPlatform(platform);
          if (strategy) {
            return await strategy.bulkAssignStaff(bulkAssignData, request);
          } else {
            return false;
          }
        })
      );
      
      // Return true if at least one platform succeeded
      return results.some(result => result === true);
    } catch (error) {
      this.logger.error(`Error in composite bulkAssignStaff: ${error.message}`, error.stack);
      return false;
    }
  }

  async bulkUnassignStaff(bulkUnassignData: StaffBulkUnassignDto, request: Request): Promise<boolean> {
    try {
      const { channels } = bulkUnassignData;

      const platforms = this.detectPlatforms(channels);
      
      // Execute for all platforms (each platform appears only once in channelIds)
      const results = await Promise.all(
        platforms.map(async (platform) => {
          const strategy = this.getStrategyForPlatform(platform);
          if (strategy) {
            return await strategy.bulkUnassignStaff(bulkUnassignData, request);
          } else {
            return false;
          }
        })
      );
      
      // Return true if at least one platform succeeded
      return results.some(result => result === true);
    } catch (error) {
      this.logger.error(`Error in composite bulkUnassignStaff: ${error.message}`, error.stack);
      return false;
    }
  }
} 