import { Injectable } from '@nestjs/common';
import { KvLogger, ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { BaseCompositeStrategy } from './base-composite.strategy';
import { UserProfileDto, UserProfileResponseDto } from '../modules/user/dto/user.dto';
import { FacebookUserStrategy } from '../strategies/facebook/facebook-user.strategy';
import { ShopeeUserStrategy } from '../strategies/shopee/shopee-user.strategy';

export interface IUserStrategy {
  getUserProfile(dto: UserProfileDto): Promise<UserProfileResponseDto>;
  getUserProfilePicture(dto: UserProfileDto): Promise<string>;
}

export interface ICompositeUserStrategy {
  getUserProfile(dto: UserProfileDto): Promise<UserProfileResponseDto>;
  getUserProfilePicture(dto: UserProfileDto): Promise<string>;
}

@Injectable()
export class CompositeUserStrategy extends BaseCompositeStrategy<IUserStrategy> implements ICompositeUserStrategy {
  protected logger: KvLogger;

  constructor(
    private readonly facebookUserStrategy: FacebookUserStrategy,
    private readonly shopeeUserStrategy: ShopeeUserStrategy,
    logger: KvLogger
  ) {
    super();
    this.logger = logger;
    this.strategies.set(ChatPlatformEnum.Facebook, facebookUserStrategy);
    this.strategies.set(ChatPlatformEnum.Instagram, facebookUserStrategy);
    this.strategies.set(ChatPlatformEnum.Shopee, shopeeUserStrategy);
  }

  async getUserProfile(dto: UserProfileDto): Promise<UserProfileResponseDto> {
    try {
      const strategy = this.getStrategyForPlatform(dto.platform);
      if (strategy) {
        return await strategy.getUserProfile(dto);
      } else {
        this.logger.error(`No strategy found for platform: ${dto.platform}`);
        return null;
      }
    } catch (error) {
      this.logger.error(`Error in composite getUserProfile: ${error.message}`, error.stack);
      return null;
    }
  }

  async getUserProfilePicture(dto: UserProfileDto): Promise<string> {
    try {
      const strategy = this.getStrategyForPlatform(dto.platform);
      if (strategy) {
        return await strategy.getUserProfilePicture(dto);
      } else {
        this.logger.error(`No strategy found for platform: ${dto.platform}`);
        return null;
      }
    } catch (error) {
      this.logger.error(`Error in composite getUserProfilePicture: ${error.message}`, error.stack);
      return null;
    }
  }
}
