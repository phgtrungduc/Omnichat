import { ChatPlatformEnum, KvLogger } from '@kiotviet-facebook-services/common';
import { IPlatformChannel } from '../common/interfaces/platform-channel.interface';

export abstract class BaseCompositeStrategy<TStrategy> {
  protected strategies: Map<ChatPlatformEnum, TStrategy> = new Map();
  protected abstract logger: KvLogger;

  protected detectPlatforms(channels?: IPlatformChannel[] | any[]): ChatPlatformEnum[] {
    const platforms: ChatPlatformEnum[] = [];

    if (!channels || channels.length === 0) {
      return [ChatPlatformEnum.Facebook]; // Default to Facebook
    }

    // Extract unique platforms from channels
    for (const channel of channels) {
      if (channel.platform && !platforms.includes(channel.platform)) {
        platforms.push(channel.platform);
      }
    }

    // If no platforms detected, default to Facebook
    if (platforms.length === 0) {
      platforms.push(ChatPlatformEnum.Facebook);
    }

    return platforms;
  }

  protected async executeForAllPlatforms<TResult>(
    platforms: ChatPlatformEnum[],
    operation: (strategy: TStrategy, platform: ChatPlatformEnum) => Promise<TResult[]>
  ): Promise<TResult[]> {
    // Tạo array các promises để thực hiện song song
    const promises = platforms.map(async (platform) => {
      try {
        const strategy = this.strategies.get(platform);
        if (strategy) {
          return await operation(strategy, platform);
        }
        return [];
      } catch (error) {
        this.logger.error(`Error executing operation for platform ${platform}: ${error.message}`);
        // Trả về mảng rỗng cho platform gặp lỗi
        return [];
      }
    });

    // Thực hiện song song tất cả operations
    const results = await Promise.all(promises);
    
    // Flatten kết quả từ tất cả platforms
    const allResults: TResult[] = [];
    for (const result of results) {
      allResults.push(...result);
    }
    
    return allResults;
  }

  protected getStrategyForPlatform(platform: ChatPlatformEnum): TStrategy | undefined {
    return this.strategies.get(platform);
  }
} 