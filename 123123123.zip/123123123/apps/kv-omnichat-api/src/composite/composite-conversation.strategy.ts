import { Injectable } from '@nestjs/common';
import { ChatError, ChatPlatformEnum, IChatConversation, KvLogger } from '@kiotviet-facebook-services/common';
import {
  IConversationStrategy,
  ICompositeConversationStrategy,
  IConversationFilters,
  IConversationSearchByAccountFilters,
  IConversationSearchByMessageFilters
} from '../interfaces/conversation.interface';
import { FacebookConversationStrategy } from '../strategies/facebook/facebook-conversation.strategy';
import { ShopeeConversationStrategy } from '../strategies/shopee/shopee-conversation.strategy';
import { ConversationSortEnum } from '../common/enums/conversation-sort.enum';
import { BaseCompositeStrategy } from './base-composite.strategy';
import { BasePagingDto } from '../common/dto/base-paging.dto';

@Injectable()
export class CompositeConversationStrategy extends BaseCompositeStrategy<IConversationStrategy> implements ICompositeConversationStrategy {
  protected logger: KvLogger;

  constructor(
    private readonly _facebookStrategy: FacebookConversationStrategy,
    private readonly _shopeeStrategy: ShopeeConversationStrategy,
    logger: KvLogger
  ) {
    super();
    this.logger = logger;
    this.strategies.set(ChatPlatformEnum.Facebook, _facebookStrategy);
    this.strategies.set(ChatPlatformEnum.Instagram, _facebookStrategy);
    this.strategies.set(ChatPlatformEnum.Shopee, _shopeeStrategy);
  }

  async getConversations(filters?: IConversationFilters): Promise<BasePagingDto<IChatConversation>> {
    try {
      // Detect platforms from unified filters using base class method
      const platforms = this.detectPlatforms(filters?.channels);

      if (platforms.length === 0) {
        throw new ChatError('CONVERSATION_NOT_FOUND', 'No platforms found');
      }

      if (platforms.length === 1) {
        const strategy = this.getStrategyForPlatform(platforms[0]);
        if (strategy) {
          
          const conversations = await strategy.getConversations(filters);
          let results = [...conversations]

          if (filters?.limit) {
            results = conversations.slice(0, filters.limit);
          }
          return {
            data: results,
            hasMore: conversations.length > filters.limit
          };
        }
      }

      // Multiple platforms - execute for all platforms using base class method
      let allConversations = await this.executeForAllPlatforms(platforms, async (strategy) => {
        return await strategy.getConversations(filters);
      });

      // Sort by timestamp if multiple platforms
      if (allConversations.length > 1) {
        allConversations = this.sortConversations(allConversations, filters?.sortBy);
      }

      let result = [...allConversations];
      // Apply pagination if specified
      if (filters?.limit) {
        const endIndex = filters.limit + 1;
        result = allConversations.slice(0, endIndex);
      }

      return {
        data: result,
        hasMore: allConversations.length > filters.limit
      };
    } catch (error) {
      this.logger.error(`Error in composite conversation strategy: ${error.message}`, error.stack);
      return {
        data: [],
        hasMore: false
      };
    }
  }

  async getConversationsSearchByAccount(filters?: IConversationSearchByAccountFilters): Promise<BasePagingDto<IChatConversation>> {
    try {
      const platforms = this.detectPlatforms(filters?.channels);

      if (platforms.length === 0) return {
        data: [],
        hasMore: false
      };

      if (platforms.length === 1) {
        const strategy = this.getStrategyForPlatform(platforms[0]);
        if (strategy) {
          const conversations = await strategy.getConversationsSearchByAccount(filters);
          let results = [...conversations]

          if (filters?.limit) {
            results = conversations.slice(0, filters.limit);
          }
          return {
            data: results,
            hasMore: conversations.length > filters.limit
          };
        }
      }

      let allConversations = await this.executeForAllPlatforms(platforms, async (strategy) => {
        return await strategy.getConversationsSearchByAccount(filters);
      });

      allConversations = allConversations.sort((a, b) => b.lastMessageTimestamp > a.lastMessageTimestamp ? 1 : -1);

      let result = [...allConversations]
      if (filters?.limit && allConversations?.length > filters.limit) {
        result = allConversations.slice(0, filters.limit);
      }
      return {
        data: result,
        hasMore: allConversations.length > filters.limit
      };
    } catch (error) {
      throw new ChatError('CONVERSATION_NOT_FOUND', error.message);
    }
  }

  async getConversationsSearchByMessage(filters?: IConversationSearchByMessageFilters): Promise<BasePagingDto<IChatConversation>> {
    try {
      const platforms = this.detectPlatforms(filters?.channels);

      if (platforms.length === 0) return {
        data: [],
        hasMore: false
      };

      if (platforms.length === 1) {
        const strategy = this.getStrategyForPlatform(platforms[0]);
        if (strategy) {
          const conversations = await strategy.getConversationsSearchByMessage(filters);
          let results = [...conversations]

          if (filters?.limit) {
            results = conversations.slice(0, filters.limit);
          }
          return {
            data: results,
            hasMore: conversations.length > filters.limit
          };
        }
      }

      let allConversations = await this.executeForAllPlatforms(platforms, async (strategy) => {
        return await strategy.getConversationsSearchByMessage(filters);
      });

      allConversations = allConversations.sort((a, b) => b.lastMessageTimestamp > a.lastMessageTimestamp ? 1 : -1);

      let result = [...allConversations]
      if (filters?.limit && allConversations?.length > filters.limit) {
        result = allConversations.slice(0, filters.limit);
      }
      return {
        data: result,
        hasMore: allConversations.length > filters.limit
      };
    } catch (error) {
      throw new ChatError('CONVERSATION_NOT_FOUND', error.message);
    }
  }

  private sortConversations(conversations: IChatConversation[], sortBy?: ConversationSortEnum): IChatConversation[] {
    switch (sortBy) {
      case ConversationSortEnum.Oldest:
        return conversations.sort((a, b) => {
          return b.lastMessageTimestamp > a.lastMessageTimestamp ? 1 : -1;
        });
  
      case ConversationSortEnum.Unread:
        return conversations.sort((a, b) => {
          if (a.unreadCount > b.unreadCount) return -1;
          if (a.unreadCount < b.unreadCount) return 1;
          return 0;
        });
  
      case ConversationSortEnum.Newest:
      default:
        return conversations.sort((a, b) => {
          return a.lastMessageTimestamp > b.lastMessageTimestamp ? 1 : -1;
        });
    }
  }
} 