import { Injectable } from '@nestjs/common';
import { ChatPlatformEnum, KvLogger } from '@kiotviet-facebook-services/common';
import { FacebookFeedpostStrategy } from '../strategies/facebook/facebook-feedpost.strategy';
import { ShopeeFeedpostStrategy } from '../strategies/shopee/shopee-feedpost.strategy';
import { IPlatformChannel } from '../common/interfaces/platform-channel.interface';
import { BaseCompositeStrategy } from './base-composite.strategy';
import { FeedpostItemDto, FeedpostListRequestDto, FeedpostListResponseDto } from '../modules/feedpost/dto/feedpost.dto';

export interface IFeedpostStrategy {
  getFeedposts(channels: IPlatformChannel[], query: FeedpostListRequestDto): Promise<FeedpostItemDto[]>;
}

export interface ICompositeFeedpostStrategy {
  getFeedposts(channels: IPlatformChannel[], query: FeedpostListRequestDto): Promise<FeedpostListResponseDto>;
}

@Injectable()
export class CompositeFeedpostStrategy extends BaseCompositeStrategy<IFeedpostStrategy> implements ICompositeFeedpostStrategy {
  protected logger: KvLogger;

  constructor(
    private readonly facebookFeedpostStrategy: FacebookFeedpostStrategy,
    private readonly shopeeFeedpostStrategy: ShopeeFeedpostStrategy,
    logger: KvLogger
  ) {
    super();
    this.logger = logger;
    this.strategies.set(ChatPlatformEnum.Facebook, facebookFeedpostStrategy);
    this.strategies.set(ChatPlatformEnum.Shopee, shopeeFeedpostStrategy);
  }

  async getFeedposts(channels: IPlatformChannel[], query: FeedpostListRequestDto): Promise<FeedpostListResponseDto> {
    try {
      // Detect platforms from channels using base class method
      const platforms = this.detectPlatforms(channels);

      // Execute for all platforms using base class method
      const allPosts = await this.executeForAllPlatforms(platforms, async (strategy) => {
        return await strategy.getFeedposts(channels, query);
      });

      const skip = query.skip || 0;

      const sortedPosts = allPosts
        .sort((a, b) => (b.createdTime || 0) - (a.createdTime || 0))
        .slice(skip, skip + query.limit);

      return {
        data: sortedPosts,
        hasMore: allPosts.length > query.limit
      };
    } catch (error) {
      this.logger.error(`Error in composite feedpost strategy: ${error.message}`, error.stack);
      return {
        data: [],
        hasMore: false
      };
    }
  }
} 