import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

export interface IPlatformChannel {
  platform: ChatPlatformEnum;
  channelId: string[];
} 

export interface IChannelPaging {
  channelId: string;
  beforeTimestamp?: number;
  afterTimestamp?: number;
  limit?: number;
  skip?: number;
}

export interface IChannelPagination {
  platform: ChatPlatformEnum;
  channelDetails: IChannelPaging[];
} 