export interface IAuditTrailRequest {
  headers: {
    retail_object?: string;
    authorization?: string;
    origin?: string;
  };
} 