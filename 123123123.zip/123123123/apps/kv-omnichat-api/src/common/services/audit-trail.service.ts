import { Injectable } from '@nestjs/common';
import { KvLogger } from '@kiotviet-facebook-services/common';
import { AuditTrailActionEnum } from '../enums/staff.enum';
import { IAuditTrailRequest } from '../interfaces/audit-trail.interface';
import { ConfigService } from '@nestjs/config';
import { AuditLogFunctions } from '@kiotviet-facebook-services/kv-audit-trail-adapter';

@Injectable()
export class AuditTrailService {
  constructor(
    private readonly logger: KvLogger,
    private readonly configService: ConfigService
  ) {}

  async publishEvent(
    req: IAuditTrailRequest, 
    content: string, 
    action: AuditTrailActionEnum, 
    functionId: AuditLogFunctions, 
    rejectUnauthorized = true
  ): Promise<void> {
    if (!req.headers["retail_object"]) {
      return;
    }
    
    try {
      await this.publishAuditTrailViaManApi(req, content, action, functionId, rejectUnauthorized);
    } catch (err: any) {
      // TODO: Implement webhookAlert.sendWebhookAlertTimeout
      this.logger.error(`[ALERT] AuditTrail had writed fail!`, {
        message: err.stack || err.message
      });
    }
  }

  private async publishAuditTrailViaManApi(
    req: IAuditTrailRequest, 
    content: string, 
    action: AuditTrailActionEnum, 
    functionId: AuditLogFunctions, 
    rejectUnauthorized: boolean
  ): Promise<void> {
    const clientAddress = this.configService.get('man-api') || req.headers["origin"]; // Example: https://api-man.kiotviet.com
    
    if (!req.headers["retail_object"]) {
      return;
    }

    const retailObj = JSON.parse(req.headers["retail_object"]);
    const headerObj: any = {
      "Content-Type": "application/json",
      "authorization": req.headers["authorization"],
    };
    
    headerObj["Cookie"] = `LatestBranch_${retailObj.id}_${retailObj.user_id}=${retailObj.branch_id}`;
    headerObj["retailer"] = retailObj.code;
    
    let actionId = 0;
    switch (action) {
      case AuditTrailActionEnum.Created:
        actionId = 1;
        break;
      case AuditTrailActionEnum.Updated:
        actionId = 2;
        break;
      case AuditTrailActionEnum.Deleted:
        actionId = 3;
        break;
    }

    try {
      await fetch(`${clientAddress}/api/logs/write`, {
        method: 'POST',
        headers: headerObj,
        body: JSON.stringify({
          "FunctionId": functionId,
          "Action": actionId,
          "Content": content,
        }),
      });
      
      this.logger.info(`Audit trail published successfully`, {
        functionId,
        action: actionId,
        content
      });
    } catch (error: any) {
      // TODO: Implement webhookAlert.sendWebhookAlertTimeout
      this.logger.error(`[ALERT] POST ${clientAddress}/api/logs/write: had error!`, {
        message: error.stack || error.message,
        functionId: functionId,
        action: actionId,
        content: content,
      });
    }
  }
} 