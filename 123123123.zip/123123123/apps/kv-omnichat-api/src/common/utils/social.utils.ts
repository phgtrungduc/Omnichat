import { ChatPlatformEnum } from "@kiotviet-facebook-services/common";
import { IPlatformChannel, IChannelPagination } from "../interfaces/platform-channel.interface";

export const buildLinkFacebook = (pageId: string, pageName: string): string => 
  `<a href="https://facebook.com/${pageId}" target="_blank">${pageName}</a>`;

export const buildLinkInstagram = (pageUserName: string, pageName: string): string => 
  `<a href="https://www.instagram.com/${pageUserName}" target="_blank">${pageName}</a>`; 

export function buildChannelIds(channels: IPlatformChannel[], platform: ChatPlatformEnum = ChatPlatformEnum.Facebook): string[] {
  return [...new Set(
    channels
      .filter(channel => {
         if (platform === ChatPlatformEnum.Instagram || platform === ChatPlatformEnum.Facebook) {
          return channel.platform === ChatPlatformEnum.Instagram || channel.platform === ChatPlatformEnum.Facebook;
         }
         return channel.platform === platform;
      }
      )
      .flatMap(channel => channel.channelId)
  )];
}
