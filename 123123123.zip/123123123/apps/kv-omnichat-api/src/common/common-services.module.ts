import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { AuditTrailService } from './services/audit-trail.service';

@Module({
  imports: [CommonModule],
  providers: [AuditTrailService],
  exports: [AuditTrailService]
})
export class CommonServicesModule {} 