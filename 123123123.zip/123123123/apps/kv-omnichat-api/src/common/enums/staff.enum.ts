export enum StaffEventType {
  StaffAssigned = 'StaffAssigned',
  StaffUnassigned = 'StaffUnassigned',
  StaffDisabled = 'StaffDisabled'
}


export enum AuditTrailActionEnum {
  Created = 'Created',
  Updated = 'Updated',
  Deleted = 'Deleted'
}

export enum StaffConversationTypeEnum {
  Message = 1,
  Comment = 2
}