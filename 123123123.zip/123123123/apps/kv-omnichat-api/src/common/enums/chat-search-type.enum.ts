/**
 * Chat Search Type Enum - maps to C# ChatSearchType
 * Used for advanced search functionality in conversation APIs
 */
export enum ChatSearchType {
  /**
   * Search in both message content and user name
   * Maps to C# ChatSearchType.All = 0
   */
  All = 0,

  /**
   * Search only in message content
   * Maps to C# ChatSearchType.MessageContent = 1
   */
  MessageContent = 1,

  /**
   * Search only in user name
   * Maps to C# ChatSearchType.UserName = 2
   */
  UserName = 2
}

/**
 * Chat Message Type Enum - maps to C# ChatMessageType
 */
export enum ChatMessageType {
  /**
   * All messages
   * Maps to C# ChatMessageType.All = 0
   */
  All = 0,

  /**
   * Unread messages only
   * Maps to C# ChatMessageType.Unread = 1
   */
  Unread = 1,

  /**
   * Read messages only
   * Maps to C# ChatMessageType.Read = 2
   */
  Read = 2,

  /**
   * Pinned messages only
   * Maps to C# ChatMessageType.Pinned = 3
   */
  Pinned = 3,

  /**
   * Not replied messages
   * Maps to C# ChatMessageType.NotReply = 4
   */
  NotReply = 4,

  /**
   * Replied messages
   * Maps to C# ChatMessageType.Reply = 5
   */
  Reply = 5
}

/**
 * Chat Sort Type Enum - maps to C# ChatSortType
 */
export enum ChatSortType {
  /**
   * Sort by time descending (newest first)
   * Maps to C# ChatSortType.Desc = 0
   */
  Desc = 0,

  /**
   * Sort by time ascending (oldest first)
   * Maps to C# ChatSortType.Asc = 1
   */
  Asc = 1
}

export enum ChatConversationType {
  MESSENGER = 'messenger',
  FEED = 'feed'
}

/**
 * Conversation Type Enum
 * Used for categorizing conversations by their source type
 */
export enum ConversationTypeEnum {
  /**
   * Messenger conversations
   */
  Messenger = 0,

  /**
   * Feed conversations (comments, posts)
   */
  Feed = 1
}

/**
 * Conversation Resolved State Enum - maps to C# ConversationResolvedState
 */
export enum ConversationResolvedState {
  /**
   * Conversation is unresolved
   * Maps to C# ConversationResolvedState.UNRESOLVED = 0
   */
  Unresolved = 0,

  /**
   * Conversation is resolved
   * Maps to C# ConversationResolvedState.RESOLVED = 1
   */
  Resolved = 1
}

/**
 * Conversation Read State Enum - maps to C# ConversationReadState
 */
export enum ConversationReadState {
  /**
   * Conversation is unread
   * Maps to C# ConversationReadState.UNREAD = 0
   */
  Unread = 0,

  /**
   * Conversation is read
   * Maps to C# ConversationReadState.READED = 1
   */
  Readed = 1
}

/**
 * Conversation State Filter Enum
 * Used for filtering conversations by their state
 */
export enum ConversationStateFilterEnum {
  /**
   * All conversations
   */
  All = 0,

  /**
   * Conversations that haven't been replied to
   */
  NotReplied = 1,

  /**
   * Conversations that have been replied to
   */
  Replied = 2,

  /**
   * Conversations that are read but not replied to
   */
  ReadButNotReplied = 3,

  /**
   * Conversations that have been processed
   */
  Resolved = 4,

  /**
   * Conversations that are unread
   */
  Unread = 5,
} 