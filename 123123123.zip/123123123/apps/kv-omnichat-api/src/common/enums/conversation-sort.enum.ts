/**
 * Conversation Sort Enum - Unified sorting for Facebook and Shopee
 */
export enum ConversationSortEnum {
  /**
   * Chưa đọc - Sort by unread status first
   * Facebook: maps to 'not_read'
   * Shopee: sort by CreatedDate for unread conversations
   */
  Unread = 'unread',

  /**
   * Thời gian cũ nhất - Sort by oldest time first
   * Facebook: sort by TimeStamp ascending
   * Shopee: maps to SortType = 0
   */
  Oldest = 'oldest',

  /**
   * Thời gian mới nhất - Sort by newest time first
   * Facebook: sort by TimeStamp descending
   * Shopee: maps to SortType = 1
   */
  Newest = 'newest'
} 