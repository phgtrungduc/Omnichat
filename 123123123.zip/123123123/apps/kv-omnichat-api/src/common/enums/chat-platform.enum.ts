export enum MessageType {
    TEXT = 'text',
    IMAGE = 'image',
    VIDEO = 'video'
  }
  
  export enum SenderType {
    CUSTOMER = 'customer',
    AGENT = 'agent'
  }