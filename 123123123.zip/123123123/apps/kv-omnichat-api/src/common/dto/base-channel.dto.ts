import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, IsEnum, IsOptional, IsBoolean } from 'class-validator';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';
import { IChannelRequest } from '../../interfaces';


export class ChannelRequestDto implements IChannelRequest {
  @ApiProperty({
    description: 'Channel ID',
    example: '790976900758321'
  })
  @IsNotEmpty({ message: 'Channel ID cannot be empty' })
  @IsString({ message: 'Channel ID must be string' })
  channelId: string;

  @ApiProperty({
    description: 'Channel platform',
    enum: ChatPlatformEnum,
    example: ChatPlatformEnum.Facebook
  })
  @IsNotEmpty({ message: 'Platform cannot be empty' })
  @IsEnum(ChatPlatformEnum, { message: 'Invalid platform' })
  platform: ChatPlatformEnum;


  @ApiProperty({
    description: 'Access token of the platform',
    example: 'xxx'
  })
  @IsOptional()
  @IsString({ message: 'Access token must be string' })
  accessToken?: string;

  @ApiProperty({
    description: 'Is admin of the platform',
    example: true
  })
  @IsOptional()
  @IsBoolean({ message: 'Is admin must be boolean' })
  isAdmin?: boolean;
} 