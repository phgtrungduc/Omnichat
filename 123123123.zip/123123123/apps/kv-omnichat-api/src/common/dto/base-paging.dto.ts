import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString } from "class-validator";

export class BasePagingDto<T> {
    @IsNotEmpty()
    @ApiProperty({
        description: 'The data',
        example: [],
        required: false
    })
    data: T[] | T;

    @IsNotEmpty()
    @IsString()
    @ApiProperty({
        description: 'Has more',
        example: true,
        required: false
    })
    hasMore: boolean;        
}