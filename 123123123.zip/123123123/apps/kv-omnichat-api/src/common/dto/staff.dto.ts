import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsOptional } from 'class-validator';
import { IChatStaff } from '@kiotviet-facebook-services/common';

export class StaffSearchDto {
  @ApiProperty({
    description: 'Page IDs separated by comma',
    example: 'page1,page2,page3',
    required: true
  })
  @IsString()
  pageId: string;
}

export class StaffResponseDto implements IChatStaff {
  @ApiProperty({
    description: 'Staff ID',
    example: 'staff_123'
  })
  staffId: string;

  @ApiProperty({
    description: 'Page ID',
    example: 'page_123'
  })
  pageId: string;

  @ApiProperty({
    description: 'Channel ID',
    example: 'page_123'
  })
  channelId: string;

  @ApiProperty({
    description: 'Staff name',
    example: 'John Doe'
  })
  name: string;

  @ApiProperty({
    description: 'Staff picture URL',
    example: 'https://example.com/avatar.jpg'
  })
  picture: string;

  @ApiProperty({
    description: 'App user ID',
    example: 'app_user_123'
  })
  appUserId: string;

  @ApiProperty({
    description: 'Staff state',
    example: 1
  })
  state: number;

  @ApiProperty({
    description: 'Last assigned timestamp',
    example: 1640995200000
  })
  lastAssigned: number;

  @ApiProperty({
    description: 'Assignment turn',
    example: 1
  })
  assignmentTurn: number;

  @ApiProperty({
    description: 'Socket IDs',
    example: ['socket_1', 'socket_2']
  })
  socketIds: string[];

  @ApiProperty({
    description: 'Timestamp',
    example: 1640995200000
  })
  timestamp: number;

  @ApiProperty({
    description: 'Keep for filter',
    example: false,
    required: false
  })
  keepForFilter?: boolean;

  @ApiProperty({
    description: 'Is role admin',
    example: false,
    required: false
  })
  isRoleAdmin?: boolean;

  @ApiProperty({
    description: 'Platform',
    example: 'facebook',
    enum: ['facebook', 'shopee']
  })
  platform: any; // ChatPlatformEnum

  @ApiProperty({
    description: 'Retailer ID',
    example: 12345
  })
  retailerId: number;

  // Legacy field for backward compatibility
  @ApiProperty({
    description: 'Staff ID (legacy field)',
    example: 'staff_123'
  })
  _id: string;
}

export class AssignStaffDto {
  // TODO: Define properties
} 