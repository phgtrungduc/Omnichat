import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty, IsOptional, IsString } from "class-validator";
import { ChatPlatformEnum } from "@kiotviet-facebook-services/common";

export class BaseParamsDto {
    @IsEnum(ChatPlatformEnum)
    @IsNotEmpty()
    @ApiProperty({
        description: 'The platform',
        example: ChatPlatformEnum.Facebook,
        enum: ChatPlatformEnum,
        required: false
    })
    platform: ChatPlatformEnum;

    @IsNotEmpty()
    @IsString()
    @ApiProperty({
        description: 'The page id/ shopid',
        example: '101077151865360',
        required: false
    })
    channelId: string;        
}