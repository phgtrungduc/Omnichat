import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsArray, ValidateNested, IsOptional, IsString } from 'class-validator';
import { Type } from 'class-transformer';
import { ChatPlatformEnum } from '@kiotviet-facebook-services/common';

export enum ConversationStatusTypeEnum {
  READ = 'read',
  RESOLVED = 'resolved'
}

export enum ConversationStatusActionEnum {
  MARK = 'mark',      
  UNMARK = 'unmark'   
}

export class ConversationIdentifierDto {
  @IsString()
  @ApiProperty({ description: 'Conversation id' })
  conversationId: string;

  @IsString()
  @ApiProperty({ description: 'Channel Id' })
  channelId: string;

  @IsEnum(ChatPlatformEnum)
  @ApiProperty({ 
    enum: ChatPlatformEnum,
    description: 'Platform'
  })
  platform: ChatPlatformEnum;

  @IsOptional()
  @IsString()
  @ApiProperty({ 
    required: false,
    description: 'Facebook User Name (Facebook)'
  })
  fbName?: string;

  @IsOptional()
  @IsString()
  @ApiProperty({ 
    required: false,
    description: 'Last Read Message Id (Shopee)'
  })
  lastReadMessageId?: string;
}

export class MarkConversationStatusDto {
  @IsEnum(ConversationStatusTypeEnum)
  @ApiProperty({ 
    enum: ConversationStatusTypeEnum,
    description: 'Loại trạng thái cần cập nhật'
  })
  statusType: ConversationStatusTypeEnum;

  @IsEnum(ConversationStatusActionEnum)
  @ApiProperty({ 
    enum: ConversationStatusActionEnum,
    description: 'Hành động: đánh dấu hoặc bỏ đánh dấu'
  })
  action: ConversationStatusActionEnum;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ConversationIdentifierDto)
  @ApiProperty({ 
    type: [ConversationIdentifierDto],
    description: 'Danh sách hội thoại cần cập nhật trạng thái'
  })
  conversations: ConversationIdentifierDto[];

}

export class ConversationStatusResultDto {
  @ApiProperty({ description: 'ID hội thoại' })
  conversationId: string;

  @ApiProperty({ description: 'ID kênh/page' })
  channelId: string;

  @ApiProperty({ enum: ChatPlatformEnum })
  platform: ChatPlatformEnum;

  @ApiProperty({ description: 'Trạng thái cập nhật thành công' })
  success: boolean;

  @ApiProperty({ required: false, description: 'Thông báo lỗi nếu có' })
  error?: string;

  @ApiProperty({ required: false, description: 'Dữ liệu phản hồi từ platform gốc' })
  platformData?: any;
}

export class MarkConversationStatusResponseDto {
  @ApiProperty({ description: 'Trạng thái tổng quát' })
  success: boolean;

  @ApiProperty({ description: 'Tổng số hội thoại được xử lý' })
  totalProcessed: number;

  @ApiProperty({ description: 'Số hội thoại thành công' })
  successCount: number;

  @ApiProperty({ description: 'Số hội thoại thất bại' })
  failureCount: number;

  @ApiProperty({ type: [ConversationStatusResultDto] })
  results: ConversationStatusResultDto[];

  @ApiProperty({ required: false, description: 'Thông báo chung' })
  message?: string;
} 