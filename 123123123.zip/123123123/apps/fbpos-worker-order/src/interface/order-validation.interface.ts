import { ErrorValidateOrderFBPosCode } from "../common/order-fbpos.enum";

export interface IOrderValidationError {
    Field: string;
    FieldId: string;
    Message: string;
    Code: ErrorValidateOrderFBPosCode;
    AdditionalData?: {
        ProductCode?: string;
        ProductName?: string;
        Id?: number;
    };
}