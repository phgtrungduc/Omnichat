import { Module } from '@nestjs/common';
import { CoreModule } from './core/core.module';
import { CreateKvOrderModule } from './modules/create-kv-order/create-kv-order.module';
import { CreateLivestreamCartModule } from './modules/create-livestream-cart/create-livestream-cart.module';
import { AlertNotificationModule } from '@kiotviet-facebook-services/alert-notification';
import { CacheModule } from "@kiotviet-facebook-services/cache";

@Module({
  imports: [
      CoreModule,
      CreateKvOrderModule,
      CreateLivestreamCartModule,
      AlertNotificationModule,
      CacheModule,
  ],
  controllers: [],
  providers: [
  ],
})
export class AppModule { }
