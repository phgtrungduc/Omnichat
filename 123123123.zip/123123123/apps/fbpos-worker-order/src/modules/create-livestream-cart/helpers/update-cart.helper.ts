import {
    FbLivestreamScriptDocument,
    TiktokLivestreamScriptDocument
} from "@kiotviet-facebook-services/fbpos-master-repository";
import { ICreateLivestreamCartPayload } from "../interface/create-livestream-cart.interface";
import { ITiktokValidateLiveComment } from "@kiotviet-facebook-services/common";

/*
 * Thêm comment
 * Đúng cú pháp, tìm thấy sản phẩm thì thêm sản phẩm vào giỏ hàng.
 * Sai cú pháp hoặc không có ProductId tìm thấy, thì không xử lý gì
 */
export const getChangeDataCommentAdded = (payload: ICreateLivestreamCartPayload, livestreamScript: FbLivestreamScriptDocument, productCarts = []) => {
    const {products, LiveStreamFormula} = livestreamScript;
    const {PreventCreatingOrderWhenOutOfQuantity = true} = LiveStreamFormula;
    const {_id: CommentId, quantity: newQuantity, productIdFound: newProductId, TimeStamp, PhoneNumber} = payload;
    if (!newProductId) {
        return {productCarts, newQuantity, newProductId, oldQuantity: 0, oldProductId: null};
    }

    const foundProduct = products.find(product => product.KvProductId === newProductId);
    let isPreventCreateCart = false; // Có xử lý giỏ hàng không khi quá số lượng
    let isOutOfQuantity = false;

  let newCommentTrack = {
    CommentId,
    Quantity: newQuantity,
    TimeStamp, PhoneNumber,
    KeywordCreateOrder: payload.KeywordCreateOrder,
    IsOutOfQuantity: false
  };
    //#region Trường hợp tìm thấy sản phẩm đã có trong giỏ hàng
    if (productCarts && productCarts.length) {
        const foundProductCart = productCarts.find(product => product.KvProductId === newProductId);
        if (foundProductCart) {
            // Check trùng comment
            const foundComment = (foundProductCart.Comments || []).find(comment => comment.CommentId === CommentId);
            if (foundComment) {
                return {productCarts, newQuantity: 0, newProductId, oldQuantity: 0, oldProductId: null};
            }

            // Nếu quá số lượng, chặn thêm giỏ hàng
            isPreventCreateCart = PreventCreatingOrderWhenOutOfQuantity && (newQuantity + foundProduct.OrderQuantity) > foundProduct.SellQuantity;
            isOutOfQuantity = (newQuantity + foundProduct.OrderQuantity) > foundProduct.SellQuantity;
            if (isPreventCreateCart) {
                return {
                    productCarts,
                    newQuantity,
                    newProductId,
                    oldQuantity: 0,
                    oldProductId: null,
                    isPreventCreateCart,
                    isOutOfQuantity
                };
            }
            newCommentTrack = {
              ... newCommentTrack,
              IsOutOfQuantity: isOutOfQuantity
            }
            foundProductCart.Quantity += newQuantity;
            foundProductCart.Comments = foundProductCart.Comments && foundProductCart.Comments.length ? [...foundProductCart.Comments, newCommentTrack] : [newCommentTrack];
            return {productCarts, newQuantity, newProductId, oldQuantity: 0, oldProductId: null, isPreventCreateCart, isOutOfQuantity};
        }
    }
    //#endregion

    //#region Trường hợp sản phẩm chưa có trong giỏ hàng
    // const foundProduct = products.find(product => product.KvProductId === newProductId);
    if (foundProduct) {
        // Nếu quá số lượng, chặn thêm giỏ hàng
        isPreventCreateCart = PreventCreatingOrderWhenOutOfQuantity && (newQuantity + (foundProduct.OrderQuantity || 0)) > (foundProduct.SellQuantity || 0);
        isOutOfQuantity = newQuantity + (foundProduct.OrderQuantity || 0) > (foundProduct.SellQuantity || 0);
        if (!isPreventCreateCart) {
            newCommentTrack = {
              ...newCommentTrack,
              IsOutOfQuantity: isOutOfQuantity
            };
            productCarts.push({
                KvProductId: newProductId,
                Quantity: newQuantity,
                Price: foundProduct.Price,
                Comments: [newCommentTrack],
            });
        }
    }
    //#endregion

  return {
    productCarts,
    newQuantity,
    newProductId,
    oldQuantity: 0,
    oldProductId: null,
    isPreventCreateCart,
    isOutOfQuantity
  };
}

/**
 * Xóa comment: Tìm sản phẩm của comment đó, và xóa nó khỏi giỏ hàng
 */
export const getChangeDataCommentRemoved = (payload: ICreateLivestreamCartPayload, productCarts = []) => {
    let newQuantity = 0;
    let newProductId = '';
    const {_id: CommentId} = payload;
    if (productCarts && productCarts.length) {
        productCarts.forEach(product => {
            const {Comments} = product;
            const foundComment = (Comments || []).find(comment => comment.CommentId === CommentId);
            if (foundComment) {
                newQuantity = -foundComment.Quantity;
                product.Comments = (product.Comments || []).filter(comment => comment.CommentId !== CommentId);
                product.Quantity = product.Quantity + newQuantity;
                newProductId = product.KvProductId;
                return;
            }
        })
    }
    return {productCarts, newQuantity, newProductId, oldQuantity: 0, oldProductId: null};
}

/**
 * Cập nhật comment: Cật nhật lại sản phẩm | Số lượng | hoặc xóa sản phẩm nếu k đúng cú pháp
 */
export const getChangeDataCommentEdited = (jsonData: ICreateLivestreamCartPayload, livestreamScript: FbLivestreamScriptDocument, productCarts = []) => {
    const {products, LiveStreamFormula} = livestreamScript;
    const {PreventCreatingOrderWhenOutOfQuantity = true} = LiveStreamFormula;
    let isPreventCreateCart = false; // Có xử lý giỏ hàng không khi quá số lượng

    let {
        _id: CommentId,
        quantity: newQuantity,
        productIdFound: newProductId,
        IsValidateFormula,
        TimeStamp,
        PhoneNumber
    } = jsonData;
    const newCommentTrack = {CommentId, Quantity: newQuantity, TimeStamp, PhoneNumber};
    let oldQuantity = 0, oldProductId = null;

    //#region Trường hợp tìm thấy sản phẩm đã có trong giỏ hàng
    if (productCarts && productCarts.length) {
        productCarts.forEach(product => {
            const {Comments} = product;
            // Nếu comment đó chỉ thay đổi số lượng vẫn update cho sản phẩm đó
            // Ex: A1 2 => A1 5
            if (newProductId === product.KvProductId) {
                const foundComment = (Comments || []).find(comment => comment.CommentId === CommentId);
                // Edit lại số lượng hoặc thêm mới
                if (foundComment) {
                    if (IsValidateFormula) {
                        const old = foundComment.Quantity;
                        foundComment.Quantity = newQuantity;
                        newQuantity -= old;
                        product.Quantity = product.Quantity + newQuantity;
                    } else {
                        // Sai cú pháp thì xóa số lượng đi
                        newQuantity = -foundComment.Quantity;
                        product.Quantity = product.Quantity + newQuantity;
                        product.Comments = (product.Comments || []).filter(comment => comment.CommentId !== CommentId);
                    }
                } else {
                    product.Quantity += newQuantity;
                    product.Comments = product.Comments && product.Comments.length ? [...product.Comments, newCommentTrack] : [newCommentTrack];
                }
            } else {
                // Edit comment mà khác sản phẩm thì xóa sản phẩm trong giỏ đi.
                // Ex: A1 2 => A2 2
                const foundComment = (Comments || []).find(comment => comment.CommentId === CommentId);
                if (foundComment) {
                    oldProductId = product.KvProductId;
                    oldQuantity = -foundComment.Quantity;
                    product.Quantity += oldQuantity;
                    product.Comments = (product.Comments || []).filter(comment => comment.CommentId !== CommentId);
                }
            }
        })

        // return { productCarts, newQuantity, newProductId, oldQuantity, oldProductId };
    }
    //#endregion
    const isFoundProductAdded = productCarts.find(product => product.KvProductId === newProductId);
    //#region Trường hợp sản phẩm chưa có trong giỏ hàng
    const foundProduct = products.find(product => product.KvProductId === newProductId);
    if (foundProduct && !isFoundProductAdded) {
        isPreventCreateCart = PreventCreatingOrderWhenOutOfQuantity && (newQuantity + (foundProduct.OrderQuantity || 0)) > (foundProduct.SellQuantity || 0);
        if (!isPreventCreateCart) {
            productCarts.push({
                KvProductId: newProductId,
                Quantity: newQuantity,
                Price: foundProduct.Price,
                Comments: [newCommentTrack]
            });
        }

    }
    //#endregion

    return {productCarts, newQuantity, newProductId, oldQuantity, oldProductId, isPreventCreateCart};
}

/*
 * Thêm comment
 * Đúng cú pháp, tìm thấy sản phẩm thì thêm sản phẩm vào giỏ hàng.
 * Sai cú pháp hoặc không có ProductId tìm thấy, thì không xử lý gì
 */
export const getChangeDataTiktokCommentAdded = (payload: ITiktokValidateLiveComment, livestreamScript: TiktokLivestreamScriptDocument, productCarts = []) => {
    const {products, LiveStreamFormula} = livestreamScript;
    const {PreventCreatingOrderWhenOutOfQuantity = true} = LiveStreamFormula;
    const {
        id: CommentId,
        quantity: newQuantity,
        kvProductId: newProductId,
        createTime: TimeStamp,
        PhoneNumber
    } = payload;

    if (!newProductId) {
        return {productCarts, newQuantity, newProductId, oldQuantity: 0, oldProductId: null};
    }

    const foundProduct = products.find(product => product.KvProductId === newProductId);
    let isPreventCreateCart = false; // Có xử lý giỏ hàng không khi quá số lượng

    const newCommentTrack = {CommentId, Quantity: newQuantity, TimeStamp, PhoneNumber};
    //#region Trường hợp tìm thấy sản phẩm đã có trong giỏ hàng
    if (productCarts && productCarts.length) {
        const foundProductCart = productCarts.find(product => product.KvProductId === newProductId);

        if (foundProductCart) {
            // Check trùng comment
            const foundComment = (foundProductCart.Comments || []).find(comment => comment.CommentId === CommentId);
            if (foundComment) {
                return {productCarts, newQuantity: 0, newProductId, oldQuantity: 0, oldProductId: null};
            }

            // Nếu quá số lượng, chặn thêm giỏ hàng
            isPreventCreateCart = PreventCreatingOrderWhenOutOfQuantity && (newQuantity + (foundProduct.OrderQuantity || 0)) > (foundProduct.SellQuantity || 0);
            if (isPreventCreateCart) {
                return {
                    productCarts,
                    newQuantity,
                    newProductId,
                    oldQuantity: 0,
                    oldProductId: null,
                    isPreventCreateCart
                };
            }
            foundProductCart.Quantity += newQuantity;
            foundProductCart.Comments = foundProductCart.Comments && foundProductCart.Comments.length ? [...foundProductCart.Comments, newCommentTrack] : [newCommentTrack];
            return {productCarts, newQuantity, newProductId, oldQuantity: 0, oldProductId: null, isPreventCreateCart};
        }
    }
    //#endregion

    //#region Trường hợp sản phẩm chưa có trong giỏ hàng
    // const foundProduct = products.find(product => product.KvProductId === newProductId);
    if (foundProduct) {
        // Nếu quá số lượng, chặn thêm giỏ hàng
        isPreventCreateCart = PreventCreatingOrderWhenOutOfQuantity && (newQuantity + (foundProduct.OrderQuantity || 0)) > (foundProduct.SellQuantity || 0);
        if (!isPreventCreateCart) {
            productCarts.push({
                KvProductId: newProductId,
                Quantity: newQuantity,
                Price: foundProduct.Price,
                Comments: [newCommentTrack]
            });
        }
    }
    //#endregion

    return {productCarts, newQuantity, newProductId, oldQuantity: 0, oldProductId: null, isPreventCreateCart};
}

export const calculateRevenue = (items: { Quantity: number; Price: number }[]) =>
    items.reduce((acc, item) => acc + item.Quantity * item.Price, 0);
