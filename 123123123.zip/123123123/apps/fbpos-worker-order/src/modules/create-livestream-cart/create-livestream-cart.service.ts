import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
  CartStatusEnum,
  ConversationStates,
  ERROR_MESSAGE_REDLOCK,
  EventTypes,
  KvBaseException,
  KvLogger,
  KvRabbitMQException,
  RabbitMqConfigAutoSendMessageFollowLivestreamScript,
  RabbitMqConfigKvOrder,
  RabbitMqConfigLivestreamCart,
  RabbitMqConfigNotification,
  RabbitMqConfigReportLivestreamProduct,
  SocialTypes
} from '@kiotviet-facebook-services/common';
import {
  FbCartsService,
  FbLivestreamScriptDocument,
  FbLivestreamScriptService,
  FbUserProfileService,
  MongodbGroupService
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { AutoReplyLivestreamMessage } from '@kiotviet-facebook-services/kv-internal-api';
import { RedisLockService, REDLOCK_CONST } from '@kiotviet-facebook-services/lock';
import { Injectable } from '@nestjs/common';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
import { ICreateKvOrderPayload } from "../create-kv-order/interface/create-kv-order.interface";
import {
  getChangeDataCommentAdded,
  getChangeDataCommentEdited,
  getChangeDataCommentRemoved
} from './helpers/update-cart.helper';
import { ICreateLivestreamCartPayload } from './interface/create-livestream-cart.interface';

const config = require('config');

@Injectable()
export class CreateLivestreamCartService {
  private readonly _rabbitMQConfig;

  constructor(
    private readonly _logger: KvLogger,
    private readonly _fbUserProfileService: FbUserProfileService,
    private readonly _mongodbGroupService: MongodbGroupService,
    private readonly _redlockService: RedisLockService,
    private readonly _amqpConnection: AmqpConnection,
    private readonly _fbLivestreamScriptService: FbLivestreamScriptService,
    private readonly _fbCartService: FbCartsService,
  ) {
    this._rabbitMQConfig = config.get('rabbitMQ');
  }

  prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

  @RabbitSubscribe({
    exchange: config.get('rabbitMQ').mainExchange,
    routingKey: RabbitMqConfigLivestreamCart.ROUTING_KEY,
    queue: `fbpos-worker-order:${RabbitMqConfigLivestreamCart.QUEUE_NAME}`,
    queueOptions: {
      durable: true,
      arguments: { 'x-queue-type': 'quorum' },
    },
  })
  private async _createLivestreamCart(payload: ICreateLivestreamCartPayload) {
    const prefixLog = this.prefixLog('_createLivestreamCart');
    const { PageId, InstagramId, videoId, productIdFound, quantity, EventType, SenderId, RetailerCode, RetailerId, BranchId } = payload;

    const logInput: IKvLogInput = {
      MessageTemplate: { payload },
      Properties: {
        'Kv.RetailerCode': RetailerCode,
        'Kv.RetailerId': RetailerId,
        'Kv.BranchId': BranchId,
        'Kv.SocialId': InstagramId || PageId,
        'Kv.SocialType': InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
        SourceContext: prefixLog,
        _startTime: Date.now()
      }
    }

    this._logger.info(logInput, `${prefixLog} received payload`);

    try {
      // Không có số lượng thì k tính toán
      if (!videoId || (productIdFound && !quantity && EventTypes.CommentAdded === EventType)) {
        this._sentEventToMQForAutoSendMessage(payload, AutoReplyLivestreamMessage.ValidComment);
        return Promise.resolve();
      }
      const livestreamScript = await this._fbLivestreamScriptService.getFbLivestreamScript('', { videoId });
      if (!livestreamScript || !livestreamScript.LiveStreamFormula.Fields?.length) {
        this._sentEventToMQForAutoSendMessage(payload, AutoReplyLivestreamMessage.ValidComment);
        return Promise.resolve();
      }

      const lock = await this._redlockService.acquire([`${REDLOCK_CONST.LOCK_KEYS.CREATE_LIVESTREAM_CART.NAME}${videoId}:${SenderId}`],
        REDLOCK_CONST.LOCK_KEYS.CREATE_LIVESTREAM_CART.TTL, {});
      // Khi Tự động tạo đơn đặng hàng, cũng update cart trong database, nên khi 2 luồng cùng chaỵ sẽ làm lỗi dữ liệu cart
      const lockCreatingOrder = await this._redlockService.acquire([`${REDLOCK_CONST.LOCK_KEYS.CREATE_KV_ORDERS.NAME}${videoId}`],
        REDLOCK_CONST.LOCK_KEYS.CREATE_KV_ORDERS.TTL, {});

      const {
        newQuantity,
        newProductId,
        oldQuantity,
        oldProductId,
        isPreventCreateCart,
        isOutOfQuantity
      } = await this._saveCart(payload, livestreamScript);

      this.handleOutOfQuantityMessage(payload, livestreamScript, isOutOfQuantity, isPreventCreateCart);

      if (!isPreventCreateCart) {
        this._sendReportLivestreamEventToMQ({
          newQuantity,
          newProductId,
          oldQuantity,
          oldProductId,
          isPreventCreateCart,
          PageId,
          videoId
        });
        this._sentEventToMQForCreatingOrder({
          PageId,
          VideoId: videoId,
        });
      }

      await Promise.all([
        this._redlockService.release(lock),
        this._redlockService.release(lockCreatingOrder)
      ]);
    } catch (err) {
      if (err?.message.includes(ERROR_MESSAGE_REDLOCK)) {
        return Promise.reject();
      }
      this._logger.error({ ...logInput, Error: new KvBaseException(err.stack) }, `${prefixLog} fail`);
    }

    this._logger.info(logInput, `${prefixLog} success`);

    return Promise.resolve();
  }

  private handleOutOfQuantityMessage(payload: ICreateLivestreamCartPayload, livestreamScript: any, isOutOfQuantity: boolean, isPreventCreateCart: boolean) {
    const { productIdFound } = payload;
    const productInScript = livestreamScript.products?.find(x => x.KvProductId == productIdFound);

    if (isOutOfQuantity) {
      //event will not be sent to createorderService -> handle only here
      if (livestreamScript.LiveStreamFormula.AutoSendMessageWhenOutOfQuantity?.Status
        && livestreamScript.LiveStreamFormula.AutoSendMessageWhenOutOfQuantity?.Content) {
        this._sentEventToMQForAutoSendMessage(payload, AutoReplyLivestreamMessage.OutOfQuantityOrder);
      } else {
        if (productInScript && productInScript.SellQuantity <= 0) return;
        if (livestreamScript.LiveStreamFormula.AutoSendMessageWithValidComment?.Status
          && livestreamScript.LiveStreamFormula.AutoSendMessageWithValidComment?.Content) {
          this._sentEventToMQForAutoSendMessage(payload, AutoReplyLivestreamMessage.ValidComment);
        }
      }
    } else {
      if (productInScript && productInScript.SellQuantity <= 0) return;
      //will have a event sent from here to CreateOrderService -> handle here and handle in CreateOrderService
      if (livestreamScript.LiveStreamFormula.AutoSendMessageWithValidComment?.Status
        && livestreamScript.LiveStreamFormula.AutoSendMessageWithValidComment?.Content && isPreventCreateCart) {
        this._sentEventToMQForAutoSendMessage(payload, AutoReplyLivestreamMessage.ValidComment);
      }
    }
  }

  private _sentEventToMQForAutoSendMessage(payload: ICreateLivestreamCartPayload, type: number) {
    if (!payload.IsValidateFormula || payload.PageId == payload.SenderId) return;
    const payloadSendMessage = {
      Type: type,
      CommentId: payload._id,
      PageId: payload.PageId,
      FbUserId: payload.SenderId,
      KeywordCreateOrder: payload.KeywordCreateOrder,
      VideoId: payload.videoId,
      PhoneNumberFound: payload.PhoneNumber
    };
    this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigAutoSendMessageFollowLivestreamScript.ROUTING_KEY, payloadSendMessage).catch(err => {
      const prefixLog = this.prefixLog('_sentEventToMQForAutoSendMessage');
      this._logger.error({ MessageTemplate: { payload, type }, Error: err }, `${prefixLog} fail`);
    });
  }

  private async _saveCart(payload: ICreateLivestreamCartPayload, livestreamScript: FbLivestreamScriptDocument) {
    const {
      SenderId,
      RetailerId,
      PriceBookId,
      PriceBookName,
      BranchId,
      EventType,
      PageId,
      videoId,
      _id: CommentId
    } = payload;

    const eventFromPage = SenderId === PageId; // Trường hợp page xóa comment của user thì không tìm thấy được SenderId của comment xóa đó
    const cachedValue = !eventFromPage ? await this._fbCartService.handleReadFbCart(SenderId, videoId) : await this._fbCartService.handleReadFbCartByCommentId(CommentId, videoId);
    let productCarts = cachedValue && cachedValue.products || [];
    let changeInfomation;
    switch (true) {
      case EventTypes.CommentRemoved === payload.EventType || (EventTypes.CommentEdited === payload.EventType && !payload.productIdFound):
        changeInfomation = getChangeDataCommentRemoved(payload, productCarts);
        break;
      case EventTypes.CommentEdited === payload.EventType:
        changeInfomation = getChangeDataCommentEdited(payload, livestreamScript, productCarts);
        break;
      default:
        changeInfomation = getChangeDataCommentAdded(payload, livestreamScript, productCarts);
        break
    }
    const {
      newQuantity,
      newProductId,
      oldQuantity,
      oldProductId,
      productCarts: changeProductCarts,
      isPreventCreateCart,
      isOutOfQuantity
    } = changeInfomation;
    productCarts = changeProductCarts.slice().filter(product => product.Quantity > 0 && product.Comments && product.Comments.length);
    const fbUserId = !eventFromPage ? SenderId : (cachedValue && cachedValue.fbUserId);

    const hasProductInCart = productCarts && productCarts.length;
    const hasUpdatedResolved = cachedValue && cachedValue.isResolved;
    const hasCreatedOrder = cachedValue && cachedValue.kvOrders && cachedValue.kvOrders.length > 0;
    this._updateConversationWhenOutOfQuantity(payload, isPreventCreateCart);

    if (hasProductInCart || hasUpdatedResolved || hasCreatedOrder) {
      await this._fbCartService.handleUpdateFbCart({
        fbUserId,
        videoId: livestreamScript.videoId,
        pageId: PageId,
        retailerId: RetailerId,
        branchId: BranchId,
        priceBookId: PriceBookId || livestreamScript.priceBookId,
        priceBookName: PriceBookName || livestreamScript.priceBookName,
        status: CartStatusEnum.UNRESOLVED,
        products: productCarts,
        ...EventTypes.CommentAdded === EventType && { isResolved: ConversationStates.UNRESOLVED }
      }, true);
    } else if (cachedValue) {
      await this._fbCartService.deleteOneFbCartById(cachedValue._id);
      await this._removeLivestreamInfoFromFBUserProfile(livestreamScript.videoId, fbUserId);
    }
    return { newQuantity, newProductId, oldQuantity, oldProductId, productCarts, isPreventCreateCart, isOutOfQuantity };

  }

  private _sentEventToMQForCreatingOrder(payload: ICreateKvOrderPayload) {
    this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigKvOrder.ROUTING_KEY, payload).catch(err => {
      const prefixLog = this.prefixLog('_sentEventToMQForCreatingOrder');
      this._logger.error({ MessageTemplate: { payload }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
    });
  }

  private async _updateConversationWhenOutOfQuantity(payload: ICreateLivestreamCartPayload, isPreventCreateCart: boolean) {
    if (!isPreventCreateCart) {
      return;
    }
    const { PageId, _id: id, GroupId, videoId } = payload;
    const db = await this._mongodbGroupService.getDatabase({ socialId: PageId });
    await db.collection(PageId).updateOne({ _id: id }, { $set: { IsOutOfQuantity: true } });
    await db.collection(`${PageId}_conversations`).updateOne({ _id: GroupId }, { $set: { IsOutOfQuantity: true } });
    this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigNotification.ROUTING_KEY, {
      PageId: PageId,
      VideoId: videoId,
      _id: id,
      IdMessage: id,
      EventType: EventTypes.ConversationUpdate,
      ConversationId: GroupId,
      Id: GroupId,
      IsOutOfQuantity: true
    }).catch(err => {
      const prefixLog = this.prefixLog('_updateConversationWhenOutOfQuantity');
      this._logger.error({ MessageTemplate: { payload, isPreventCreateCart }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
    });
  }

  private async _removeLivestreamInfoFromFBUserProfile(videoId: string, fbUserId: string) {
    await this._fbUserProfileService.handleUpdateFbUserProfile({
      id: fbUserId,
      $pull: { "livestreamInfoes": { "videoId": videoId } }
    }, true)
  }

  private _sendReportLivestreamEventToMQ({
    videoId,
    PageId,
    newQuantity,
    newProductId,
    oldQuantity,
    oldProductId,
    isPreventCreateCart
  }) {
    const changeProducts = [];
    if (newProductId !== null) {
      changeProducts.push({ productId: newProductId, quantity: newQuantity });
    }
    if (oldProductId !== null) {
      changeProducts.push({ productId: oldProductId, quantity: oldQuantity });
    }
    this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigReportLivestreamProduct.ROUTING_KEY, {
      videoId,
      pageId: PageId,
      changeProducts,
    }
    ).catch(err => {
      const prefixLog = this.prefixLog('_sendReportLivestreamEventToMQ');
      this._logger.error({ MessageTemplate: { videoId, PageId, newQuantity, newProductId, oldQuantity, oldProductId, isPreventCreateCart }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
    });
  }

}
