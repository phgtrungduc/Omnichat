import { IFeed } from "@kiotviet-facebook-services/common";

export interface ICreateLivestreamCartPayload extends IFeed {
    RetailerId: string;
    RetailerCode: string;
    BranchId: string;
    PageId: string;
    PhoneNumber: string;

    // For livestream
    PriceBookId: number;
    PriceBookName: string;
    IsAutoCreateKvCustomer: boolean;
    IsValidateFormula: boolean;
    IsAlmostValidate: boolean;
    videoId: string;
    productIdFound: number;
    quantity: number;
    KeywordCreateOrder?: string;
}
