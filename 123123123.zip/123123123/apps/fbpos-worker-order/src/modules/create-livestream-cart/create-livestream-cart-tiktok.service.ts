import {
    CartStatusEnum,
    ERROR_MESSAGE_REDLOCK,
    ITiktokValidateLiveComment,
    KvBaseException,
    KvLogger,
    KvRabbitMQException,
    RabbitMqConfigKvOrderTiktokLive,
    RabbitMqConfigLivestreamTiktokCart,
    RabbitMqConfigTiktokNotification,
    TiktokEventTypes
} from '@kiotviet-facebook-services/common';
import { Injectable } from '@nestjs/common';
import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import { pick } from 'lodash';
import {
    MongodbGroupService,
    TiktokCartsService,
    TiktokLivestreamScriptDocument,
    TiktokLivestreamScriptService
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { RedisLockService, REDLOCK_CONST } from '@kiotviet-facebook-services/lock';
import { getChangeDataTiktokCommentAdded } from './helpers/update-cart.helper';
import { Types } from "mongoose";

const config = require('config');

interface ITiktokScriptChange {
    kvProduct: {
        kvProductId: number;
        orderQuantity: number;
    },
    isWarningOutOfQuantity?: boolean;
}

@Injectable()
export class CreateLivestreamCartTiktokService {
    private readonly _rabbitMQConfig;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _redlockService: RedisLockService,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _tiktokLivestreamScriptService: TiktokLivestreamScriptService,
        private readonly _tiktokCartService: TiktokCartsService,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigLivestreamTiktokCart.ROUTING_KEY,
        queue: `fbpos-worker-order:${RabbitMqConfigLivestreamTiktokCart.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: {'x-queue-type': 'quorum'},
        },
    })
    private async _createLivestreamTiktokCart(payload: ITiktokValidateLiveComment) {
        const prefixLog = this.prefixLog('_createLivestreamTiktokCart');
        const baseInfoLog = {Context: {payload}, SourceContext: '_createLivestreamTiktokCart'};
        this._logger.info(`${prefixLog} received payload`, baseInfoLog);
        const {livestreamScriptId, kvProductId, quantity, userId} = payload;
        try {
            if (!livestreamScriptId || (kvProductId && !quantity)) {
                this._logger.warn(`${prefixLog} warning: livestreamScriptId | kvProductId | quantity is required`, baseInfoLog);
                return Promise.resolve();
            }
            const tiktokLivestreamScript = await this._tiktokLivestreamScriptService.findById(livestreamScriptId);
            if (!tiktokLivestreamScript || !tiktokLivestreamScript.products?.length) {
                this._logger.warn(`${prefixLog} warning: Tiktok livestream not setup successfully`, baseInfoLog);
                return Promise.resolve();
            }

            const lock = await this._redlockService.acquire([`${REDLOCK_CONST.LOCK_KEYS.CREATE_TIKTOK_LIVESTREAM_CART.NAME}${livestreamScriptId}:${userId}`],
                REDLOCK_CONST.LOCK_KEYS.CREATE_TIKTOK_LIVESTREAM_CART.TTL, {});
            const {
                newProductId,
                isPreventCreateCart,
            } = await this._saveCart(payload, tiktokLivestreamScript);
            const updateChange = await this._updateRevenueAndOrderQuantity(tiktokLivestreamScript, newProductId, isPreventCreateCart);

            if (!isPreventCreateCart) {
                this._sendCreateOrderEventToMQ(payload, updateChange);
            }
            if (updateChange.isWarningOutOfQuantity) {
                this._sendWarningOfQuantityEventToMQ(payload);
            }
            if (updateChange.kvProduct) {
                this._sendUpdateKvProductEventToMQ(payload, updateChange);
            }
            if (isPreventCreateCart) {
                this._sendUpdateOutOfQuantityCommentEventToMQ(payload);
            }
            await this._redlockService.release(lock).catch(e => this._logger.error(`${prefixLog} release lock err`, e)); // Release lock
            this._logger.info(`${prefixLog} success`, baseInfoLog);
        } catch (err) {
            if (err?.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._logger.error(`${prefixLog} fail`, new KvBaseException(err.stack), {
                ...baseInfoLog,
                ErrorContext: pick(err, ['message', 'stack']),
            });

        }

        return Promise.resolve();
    }

    private async _saveCart(payload: ITiktokValidateLiveComment, tiktokLivestreamScript: TiktokLivestreamScriptDocument) {
        const {
            userId,
            livestreamScriptId,
            liveUserId,
            retailerId,
            branchId,
            priceBookName,
            priceBookId
        } = payload;

        const cachedValue = await this._tiktokCartService.handleReadTiktokCart(userId, livestreamScriptId)
        let productCarts = cachedValue && cachedValue.products || [];

        const {
            newQuantity,
            newProductId,
            oldQuantity,
            oldProductId,
            productCarts: changeProductCarts,
            isPreventCreateCart,
        } = getChangeDataTiktokCommentAdded(payload, tiktokLivestreamScript, productCarts);

        productCarts = changeProductCarts.slice().filter(product => product.Quantity > 0 && product.Comments && product.Comments.length);
        const hasProductInCart = productCarts?.length;
        const hasCreatedOrder = cachedValue?.kvOrders?.length > 0;
        await this._updateCommentWhenOutOfQuantity(payload, isPreventCreateCart);

        if (hasProductInCart || hasCreatedOrder) {
            await this._tiktokCartService.handleUpdateTiktokCart({
                userId,
                livestreamScriptId,
                liveUserId,
                retailerId,
                branchId,
                priceBookId: priceBookId || tiktokLivestreamScript.priceBookId,
                priceBookName: priceBookName || tiktokLivestreamScript.priceBookName,
                status: CartStatusEnum.UNRESOLVED,
                products: productCarts,
            }, true);
        }
        return {
            newQuantity,
            newProductId,
            oldQuantity,
            oldProductId,
            productCarts,
            isPreventCreateCart,
            cart: cachedValue
        };

    }

    private async _updateCommentWhenOutOfQuantity(payload: ITiktokValidateLiveComment, isPreventCreateCart: boolean) {
        if (!isPreventCreateCart) {
            return;
        }
        const {liveUserId, id} = payload;
        const db = await this._mongodbGroupService.getDatabase({type: 'tiktok'});
        await db.collection(this._mongodbGroupService.tiktokConversationDetailsCollName).updateOne({
            _id: id,
            liveUserId
        }, {$set: {IsOutOfQuantity: true}});
    }

    private _sendCreateOrderEventToMQ(payload: ITiktokValidateLiveComment, updateChange: ITiktokScriptChange) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange,
            RabbitMqConfigKvOrderTiktokLive.ROUTING_KEY,
            payload
        ).catch(err => {
            this._logger.error(`${this.prefixLog('_sendCreateOrderAndTiktokNotificationEventToMQ')} fail`,
                new KvRabbitMQException(err.stack), {
                    SourceContext: '_sendCreateOrderAndTiktokNotificationEventToMQ',
                    Context: payload,
                    ErrorContext: pick(err, ['message', 'stack'])
                });
        });
    }

    private _sendUpdateKvProductEventToMQ(payload: ITiktokValidateLiveComment, updateChange: ITiktokScriptChange) {
        const event = {
            event: TiktokEventTypes.UPDATE_ANALYTIC,
            ...pick(payload, "userId", "livestreamScriptId", "liveUserId"),
            ...updateChange
        }
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange,
            RabbitMqConfigTiktokNotification.ROUTING_KEY,
            event
        ).catch(err => {
            this._logger.error(`${this.prefixLog('_sendCreateOrderAndTiktokNotificationEventToMQ')} fail`,
                new KvRabbitMQException(err.stack), {
                    SourceContext: '_sendCreateOrderAndTiktokNotificationEventToMQ',
                    Context: payload,
                    ErrorContext: pick(err, ['message', 'stack'])
                });
        });
    }

    private _sendWarningOfQuantityEventToMQ(payload: ITiktokValidateLiveComment) {
        const event = {
            ...pick(payload, "userId", "livestreamScriptId", "liveUserId", "kvProductId", "id"),
            event: TiktokEventTypes.WARNING_OUT_OF_QUANTITY,
        }
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigTiktokNotification.ROUTING_KEY,
            event
        ).catch(err => {
            this._logger.error(`${this.prefixLog('_sendWarningOfQuantityEventToMQ')} fail`,
                new KvRabbitMQException(err.stack), {
                    SourceContext: '_sendWarningOfQuantityEventToMQ',
                    Context: payload,
                    ErrorContext: pick(err, ['message', 'stack'])
                });
        });
    }

    private _sendUpdateOutOfQuantityCommentEventToMQ(payload: ITiktokValidateLiveComment) {
        const event = {
            ...pick(payload, "userId", "livestreamScriptId", "liveUserId", "kvProductId", "id"),
            event: TiktokEventTypes.UPDATE_TIKTOK_COMMENT_OUT_OF_QUANTITY,
        }
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigTiktokNotification.ROUTING_KEY,
            event
        ).catch(err => {
            this._logger.error(`${this.prefixLog('_sendUpdateOutOfQuantityCommentEventToMQ')} fail`,
                new KvRabbitMQException(err.stack), {
                    SourceContext: '_sendUpdateOutOfQuantityCommentEventToMQ',
                    Context: payload,
                    ErrorContext: pick(err, ['message', 'stack'])
                });
        });
    }


    private async _updateRevenueAndOrderQuantity(
        tiktokLivestreamScript: TiktokLivestreamScriptDocument,
        newProductId: number,
        isPreventCreateCart = false
    ): Promise<ITiktokScriptChange> {
        if (isPreventCreateCart) {
            return {kvProduct: null};
        }
        let isWarningOutOfQuantity = false;
        const {products} = tiktokLivestreamScript;
        let orderQuantity = 0;
        products.forEach(product => {
            if (product.KvProductId === newProductId) {
                product.OrderQuantity = (product.OrderQuantity || 0) + 1;
                orderQuantity = product.OrderQuantity;
                isWarningOutOfQuantity = orderQuantity > product.SellQuantity;
            }
        })


        const {retailerId, retailerCode} = tiktokLivestreamScript;
        await this._tiktokLivestreamScriptService.updateTiktokLivestreamScript(
            retailerId,
            retailerCode,
            {_id: new Types.ObjectId(tiktokLivestreamScript['_id'] as any), products}
        )

        return {
            kvProduct: {
                kvProductId: newProductId, orderQuantity
            },
            isWarningOutOfQuantity
        };
    }


}
