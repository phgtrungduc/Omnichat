import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { LockModule } from '@kiotviet-facebook-services/lock';
import { CreateLivestreamCartService } from './create-livestream-cart.service';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { CreateLivestreamCartTiktokService } from "./create-livestream-cart-tiktok.service";

@Module({
  imports: [CommonModule, KvRabbitMQModule, LockModule, FbPosMasterRepositoryModule],
  providers: [CreateLivestreamCartService],
})
export class CreateLivestreamCartModule {
}
