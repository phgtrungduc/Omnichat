import {
    ERROR_MESSAGE_REDLOCK,
    EventTypes,
    extractTokens,
    KvLogger,
    KvOrderRetailerException,
    KvOrderSourceType,
    KvRabbitMQException,
    RabbitMqConfigAutoSendMessageTemplate,
    RabbitMqConfigKvOrderCatalog,
    RabbitMqConfigNotification,
    replaceTokens,
    sleep,
    SocialTypes
} from '@kiotviet-facebook-services/common';
import { Inject, Injectable } from '@nestjs/common';
import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    FbCatalogConnectionDocument,
    FbCatalogConnectionService,
    isAutoSendMessageWithOrderPreview,
    isAutoSendMessageWithoutOrderPreview,
    MongodbGroupService,
    PageSubscriptionService,
    RetailOrderRepository,
    WebhookSubscriptionRepository
} from '@kiotviet-facebook-services/fbpos-master-repository';

import { buildPayloadOrderCatalog } from './helpers/create-kv-order.helper';
import { pick } from 'lodash';
import { Cache, CACHE_MANAGER } from "@nestjs/cache-manager";
import { ICreateKvOrderCatalogPayload } from "./interface/create-kv-order.interface";
import {
    IMetaDataPayload
} from "../../../../fbpos-worker-chat-messaging/src/modules/auto-send-message/interface/message-create-order-payload.interface";
import { buildOrderData } from './helpers/build-order.helper';
import { AUTO_SOCIAL_ID, AUTO_SOCIAL_NAME } from "@kiotviet-facebook-services/kv-internal-api";
import { RedisLockService, REDLOCK_CONST } from "@kiotviet-facebook-services/lock";
import { KvOrderUtilsService } from "../kv-order-common/kv-order-utils.service";
import { ErrorValidateOrderFBPosCode } from '../../common/order-fbpos.enum';
import { IOrderValidationError } from '../../interface/order-validation.interface';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class CreateKvOrderCatalogService {
    private readonly _rabbitMQConfig;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _redlockService: RedisLockService,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _fbCatalogConnectionService: FbCatalogConnectionService,
        private readonly _retailOrderRepository: RetailOrderRepository,
        private readonly _pageSubscriptionService: PageSubscriptionService,
        private readonly _webhookSubscriptionRepository: WebhookSubscriptionRepository,
        private readonly _kvOrderUtilsService: KvOrderUtilsService,
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigKvOrderCatalog.ROUTING_KEY,
        queue: `fbpos-worker-order:${RabbitMqConfigKvOrderCatalog.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _createKvOrderCatalog(payload: ICreateKvOrderCatalogPayload) {
        const prefixLog = this.prefixLog('_createKvOrderCatalog');

        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.RetailerId': payload?.retailerId,
                'Kv.RetailerCode': payload?.retailerCode,
                'Kv.BranchId': payload?.branchId,
                'Kv.SocialId': payload?.InstagramId || payload?.PageId,
                'Kv.SocialType': payload?.InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        const { catalogId, socialUserKvCustomer, Order: order, PageId, TimeStamp, _id } = payload;
        if (!catalogId || !socialUserKvCustomer || !order.products?.length) {
            return Promise.resolve();
        }
        const { retailerCode, retailerId, branchId } = socialUserKvCustomer;
        try {
            const lock = await this._redlockService.acquire([`${REDLOCK_CONST.LOCK_KEYS.CREATE_KV_ORDERS_CATALOG.NAME}${retailerId}`], REDLOCK_CONST.LOCK_KEYS.CREATE_KV_ORDERS_CATALOG.TTL, {});
            const catalogConnection = await this._fbCatalogConnectionService.getCatalogConnection(retailerId, catalogId, PageId);
            if (!catalogConnection) {
                return Promise.resolve();
            }

            const db = await this._mongodbGroupService.getDatabase({ socialId: PageId });
            const exist = await db.collection(PageId).findOne({ _id }, { lean: true });
            if (exist?.Order?.kvOrderId) {
                await this._redlockService.release(lock);
                return Promise.resolve();
            }
            const { catalogName, pricebookId, pricebookName } = catalogConnection;
            const retailerIds = order.products.map(item => item.retailer_id);
            const productCatalogs = await db.collection(this._mongodbGroupService.productCatalogsCollName)
                .find({ pageId: PageId, catalogId, retailerId, id: { $in: retailerIds } })
                .project({ id: 1, kvProduct: 1 })
                .toArray();
            if (!productCatalogs.length) {
                await this._redlockService.release(lock);
                return Promise.resolve();
            }
            const socialInfo = await this._webhookSubscriptionRepository.getSubscriptionBySocialId(PageId, true);
            const socialName = socialInfo && (socialInfo.PageInfo && socialInfo.PageInfo['name'] || socialInfo.InstagramInfo && socialInfo.InstagramInfo['username']) || '';

            const payloadOrder = buildPayloadOrderCatalog({
                order,
                branchId,
                pricebookId,
                pricebookName,
                PurchaseDate: new Date(TimeStamp),
                Description: `Đơn hàng được tạo tự động trên Catalog ${catalogName}`,
                customer: socialUserKvCustomer,
                productCatalogs,
            })
            let result;
            try {
                result = await this._kvOrderUtilsService.createKvOrder({
                    id: _id,
                    retailerCode,
                    retailerId,
                    branchId: `${branchId}`,
                    pageId: PageId,
                    fbUserId: socialUserKvCustomer.userId,
                    kvCustomerId: socialUserKvCustomer.kvCustomerId,
                    sourceId: catalogId,
                    sourceType: KvOrderSourceType.FACEBOOK_CATALOG,
                    order: payloadOrder,
                    additionalOrder: {
                        CatalogName: catalogName,
                        SocialName: socialName,
                        SocialUrl: `https://facebook.com/${PageId}`,
                        SocialId: PageId,
                        SocialUserId: AUTO_SOCIAL_ID,
                        SocialUserName: AUTO_SOCIAL_NAME,
                    }
                });
            } catch (e) {
                this._logger.error({ ...logInput, Error: new KvOrderRetailerException(e.stack) }, `${prefixLog} create order fail`);
            }
            await this._updateDataAfterCreatedOrder(payload, result, catalogConnection);

            await this._redlockService.release(lock);
        } catch (err) {
            if (err?.message.includes(ERROR_MESSAGE_REDLOCK)) {
                await sleep(3000);
                return Promise.reject();
            }
            this._logger.error({ ...logInput, Error: new KvOrderRetailerException(err.stack) }, `${prefixLog} fail`);
        }

        this._logger.info(logInput, `${prefixLog} success`);
        return Promise.resolve();
    }

    private async _updateDataAfterCreatedOrder(payload: ICreateKvOrderCatalogPayload, result: any, catalogConnection: FbCatalogConnectionDocument) {
        const error = result?.status !== 200 && result?.error?.ResponseStatus ||
            result?.data?.ResponseStatus ||
            result?.response?.data?.ResponseStatus ||
            result?.message && { Message: result?.message } || null;
        const order = !error && result?.data || null;

        if (!error && !order) {
            return Promise.resolve();
        }
        const { PageId, _id } = payload;
        const db = await this._mongodbGroupService.getDatabase({ socialId: PageId });

        await this._processOrderInMessage(error, payload, order, db, _id, PageId);

        if (order && !error) {
            const { retailerId, socialUserKvCustomer, PageId, branchId } = payload;
            const { userId } = socialUserKvCustomer;
            const pageSetting = await this._pageSubscriptionService.getPageSetting(PageId);
            const setting: any = pageSetting?.Setting;

            // Gửi tin nhắn tự động có nút "Xem đơn hàng"
            if (isAutoSendMessageWithOrderPreview(setting)) {
                const content = setting.OrderConfirm.Content;
                const tokens = extractTokens(content);
                const orderData = buildOrderData(order);
                payload.content = tokens.length > 0 ? replaceTokens(content, tokens, orderData) : content;
                this._sentEventToSendingMessageTemplateButton(payload, catalogConnection, order);
            }
            // Gửi tin nhắn tự động không có nút "Xem đơn hàng" khi không chọn option gửi kèm chi tiết đơn hàng
            else if (isAutoSendMessageWithoutOrderPreview(setting)) {
                const content = setting.OrderConfirm.Content;
                const tokens = extractTokens(content);
                const orderData = buildOrderData(order);
                payload.content = tokens.length > 0 ? replaceTokens(content, tokens, orderData) : content;
                this._sentEventToSendingMessageTemplateWithoutButton(payload, catalogConnection, order);
            }

            await this._savingMappingOrderFacebookPos({
                orderId: order.Id,
                conversationId: userId,
                psId: userId,
                pageId: PageId,
                retailerId,
                branchId: parseInt(branchId),
            });
        }
        this._sentEventToNotificationAtferCreatedOrder(payload, catalogConnection.catalogName, order, error);

    }

    private _sentEventToNotificationAtferCreatedOrder(payload: ICreateKvOrderCatalogPayload, catalogName: string, order: any, error = null) {
        const { PageId, catalogId, retailerId, _id, GroupId } = payload;
        if (!order) {
            return;
        }
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigNotification.ROUTING_KEY, {
            MessageId: _id,
            Id: GroupId,
            Order: { ...(order || {}), kvOrderId: order?.Id, kvOrderCode: order?.Code, kvError: error || null },
            PageId,
            CatalogId: catalogId,
            CatalogName: catalogName,
            RetailerId: retailerId,
            SocialType: SocialTypes.FACEBOOK_CATALOG,
            EventType: EventTypes.SuccessfullyCreatedOrderCatalog
        }).catch(err => {
            const prefixLog = this.prefixLog('_sentEventToNotificationAtferCreatedOrder');
            this._logger.error({ MessageTemplate: { payload, catalogName, order }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }

    private async _savingMappingOrderFacebookPos(retailerOrder: any) {
        await this._retailOrderRepository.create(retailerOrder);
    }

    private _sentEventToSendingMessageTemplateButton(payload: ICreateKvOrderCatalogPayload, catalogConnection: FbCatalogConnectionDocument, order: any) {
        const { PageId, retailerId, retailerCode, content } = payload;
        const { userId } = payload.socialUserKvCustomer;
        const payloadEventMQ = {
            PageId,
            RetailerId: retailerId,
            RetailerCode: retailerCode,
            Content: content,
            FbUserId: userId,
            Metadata: {
                OrderCode: order?.Code,
                ...pick(catalogConnection, ['catalogId', 'catalogName'])
            } as IMetaDataPayload
        };
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigAutoSendMessageTemplate.ROUTING_KEY, payloadEventMQ).catch(err => {
            const prefixLog = this.prefixLog('_sentEventToSendingMessageTemplateButton');
            this._logger.error({ MessageTemplate: { payload, catalogConnection, order }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }

    private _sentEventToSendingMessageTemplateWithoutButton(payload: ICreateKvOrderCatalogPayload, catalogConnection: FbCatalogConnectionDocument, order: any) {
        const { PageId, retailerId, retailerCode, content } = payload;
        const { userId } = payload.socialUserKvCustomer;
        const payloadEventMQ = {
            PageId,
            RetailerId: retailerId,
            RetailerCode: retailerCode,
            Content: content,
            FbUserId: userId,
            Metadata: {
                ...pick(catalogConnection, ['catalogId', 'catalogName'])
            } as IMetaDataPayload
        };
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigAutoSendMessageTemplate.ROUTING_KEY, payloadEventMQ).catch(err => {
            const prefixLog = this.prefixLog('_sentEventToSendingMessageTemplateWithoutButton');
            this._logger.error({ MessageTemplate: { payload, catalogConnection, order }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }

    private async _processOrderInMessage(
        error: any,
        payload: ICreateKvOrderCatalogPayload,
        order: any,
        db: any,
        _id: string,
        PageId: string
    ): Promise<void> {
        // Success case - no error
        if (!error) {
            await this._updateOrderBasicError(db, PageId, _id, order, null);
            return;
        }

        // Handle basic error without message
        await this._updateOrderBasicError(db, PageId, _id, order, error);
    }

    private async _updateOrderBasicError(
        db: any,
        PageId: string,
        _id: string,
        order: any,
        error: any
    ): Promise<void> {
        await db.collection(PageId).updateOne({ _id }, {
            $set: {
                "Order.kvOrderId": order?.Id || null,
                "Order.kvOrderCode": order?.Code || null,
                "Order.kvError": error || null
            }
        });
    }

    private _processErrorMessages(errorMessages: IOrderValidationError[], products: any[]): [string | null, any[]] {
        let orderMessage: string | null = null;

        // // Check for order level errors
        // const hasOrderLevelError = errorMessages.some(err =>
        //     [
        //         ErrorValidateOrderFBPosCode.BranchEmpty,
        //         ErrorValidateOrderFBPosCode.OrderDetailsEmpty,
        //         ErrorValidateOrderFBPosCode.ProductDeleted,
        //         ErrorValidateOrderFBPosCode.ProductNotAllowSale,
        //         ErrorValidateOrderFBPosCode.CustomerNotFound,
        //         ErrorValidateOrderFBPosCode.ProductNotActive
        //     ].includes(err.Code)
        // );
        const hasOrderLevelError = true;
        if (hasOrderLevelError) {
            orderMessage = "Không thể tạo đơn tự động";
        }

        // Process product level errors
        const productsWithErrors = products.map(product => {
            const productError = errorMessages.find(err =>
                (err.AdditionalData?.ProductCode === product.retailer_id)
            );

            if (!productError) {
                return { ...product, error_message: null };
            }

            const errorMessage = this._getProductErrorMessage(productError.Code);
            return {
                ...product,
                error_message: errorMessage,
                error_code: productError.Code
            };
        });

        return [orderMessage, productsWithErrors];
    }

    private _getProductErrorMessage(errorCode: ErrorValidateOrderFBPosCode): string {
        switch (errorCode) {
            case ErrorValidateOrderFBPosCode.ProductNotExist:
            case ErrorValidateOrderFBPosCode.ProductCodeChange:
            case ErrorValidateOrderFBPosCode.ProductDeleted:
            case ErrorValidateOrderFBPosCode.ProductNotAllowSale:
            case ErrorValidateOrderFBPosCode.ProductNotActive:
                return "Hàng hóa không tồn tại trên KiotViet";
            case ErrorValidateOrderFBPosCode.ProductQuantity:
                return 'Hết hàng';
            default:
                return "";
        }
    }

}
