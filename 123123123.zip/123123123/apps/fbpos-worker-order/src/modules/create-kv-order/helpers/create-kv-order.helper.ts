import { CartStatusEnum, IOrderMessenger, IProductMessenger } from "@kiotviet-facebook-services/common";
import {
    FbCartsDocument,
    FbUserProfileDocument,
    SocialUserKvCustomerDocument,
    TiktokCartsDocument
} from "@kiotviet-facebook-services/fbpos-master-repository";
import { CustomerSocialTypes } from "@kiotviet-facebook-services/kv-internal-api";

export function getQueryUpdateCart(cart: FbCartsDocument, result: any) {
    const {value, reason} = result;

    const error = reason?.error?.ResponseStatus ||
        reason?.data?.ResponseStatus ||
        reason?.response?.data?.ResponseStatus ||
        reason?.message && {Message: reason.message} || null;
    let status = value?.data?.Id ? CartStatusEnum.CREATED_INVOICE : CartStatusEnum.ERROR_CREATED_INVOICE;
    // Trường hợp tạo Khách hàng KiotViet tự động chưa xong thì đánh đấu status là Unresolved để tạo đơn lại
    // Nếu tạo khách hàng xong, thì tạo đơn lại
    if (error?.Message.indexOf('Không tìm thấy thông tin khách hàng hoặc giỏ hàng rỗng') > -1) {
        status = CartStatusEnum.WAITING_CREATE_CUSTOMER;
    }

    return {
        updateOne: {
            filter: {_id: cart._id},
            update: {
                $set: {
                    status,
                    ...value?.data?.Id && {
                        products: [],
                        productInOrders: [...cart.products.slice(), ...cart.productInOrders.slice()]
                    }
                },
                $addToSet: {
                    kvOrders: {
                        kvOrderId: value?.data?.Id || '',
                        kvOrderCode: value?.data?.Code || '',
                        isAuto: true,
                        ...error && {error: error}
                    }
                }
            },
            upsert: true,
        },
    }
}

export function getQueryRemoveErrorOrderCart(cart: FbCartsDocument) {
    return {
        updateOne: {
            filter: {_id: cart._id},
            update: {
                $pull: {
                    kvOrders: {
                        error: {$exists: true}
                    }
                }
            },
            upsert: true,
        },
    }
}

export function getRetailerOrder(cart: FbCartsDocument, retailerId: number, branchId: number, result) {
    const {value} = result;
    const {products} = cart;
    const comments = [];
    (products || []).forEach(product => {
        comments.push(...product.Comments);
    });
    comments.sort((a, b) => (b.TimeStamp || 0) - (a.TimeStamp || 0));

    const lastCommentId = comments.length ? comments[0].CommentId : undefined;
    if (value?.data?.Id) {
        return {
            orderId: value?.data?.Id,
            conversationId: lastCommentId || cart.fbUserId,
            psId: cart.fbUserId,
            pageId: cart.pageId,
            retailerId,
            branchId,
        }
    }
    return null;
};

export function getCustomerByBranch(fbUserProfiles: FbUserProfileDocument[], fbUserId: string, branchId: number) {
    const foundProfile = fbUserProfiles.find(profile => profile.id === fbUserId);
    const foundCustomerByBranch = foundProfile ? (foundProfile.kvCustomers || []).find(cus => cus['branchId'] === branchId) : null;
    return foundCustomerByBranch ? {
        customerId: foundCustomerByBranch['kvCustomerId'],
        customerCode: foundCustomerByBranch['kvCustomerCode']
    } : null;
}

export function buildPayloadOrder(fbCart: FbCartsDocument, branchId: string, Description: string, customer: any, fromType = CustomerSocialTypes.Facebook): any {
    const {updatedAt, products, priceBookId, priceBookName} = fbCart;
    let customerId = 0, customerCode = '';
    if (customer) {
        customerId = customer.customerId || customer.kvCustomerId;
        customerCode = customer.customerCode || customer.kvCustomerCode;
    }

    const OrderDetails = products.map((product: any) => {
        return {
            ProductId: product.KvProductId,
            Quantity: product.Quantity,
            Price: product.Price
        }
    });

    const existOrder = fbCart.kvOrders?.length ? fbCart.kvOrders.filter(order => order.isAuto && order.kvOrderId)
        .sort((a, b) => (a.kvOrderId > b.kvOrderId ? 1 : -1))
        .pop() : null;

    return {
        ...existOrder && {Id: existOrder.kvOrderId},
        FromType: fromType,
        IsLivestream: true,
        FromFbPos: true,
        BranchId: branchId,
        PurchaseDate: updatedAt,
        ...priceBookName && priceBookId && {
            Extra: JSON.stringify({
                PriceBookId: {
                    Id: priceBookId,
                    Name: priceBookName
                }
            })
        },
        ...(customerCode && {CustomerCode: customerCode}),
        ...(customerId && {CustomerId: customerId}),
        OrderDetails,
        Description
    };
}

export function buildPayloadOrderTiktok(tiktokCart: TiktokCartsDocument, branchId: string, Description: string, customer: any, existOrder: any): any {
    const {updatedAt, products, priceBookId, priceBookName} = tiktokCart;
    let customerId = 0, customerCode = '';
    if (customer) {
        customerId = customer.kvCustomerId;
        customerCode = customer.kvCustomerCode;
    }

    const OrderDetails = products.map((product: any) => {
        return {
            ProductId: product.KvProductId,
            Quantity: product.Quantity,
            Price: product.Price
        }
    });

    return {
        ...existOrder && {Id: existOrder.kvOrderId},
        FromType: CustomerSocialTypes.TiktokLive,
        IsLivestream: true,
        BranchId: branchId,
        PurchaseDate: updatedAt,
        Extra: JSON.stringify({PriceBookId: {Id: priceBookId || 0, Name: priceBookName || 'Bảng giá chung'}}),
        ...(customerCode && {CustomerCode: customerCode}),
        ...(customerId && {CustomerId: customerId}),
        OrderDetails,
        Description
    };
}

export interface IPayloadOrderCatalogParams {
    order: IOrderMessenger;
    PurchaseDate: Date;
    branchId: string;
    Description: string;
    customer: SocialUserKvCustomerDocument;
    productCatalogs: any;
    pricebookName?: string;
    pricebookId?: number;
}

export function buildPayloadOrderCatalog(payload: IPayloadOrderCatalogParams): any {
    const {
        order,
        PurchaseDate,
        branchId,
        Description,
        customer,
        pricebookId,
        pricebookName,
        productCatalogs,
    } = payload;
    let customerId = 0, customerCode = '';
    if (customer) {
        customerId = parseInt(customer.kvCustomerId);
        customerCode = customer.kvCustomerCode;
    }
    const {products} = order;

    /**
     * https://developers.facebook.com/docs/marketing-api/catalog-batch/reference/
     * The price multiplied by 100, for all currencies. Example: 490 when used with USD denotes $4.90, and 49000 when used with JPY denotes ¥490.
     */
    const OrderDetails = products.map((product: IProductMessenger) => {
        const foundProductKv = productCatalogs.find(item => item.id === product.retailer_id);
        if (foundProductKv) {
            return {
                ProductId: foundProductKv.kvProduct?.id,
                Quantity: product.quantity,
                Price: product.unit_price / 100
            }
        }
        return null;

    }).filter(item => !!item);

    return {
        FromType: CustomerSocialTypes.Facebook,
        FromFbPos: true,
        BranchId: branchId,
        PurchaseDate,
        Extra: JSON.stringify({PriceBookId: {Id: pricebookId || 0, Name: pricebookName || 'Bảng giá chung'}}),
        ...(customerCode && {CustomerCode: customerCode}),
        ...(customerId && {CustomerId: customerId}),
        OrderDetails,
        Description
    };
}
