export enum PaymentStatus {
  Paid = 0,
  Void = 1
}

export function buildOrderData(order) {
    const data = {};
    if (!order) {
        return data;
    }

    const { Code, Total, TotalQuantity, Customer, DeliveryDetail, OrderDetails, Payments } = order;
    data['{Ma_Don_Hang}'] = Code;
    data['{Tam_Ung_Dat_Hang}'] = '0';

    if (Customer) {
        data['{Khach_Hang}'] = Customer.Name || '';
        data['{So_Dien_Thoai}'] = Customer.ContactNumber || '';
        data['{Dia_Chi_Khach_Hang}'] = getAddressFull(Customer);
        data['{Gioi_Tinh_Khach_Hang}'] = Customer.Gender == true ? 'Nam' : (Customer.Gender == false ? 'Nữ' : '');
        data["{Danh_Xung}"] = Customer.Gender == undefined ? 'anh/chị' : (Customer.Gender == true ? 'anh' : 'chị');
    }

    if (OrderDetails) {
        data["{Ma_Hang}"] = OrderDetails.map(d => d.ProductCode).join(", ");
        data["{Ten_Hang_Hoa}"] = OrderDetails.map(d => d.ProductName).join(", ");
        data["{Ma_Ten_Hang}"] = OrderDetails.map(d => d.ProductCode + ": " + d.ProductName).join(", ");
        data["{So_Luong}"] = OrderDetails.map(d => d.Quantity).join(", ");
        data["{Don_Gia}"] = formatNumber(OrderDetails.map(d => d.Price).join(", "));
        data["{So_Luong_Ten_Ma_Hang}"] = OrderDetails.map(d => d.Quantity + " " + d.ProductName + " (" + d.ProductCode + ")").join(", ");
        data['{Tong_So_Luong}'] = getTotalQuantity(OrderDetails);
        data['{Tong_Cong}'] = formatNumber(getTotal(OrderDetails));
    }

    if (Payments) {
      data['{Tam_Ung_Dat_Hang}'] = formatNumber(Payments.reduce((sum, payment) => sum + (payment.Status !== PaymentStatus.Void && !payment.System ? payment.Amount : 0), 0));
    }

    data['{Tong_Can_Thanh_Toan}'] = formatNumber((data['{Tong_Cong}'] || Total) - data['{Tam_Ung_Dat_Hang}']);

    if (data['{Tong_Can_Thanh_Toan}'] < 0) {
      data['{Tong_Can_Thanh_Toan}'] = '0';
    }

    if (DeliveryDetail) {
        data['{Dia_Chi_Nguoi_Nhan}'] = getAddressFull(DeliveryDetail);
    }

    return data;
}

// Entity can be Customer or DeliveryDetail
function getAddressFull(entity) {
    const {Address, WardName, LocationName} = entity;
    let reserverLocation = '';
    if (LocationName) {
        const index = LocationName.lastIndexOf('-');
        if (index >= 0 && index < LocationName.length - 1) {
            reserverLocation = LocationName.substring(index + 1).trim() + ', ' + LocationName.substring(0, index).trim();
        }
    }
    return `${Address ? `${Address}, ` : ''}${WardName ? `${WardName}, ` : ''}${reserverLocation}`;
}

function getTotalQuantity(orderDetails) {
    if (!orderDetails || !orderDetails.length) {
        return 0;
    }
    return orderDetails.reduce((sum, orderDetail) => sum + orderDetail.Quantity, 0);
}

function getTotal(orderDetails) {
    if (!orderDetails || !orderDetails.length) {
        return 0;
    }
    return orderDetails.reduce((sum, orderDetail) => sum + (orderDetail.Quantity * orderDetail.Price), 0);
}

function formatNumber(value, format = "n0", locale = "en-US") {
  if (!/^n\d+$/.test(format)) return value;

  const decimalPlaces = parseInt(format.slice(1), 10); // Extract number from "n0", "n2", etc.

  return new Intl.NumberFormat(locale, {
    minimumFractionDigits: decimalPlaces,
    maximumFractionDigits: decimalPlaces,
  }).format(value);
}
