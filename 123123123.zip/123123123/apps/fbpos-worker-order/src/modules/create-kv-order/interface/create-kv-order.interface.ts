import { IMessenger, ITiktokValidateLiveComment } from "@kiotviet-facebook-services/common";
import { IKVCustomer } from "@kiotviet-facebook-services/kv-internal-api";
import { SocialUserKvCustomerDocument } from "@kiotviet-facebook-services/fbpos-master-repository";

export interface ICreateKvOrderPayload {
    PageId: string;
    PostId?: string;
    LivestreamId?: string;
    VideoId?: string;
    FromSource?: string
}

export interface ICreateKvOrderTiktokPayload extends ITiktokValidateLiveComment {
    kvCustomer: IKVCustomer;
}

export interface ICreateKvOrderCatalogPayload extends IMessenger {
    retailerId: number;
    retailerCode: string;
    branchId: string;
    catalogId: string;
    socialUserKvCustomer: SocialUserKvCustomerDocument;
    content?: string;
}
