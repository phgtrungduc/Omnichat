import {
    CartStatusEnum,
    ERROR_MESSAGE_REDLOCK,
    ITiktokValidateLiveComment,
    KvLogger,
    KvOrderRetailerException,
    KvRabbitMQException,
    RabbitMqConfigKvOrderTiktokLive,
    RabbitMqConfigTiktokNotification,
    RabbitMqConfigTiktokReportLivestreamDashboard,
    TiktokEventTypes
} from '@kiotviet-facebook-services/common';
import { Inject, Injectable } from '@nestjs/common';
import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    MongodbGroupService,
    SocialUserKvCustomerService,
    TiktokCartsDocument,
    TiktokCartsService,
    TiktokLivestreamScriptDocument,
    TiktokLivestreamScriptService,
    TiktokUserProfileService
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { RedisLockService, REDLOCK_CONST } from '@kiotviet-facebook-services/lock';
import { KvOrderApiService } from '@kiotviet-facebook-services/kv-internal-api';
import { buildPayloadOrderTiktok } from './helpers/create-kv-order.helper';
import { CACHE_KEYS } from "@kiotviet-facebook-services/cache";
import { Types } from "mongoose";
import { pick } from 'lodash';
import { Cache, CACHE_MANAGER } from "@nestjs/cache-manager";

const config = require('config');
const MAX_EVENTS_FOR_REPORT = 10;
const MIN_TIME_BETWEEN_REPORTS = 3000; // 3s
@Injectable()
export class CreateKvOrderForTiktokService {
    private readonly _rabbitMQConfig;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _tiktokCartService: TiktokCartsService,
        private readonly _tiktokUserProfileService: TiktokUserProfileService,
        private readonly _tiktokLivestreamScriptService: TiktokLivestreamScriptService,
        private readonly _socialUserKvCustomerService: SocialUserKvCustomerService,
        private readonly _kvOrderService: KvOrderApiService,
        private readonly _redlockService: RedisLockService,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _mongodbGroupService: MongodbGroupService,
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigKvOrderTiktokLive.ROUTING_KEY,
        queue: `fbpos-worker-order:${RabbitMqConfigKvOrderTiktokLive.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: {'x-queue-type': 'quorum'},
        },
    })
    private async _createKvOrderForTiktok(payload: ITiktokValidateLiveComment) {
        const prefixLog = this.prefixLog('_createKvOrderForTiktok');
        const baseInfoLog = {Context: {payload}, SourceContext: '_createKvOrderForTiktok'};
        this._logger.info(`${prefixLog} received payload`, baseInfoLog);
        const {userId, livestreamScriptId} = payload;
        if (!userId || !livestreamScriptId) {
            this._logger.warn(`${prefixLog} warning: Missing or invalid userId | livestreamScriptId`, baseInfoLog);
            return Promise.resolve();
        }

        try {
            const tiktokLivestreamScript = await this._tiktokLivestreamScriptService.findById(livestreamScriptId);
            if (!tiktokLivestreamScript || !tiktokLivestreamScript.LiveStreamFormula.AutoCreatingOrder) {
                this._logger.warn(`${prefixLog} warning: Tiktok livestream not setup successfully for Creating Order`, baseInfoLog);
                return Promise.resolve();
            }
            const lock = await this._redlockService.acquire([`${REDLOCK_CONST.LOCK_KEYS.CREATE_KV_ORDERS_TIKTOK_LIVE.NAME}${livestreamScriptId}`], REDLOCK_CONST.LOCK_KEYS.CREATE_KV_ORDERS_TIKTOK_LIVE.TTL, {});
            const {branchId, retailerId, retailerCode, name, id} = tiktokLivestreamScript;
            const [cart, socialUserKvCustomer] = await Promise.all([
                this._tiktokCartService.handleReadTiktokCart(userId, livestreamScriptId),
                this._socialUserKvCustomerService.handleReadSocialUserKvCustomer({userId, retailerId, branchId})
            ]);
            if (!socialUserKvCustomer) {
                this._logger.warn(`${prefixLog} warning: Create KvOrder required KvCustomer`, baseInfoLog);
                await this._redlockService.release(lock).catch(e => this._logger.error(`${prefixLog} release lock err`, e)); // Release lock
                return Promise.resolve();
            }
            if (!cart?.products?.length) {
                this._logger.warn(`${prefixLog} warning: Order details is required`, baseInfoLog);
                await this._redlockService.release(lock).catch(e => this._logger.error(`${prefixLog} release lock err`, e)); // Release lock
                return Promise.resolve();
            }
            const kvOrder = cart.kvOrders?.length ? cart.kvOrders.find(order => order.isAuto && order.kvOrderId) : null;
            const payloadOrder = buildPayloadOrderTiktok(cart,
                `${branchId}`,
                `Đơn đặt hàng được tạo tự động từ phát trực tiếp LIVETIKTOK${id.toString().padStart(6, '0')} - ${name}`,
                socialUserKvCustomer, kvOrder);
            let result;
            try {
                result = await this._kvOrderService.createOrder({
                    retailerId, retailerCode, branchId: `${branchId}`, order: payloadOrder
                });
            } catch (e) {
                result = e.response;
                this._logger.error(`${prefixLog} error`, new KvOrderRetailerException(e.stack), {
                    SourceContext: 'this._kvOrderService.createOrder',
                    Context: baseInfoLog,
                    ErrorContext: {message: e.message, stack: e.stack},
                });
            }
            await this._updateDataAfterCreatedOrder(cart, result, kvOrder, tiktokLivestreamScript);

            await this._redlockService.release(lock).catch(e => this._logger.error(`${prefixLog} release lock err`, e)); // Release lock
            this._logger.info(`${prefixLog} success`, baseInfoLog);
        } catch (err) {
            if (err?.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._logger.error(`${prefixLog} fail`, new KvOrderRetailerException(err.stack), {
                ...baseInfoLog,
                ErrorContext: pick(err, ['message', 'stack']),
            });
        }

        return Promise.resolve();
    }

    private async _updateDataAfterCreatedOrder(cart: TiktokCartsDocument, result: any, existOrder: any, tiktokLivestreamScript: TiktokLivestreamScriptDocument = null) {
        const error = result?.status !== 200 && result?.error?.ResponseStatus ||
            result?.data?.ResponseStatus ||
            result?.response?.data?.ResponseStatus ||
            result?.message && {Message: result?.message} || null;
        const order = !error && result?.data || null;

        if (!error && !order) {
            return Promise.resolve();
        }
        let updateCart = await this._tiktokCartService.updateCart(cart._id,
            {
                $set: {
                    status: !error ? CartStatusEnum.CREATED_INVOICE : CartStatusEnum.ERROR_CREATED_INVOICE,
                    ...!error && {
                        products: [],
                    },
                },
                ...existOrder && {$inc: {totalUpdateOrder: 1}},
                $addToSet: {
                    kvOrders: {
                        kvOrderId: order?.Id,
                        kvOrderCode: order?.Code,
                        isAuto: true,
                        ...error && {error},
                    },
                    ...!error && {productInOrders: cart.products.slice()}
                }
            },
            {upsert: true}
        );

        if (order) {
            // Tạo thành 2 query vì 1 câu query k thể vừa $addToSet với $pull được
            // Xóa đơn lỗi nếu tạo đơn thành công
            updateCart = await this._tiktokCartService.updateCart(cart._id,
                {
                    $pull: {
                        kvOrders: {
                            error: {$exists: true}
                        }
                    }
                },
                {upsert: true}
            );
        }
        // TODO: Tạm thời k dùng cache
        // await this._tiktokCartService.invalidCacheCart(updateCart.userId, updateCart.livestreamScriptId);

        if (!error && updateCart && tiktokLivestreamScript) {
            await Promise.all([
                this._processSendMQToCalculateReport(updateCart.livestreamScriptId),
                // this._updateAnalyticTiktokLivestreamScript(tiktokLivestreamScript, updateCart, existOrder),
                this._updateCommentsCreatedOrderSuccess(updateCart)
            ])
        }
    }

    private _sentEventToCalculateReportMQ(livestreamScriptId: string | number) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigTiktokReportLivestreamDashboard.ROUTING_KEY, {
            livestreamScriptId,
            event: TiktokEventTypes.UPDATE_ANALYTIC
        }).catch(err => {
            this._logger.error(`${this.prefixLog('_sentEventToMQ')} fail`,
                new KvRabbitMQException(err.stack), {
                    SourceContext: '_sentEventToMQ',
                    Context: {...event},
                    ErrorContext: pick(err, ['message', 'stack'])
                });
        });
    }

    /**
     * Khi nhận đủ 10 comment thì tính report
     * Nếu dưới 10 comment thì 5s sau tính report
     * @param livestreamScriptId
     * @private
     */
    private async _processSendMQToCalculateReport(livestreamScriptId: string) {
        let livestreamDictionary = await this._cache.get(CACHE_KEYS.LIVESTREAM_TIKTOK_DICTIONARY.NAME) as any;
        if (!livestreamDictionary) {
            livestreamDictionary = {};
        }
        livestreamDictionary[livestreamScriptId] = (livestreamDictionary[livestreamScriptId] || 0) + 1;
        const total = livestreamDictionary[livestreamScriptId];
        if (total >= MAX_EVENTS_FOR_REPORT) {
            this._sentEventToCalculateReportMQ(livestreamScriptId);
            delete livestreamDictionary[livestreamScriptId];
            await this._cache.set(CACHE_KEYS.LIVESTREAM_TIKTOK_DICTIONARY.NAME, livestreamDictionary, {ttl: CACHE_KEYS.LIVESTREAM_TIKTOK_DICTIONARY.TTL} as any);
        } else {
            setTimeout(async () => {
                if (total > 0) {
                    this._sentEventToCalculateReportMQ(livestreamScriptId);
                    delete livestreamDictionary[livestreamScriptId];
                    await this._cache.set(CACHE_KEYS.LIVESTREAM_TIKTOK_DICTIONARY.NAME, livestreamDictionary, {ttl: CACHE_KEYS.LIVESTREAM_TIKTOK_DICTIONARY.TTL} as any);
                }
            }, MIN_TIME_BETWEEN_REPORTS);
        }
    }


    private async _updateAnalyticTiktokLivestreamScript(tiktokLivestreamScript: TiktokLivestreamScriptDocument,
                                                        cart: TiktokCartsDocument,
                                                        existOrder = null) {
        // const revenueCart = calculateRevenue(cart?.productInOrders || []);
        // const newRevenue = (tiktokLivestreamScript.revenue || 0) + revenueCart;
        const newRevenue = await this._tiktokCartService.getRevenue(tiktokLivestreamScript._id);
        const {retailerId, retailerCode} = tiktokLivestreamScript;
        const totalCustomerCreatedOrders = await this._tiktokCartService.countTotalCarts(tiktokLivestreamScript._id);
        await this._tiktokLivestreamScriptService.updateTiktokLivestreamScript(
            retailerId,
            retailerCode,
            {
                _id: new Types.ObjectId(tiktokLivestreamScript['_id'] as any),
                revenue: newRevenue,
                totalCustomerCreatedOrders,
                ...!existOrder && {$inc: {totalOrders: 1}}
            }
        )

        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange,
            `${RabbitMqConfigTiktokNotification.ROUTING_KEY}`,
            {
                event: TiktokEventTypes.UPDATE_ANALYTIC,
                livestreamScriptId: tiktokLivestreamScript._id,
                liveUserId: tiktokLivestreamScript.userId,
                revenue: newRevenue,
                totalCustomerCreatedOrders,
                ...!existOrder && {
                    totalOrders: tiktokLivestreamScript.totalOrders + 1,
                },

            }
        ).catch(err => {
            this._logger.error(`${this.prefixLog('_updateChangeRevenueTiktokLivestreamScript')} fail`,
                new KvRabbitMQException(err.stack), {
                    SourceContext: '_updateChangeRevenueTiktokLivestreamScript',
                    Context: {cart},
                    ErrorContext: pick(err, ['message', 'stack'])
                });
        });
    }

    private async _updateCommentsCreatedOrderSuccess(cart: TiktokCartsDocument) {
        if (!cart || !cart.productInOrders?.length) {
            return;
        }
        const commentIds = [];

        cart.productInOrders.forEach(product => {
            product.Comments.forEach(comment => {
                commentIds.push(comment.CommentId);
            });
        });

        const db = await this._mongodbGroupService.getDatabase({type: 'tiktok'});
        await db.collection(this._mongodbGroupService.tiktokConversationDetailsCollName).updateMany({
            id: {$in: commentIds}
        }, {$set: {IsCreatedOrder: true}});
    }
}
