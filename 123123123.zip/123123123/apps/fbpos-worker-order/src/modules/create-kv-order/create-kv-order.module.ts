import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { KvInternalApiModule } from '@kiotviet-facebook-services/kv-internal-api';
import { FacebookSdkModule } from '@kiotviet-facebook-services/facebook-sdk';
import { LockModule } from '@kiotviet-facebook-services/lock';
import { CreateKvOrderService } from './create-kv-order.service';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { CreateKvOrderCatalogService } from "./create-kv-order-catalog.service";
import { KvOrderCommonModule } from "../kv-order-common/kv-order-common.module";

@Module({
    imports: [CommonModule, KvRabbitMQModule, KvInternalApiModule, FacebookSdkModule, LockModule, FbPosMasterRepositoryModule, KvOrderCommonModule],
    providers: [CreateKvOrderService, CreateKvOrderCatalogService],
})
export class CreateKvOrderModule {
}
