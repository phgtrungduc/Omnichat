import { AmqpConnection, RabbitSubscribe } from "@golevelup/nestjs-rabbitmq";
import {
    CartStatusEnum,
    ERROR_MESSAGE_REDLOCK,
    KvLogger,
    KvOrderRetailerException,
    KvOrderSourceType,
    KvRabbitMQException,
    RabbitMqConfigAutoSendMessageFollowLivestreamScript,
    RabbitMqConfigKvOrder,
    sleep,
    SocialTypes
} from "@kiotviet-facebook-services/common";
import {
    FbCartsDocument,
    FbCartsRepository,
    FbLivestreamScriptDocument,
    FbLivestreamScriptService,
    PageSubscriptionService,
    RetailOrderRepository,
    SocialUserKvCustomerService,
    WebhookSubscriptionRepository
} from "@kiotviet-facebook-services/fbpos-master-repository";
import {
    AUTO_SOCIAL_ID,
    AUTO_SOCIAL_NAME,
    AutoReplyLivestreamMessage
} from "@kiotviet-facebook-services/kv-internal-api";
import { RedisLockService, REDLOCK_CONST } from "@kiotviet-facebook-services/lock";
import { Injectable } from "@nestjs/common";
import { IKvLogInput } from "libs/shared/common/src/lib/logger/interfaces/logger.interface";
import { KvOrderUtilsService } from "../kv-order-common/kv-order-utils.service";
import {
    buildPayloadOrder,
    getQueryRemoveErrorOrderCart,
    getQueryUpdateCart,
    getRetailerOrder
} from "./helpers/create-kv-order.helper";
import { ICreateKvOrderPayload } from "./interface/create-kv-order.interface";

const config = require('config');
const relaxTimeSecond = 0; // Wait time for rate limit

@Injectable()
export class CreateKvOrderService {
    private chunkSize = config.get('autoCreateOrderChunkSize') || 10;
    private readonly _rabbitMQConfig;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _fbCartsRepository: FbCartsRepository,
        private readonly _retailOrderRepository: RetailOrderRepository,
        private readonly _pageSubscriptionService: PageSubscriptionService,
        private readonly _redlockService: RedisLockService,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _fbLivestreamScriptService: FbLivestreamScriptService,
        private readonly _socialUserKvCustomerService: SocialUserKvCustomerService,
        private readonly _webhookSubscriptionRepository: WebhookSubscriptionRepository,
        private readonly _kvOrderUtilsService: KvOrderUtilsService,

    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigKvOrder.ROUTING_KEY,
        queue: `fbpos-worker-order:${RabbitMqConfigKvOrder.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _createKvOrder(payload: ICreateKvOrderPayload) {
        const prefixLog = this.prefixLog('_createKvOrder');
        const { PageId, LivestreamId, VideoId, FromSource } = payload;

        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': PageId,
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        if (!PageId || (!LivestreamId && !VideoId)) {
            return Promise.resolve();
        }

        try {
            const filter = LivestreamId ? { livestreamId: LivestreamId } : { videoId: VideoId };
            const livestreamScript = await this._fbLivestreamScriptService.getFbLivestreamScript('', filter) as FbLivestreamScriptDocument;
            if (!livestreamScript || !livestreamScript.LiveStreamFormula || !livestreamScript.LiveStreamFormula?.AutoCreatingOrder || !livestreamScript?.retailerCode) {
                return Promise.resolve();
            }
            const { videoId, branchId, retailerCode, name, id, retailerId, pageId } = livestreamScript;

            const lock = await this._redlockService.acquire([`${REDLOCK_CONST.LOCK_KEYS.CREATE_KV_ORDERS.NAME}${videoId}`], REDLOCK_CONST.LOCK_KEYS.CREATE_KV_ORDERS.TTL, {});

            const limit = this.chunkSize;
            let batchCount = 0;
            let skip = 0;
            let isRunning = true;
            const description = `Đơn đặt hàng được tạo tự động từ phát trực tiếp ${id} - ${name}`;
            let isCreatedSuccess = false;
            const socialInfo = await this._webhookSubscriptionRepository.getSubscriptionBySocialId(pageId);
            const isFromCustomerWorker = 'fbpos-worker-customer' === FromSource;
            while (isRunning) {
                const fbCarts = await this._fbCartsRepository.getFbCartsHasProduct(videoId, isFromCustomerWorker, skip, limit);
                const total = fbCarts.length;
                isRunning = total >= limit;
                if (total > 0) {
                    batchCount++;
                    await this._updateStateProcessing(fbCarts);
                    const socialUserKvCustomers = await this._socialUserKvCustomerService.getSocialUserKvCustomersByIds(fbCarts.map(cart => cart.fbUserId), retailerId, `${branchId}`);

                    const payloadOrders = fbCarts.map(cart => {
                        const socialUserCustomer = socialUserKvCustomers.find(item => item.userId === cart.fbUserId);
                        cart['socialUserKvCustomer'] = socialUserCustomer;
                        return buildPayloadOrder(cart, `${branchId}`, description, socialUserCustomer);
                    });

                    const createOrderApiPromises: Promise<any>[] = payloadOrders.map(order => {
                        if (!order.CustomerId || !order.OrderDetails || !order.OrderDetails.length) {
                            return Promise.reject({
                                error: {
                                    ResponseStatus: {
                                        ErrorCode: "KvValidateException",
                                        Message: "Không tìm thấy thông tin khách hàng hoặc giỏ hàng rỗng",
                                    },
                                },
                                value: {},
                            });
                        }
                        const socialUserCustomer = socialUserKvCustomers.find(item => item.kvCustomerId === order.CustomerId);

                        return this._kvOrderUtilsService.createKvOrder(
                            {
                                id: `${videoId}_${socialUserCustomer.userId}`,
                                retailerId,
                                retailerCode,
                                order,
                                pageId,
                                sourceId: videoId,
                                sourceType: KvOrderSourceType.FACEBOOK_LIVESTREAM,
                                fbUserId: socialUserCustomer?.userId,
                                kvCustomerId: order.CustomerId,
                                branchId: `${branchId}`,
                                additionalOrder: {
                                    SocialUserId: AUTO_SOCIAL_ID,
                                    SocialUserName: AUTO_SOCIAL_NAME,
                                    SocialId: pageId,
                                    SocialName: socialInfo && (socialInfo.PageInfo && socialInfo.PageInfo['name'] || socialInfo.InstagramInfo && socialInfo.InstagramInfo['username']) || ''
                                }
                            }
                        )
                    });
                    await this._bulkCreateKvOrder(fbCarts, createOrderApiPromises, livestreamScript);
                    isCreatedSuccess = true;
                    await sleep(relaxTimeSecond * 1000);
                }
            }

            // if (isCreatedSuccess) {
            //     const waitTime = 1000;
            //     const estimatedTimeCreatedDone = batchCount * 1000 * relaxTimeSecond;
            //     setTimeout(() => {
            //         this._sendCreatedSuccessEventToMQ(livestreamScript);
            //     }, (estimatedTimeCreatedDone + waitTime));
            // }


            await this._redlockService.release(lock);
            this._logger.info(logInput, `${prefixLog} success`);

        } catch (err) {
            if (err?.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._logger.error({ ...logInput, Error: new KvOrderRetailerException(err.stack) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }

    /**
     * Update status for locking when create invoice
     * @param carts
     */
    private async _updateStateProcessing(carts: FbCartsDocument[]) {
        const bulkOps = carts.map(cart => {
            return {
                updateOne: {
                    filter: { _id: cart._id },
                    update: {
                        $set: {
                            status: CartStatusEnum.IN_PROCESSING
                        },
                    },
                    upsert: true,
                },
            }
        });
        await this._fbCartsRepository.bulkWrite(bulkOps);
    }

    private async _bulkCreateKvOrder(fbCarts: FbCartsDocument[], createOrderApiPromises: Promise<any>[], livestreamScript: FbLivestreamScriptDocument) {
        try {
            const results = await Promise.allSettled(createOrderApiPromises);
            await this._updateDataAfterCreatedOrder(fbCarts, livestreamScript, results);
            // this._sendCreatedSuccessEventToMQ(livestreamScript); // Spam

            const orderCreated = results.map(res => res['value'] && res['value'].data);


            const { pageId } = livestreamScript;
            const subscriptions = await this._pageSubscriptionService.getByPageId(pageId);
            orderCreated.forEach((order, index) => {
                const cart = fbCarts[index];
                let comment_id = '';
                let keywordCreateOrder = '';
                let phoneNumber = '';
                let isOutOfQuantity = false;
                if (cart && cart.products && cart.products.length) {
                    const foundProduct = cart.products.find(product => product.Comments && product.Comments.length);
                    if (foundProduct) {
                        comment_id = foundProduct.Comments[0].CommentId;
                        keywordCreateOrder = foundProduct.Comments[0].KeywordCreateOrder;
                        phoneNumber = foundProduct.Comments[0].PhoneNumber;
                        isOutOfQuantity = foundProduct.Comments[0].IsOutOfQuantity;
                    }

                    const productInScript = livestreamScript.products.find(x => x.KvProductId == foundProduct.KvProductId);

                    if (!comment_id || !order || !order.Id) return;

                    if (livestreamScript.LiveStreamFormula?.AutoSendMessageWithValidComment?.Status && livestreamScript.LiveStreamFormula?.AutoSendMessageWithValidComment?.Content) {
                        // if product out of quantity there was a message sent from CreateCartService -> so not handle here
                        // if not out of quantity and create order success, the message will not be sent when sell quantity of product <=0
                        if (productInScript && productInScript.SellQuantity <= 0) return;
                        return this._sentEventToMQForAutoSendMessage({
                            videoId: livestreamScript.videoId,
                            pageId: livestreamScript.pageId,
                            commentId: comment_id,
                            keywordCreateOrder: keywordCreateOrder,
                            fbUserId: cart.fbUserId,
                            phoneNumber: phoneNumber,
                            orderCode: order.Code
                        });
                    }
                    return;
                }
            });
        } catch (error) {
            const prefixLog = this.prefixLog('_bulkCreateKvOrder');
            this._logger.error({ MessageTemplate: { livestreamScript }, Error: new KvOrderRetailerException(error.stack) }, `${prefixLog} fail`);
        }
    }


    private async _updateDataAfterCreatedOrder(fbCarts: FbCartsDocument[], livestreamScript: FbLivestreamScriptDocument, results: any) {
        const { branchId, retailerId } = livestreamScript;

        // Xóa đơn lỗi cũ trước khi insert/update đơn mới
        await this._fbCartsRepository.bulkWrite(results.map((result, index) => {
            return getQueryRemoveErrorOrderCart(fbCarts[index]);
        }));
        await this._fbCartsRepository.bulkWrite(results.map((result, index) => {
            //Tìm chính xác giỏ hàng để gắn
            const foundCart = fbCarts.find(cart => cart['socialUserKvCustomer']?.kvCustomerId === `${result?.value?.data?.Customer?.Id}`) || fbCarts[index];
            return getQueryUpdateCart(foundCart, result);
        }));

        // Mapping retailer order
        const retailerOrders = results.map((result, index) => {
            return getRetailerOrder(fbCarts[index], retailerId, branchId, result);
        }).filter(order => !!order);
        if (retailerOrders && retailerOrders.length) {
            await this._retailOrderRepository.create(retailerOrders);
        }
    }


    private _sentEventToMQForAutoSendMessage({
        commentId,
        videoId,
        pageId,
        fbUserId,
        keywordCreateOrder,
        phoneNumber,
        orderCode
    }) {
        const payloadSendMessage = {
            Type: AutoReplyLivestreamMessage.ValidComment,
            CommentId: commentId,
            PageId: pageId,
            FbUserId: fbUserId,
            KeywordCreateOrder: keywordCreateOrder,
            VideoId: videoId,
            PhoneNumberFound: phoneNumber,
            OrderCode: orderCode
        };
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigAutoSendMessageFollowLivestreamScript.ROUTING_KEY, payloadSendMessage).catch(err => {
            const prefixLog = this.prefixLog('_sentEventToMQForAutoSendMessage');
            this._logger.error({ MessageTemplate: { payloadSendMessage }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`)
        });
    }
}
