import { ICreateOrderPayload } from "@kiotviet-facebook-services/kv-internal-api";
import { KvOrderSourceType } from "@kiotviet-facebook-services/common";

export interface IAdditionalCreatedOrderPayload extends ICreateOrderPayload {
    id: string;
    pageId: string;
    fbUserId: string;
    kvCustomerId: string;
    sourceId: string;
    sourceType: KvOrderSourceType;
}
