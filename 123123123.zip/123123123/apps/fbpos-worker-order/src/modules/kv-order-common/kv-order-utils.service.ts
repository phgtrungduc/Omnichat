import { KvLogger, KvOrderRetailerException, KvResponseMongoDbException, } from '@kiotviet-facebook-services/common';
import { KvOrderErrorsService } from "@kiotviet-facebook-services/fbpos-master-repository";
import { KvOrderApiService } from "@kiotviet-facebook-services/kv-internal-api";
import { Injectable } from '@nestjs/common';
import { IAdditionalCreatedOrderPayload } from "./interface/create-kv-order.interface";

@Injectable()
export class KvOrderUtilsService {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _kvOrderErrorsService: KvOrderErrorsService,
        private readonly _kvOrderApiService: KvOrderApiService,
    ) {
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async createKvOrder(payloadOrder: IAdditionalCreatedOrderPayload) {
        let result = null;

        try {
            result = await this._kvOrderApiService.createOrder(payloadOrder);
        } catch (e) {
            const prefixLog = this.prefixLog('createdKvOrder');
            this._logger.error({ MessageTemplate: { payloadOrder }, Error: new KvOrderRetailerException(e.stack) }, `${prefixLog} fail`);

        }

        const error = result?.status !== 200 && result?.error?.ResponseStatus ||
            result?.data?.ResponseStatus ||
            result?.response?.data?.ResponseStatus ||
            result?.message && { Message: result?.message } || null;

        if (error) {
            this._kvOrderErrorsService.updateKvOrderError({
                _id: payloadOrder.id,
                pageId: payloadOrder.pageId,
                retailerId: payloadOrder.retailerId,
                retailerCode: payloadOrder.retailerCode,
                branchId: payloadOrder.branchId,
                fbUserId: payloadOrder.fbUserId,
                kvCustomerId: payloadOrder.kvCustomerId,
                sourceId: payloadOrder.sourceId,
                sourceType: payloadOrder.sourceType,
                payload: payloadOrder.order,
                error,
            }, true).then(result => {

            }).catch(e => {
                const prefixLog = this.prefixLog('updateKvOrderError');
                this._logger.error({ MessageTemplate: { payloadOrder }, Error: new KvResponseMongoDbException(e.stack) }, `${prefixLog} fail`);
            });
        }
        return result;
    }
}
