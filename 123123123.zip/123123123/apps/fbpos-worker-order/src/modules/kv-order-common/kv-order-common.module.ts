import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvOrderUtilsService } from "./kv-order-utils.service";
import { KvInternalApiModule } from "@kiotviet-facebook-services/kv-internal-api";
import { FbPosMasterRepositoryModule } from "@kiotviet-facebook-services/fbpos-master-repository";

@Module({
    imports: [
        CommonModule,
        KvInternalApiModule,
        FbPosMasterRepositoryModule
    ],
    exports: [KvOrderUtilsService],
    providers: [KvOrderUtilsService],
})
export class KvOrderCommonModule {
}
