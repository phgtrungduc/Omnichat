export enum ErrorValidateOrderFBPosCode {
    BranchEmpty = 1,
    OrderDetailsEmpty = 2,
    ProductNotExist = 3,
    ProductCodeChange = 4,
    ProductDeleted = 5,
    ProductNotAllowSale = 6,
    ProductQuantity = 7,
    CustomerNotFound = 8,
    ProductNotActive = 9,
}