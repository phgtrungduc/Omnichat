import { Injectable } from '@nestjs/common';
import { RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    KvLogger,
    KvResponseMongoDbException,
    RabbitMQConfigKvReindexMongoDb,
    SocialTypes
} from '@kiotviet-facebook-services/common';
import { IReindexMongoDbPayload } from './interfaces/reindex-mongodb-payload.interface';
import { getDbNameSocialConversation, MongodbGroupService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { pick } from 'lodash';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class KvReindexMongodbService {
    constructor(
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
    ) {

    }

    prefixLog = (functionName) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigKvReindexMongoDb.ROUTING_KEY,
        queue: `fbpos-worker-operation:${RabbitMQConfigKvReindexMongoDb.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        }
    })
    private async _handleReindexMongodb(payload: IReindexMongoDbPayload) {
        const { SocialId, SocialType } = payload;
        const prefixLog = this.prefixLog('_handleReindexMongodb');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': payload.SocialId,
                'Kv.SocialType': payload.SocialType,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        if (!SocialId && (!SocialType || !Object.values(SocialTypes).includes(SocialType))) {
            return Promise.resolve();
        }

        try {
            if (SocialTypes.TIKTOK === SocialType) {
                await this._createCollectionAndIndexTiktok();
                return Promise.resolve();
            }
            if (SocialTypes.FACEBOOK_CATALOG === SocialType) {
                await this._createCollectionAndIndexProductCatalog();
                return Promise.resolve();
            }
            const db = await this._mongodbGroupService.getDatabase({ socialId: SocialId }, true);

            await this._checkAndReindexSocialIdCollection(SocialId, db);
            await this._checkAndReindexSocialIdConversationColl(SocialId, db);
            this._logger.info(logInput, `${prefixLog} success`);

        } catch (err) {
            this._logger.error({ ...logInput, Error: new KvResponseMongoDbException(err.stack) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }

    private async _createCollectionAndIndexTiktok() {
        const db = await this._mongodbGroupService.getDatabase({ type: 'tiktok' }, true);

        let tiktokConversationDetailColl;
        try {
            tiktokConversationDetailColl = await db.createCollection(
                this._mongodbGroupService.tiktokConversationDetailsCollName,
                { autoIndexId: true }
            );
        } catch (error) {
            tiktokConversationDetailColl = db.collection(
                this._mongodbGroupService.tiktokConversationDetailsCollName
            );

        }

        const existingIndexes = await tiktokConversationDetailColl.indexes();
        const existingIndexNames = new Set(existingIndexes.map((index) => index.name));

        const indexPromises = [];

        if (!existingIndexNames.has("id_1")) {
            indexPromises.push(
                tiktokConversationDetailColl.createIndex(
                    { id: 1 },
                    { unique: true, background: true, name: "id_1" }
                )
            );
        }

        if (!existingIndexNames.has("liveUserId_1_livestreamScriptId_1_userId_1_createTime_-1")) {
            indexPromises.push(
                tiktokConversationDetailColl.createIndex(
                    {
                        liveUserId: 1,
                        livestreamScriptId: 1,
                        userId: 1,
                        createTime: -1,
                    },
                    {
                        background: true,
                        name: "liveUserId_1_livestreamScriptId_1_userId_1_createTime_-1",
                    }
                )
            );
        }

        // Wait for all index operations to complete
        await Promise.all(indexPromises);
    }


    private async _createCollectionAndIndexProductCatalog() {
        const groups = this._mongodbGroupService.getAllGroup();
        if (!groups?.length) {
            return;
        }

        await Promise.allSettled(
            groups.map(async (group) => {
                const db = await this._mongodbGroupService.getDatabase({ group }, true);

                try {
                    await db.createCollection(this._mongodbGroupService.productCatalogsCollName, {
                        autoIndexId: true,
                    });
                } catch (error) {
                    // Error handling remains unchanged
                }

                const productCatalogsColl = db.collection(this._mongodbGroupService.productCatalogsCollName);

                const existingIndexes = await productCatalogsColl.indexes();
                const existingIndexNames = new Set(existingIndexes.map((index) => index.name));

                const indexPromises = [];

                if (!existingIndexNames.has("pageId_1_catalogId_1_retailerId_1_kvStatus_1_createdAt_-1")) {
                    indexPromises.push(
                        productCatalogsColl.createIndex(
                            {
                                pageId: 1,
                                catalogId: 1,
                                retailerId: 1,
                                kvStatus: 1,
                                createdAt: -1,
                            },
                            {
                                background: true,
                                name: "pageId_1_catalogId_1_retailerId_1_kvStatus_1_createdAt_-1",
                            }
                        )
                    );
                }

                if (!existingIndexNames.has("textSearch_text")) {
                    indexPromises.push(
                        productCatalogsColl.createIndex(
                            { textSearch: "text" },
                            {
                                background: true,
                                name: "textSearch_text",
                            }
                        )
                    );
                }

                if (!existingIndexNames.has("pageId_1_product_catalog_id_1")) {
                    indexPromises.push(
                        productCatalogsColl.createIndex(
                            {
                                pageId: 1,
                                product_catalog_id: 1,
                            },
                            {
                                background: true,
                                name: "pageId_1_product_catalog_id_1",
                            }
                        )
                    );
                }

                if (!existingIndexNames.has("pageId_1_catalogId_1_retailerId_1_createdAt_-1")) {
                    indexPromises.push(
                        productCatalogsColl.createIndex(
                            {
                                pageId: 1,
                                catalogId: 1,
                                retailerId: 1,
                                createdAt: -1,
                            },
                            {
                                background: true,
                                name: "pageId_1_catalogId_1_retailerId_1_createdAt_-1",
                            }
                        )
                    );
                }

                if (!existingIndexNames.has("pageId_1_catalogId_1_retailerId_1_title_1_createdAt_-1")) {
                    indexPromises.push(
                        productCatalogsColl.createIndex(
                            {
                                pageId: 1,
                                catalogId: 1,
                                retailerId: 1,
                                title: 1,
                                createdAt: -1,
                            },
                            {
                                background: true,
                                name: "pageId_1_catalogId_1_retailerId_1_title_1_createdAt_-1",
                                collation: {
                                    locale: "en",
                                    strength: 2,
                                    caseLevel: true,
                                    numericOrdering: true,
                                },
                            }
                        )
                    );
                }

                if (!existingIndexNames.has("pageId_1_catalogId_1_retailerId_1_availability_1_createdAt_-1")) {
                    indexPromises.push(
                        productCatalogsColl.createIndex(
                            {
                                pageId: 1,
                                catalogId: 1,
                                retailerId: 1,
                                availability: 1,
                                createdAt: -1,
                            },
                            {
                                background: true,
                                name: "pageId_1_catalogId_1_retailerId_1_availability_1_createdAt_-1",
                            }
                        )
                    );
                }

                if (!existingIndexNames.has("pageId_1_catalogId_1_retailerId_1_kvProduct.price_1_createdAt_-1")) {
                    indexPromises.push(
                        productCatalogsColl.createIndex(
                            {
                                pageId: 1,
                                catalogId: 1,
                                retailerId: 1,
                                "kvProduct.price": 1,
                                createdAt: -1,
                            },
                            {
                                background: true,
                                name: "pageId_1_catalogId_1_retailerId_1_kvProduct.price_1_createdAt_-1",
                            }
                        )
                    );
                }

                await Promise.all(indexPromises);
            })
        );
    }



    private async _checkAndReindexSocialIdCollection(socialId: string, dbInstance) {
        try {
            await dbInstance.createCollection(socialId, { autoIndexId: true });
        } catch (e) {
        }
        const socialIdColl = dbInstance.collection(socialId);
        const indexesColl = await socialIdColl.indexInformation();
        const existingIndexes = Object.keys(indexesColl).join(", ");
        await Promise.all([
            this._createIndexGroupIdTimeStamp(indexesColl, socialIdColl),
            this._createIndexFullTextSearch(indexesColl, socialIdColl),
            this._createIndexVideoIdLivestream(indexesColl, socialIdColl)
        ]);
    }

    private async _checkAndReindexSocialIdConversationColl(socialId: string, dbInstance) {
        try {
            await dbInstance.createCollection(getDbNameSocialConversation(socialId), { autoIndexId: true });
        } catch (e) {
        }
        const socialIdConversationColl = dbInstance.collection(getDbNameSocialConversation(socialId));
        const indexesColl = await socialIdConversationColl.indexInformation();
        const existingIndexes = Object.keys(indexesColl).join(", ");

        await Promise.all([
            this._createIndexSenderIdTimestampConversation(indexesColl, socialIdConversationColl),
            this._createIndexAppUserIdTimestampConversation(indexesColl, socialIdConversationColl),
            this._createIndexTimestampTypeResolvedStateConversation(indexesColl, socialIdConversationColl),
            this._createIndexTagTypeTimestampConversation(indexesColl, socialIdConversationColl),
            this._createIndexTextSearchSenderNameConversation(indexesColl, socialIdConversationColl),
        ]);
    }

    private async _createIndexGroupIdTimeStamp(indexes, socialIdCollection) {
        if (!indexes || !socialIdCollection) return;
        if (indexes["GroupId_1_TimeStamp_-1"] === undefined) {
            await socialIdCollection.createIndex({ GroupId: 1, TimeStamp: -1 }, { background: true });
        }
    }

    private async _createIndexVideoIdLivestream(indexes, socialIdCollection) {
        if (!indexes || !socialIdCollection) return;
        if (indexes["videoId_-1_IsValidateFormula_1_TimeStamp_-1"] === undefined) {
            await socialIdCollection.createIndex({ videoId: -1, IsValidateFormula: 1, TimeStamp: -1 }, {
                background: true,
                sparse: true
            });
        }
    }

    private async _createIndexFullTextSearch(indexes, socialIdCollection) {
        try {
            if (!indexes || !socialIdCollection) {
                return;
            }
            if (indexes["textsearch_username10_text5"] === undefined) {
                await socialIdCollection.createIndexes([
                    {
                        key: { SenderName: "text", Message: "text", TimeStamp: -1, Field: 1 },
                        weights: { SenderName: 10, Message: 5 },
                        name: "textsearch_username10_text5",
                        background: true,
                    },
                ]);
            }
        } catch (error) {
            if (error && error.message && error.message.includes("Message_text")) {
                return;
            }

            throw error;
        }
    }

    private async _createIndexSenderIdTimestampConversation(indexes, socialIdConversationColl) {
        if (!indexes || !socialIdConversationColl) {
            return;
        }
        if (indexes["SenderId_-1_TimeStamp_-1"] === undefined) {
            await socialIdConversationColl.createIndex(
                { SenderId: -1, TimeStamp: -1 },
                { background: true, sparse: true }
            )
        }
    }

    private async _createIndexAppUserIdTimestampConversation(indexes, socialIdConversationColl) {
        if (!indexes || !socialIdConversationColl) {
            return;
        }
        if (indexes["AppUserId_-1_TimeStamp_-1"] === undefined) {
            await socialIdConversationColl.createIndex(
                { AppUserId: -1, TimeStamp: -1 },
                { background: true, sparse: true }
            )
        }
    }

    private async _createIndexTimestampTypeResolvedStateConversation(indexes, socialIdConversationColl) {
        if (!indexes || !socialIdConversationColl) {
            return;
        }
        if (indexes["TimeStamp_-1_Type_1_Resolved_1_State_1"] === undefined) {
            await socialIdConversationColl.createIndex(
                { TimeStamp: -1, Type: 1, Resolved: 1, State: 1 },
                { background: true },
            )
        }
    }

    private async _createIndexTagTypeTimestampConversation(indexes, socialIdConversationColl) {
        if (!indexes || !socialIdConversationColl) {
            return;
        }
        if (indexes["Tags_1_Type_1_TimeStamp_-1"] === undefined) {
            await socialIdConversationColl.createIndex(
                { Tags: 1, Type: 1, TimeStamp: -1 },
                { background: true }
            )
        }
    }

    private async _createIndexTextSearchSenderNameConversation(indexes, socialIdConversationColl) {
        if (!indexes || !socialIdConversationColl) {
            return;
        }

        if (indexes["textsearch_sendername1_senderusername1"] === undefined) {
            await socialIdConversationColl.createIndex(
                { SenderName: "text", SenderUserName: "text", TimeStamp: -1, Type: 1 },
                { name: "textsearch_sendername1_senderusername1", background: true, default_language: "none" } // default_language: "none" để tránh "mongodb Stop word"
            )
        }
    }
}
