import { SocialTypes } from "@kiotviet-facebook-services/common";

export class IReindexMongoDbPayload {
    SocialId?: string;
    SocialType?: SocialTypes.TIKTOK;
}
