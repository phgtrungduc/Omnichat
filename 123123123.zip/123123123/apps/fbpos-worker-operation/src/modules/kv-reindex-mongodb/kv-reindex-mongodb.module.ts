import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { KvReindexMongodbService } from './kv-reindex-mongodb.service';

@Module({
  imports: [CommonModule, KvRabbitMQModule],
  providers: [KvReindexMongodbService],
})
export class KvReindexMongodbModule {
}
