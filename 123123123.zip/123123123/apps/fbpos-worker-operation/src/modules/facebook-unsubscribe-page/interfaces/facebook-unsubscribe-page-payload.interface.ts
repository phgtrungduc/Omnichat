export interface IFacebookUnsubscribePagePayload {
    PageId: string;
}
