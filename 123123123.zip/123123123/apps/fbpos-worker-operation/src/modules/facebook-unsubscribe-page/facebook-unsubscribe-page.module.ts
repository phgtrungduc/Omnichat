import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { FacebookUnsubscribePageService } from './facebook-unsubscribe-page.service';
import { FacebookSdkModule } from "@kiotviet-facebook-services/facebook-sdk";

@Module({
  imports: [CommonModule, KvRabbitMQModule, FacebookSdkModule],
  providers: [FacebookUnsubscribePageService],
})
export class FacebookUnsubscribePageModule {
}
