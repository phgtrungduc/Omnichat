import { RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    FacebookResponseException,
    KvLogger,
    RabbitMqConfigUnsubscribeFacebookPage,
    SocialTypes
} from '@kiotviet-facebook-services/common';
import { FacebookPageService } from "@kiotviet-facebook-services/facebook-sdk";
import { Injectable } from '@nestjs/common';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
import { IFacebookUnsubscribePagePayload } from "./interfaces/facebook-unsubscribe-page-payload.interface";

const config = require('config');

@Injectable()
export class FacebookUnsubscribePageService {
    constructor(
        private readonly _logger: KvLogger,
        private readonly _facebookPageService: FacebookPageService) {
    }

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigUnsubscribeFacebookPage.ROUTING_KEY,
        queue: `fbpos-worker-operation:${RabbitMqConfigUnsubscribeFacebookPage.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        }
    })
    private async _handledFacebookUnsubscribePage(payload: IFacebookUnsubscribePagePayload) {
        const prefixLog = this._logger.getPrefixLog(this.constructor.name, '_handledFacebookUnsubscribePage');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': payload?.PageId,
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        if (!payload?.PageId) {
            return Promise.resolve();
        }

        try {
            await this._facebookPageService.unsubscribePage(payload.PageId);
            this._logger.info(logInput, `${prefixLog} success`);

        } catch (err) {
            this._logger.error({ ...logInput, Error: new FacebookResponseException(err.stack, { cause: err }) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }
}
