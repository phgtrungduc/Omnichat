import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { KvAuditTrailService } from './kv-audit-trail.service';
import { TagAuditService } from './services/tag-audit.service';
import { PageAuditService } from './services/page-audit.service';
import { CommonAuditService } from "./services/common-audit.service";
import { CatalogAuditService } from "./services/catalog-audit.service";
import { KvInternalApiModule } from "@kiotviet-facebook-services/kv-internal-api";

@Module({
  imports: [CommonModule, KvRabbitMQModule, KvInternalApiModule],
  providers: [KvAuditTrailService, TagAuditService, PageAuditService, CommonAuditService, CatalogAuditService],
})
export class KvAuditTrailModule {
}
