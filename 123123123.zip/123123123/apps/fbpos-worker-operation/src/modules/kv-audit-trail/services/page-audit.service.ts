import { Injectable } from '@nestjs/common';
import { EventTypes, SocialTypes } from '@kiotviet-facebook-services/common';
import { AuditLogActions } from '@kiotviet-facebook-services/kv-audit-trail-adapter';
import { PageAuditLogPayload } from '../interfaces/kv-audit-load-payload.interface';
import { CommonAuditService } from "./common-audit.service";
import { IKvAuditLog } from "@kiotviet-facebook-services/kv-internal-api";

@Injectable()
export class PageAuditService {
    constructor(private readonly _commonAuditService: CommonAuditService) {
    }

    async getAuditTrailRequest(payload: PageAuditLogPayload): Promise<IKvAuditLog> {
        const eventType = payload.EventType;
        switch (eventType) {
            case EventTypes.PageInstalled:
            case EventTypes.PageUninstalled:
                return this._getPageInstalledOrUninstalledAuditTrailRequest(payload);
            default:
                break;
        }
        return Promise.resolve(null);
    }

    private async _getPageInstalledOrUninstalledAuditTrailRequest(payload: PageAuditLogPayload): Promise<IKvAuditLog> {
        const {PageInfoes, EventType, RetailerInfo} = payload;
        if (!PageInfoes || !PageInfoes.length) {
            return null;
        }
        const auditSocialInfoes = [];

        for (let i = 0; i < PageInfoes.length; i++) {
            const item = PageInfoes[0];
            const info = await this._commonAuditService.getSocialInfoForAuditLog(item.SocialId);
            if (info) {
                auditSocialInfoes.push(info);
            }
        }
        if (!auditSocialInfoes.length) {
            return null;
        }
        const isAddNew = EventTypes.PageInstalled === EventType;
        const actionContent = isAddNew ? 'Thêm kết nối' : 'Xóa kết nối';
        const socialContent = SocialTypes.FACEBOOK === auditSocialInfoes?.[0].socialType ? 'trang Facebook' : 'tài khoản Instagram';
        const linkPages = auditSocialInfoes.map(info => info.linkPage).join(', ');
        return {
            FunctionId: auditSocialInfoes?.[0].auditLogFunction,
            Action: isAddNew ? AuditLogActions.Created : AuditLogActions.Deleted,
            Content: `${actionContent} ${socialContent} ${linkPages} thành công.`,
            UserId: RetailerInfo?.UserId || -1
        };
    }


}
