import { Inject, Injectable } from '@nestjs/common';
import { ConversationType, EventTypes, SocialTypes } from '@kiotviet-facebook-services/common';
import { AuditLogActions, AuditLogFunctions } from '@kiotviet-facebook-services/kv-audit-trail-adapter';
import { TagAuditLogPayload } from '../interfaces/kv-audit-load-payload.interface';
import {
    MongodbGroupService,
    TagRepository,
    WebhookSubscriptionRepository
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { CACHE_KEYS } from '@kiotviet-facebook-services/cache';
import { IKvAuditLog } from "@kiotviet-facebook-services/kv-internal-api";

const getSocialTypeName = (socialType: SocialTypes | string) => {
    if (SocialTypes.INSTAGRAM === socialType) {
        return 'tài khoản Instagram';
    }
    return 'trang Facebook';
}

interface ISocialInfo {
    socialName: string;
    socialType: string;
    socialTypeName: string;
}

@Injectable()
export class TagAuditService {
    constructor(
        private readonly _webhookSubscriptionRepository: WebhookSubscriptionRepository,
        private readonly _tagRepository: TagRepository,
        private readonly _mongodbGroupService: MongodbGroupService,
        @Inject(CACHE_MANAGER) readonly _cache: Cache) {
    }


    async getAuditTrailRequest(payload: TagAuditLogPayload): Promise<IKvAuditLog> {
        const eventType = payload.EventType;

        switch (eventType) {
            case EventTypes.TagCreated:
                return await this._getCreatedTagAuditTrailRequest(payload);
            case EventTypes.TagUpdated:
                return await this._getUpdatedTagAuditTrailRequest(payload);
            case EventTypes.TagRemoved:
                return await this._getRemovedTagAuditTrailRequest(payload);
            case EventTypes.TagDetached:
                return await this._getDetachedTagAuditTrailRequest(payload);
            default:
                break;
        }

        return Promise.resolve(null);
    }


    private async _getCreatedTagAuditTrailRequest(payload: TagAuditLogPayload): Promise<IKvAuditLog> {
        const {SocialId, Data, RetailerInfo} = payload;
        const {tag} = Data;
        const {socialTypeName, socialName} = await this._getSocialInfo(SocialId);

        return {
            FunctionId: AuditLogFunctions.ConversationTag,
            Action: AuditLogActions.Created,
            Content: `Thêm nhãn hội thoại ${tag} thành công trên ${socialTypeName} ${socialName}.`,
            UserId: RetailerInfo?.UserId || -1
        };
    }

    private async _getUpdatedTagAuditTrailRequest(payload: TagAuditLogPayload): Promise<IKvAuditLog> {
        const {Data, SocialId, RetailerInfo} = payload;
        const {tag, color, oldTag, oldColor, conversationid} = Data;
        const {socialTypeName, socialName} = await this._getSocialInfo(SocialId);
        let content = '';

        if (tag || color) {
            content = `Cập nhật nhãn hội thoại trên ${socialTypeName} ${socialName}: ${oldTag} -> ${tag}, màu ${oldColor} -> màu ${color}.`
        } else if (conversationid && SocialId) {
            content = await this._getAssignOrDetachedTagContent(payload, conversationid, socialName, socialTypeName);
        }

        return {
            FunctionId: AuditLogFunctions.ConversationTag,
            Action: AuditLogActions.Updated,
            Content: content,
            UserId: RetailerInfo?.UserId || -1

        };
    }

    private async _getRemovedTagAuditTrailRequest(payload: TagAuditLogPayload): Promise<IKvAuditLog> {
        const {SocialId, Data, RetailerInfo} = payload;
        const {tagname} = Data;
        const {socialTypeName, socialName} = await this._getSocialInfo(SocialId);

        return {
            FunctionId: AuditLogFunctions.ConversationTag,
            Action: AuditLogActions.Deleted,
            Content: `Xóa nhãn hội thoại ${tagname} thành công trên ${socialTypeName} ${socialName}.`,
            UserId: RetailerInfo?.UserId || -1
        };
    }

    private async _getAssignOrDetachedTagContent(payload: TagAuditLogPayload, conversationId: string, socialName: string, socialTypeName: string): Promise<string> {
        const {EventType, SocialId, Data} = payload;
        if (EventTypes.TagDetached !== EventType && EventTypes.TagUpdated !== EventType) {
            return '';
        }
        const conversation = await this._getConversation(SocialId, conversationId);
        const senderName = conversation && (conversation.SenderName || conversation.SenderUserName) || '';
        const tagName = await this._getTagName(Data.tagid);
        if (!conversation || !senderName || !tagName) {
            return '';
        }
        switch (conversation.Type) {
            case ConversationType.MESSENGER:
                return EventTypes.TagUpdated === EventType ?
                    `Gắn nhãn ${tagName} vào tin nhắn của ${senderName} trên ${socialTypeName} ${socialName}.` :
                    `Gỡ nhãn ${tagName} khỏi tin nhắn của ${senderName} trên ${socialTypeName} ${socialName}.`;
            case ConversationType.FEED:
                const commentDetail = await this._getDetailConversation(SocialId, conversationId);
                let comment = commentDetail && commentDetail.Message;
                // If not found comment, it maybe is attachment
                if (!comment) {
                    comment = commentDetail
                        && commentDetail.entry
                        && commentDetail.entry[0]
                        && commentDetail.entry[0].changes
                        && commentDetail.entry[0].changes[0]
                        && commentDetail.entry[0].changes[0].value
                        && commentDetail.entry[0].changes[0].value.photo;
                    comment = "Ảnh: " + comment;
                }
                return EventTypes.TagUpdated === EventType ?
                    `Gắn nhãn ${tagName} vào bình luận ${comment} của ${senderName} trên ${socialTypeName} ${socialName}.` :
                    `Gỡ nhãn ${tagName} vào bình luận ${comment} của ${senderName} trên ${socialTypeName} ${socialName}.`;
            default:
                return '';
        }
    }

    private async _getDetachedTagAuditTrailRequest(payload: TagAuditLogPayload): Promise<IKvAuditLog> {
        const {SocialId, Data, RetailerInfo} = payload;
        const {conversationid} = Data;
        const {socialTypeName, socialName} = await this._getSocialInfo(SocialId);
        const content = await this._getAssignOrDetachedTagContent(payload, conversationid, socialName, socialTypeName);

        return {
            FunctionId: AuditLogFunctions.ConversationTag,
            Action: AuditLogActions.Updated,
            Content: content,
            UserId: RetailerInfo?.UserId || -1
        };
    }

    private async _getConversation(socialId: string, conversationId: string): Promise<any> {
        const db = await this._mongodbGroupService.getDatabase({socialId});
        return await db.collection(`${socialId}_conversation`).findOne({_id: conversationId});
    }

    private async _getDetailConversation(socialId: string, conversationId: string): Promise<any> {
        const db = await this._mongodbGroupService.getDatabase({socialId});
        return await db.collection(`${socialId}`).findOne({_id: conversationId});
    }

    private async _getTagName(tagId: string) {
        const key = `${CACHE_KEYS.TAG.TAG_ID.NAME}${tagId}`;
        const cache = await this._cache.get(key) as any;
        if (cache) {
            return cache.detail?.title || '';
        }

        const tag = await this._tagRepository.findById(tagId);
        if (tag) {
            await this._cache.set(key, tag, {ttl: CACHE_KEYS.TAG.TAG_ID.TTL} as any);
        }
        return tag && tag.detail && tag.detail['title'] || '';

    }

    private async _getSocialInfo(socialId: string): Promise<ISocialInfo> {
        const socialInfo = await this._webhookSubscriptionRepository.getSubscriptionBySocialId(socialId);
        const socialName = socialInfo && (socialInfo.PageInfo && socialInfo.PageInfo['name'] || socialInfo.InstagramInfo && socialInfo.InstagramInfo['username']) || '';
        const socialType = socialInfo.SocialType || (socialInfo.InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK);
        const socialTypeName = getSocialTypeName(socialType);
        return {
            socialName,
            socialType,
            socialTypeName
        };
    }
}
