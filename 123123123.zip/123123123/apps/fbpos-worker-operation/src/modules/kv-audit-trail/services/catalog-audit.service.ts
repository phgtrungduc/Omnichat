import { Injectable } from '@nestjs/common';
import { EventTypes, FacebookCatalogSyncInventoryTypes, SocialTypes } from '@kiotviet-facebook-services/common';
import { AuditLogActions, AuditLogFunctions } from '@kiotviet-facebook-services/kv-audit-trail-adapter';
import { CatalogAuditLogPayload } from '../interfaces/kv-audit-load-payload.interface';
import { CommonAuditService } from './common-audit.service';
import { IKvAuditLog } from "@kiotviet-facebook-services/kv-internal-api";

@Injectable()
export class CatalogAuditService {
    constructor(private readonly commonAuditService: CommonAuditService) {
    }

    async getAuditTrailRequest(payload: CatalogAuditLogPayload): Promise<IKvAuditLog> {
        switch (payload.EventType) {
            case EventTypes.CatalogInstalled:
            case EventTypes.CatalogUninstalled:
                return this._getCatalogInstalledAuditTrailRequest(payload);
            case EventTypes.SetupCatalog:
                return this._getSetupCatalogAuditTrailRequest(payload);
            case EventTypes.SendProductCatalog:
                return this._getSendProductCatalogAuditTrailRequest(payload);
            default:
                return null;
        }
    }

    private async _getCatalogInstalledAuditTrailRequest(payload: CatalogAuditLogPayload): Promise<IKvAuditLog> {
        const { SocialId, RetailerInfo } = payload;
        const { catalogName } = payload?.Data || {};
        const inInstalled = EventTypes.CatalogInstalled === payload.EventType;
        const { socialType, linkPage } = await this.commonAuditService.getSocialInfoForAuditLog(SocialId);

        const socialContent = this._getSocialContent(socialType);
        const actionContent = inInstalled ?
            `Kết nối thành công Catalog ${catalogName}` : `Xóa kết nối Catalog ${catalogName}`;

        return {
            FunctionId: AuditLogFunctions.CatalogManagementSetting,
            Action: inInstalled ? AuditLogActions.Created : AuditLogActions.Deleted,
            Content: `${actionContent} thuộc ${socialContent} ${linkPage}.`,
            UserId: RetailerInfo?.UserId || -1
        };
    }

    private async _getSetupCatalogAuditTrailRequest(payload: CatalogAuditLogPayload): Promise<IKvAuditLog> {
        const { SocialId, RetailerInfo } = payload;
        const {
            catalogName, branchName, syncInventory,
            pricebookName, oldPricebookName, oldSyncInventory, oldBranchName,
            isPriceBookChange,
            oldIsAutoDeleteProductsOnStatusChange, isAutoDeleteProductsOnStatusChange
        } = payload?.Data || {};

        const { socialType, linkPage } = await this.commonAuditService.getSocialInfoForAuditLog(SocialId);
        const socialContent = this._getSocialContent(socialType);
        const isUpdate = oldBranchName || oldSyncInventory || oldPricebookName;
        if (isPriceBookChange && oldPricebookName && pricebookName) {
            return {
                FunctionId: AuditLogFunctions.CatalogManagementSetting,
                Action: AuditLogActions.Updated,
                Content: `Cập nhật bảng giá Catalog ${catalogName} thuộc ${socialContent} ${linkPage}: ${this._formatChange(oldPricebookName, pricebookName)}`,
                UserId: RetailerInfo?.UserId || -1
            };
        }
        const contentLines = [
            `${isUpdate ? 'Cập nhật thiết lập' : 'Thiết lập'} Catalog ${catalogName} thuộc ${socialContent} ${linkPage}.`,
            `• Chi nhánh đồng bộ: ${this._formatChange(oldBranchName, branchName)}`,
            `• Đồng bộ tồn kho: ${this._formatChange(
                oldSyncInventory ? this.getLabelSyncInventory(oldSyncInventory) : '',
                this.getLabelSyncInventory(syncInventory)
            )}`,
            `• Đồng bộ giá bán: ${this._formatChange(oldPricebookName, pricebookName)}`,
            `• Tự động xóa hàng hóa thay đổi trạng thái: ${this._formatChange(
                this.getLabelOnOff(oldIsAutoDeleteProductsOnStatusChange),
                this.getLabelOnOff(isAutoDeleteProductsOnStatusChange)
            )}`,
        ];

        return {
            FunctionId: AuditLogFunctions.CatalogManagementSetting,
            Action: AuditLogActions.Updated,
            Content: contentLines.join('<br> '),
            UserId: RetailerInfo?.UserId || -1

        };
    }

    private async _getSendProductCatalogAuditTrailRequest(payload: CatalogAuditLogPayload): Promise<IKvAuditLog> {
        const { SocialId, RetailerInfo, ProductData } = payload;
        if (!ProductData?.length) {
            return null;
        }
        const { catalogName, isAutoSync } = payload?.Data || {};

        const { socialType, linkPage } = await this.commonAuditService.getSocialInfoForAuditLog(SocialId);
        const socialContent = this._getSocialContent(socialType);
        const getActionText = (method, isAutoSync) => {
            const actionMap = {
                CREATE: "Đăng",
                UPDATE: "Đăng lại",
                DELETE: "Xóa"
            };
            return isAutoSync ? "Đồng bộ tự động" : (actionMap[method] || "Hành động không xác định");
        };

        let content = `${getActionText(ProductData[0].method, isAutoSync)} ${ProductData.length} hàng hóa trên Catalog ${catalogName} thuộc ${socialContent} ${linkPage}. <br> `;
        const productContents = []
        for (let i = 0; i < ProductData.length; i++) {
            const product = ProductData[i].data;
            let content = '•';

            if (product.id) content += ` Mã hàng: [ProductCode]${product.id}[/ProductCode];`;
            if (product.kvProduct?.name) content += ` Tên hàng: ${product.kvProduct.name};`;
            if (product.quantity_to_sell_on_facebook != null) content += ` Tồn kho: ${product.quantity_to_sell_on_facebook};`;
            if (product.price) content += ` Giá bán: ${product.price}`;

            if (content !== '•') productContents.push(content);
        }
        if (productContents?.length) {
            content = content + productContents.join('<br> ')
        }

        return {
            FunctionId: AuditLogFunctions.CatalogManagementSetting,
            Action: AuditLogActions.Updated,
            Content: content,
            UserId: RetailerInfo?.UserId || -1
        };
    }

    private _getSocialContent(socialType: string): string {
        return socialType === SocialTypes.FACEBOOK ? 'trang Facebook' : 'tài khoản Instagram';
    }

    private _formatChange(oldValue: string, newValue: string): string {
        if (!newValue) {
            return oldValue || '';
        }
        return oldValue && oldValue !== newValue ? `${oldValue} -> ${newValue}` : newValue;
    }

    private getLabelSyncInventory(syncInventory: FacebookCatalogSyncInventoryTypes): string {
        switch (syncInventory) {
            case FacebookCatalogSyncInventoryTypes.INVENTORY:
                return 'Tồn kho';
            case FacebookCatalogSyncInventoryTypes.INVENTORY_EXCLUDING_ORDER_ITEM:
                return 'Tồn kho trừ đặt hàng';
            default:
                return '';
        }
    }

    private getLabelOnOff(isOn: boolean): string {
        return isOn ? 'Bật' : 'Tắt';
    }
}
