import { Injectable } from '@nestjs/common';
import { SocialTypes } from '@kiotviet-facebook-services/common';
import { AuditLogFunctions } from '@kiotviet-facebook-services/kv-audit-trail-adapter';
import { WebhookSubscriptionRepository } from '@kiotviet-facebook-services/fbpos-master-repository';
import { IAuditLogSocialInfo } from '../interfaces/audit-log-social-info.interface';

@Injectable()
export class CommonAuditService {
    constructor(private readonly _webhookSubscriptionRepository: WebhookSubscriptionRepository) {
    }

    buildLinkFacebook = (pageId, pageName) => `<a href="https://facebook.com/${pageId}" target="_blank">${pageName}</a>`;
    buildLinkInstagram = (pageUserName, pageName) => `<a href="https://www.instagram.com/${pageUserName}" target="_blank">${pageName}</a>`;

    async getSocialInfoForAuditLog(socialId: string): Promise<IAuditLogSocialInfo> {
        const socialInfo = await this._webhookSubscriptionRepository.getSubscriptionBySocialId(socialId, true);
        if (!socialInfo) {
            return null;
        }
        const socialName = socialInfo && (socialInfo.PageInfo && socialInfo.PageInfo['name'] || socialInfo.InstagramInfo && socialInfo.InstagramInfo['username']) || '';
        const socialType = socialInfo.SocialType || (socialInfo.InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK);

        const isInstagram = SocialTypes.INSTAGRAM === socialType;
        return {
            pageLabel: isInstagram ? 'Tài khoản Instagram' : 'Trang Facebook',
            socialType,
            linkPage: isInstagram ? this.buildLinkInstagram(socialName, socialName) :
                this.buildLinkFacebook(socialId, socialName),
            auditLogFunction: isInstagram ? AuditLogFunctions.InstagramFanpageSettings : AuditLogFunctions.FacebookFanpageSettings
        };
    }


}
