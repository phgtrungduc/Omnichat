import { Injectable } from '@nestjs/common';
import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    EventTypes,
    IBaseEventPayload,
    IndustryTypes,
    KvAuditTrailException,
    KvLogger,
    KvRabbitMQException,
    RabbitMQConfigKvAuditTrail,
    sleep,
    SocialTypes
} from '@kiotviet-facebook-services/common';
import {
    CatalogAuditLogPayload,
    PageAuditLogPayload,
    TagAuditLogPayload
} from './interfaces/kv-audit-load-payload.interface';
import { TagAuditService } from './services/tag-audit.service';
import { PageAuditService } from './services/page-audit.service';
import { pick } from 'lodash';
import { CatalogAuditService } from "./services/catalog-audit.service";
import { IKvAuditLog, KvAuditLogService } from "@kiotviet-facebook-services/kv-internal-api";
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class KvAuditTrailService {
    private readonly _maxRetry = 20;
    private readonly _delay = 10000;
    private readonly _rabbitMQConfig;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _tagService: TagAuditService,
        private readonly _pageService: PageAuditService,
        private readonly _catalogAuditService: CatalogAuditService,
        private readonly _kvAuditLogService: KvAuditLogService,
        private readonly _amqpConnection: AmqpConnection,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');

    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);


    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMQConfigKvAuditTrail.ROUTING_KEY,
        queue: `fbpos-worker-operation:${RabbitMQConfigKvAuditTrail.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        }
    })
    private async _handleKvAuditLog(payload: IBaseEventPayload) {
        const prefixLog = this.prefixLog('_handleKvAuditLog');

        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.RetailerCode': payload?.RetailerInfo?.Code,
                'Kv.RetailerId': payload?.RetailerInfo?.Id,
                'Kv.BranchId': payload?.RetailerInfo?.BranchId,
                'Kv.UserId': payload?.RetailerInfo?.UserId,
                'Kv.GroupId': payload?.RetailerInfo?.ZoneId,
                'Kv.SocialId': payload?.SocialId,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        const eventType = payload.EventType;
        try {
            const Industry = payload?.RetailerInfo?.Industry && parseInt(payload?.RetailerInfo?.Industry) || IndustryTypes.MOTHER_AND_BABY;
            if ([IndustryTypes.HOTEL, IndustryTypes.SALON, IndustryTypes.FNB].includes(Industry)) {
                return Promise.resolve();
            }
            let data: IKvAuditLog;
            switch (eventType) {
                case EventTypes.TagCreated:
                case EventTypes.TagUpdated:
                case EventTypes.TagRemoved:
                case EventTypes.TagDetached:
                    data = await this._tagService.getAuditTrailRequest(payload as TagAuditLogPayload);
                    break;
                case EventTypes.PageInstalled:
                case EventTypes.PageUninstalled:
                    data = await this._pageService.getAuditTrailRequest(payload as PageAuditLogPayload);
                    break;
                case EventTypes.CatalogInstalled:
                case EventTypes.CatalogUninstalled:
                case EventTypes.SetupCatalog:
                case EventTypes.SendProductCatalog:
                    data = await this._catalogAuditService.getAuditTrailRequest(payload as CatalogAuditLogPayload);
                    break;
                default:
                    break;
            }
            if (data) {
                await this._kvAuditLogService.addAuditLog(payload.RetailerInfo.Code, payload.RetailerInfo.Id, data);
            }
            this._logger.info(logInput, `${prefixLog} success`);

        } catch (err) {
            this._logger.error({ ...logInput, Error: new KvAuditTrailException(err.stack) }, `${prefixLog} fail`);
            if ((payload.retryTime || 0) <= this._maxRetry) {
                this._sentEventToMQToRetryKvAuditLog(payload);
            }
            return Promise.resolve();
        }

        return Promise.resolve();
    }

    private async _sentEventToMQToRetryKvAuditLog(payload: IBaseEventPayload) {
        await sleep(this._delay);
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMQConfigKvAuditTrail.ROUTING_KEY,
            { ...payload, retryTime: (payload.retryTime || 0) + 1 }
        ).catch(err => {
            const prefixLog = this.prefixLog('_sentEventToMQToRetryKvAuditLog');
            this._logger.error({ MessageTemplate: { payload }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }
}
