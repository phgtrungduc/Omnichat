import { FacebookCatalogSyncInventoryTypes, IBaseEventPayload } from "@kiotviet-facebook-services/common";
import { IRetailerAuditInfo } from "@kiotviet-facebook-services/kv-audit-trail-adapter";
import { IFacebookCatalogItemBatchRequest } from "@kiotviet-facebook-services/facebook-sdk";

export class TagAuditLogPayload implements IBaseEventPayload {
    EventType: string;
    SocialId: string;
    Data: any;
    RetailerInfo: IRetailerAuditInfo;
    retryTime?: number;
}

export class PageAuditLogPayload implements IBaseEventPayload {
    EventType: string;
    SocialId: string;
    Data: any;
    RetailerInfo: IRetailerAuditInfo;
    PageInfoes: any[];
    retryTime?: number;
}

export class CatalogAuditLogPayload implements IBaseEventPayload {
    EventType: string;
    SocialId: string;
    Data: ICatalogInfo;
    ProductData?: IFacebookCatalogItemBatchRequest[];
    RetailerInfo: IRetailerAuditInfo;
    retryTime?: number;
}

export interface ICatalogInfo {
    catalogName: string;

    branchName?: string;
    syncInventory?: FacebookCatalogSyncInventoryTypes;
    pricebookName?: string;

    oldBranchName?: string;
    oldSyncInventory?: FacebookCatalogSyncInventoryTypes;
    oldPricebookName?: string;
    oldIsAutoDeleteProductsOnStatusChange?: boolean;

    isPriceBookChange?: boolean;
    isAutoDeleteProductsOnStatusChange?: boolean;
    isAutoSync?: boolean;
}
