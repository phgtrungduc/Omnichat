import { SocialTypes } from "@kiotviet-facebook-services/common";
import { AuditLogFunctions } from "@kiotviet-facebook-services/kv-audit-trail-adapter";

export interface IAuditLogSocialInfo {
    pageLabel: string;
    socialType: string | SocialTypes;
    linkPage: string;
    auditLogFunction: AuditLogFunctions;
}