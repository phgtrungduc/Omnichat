import { Module } from '@nestjs/common';
import { CoreModule } from './core/core.module';
import { KvAuditTrailModule } from './modules/kv-audit-trail/kv-audit-trail.module';
import { KvReindexMongodbModule } from './modules/kv-reindex-mongodb/kv-reindex-mongodb.module';
import { AlertNotificationModule } from '@kiotviet-facebook-services/alert-notification';
import { FacebookUnsubscribePageModule } from "./modules/facebook-unsubscribe-page/facebook-unsubscribe-page.module";

@Module({
    imports: [
        CoreModule,
        KvAuditTrailModule,
        KvReindexMongodbModule,
        FacebookUnsubscribePageModule,
        AlertNotificationModule
    ],
    controllers: [],
    providers: [],
})
export class AppModule {
}
