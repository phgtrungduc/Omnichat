import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { CacheModule } from '@kiotviet-facebook-services/cache';

process.env['NODE_CONFIG_DIR'] = `${__dirname}/config/`;
const config = require('config');

@Global()
@Module({
    imports: [
        ConfigModule.forRoot({
            isGlobal: true,
            load: [() => config],
        }),
        CacheModule
    ],
    providers: [],
    exports: [],
})
export class CoreModule {
}
