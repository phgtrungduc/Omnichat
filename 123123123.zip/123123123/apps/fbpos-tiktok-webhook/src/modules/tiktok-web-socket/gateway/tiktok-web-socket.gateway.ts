import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import { KvBaseException, KvLogger, KvRabbitMQException, RabbitMQConfigTiktokWebhook, RabbitMqConfigTiktokWebSocket, SocialTypes } from '@kiotviet-facebook-services/common';
import { WebSocketGateway, WebSocketServer, OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect, SubscribeMessage } from '@nestjs/websockets';
import { WebSocket, Server } from 'ws';
import { pick } from 'lodash';
import { TiktokLivestreamScriptService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { Inject } from '@nestjs/common';
import { CACHE_KEYS } from '@kiotviet-facebook-services/cache';
import { CACHE_MANAGER, Cache } from '@nestjs/cache-manager';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

const QUEUE_ROUTING = {
  chat: 'tiktok.db.tiktoknotification.tiktokcomment.tiktokautocreateuserprofile',
  member: 'tiktok.tiktoknotification',
  roomUser: 'tiktok.tiktoknotification',
  like: 'tiktok.tiktoknotification',
  streamEnd: 'tiktok.tiktoknotification.tiktoklivereportdashboard'
}

@WebSocketGateway({ path: 'ws' })
export class TiktokWebsocketsGateway implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect {
  private readonly _rabbitMQConfig;
  constructor(private readonly _amqpConnection: AmqpConnection,
    private readonly _logger: KvLogger,
    private readonly _tiktokLivestreamScriptService: TiktokLivestreamScriptService,
    @Inject(CACHE_MANAGER) private readonly _cache: Cache,
  ) {
    this._rabbitMQConfig = config.get('rabbitMQ');
  }
  prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

  @WebSocketServer() server: Server;

  @RabbitSubscribe({
    exchange: config.get('rabbitMQ').mainExchange,
    routingKey: RabbitMqConfigTiktokWebSocket.ROUTING_KEY,
    queue: `fbpos-tiktok-webhook:${RabbitMqConfigTiktokWebSocket.QUEUE_NAME}`,
    queueOptions: {
      durable: true,
      arguments: { 'x-queue-type': 'quorum' },
    },
  })
  async handEventTiktok(payload: any) {
    const prefixLog = this.prefixLog('handEventTiktok');
    const logInput: IKvLogInput = {
      MessageTemplate: { payload },
      Properties: {
        'Kv.SocialType': SocialTypes.TIKTOK,
        SourceContext: prefixLog,
        _startTime: Date.now()
      }
    }
    try {
      this._logger.info(logInput, `${prefixLog} received payload`);
      const { event, data } = payload;
      switch (event) {
        case 'streamEnd':
          this.manualDisconnectLivestream(data, prefixLog, logInput);
          break;
        case 'init':
          const { livestreamScriptId } = data;
          if (!livestreamScriptId) {
            break;
          }
          const cacheKey = `${CACHE_KEYS.LIVESTREAM_SCRIPT_INPROGRESS.CONFIG}${livestreamScriptId}`;
          await this._cache.set(cacheKey, 'true', { ttl: CACHE_KEYS.LIVESTREAM_SCRIPT_INPROGRESS.TTL } as any);
          break;
        default:
          break;
      }
      this._logger.info(logInput, `${prefixLog} success`);
      return Promise.resolve();
    } catch (error) {
      this._logger.error({ ...logInput, Error: new KvBaseException(error.stack) }, `${prefixLog} fail`);
    }
  }

  manualDisconnectLivestream(data: any, prefixLog: string, logInput: IKvLogInput) {
    if (!data || !data.length) {
      return;
    }
    const payloadToExtension = {
      data: data,
      eventType: 'accountDisconnected'
    }
    this.server.clients.forEach(client => client.send(JSON.stringify(payloadToExtension)));

    data.forEach(livestreamScriptId => {
      this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMQConfigTiktokWebhook.ROUTING_KEY, {
        event: 'streamEnd',
        data: {
          livestreamScriptId: livestreamScriptId
        }
      }).catch(err => {
        this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
      });
    });
  }

  //implement interface OnGatewayInit: executed when the WebSocket gateway is initialized
  afterInit(server: Server) {
    this.server = server;
    console.log('WebSocket Gateway initialized');
  }

  //implement interface OnGatewayConnection: called when a new WebSocket connection is established
  handleConnection(client: WebSocket) {
    console.log(`Client connected.`);
  }

  //disconnect from client to this websocket
  handleDisconnect(client: WebSocket) {
    // console.log(client);
  }

  @SubscribeMessage('initConnection')
  handleMessageInitConnection(client: WebSocket, payload: string): void {

  }

  @SubscribeMessage('chat')
  handleChatEvent(client: WebSocket, payload: string) {
    const data = {
      event: 'chat',
      data: payload
    }
    this._sentEventToMQHandleProcessTiktokWebhook(data);
  }

  //event disconnect from client to tiktok ws
  @SubscribeMessage('disconnected')
  handleDisconnectedEvent(client: WebSocket, payload: string) {
    const data = {
      event: 'disconnected',
      data: payload
    }
    this._sentEventToMQHandleProcessTiktokWebhook(data);
  }

  @SubscribeMessage('streamEnd')
  handleStreamEndEvent(client: WebSocket, payload: string) {
    const data = {
      event: 'streamEnd',
      data: payload
    }
    this._sentEventToMQHandleProcessTiktokWebhook(data);
  }

  @SubscribeMessage('ping')
  async handleHealthCheckEvent(client: WebSocket, payload: any) {
    try {
      const { livestreamScriptId } = payload;
      const cacheKey = `${CACHE_KEYS.LIVESTREAM_SCRIPT_INPROGRESS.CONFIG}${livestreamScriptId}`;
      await this._cache.set(cacheKey, 'true', { ttl: CACHE_KEYS.LIVESTREAM_SCRIPT_INPROGRESS.TTL } as any);
    } catch (error) {
      console.log(error);
    }
  }


  private _sentEventToMQHandleProcessTiktokWebhook(payload: any) {
    const prefixLog = this.prefixLog('_sentEventToMQHandleProcessTiktokWebhook');
    this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMQConfigTiktokWebhook.ROUTING_KEY, payload).catch(err => {
      this._logger.error({ MessageTemplate: { payload }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
    });
  }
}
