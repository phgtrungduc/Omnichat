import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { CommonModule } from "@kiotviet-facebook-services/common";
import { KvRabbitMQModule } from "@kiotviet-facebook-services/rabbitmq";
import { TiktokWebsocketsGateway } from './gateway/tiktok-web-socket.gateway';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';

@Module({
  imports: [FbPosMasterRepositoryModule, CommonModule, HttpModule, KvRabbitMQModule],
  controllers: [],
  providers: [TiktokWebsocketsGateway],
  exports: []
})
export class TiktokWebSocketModule {
}
