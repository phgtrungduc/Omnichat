import { Controller, Get } from '@nestjs/common';
import { ApiResponse, ApiTags } from '@nestjs/swagger';

@Controller('')
@ApiTags('')
export class HealthController {
    constructor() {
    }

    @Get('/ping')
    @ApiResponse({status: 200})
    healthPing() {
        return 'pong';
    }

}
