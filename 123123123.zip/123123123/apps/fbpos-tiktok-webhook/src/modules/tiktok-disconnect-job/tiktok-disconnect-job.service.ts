import { InjectQueue } from '@nestjs/bullmq';
import { Injectable } from '@nestjs/common';
import { Queue } from 'bullmq';

@Injectable()
export class TiktokDisconnectJobService {
  constructor(@InjectQueue('tiktok-disconnect') private disconnectedJobQueue: Queue) {
  }

  public async handleJobv2() {
    const connection = await this.disconnectedJobQueue.client as any;
    if (connection && connection.options) {
      const { host, port, db } = connection.options;
      console.log(`Job  is connected to Redis server at ${host}:${port}, database ${db}`);
    } else {
      console.log(`Job has no Redis connection information available.`);
    }

    await this.disconnectedJobQueue.add('streamEnd', {}, { repeat: { every: 1000 * 60 } });
  }
}
