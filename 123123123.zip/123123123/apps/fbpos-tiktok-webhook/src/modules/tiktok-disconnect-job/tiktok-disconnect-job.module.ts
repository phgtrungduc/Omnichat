import { Module } from "@nestjs/common";
import { TiktokDisconnectJobService } from "./tiktok-disconnect-job.service";
import { BullModule } from '@nestjs/bullmq';
import { CommonModule } from "@kiotviet-facebook-services/common";
import { DiconnectedConsumer } from "./consumer.service";
import { KvRabbitMQModule } from "@kiotviet-facebook-services/rabbitmq";
import { FbPosMasterRepositoryModule } from "@kiotviet-facebook-services/fbpos-master-repository";
@Module({
  imports: [
    CommonModule,
    KvRabbitMQModule,
    FbPosMasterRepositoryModule,
    BullModule.registerQueue({
      name: 'tiktok-disconnect',
      defaultJobOptions: {
        removeOnComplete: true,
        removeOnFail: true,
      },
    })
  ],
  controllers: [],
  providers: [TiktokDisconnectJobService, DiconnectedConsumer],
  exports: []
})
export class TiktokDisconnectedJobModule {
  constructor(private  _tiktokDisconnectJobService: TiktokDisconnectJobService ){
    _tiktokDisconnectJobService.handleJobv2();
  }
}
