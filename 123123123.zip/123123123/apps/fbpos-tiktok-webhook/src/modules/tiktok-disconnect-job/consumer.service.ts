import { AmqpConnection } from '@golevelup/nestjs-rabbitmq';
import { CACHE_KEYS } from '@kiotviet-facebook-services/cache';
import { KvBaseException, KvLogger, KvRabbitMQException, LivestreamStatusEnum, RabbitMQConfigTiktokWebhook, SocialTypes } from '@kiotviet-facebook-services/common';
import { TiktokLiveStreamScriptRepository } from '@kiotviet-facebook-services/fbpos-master-repository';
import {
  Processor,
  WorkerHost
} from '@nestjs/bullmq';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject, Injectable } from '@nestjs/common';
import { Job } from 'bullmq';
import { Cache } from 'cache-manager';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
const LIMIT_PROCESS = 50;
const config = require('config');

@Processor('tiktok-disconnect')

@Injectable()
export class DiconnectedConsumer extends WorkerHost {
  private readonly _rabbitMQConfig;

  constructor(@Inject(CACHE_MANAGER) private readonly _cache: Cache,
    private readonly _tiktokLivestreamScriptRepository: TiktokLiveStreamScriptRepository,
    private readonly _amqpConnection: AmqpConnection,
    private readonly _logger: KvLogger) {
    super();
    this._rabbitMQConfig = config.get('rabbitMQ');
  }
  prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

  async process(job: Job<any, any, string>): Promise<any> {
    const prefixLog = this.prefixLog('ProcessEndLivestream');


    try {
      const fbLivestreamScripts = await this._tiktokLivestreamScriptRepository.getTiktokLivestreamScripts({ status: LivestreamStatusEnum.PROCESSING }, { selectedKeys: { _id: 1 }, limit: LIMIT_PROCESS });
      if (fbLivestreamScripts && fbLivestreamScripts.length) {
        for (let i = 0; i < fbLivestreamScripts.length; i++) {
          const lss = fbLivestreamScripts[i];
          const cacheKey = `${CACHE_KEYS.LIVESTREAM_SCRIPT_INPROGRESS.CONFIG}${lss._id}`;
          const value = await this._cache.get(cacheKey);
          if (!value) {
            const logInput: IKvLogInput = {
              MessageTemplate: { lss },
              Properties: {
                'Kv.SocialType': SocialTypes.TIKTOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
              }
            }
            this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMQConfigTiktokWebhook.ROUTING_KEY, {
              event: 'streamEnd',
              data: {
                livestreamScriptId: lss._id
              }
            }).catch(err => {
              this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
            });
            this._logger.info(logInput, `${prefixLog} success`);
          }
        }
      }
    } catch (error) {
      this._logger.error({ Error: new KvBaseException(error.stack) }, `${prefixLog} fail`);
    }
  }
}
