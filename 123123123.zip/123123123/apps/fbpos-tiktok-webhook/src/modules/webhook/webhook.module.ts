import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { WebhookController } from "./webhook.controller";
import { DeliveryEventService } from "./services";
import { CommonModule } from "@kiotviet-facebook-services/common";
import { KvRabbitMQModule } from "@kiotviet-facebook-services/rabbitmq";

@Module({
    imports: [CommonModule, HttpModule, KvRabbitMQModule],
    controllers: [WebhookController],
    providers: [DeliveryEventService],
    exports: [DeliveryEventService]
})
export class WebhookModule {
}
