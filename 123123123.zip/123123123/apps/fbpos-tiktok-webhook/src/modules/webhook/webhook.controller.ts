import { Body, Controller, HttpCode, HttpStatus, Post, UseInterceptors, ValidationPipe } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { TiktokWebhookDto } from "../../common/dto/tiktok-webhook.dto";
import { APITransformInterceptor } from "../../common/interceptors";
import { DeliveryEventService } from "./services";

@Controller('webhook')
@ApiTags('webhook')
export class WebhookController {
    constructor(private readonly _deliveryEventService: DeliveryEventService) {
    }

    @Post('')
    @HttpCode(HttpStatus.OK)
    @UseInterceptors(APITransformInterceptor)
    receiveWebhook(@Body(new ValidationPipe({transform: true})) params: TiktokWebhookDto) {
        this._deliveryEventService.deliveryEvent(params);
        return "Success";
    }
}
