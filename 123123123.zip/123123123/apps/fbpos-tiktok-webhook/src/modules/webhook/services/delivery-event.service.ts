import { AmqpConnection } from "@golevelup/nestjs-rabbitmq";
import { KvLogger, KvRabbitMQException, RabbitMQConfigTiktokWebhook } from "@kiotviet-facebook-services/common";
import { Injectable } from "@nestjs/common";
import { TiktokWebhookDto } from "../../../common/dto/tiktok-webhook.dto";

const config = require('config');

@Injectable()
export class DeliveryEventService {
    private readonly _rabbitMQConfig;

    constructor(private readonly _logger: KvLogger,
        private readonly _amqpConnection: AmqpConnection,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async deliveryEvent(payload: TiktokWebhookDto) {
        const prefixLog = this.prefixLog('deliveryEvent');
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMQConfigTiktokWebhook.ROUTING_KEY, payload).catch(err => {
            this._logger.error({ MessageTemplate: { payload }, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }
}
