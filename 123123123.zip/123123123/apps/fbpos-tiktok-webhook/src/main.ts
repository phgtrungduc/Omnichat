/**
 * This is not a production server yet!
 * This is only a minimal backend to get started.
 */
require('./tracer');
import { HttpStatus, Logger, UnprocessableEntityException, ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';

import { AppModule } from './app.module';
import { AlertNotificationService } from "@kiotviet-facebook-services/alert-notification";
import { WsAdapter } from '@nestjs/platform-ws';

async function bootstrap() {
    const app = await NestFactory.create(AppModule);
    const alertService = app.get<AlertNotificationService>(AlertNotificationService);
    const globalPrefix = '';
    app.setGlobalPrefix(globalPrefix);
    app.useGlobalPipes(new ValidationPipe({
        whitelist: true,
        errorHttpStatusCode: HttpStatus.UNPROCESSABLE_ENTITY,
        transform: true,
        dismissDefaultMessages: true,
        exceptionFactory: errors => new UnprocessableEntityException(errors),
    }));
    const port = process.env.PORT || 3000;
    app.useWebSocketAdapter(new WsAdapter(app));
    await app.listen(port);
    Logger.log(`🚀 Application is running on: http://localhost:${port}/${globalPrefix}`);
    alertService.send(`🚀*[fbpos-tiktok-webhook]* [Notification] Service was restarted`);

}

bootstrap();
