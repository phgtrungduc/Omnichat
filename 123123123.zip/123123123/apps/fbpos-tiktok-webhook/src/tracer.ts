import { getNodeAutoInstrumentations } from '@opentelemetry/auto-instrumentations-node';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-grpc';
import { OTLPMetricExporter } from '@opentelemetry/exporter-metrics-otlp-grpc';

import { NodeSDK } from '@opentelemetry/sdk-node';
import {
    BasicTracerProvider,
    ConsoleSpanExporter,
    SimpleSpanProcessor,
} from '@opentelemetry/sdk-trace-node';
import { Resource } from '@opentelemetry/resources';
import { PeriodicExportingMetricReader } from '@opentelemetry/sdk-metrics';
import { diag, DiagConsoleLogger, DiagLogLevel } from '@opentelemetry/api';

interface OpenTelemetryConfig {
    active: boolean;
    services: string[];
    url?: string;
}
process.env['NODE_CONFIG_DIR'] = `${__dirname}/config/`;

const config = require('config');

const OPEN_TELEMETRY = config.get('opentelemetry') as OpenTelemetryConfig;
const serviceName = 'fbpos-tiktok-webhook';
if (OPEN_TELEMETRY.active && OPEN_TELEMETRY.services.includes(serviceName)) {
    const exporter = new OTLPTraceExporter({ url: OPEN_TELEMETRY.url });
    const metricExporter = new OTLPMetricExporter({
        url: OPEN_TELEMETRY.url,
        headers: {},
        concurrencyLimit: 1, // an optional limit on pending requests
    });

    const provider = new BasicTracerProvider({
        resource: new Resource({
            'service.name': serviceName
        }),
    });

    // export spans to console (useful for debugging)
    provider.addSpanProcessor(
        new SimpleSpanProcessor(new ConsoleSpanExporter()),
    );

    // export spans to opentelemetry collector
    provider.addSpanProcessor(new SimpleSpanProcessor(exporter));
    provider.register();

    // For troubleshooting, set the log level to DiagLogLevel.DEBUG
    diag.setLogger(new DiagConsoleLogger(), DiagLogLevel.DEBUG); // Important for tracing
    const sdk = new NodeSDK({
        traceExporter: exporter,
        metricReader: new PeriodicExportingMetricReader({ exporter: metricExporter }),
        instrumentations: [
            getNodeAutoInstrumentations({
                // Lets disable fs for now, otherwise we cannot see the traces we want,
                // You can disable or enable instrumentation as needed
                '@opentelemetry/instrumentation-fs': { enabled: false },
            }),

        ],
    });

    sdk.start();
    console.log(`Setup opentelemetry success in ${serviceName} in gateway url ${OPEN_TELEMETRY.url || 'http://10.12.10.10:4317'}`);

} else {
    console.log(`Not active setup opentelemetry in ${serviceName}`);
}
