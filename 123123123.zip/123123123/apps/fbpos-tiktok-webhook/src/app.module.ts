import { Module } from '@nestjs/common';
import { AlertNotificationModule } from "@kiotviet-facebook-services/alert-notification";
import { CoreModule } from "./core/core.module";
import { HealthModule } from "./modules/health/health.module";
import { HttpModule } from "@nestjs/axios";
import { WebhookModule } from "./modules/webhook/webhook.module";
import { TiktokWebSocketModule } from './modules/tiktok-web-socket/tiktok-web-socket.module';
import { TiktokDisconnectedJobModule } from './modules/tiktok-disconnect-job/tiktok-disconnect-job.module';
import { BullModule } from '@nestjs/bullmq';
import { ConfigModule, ConfigService } from '@nestjs/config';
process.env['NODE_CONFIG_DIR'] = `${__dirname}/config/`;
const config = require('config');

@Module({
    imports: [
        CoreModule,
        ConfigModule.forRoot({
          isGlobal: true,
          load: [() => config],
        }),
        HttpModule,
        AlertNotificationModule,
        HealthModule,
        // WebhookModule,
        TiktokWebSocketModule,
        // TiktokDisconnectedJobModule,
        BullModule.forRootAsync({
          imports: [ConfigModule],
          inject: [ConfigService],
          useFactory: (config: ConfigService) =>  config.get('bullQueue'),
        }),
    ],
    controllers: [],
    providers: [],
})
export class AppModule {
}
