import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty } from 'class-validator';
import { TiktokEventTypes } from "@kiotviet-facebook-services/common";

export class TiktokWebhookDto {
    @ApiProperty({
        required: true,
        type: Object,
    })
    @IsNotEmpty()
    data: any;

    @ApiProperty({
        required: true,
        enum: TiktokEventTypes,
    })
    @IsEnum(TiktokEventTypes)
    event: TiktokEventTypes;
}
