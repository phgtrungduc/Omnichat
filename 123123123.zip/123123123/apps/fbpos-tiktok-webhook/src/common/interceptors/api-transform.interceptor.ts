import {
  CallHandler,
  ExecutionContext,
  NestInterceptor,
  BadRequestException,
  Injectable,
} from '@nestjs/common';
import type { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

export interface IResponse<T> {
  statusCode?: number;
  error?: string;
  data?: T;
}

@Injectable()
export class APITransformInterceptor<T> implements NestInterceptor<T, IResponse<T>> {
  intercept(context: ExecutionContext, next: CallHandler): Observable<IResponse<T>> {
    return next.handle().pipe(
      map((data) => {
        const statusCode = context
          .switchToHttp()
          .getResponse().statusCode;
        return {
          statusCode,
          data,
        };
      }),
      catchError((err) => {
        throw new BadRequestException(err);
      }),
    );
  }
}
