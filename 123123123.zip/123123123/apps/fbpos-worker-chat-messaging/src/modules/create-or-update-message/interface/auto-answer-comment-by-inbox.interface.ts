import { IFeed } from "@kiotviet-facebook-services/common";

export interface IAutoAnswerCommentByInboxPayload extends IFeed {
    RetailerId: string;
    RetailerCode: string;
    BranchId: string;
    PageId: string;
    PhoneNumber: string;
}
