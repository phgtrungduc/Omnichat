// {
//     PageId: '101837475110575',
//     _id: '9381793928558125',
//     Type: 'messenger',
//     State: 0,
//     TimeStamp: 1713258244424,
//     Staff: [ 'staff_102343337255201' ],
//     Action: 'update',
//     SenderId: '9381793928558125',
//     LastMessage: {
//       _id: 'm_ti2E0Wm-T5_VJl-z4u1eMK12ypovtHhT0i9S0ijNfwPx6kt-4iQNTJHocV_9UfPG5q4ucoGKyt1jfMPGV6s3mg',
//       TimeStamp: 1713258244424,
//       Field: 'messenger',
//       SenderId: '9381793928558125',
//       PageId: '101837475110575'
//     },
//     QuoteId: 'm_FyARa5ov_RHQkBrGwUtfga12ypovtHhT0i9S0ijNfwOfCQqYkhYJW0NflKWgEIzscpQpHd4QH7BVXCenqrCl7w'
//   }

export interface ISyncQuoteMessagePayload {
    PageId?: string;
    InstagramId?: string;
    _id: string; // = PageId
    Type: string;
    State: number;
    TimeStamp: number;
    Staff: string[];
    Action: string;
    SenderId: string;
    LastMessage: {
        _id: string;
        TimeStamp: number;
        Field: string;
        SenderId: string;
        PageId: string;
    };
    QuoteId: string;
}
