import {
    KvLogger,
    ERROR_MESSAGE_REDLOCK,
    IMessenger,
    ConversationType,
    SocialTypes,
    EventTypes,
    RabbitMqConfigSyncMessageWebhook,
} from '@kiotviet-facebook-services/common';
import { Injectable } from '@nestjs/common';
import { RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import { InstagramHandlerService } from './services/instagram-handler.service';
import { FacebookHandlerService } from "./services/facebook-handler.service";
import { isMessageReply } from "@kiotviet-facebook-services/fbpos-master-repository";
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class SyncMessageWebhookService {
    constructor(
        private readonly _logger: KvLogger,
        private readonly _instagramHandlerService: InstagramHandlerService,
        private readonly _facebookHandlerService: FacebookHandlerService,
    ) {
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigSyncMessageWebhook.ROUTING_KEY,
        queue: `fbpos-worker-chat-messaging:${RabbitMqConfigSyncMessageWebhook.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _syncMessageWebhook(payload: IMessenger) {
        const prefixLog = this.prefixLog('_syncMessageWebhook');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': payload?.InstagramId || payload?.PageId,
                'Kv.SocialType': payload?.InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);
        if (!payload) {
            return Promise.resolve();
        }
        try {
            const { Field, Channel } = payload;
            if (ConversationType.MESSENGER !== Field) {
                return Promise.resolve();
            }

            if (SocialTypes.INSTAGRAM === Channel) {
                await this._syncInstagramWebhook(payload);
            } else if (SocialTypes.FACEBOOK === Channel) {
                await this._syncFacebookWebhook(payload);
            }
            this._logger.info(logInput, `${prefixLog} success`);

        } catch (err) {
            if (err?.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._logger.error({ ...logInput, Error: err }, `${prefixLog} fail`);

        }

        return Promise.resolve();
    }

    private async _syncFacebookWebhook(payload: IMessenger) {
        const { EventType } = payload;
        switch (EventType) {
            case EventTypes.MessageCreated:
                if (isMessageReply(payload)) {
                    this._facebookHandlerService.editCommentReplied(payload).then();
                }
                return this._facebookHandlerService.createMessage(payload);
            case EventTypes.MessageRead:
                return this._facebookHandlerService.addMessengerRead(payload);
            default:
                break;
        }
    }

    private async _syncInstagramWebhook(payload: IMessenger) {
        const { EventType } = payload;
        switch (EventType) {
            case EventTypes.MessageCreated:
                return this._instagramHandlerService.createInstagramMessage(payload);
            case EventTypes.MessageRead:
                return this._instagramHandlerService.addDirectMessageRead(payload);
            // Xóa trên app thì có event webhook, trên website thì không
            case EventTypes.MessageDeleted:
                return this._instagramHandlerService.updateInstagramMessage(payload);
            default:
                break;
        }
    }
}
