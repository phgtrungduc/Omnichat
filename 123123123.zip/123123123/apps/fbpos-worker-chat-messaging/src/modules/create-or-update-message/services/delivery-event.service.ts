import {
    ConversationStates,
    currentMinuteInDay,
    EventTypes,
    KvLogger,
    KvRabbitMQException,
    RabbitMqConfigQuoteMessage,
    RabbitMqConfigStaffAssignmentFinal,
    SocialTypes
} from '@kiotviet-facebook-services/common';
import { PageStaffService, PageSubscriptionService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { AmqpConnection } from '@kiotviet-facebook-services/rabbitmq';
import { Injectable } from '@nestjs/common';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class DeliveryEventService {
    private readonly _rabbitMQConfig;

    constructor(
        private readonly _logger: KvLogger,
        private readonly _pageSubscriptionService: PageSubscriptionService,
        private readonly _amqpConnection: AmqpConnection,
        private readonly _pageStaffService: PageStaffService,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    sentEventMQForUpdatingSomething(conversation: any) {
        this._sentEventMQToUpdateReport(conversation);
        this._sentEventMQUpdateStaffConversation(conversation);
        this._sentEventMQToUpdateQuote(conversation);
        this._sentEventMQCheckStaffAssigment(conversation);
    }

    sentEventMQForUpdatingSenderName(PageId: string, Psid: string) {
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, 'fireandforget.psid.all', {
            PageId,
            Psid
        }).catch(err => {
            const prefixLog = this.prefixLog('sentEventMQForUpdatingSenderName');
            const logInput: IKvLogInput = {
                MessageTemplate: { PageId, Psid },
                Properties: {
                    'Kv.SocialId': PageId,
                    'Kv.SocialType': SocialTypes.FACEBOOK,
                    SourceContext: prefixLog,
                    _startTime: Date.now()
                }
            };
            this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }

    private _sentEventMQToUpdateReport(conversation: any) {
        if (!conversation) {
            return;
        }

        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, `kvfb.worker.conversation.${conversation.Action}`, conversation)
            .catch(err => {
                const prefixLog = this.prefixLog('_sentEventMQToUpdateReport');
                const logInput: IKvLogInput = {
                    MessageTemplate: { conversation },
                    Properties: {
                        SourceContext: prefixLog,
                        _startTime: Date.now()
                    }
                };
                this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
            });
    }

    private async _sentEventMQUpdateStaffConversation(conversation: any) {
        if (!conversation) {
            return;
        }

        // Đổi logic bắn sang routing key .conversation.staff. thành đoạn code bên dưới, giảm 1 lần qua rabbit
        if (ConversationStates.UNREAD === conversation.State && (!conversation.Staff || !conversation.Staff.length)) {
            const { PageId } = conversation;
            let pageSetting = null;
            let assignmentSetting = {};
            try {
                pageSetting = await this._pageSubscriptionService.getPageSetting(PageId);
                assignmentSetting = pageSetting?.ConversationAssignment || {};
            } catch (error) {
            }
            const prefixLog = this.prefixLog('_sentEventMQUpdateStaffConversation');

            const logInput: IKvLogInput = {
                MessageTemplate: { conversation, assignmentSetting },
                Properties: {
                    SourceContext: prefixLog,
                    _startTime: Date.now()
                }
            };

            this._logger.info(logInput, `${prefixLog} received conversation for update staff assignment`);
            if (this._isAutoBySetting(assignmentSetting)) {
                this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigStaffAssignmentFinal.ROUTING_KEY, {
                    pageId: PageId,
                    conversation,
                    setting: assignmentSetting
                }).catch(err => {
                    this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
                });
            }
        }
    }


    private _isAutoBySetting(setting: any) {
        const currentMinute = currentMinuteInDay();
        const inRange = setting.StartTime <= currentMinute && currentMinute <= setting.EndTime;
        return setting.AutoAssign && inRange;
    }

    private _sentEventMQToUpdateQuote(conversation: any) {
        if (!conversation || !conversation.QuoteId) {
            return;
        }

        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigQuoteMessage.ROUTING_KEY, conversation)
            .catch(err => {
                const prefixLog = this.prefixLog('_sentEventMQToUpdateQuote');
                const logInput: IKvLogInput = {
                    MessageTemplate: { conversation },
                    Properties: {
                        SourceContext: prefixLog,
                        _startTime: Date.now()
                    }
                };
                this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
            });
    }

    private async _sentEventMQCheckStaffAssigment(conversation: any) {
        if (!conversation || !conversation.Staff || !conversation.Staff.length) {
            return;
        }
        const socialId = conversation.InstagramId || conversation.PageId;
        const prefixLog = this.prefixLog('_sentEventMQCheckStaffAssigment');
        const logInput: IKvLogInput = {
            MessageTemplate: { conversation },
            Properties: {
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        };
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, `kvfb.notification.staff.${EventTypes.CheckStaffAssigned}`,
            {
                EventType: EventTypes.CheckStaffAssigned,
                PageId: socialId,
                Field: 'staff',
                Data: {
                    Id: conversation.Staff[0],
                    conversationId: conversation._id
                }
            }).catch(err => {
                this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} CheckStaffAssigned fail`);

            });

        // Bắn lại staff đã được phân công trước đó cho conversation hiện tại để đảm bảo cho
        // trường hợp hội thoại chưa được load trước đó phía client web
        const staffs = (await this._pageStaffService.getStaffs(socialId))
            .filter(item => item.name)
            .map(item => ({ ...item, _id: item.staffId }));

        if (staffs?.length) {
            const foundStaff = staffs.find(staff => staff.staffId === conversation.Staff[0]);
            if (foundStaff) {
                this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, `kvfb.notification.staff.${EventTypes.StaffAssigned}`,
                    {
                        EventType: EventTypes.StaffAssigned,
                        PageId: socialId,
                        Field: "staff",
                        Data: {
                            Id: foundStaff.staffId,
                            Name: foundStaff.name,
                            Picture: foundStaff.picture,
                            AppUserId: foundStaff.appUserId,
                            conversationId: conversation._id,
                        },
                    }).catch(err => {
                        this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} StaffAssigned fail`);
                    });
            }
        }
    }
}
