import { Inject, Injectable } from '@nestjs/common';
import {
    ConversationStates,
    ConversationType,
    IMessenger,
    KvBaseException,
    KvLogger,
    KvResponseMongoDbException,
    SocialTypes
} from '@kiotviet-facebook-services/common';
import {
    FbUserProfileService, getCommentIdInMetadata,
    getDbNameSocialConversation,
    MongodbGroupService,
    PageSubscriptionService
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { RedisLockService, REDLOCK_CONST } from '@kiotviet-facebook-services/lock';
import { pick } from 'lodash';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { DeliveryEventService } from "./delivery-event.service";
import { FacebookMessageService } from "@kiotviet-facebook-services/facebook-sdk";
import { FacebookConversionService } from '../facebook-conversion.service';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

@Injectable()
export class FacebookHandlerService {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _pageSubscriptionService: PageSubscriptionService,
        private readonly _redlockService: RedisLockService,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _fbUserProfileService: FbUserProfileService,
        private readonly _deliveryEventService: DeliveryEventService,
        private readonly _facebookMessageService: FacebookMessageService,
        private readonly facebookConversionService: FacebookConversionService,
        @Inject(CACHE_MANAGER) private readonly _cache: Cache,
    ) {
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async createMessage(payload: IMessenger) {
        const { PageId, GroupId, SenderId, Psid, ConversationPrefix, Message, TimeStamp } = payload;
        const lock = await this._redlockService.acquire(
            [`${REDLOCK_CONST.MESSAGES.ADD_MESSAGE.NAME}${PageId}:${GroupId}`],
            REDLOCK_CONST.MESSAGES.ADD_MESSAGE.TTL,
            {},
        );
        const prefixLog = this.prefixLog('createMessage');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': payload?.InstagramId || payload?.PageId,
                'Kv.SocialType': payload?.InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        try {
            // Make request for conversion api
            this._handleConversionApiAction(payload);

            payload = await this._mapAttachmentsInfo(payload, PageId);

            const db = await this._mongodbGroupService.getDatabase({ socialId: PageId });
            await db.collection(PageId).insertOne(payload); // Process insert conversation detail

            // Process insert/update conversation
            const conversationMessage = `${(ConversationPrefix || "")}${(Message || "")}`;
            const senderId = SenderId || Psid;
            const isMessSentFromPage = senderId === PageId;
            const isAutoMessage = isMessSentFromPage && 1 == payload.SentAuto;
            const isRead = isMessSentFromPage && !isAutoMessage;

            const updateDefinition = {
                Message: conversationMessage,
                TimeStamp: payload.TimeStamp,
                LastSenderId: senderId,
                LastSenderName: payload.SenderName,
            } as any;

            if (!isMessSentFromPage) {
                updateDefinition.State = ConversationStates.UNREAD;
            } else if (isRead) {
                updateDefinition.State = ConversationStates.READ;
            }

            if (payload.MessageHasPhone && !isMessSentFromPage) {
                updateDefinition.HasPhone = true;
            }
            if (payload.MessageHasEmail && !isMessSentFromPage) {
                updateDefinition.HasEmail = true;
            }

            let conversation = null;
            if (!isRead) {
                conversation = await db.collection(getDbNameSocialConversation(PageId)).findOne({ _id: GroupId });
                if (conversation && ConversationStates.READ === conversation.State) {
                    updateDefinition.LastUnreadTimestamp = payload.TimeStamp;
                }
            }

            // Update Unread Message Count
            if (!isMessSentFromPage) {
                updateDefinition.UnreadMessageCount = conversation && conversation.UnreadMessageCount && !isRead ? (conversation.UnreadMessageCount + 1) : 1;
                updateDefinition.Resolved = ConversationStates.UNRESOLVED;  // When receive message from fbuser, set conversation is unresolved
            } else if (!isAutoMessage) {
                updateDefinition.UnreadMessageCount = 0;
            }

            const updateResult = await db.collection(getDbNameSocialConversation(PageId)).updateOne({
                _id: GroupId,
                TimeStamp: { $lt: TimeStamp }
            }, { $set: updateDefinition });
            if (updateResult.modifiedCount < 1) {
                let SenderName = payload.SenderName;

                if (!SenderName) {
                    try {
                        const profile = await this._fbUserProfileService.handleReadFbUserProfile(Psid);
                        if (profile) {
                            SenderName = profile.name;
                        }
                    } catch (e) {
                    }
                }

                await db.collection(getDbNameSocialConversation(PageId))
                    .insertOne(
                        {
                            _id: payload.GroupId,
                            SenderId: payload.Psid,
                            SenderName: SenderName,
                            PageId: payload.PageId,
                            Message: conversationMessage,
                            TimeStamp: payload.TimeStamp,
                            LastUnreadTimestamp: payload.TimeStamp,
                            Type: ConversationType.MESSENGER,
                            State: (isRead ? ConversationStates.READ : ConversationStates.UNREAD),
                            HasPhone: (!!payload.MessageHasPhone),
                            HasEmail: (!!payload.MessageHasEmail),
                            LastSenderId: senderId,
                            LastSenderName: payload.SenderName,
                            Resolved: ConversationStates.UNRESOLVED,
                            UnreadMessageCount: isRead ? 0 : 1
                        }
                    );

                if (!SenderName) {
                    this._deliveryEventService.sentEventMQForUpdatingSenderName(PageId, Psid);
                }
            }

            const conversationNew = {
                PageId,
                _id: payload.GroupId,
                Type: ConversationType.MESSENGER,
                State: (isRead ? ConversationStates.READ : ConversationStates.UNREAD),
                TimeStamp: payload.TimeStamp,
                Staff: (conversation != null ? conversation.Staff : null),
                Action: (conversation != null ? "update" : "create"),
                SenderId: senderId,
                LastMessage:
                {
                    _id: payload._id,
                    TimeStamp: payload.TimeStamp,
                    Field: payload.Field,
                    SenderId: senderId,
                    PageId
                },
                QuoteId: payload.QuoteId || ""
            };
            this._deliveryEventService.sentEventMQForUpdatingSomething(conversationNew);
        } catch (err) {
            if (!(err?.message?.includes("E11000 duplicate key error collection"))) {
                this._logger.error({ ...logInput, Error: new KvResponseMongoDbException(err.stack) }, `${prefixLog} fail`);
                throw err;
            }
        } finally {
            await this._redlockService.release(lock).catch(e => this._logger.error(`${this.prefixLog('createMessage')} release lock err`, e));
        }
    }

    async editCommentReplied(payload: IMessenger) {
        try {
            const { PageId } = payload;
            const commentId = getCommentIdInMetadata(payload);
            const db = await this._mongodbGroupService.getDatabase({ socialId: PageId });
            await db.collection(PageId).updateOne({ _id: commentId }, { $set: { Replied: true } });
        } catch (err) {
            const prefixLog = this.prefixLog('editCommentReplied');
            const logInput: IKvLogInput = {
                MessageTemplate: { payload },
                Properties: {
                    'Kv.SocialId': payload?.InstagramId || payload?.PageId,
                    'Kv.SocialType': payload?.InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
                    SourceContext: prefixLog,
                }
            }
            this._logger.error({ ...logInput, Error: new KvResponseMongoDbException(err.stack) }, `${prefixLog} fail`);

        }
    }

    async addMessengerRead(payload: IMessenger) {
        const { PageId, GroupId } = payload;
        const messaging = payload.entry[0].messaging || payload.entry[0].standby;
        const timeRead = (messaging[0].read as any).watermark;
        const db = await this._mongodbGroupService.getDatabase({ socialId: PageId });
        await db.collection(getDbNameSocialConversation(PageId)).updateOne({ _id: GroupId }, { $set: { TimeRead: timeRead } });
    }

    private async _mapAttachmentsInfo(messenger: IMessenger, socialId: string) {
        const newMessenger = { ...messenger };
        const payload = newMessenger.entry[0].messaging && newMessenger.entry[0].messaging[0] ||
            newMessenger.entry[0].standby && newMessenger.entry[0].standby[0]
        const attachments = (payload.message || {}).attachments || [];
        const checkAttachmentFile = attachments.find(item => item.type === 'file');
        if (!checkAttachmentFile || (checkAttachmentFile.payload && checkAttachmentFile.payload.name)) {
            return newMessenger;
        }
        const subscription = await this._pageSubscriptionService.getSubscriptionBySocialId(socialId);
        const accessToken = subscription?.AccessToken;
        if (!accessToken) {
            return newMessenger;
        }
        const messageId = newMessenger._id;
        const messageDetail = await this._facebookMessageService.getDetailMessage({
            access_token: subscription.AccessToken,
            id: messageId
        });
        if (!messageDetail) {
            return newMessenger;
        }
        const attachmentsDetail = (messageDetail.attachments || {}).data || [];
        if (!attachmentsDetail.length) return newMessenger;
        payload.message.attachments = (attachmentsDetail as any).map((item, index) => {
            return {
                "type": "file",
                "payload": {
                    ...item,
                    url: attachments[index]['url'] || item.file_url
                }
            }
        })
        if (newMessenger.entry[0].messaging && newMessenger.entry[0].messaging[0]) {
            newMessenger.entry[0].messaging[0] = payload;
        }
        if (newMessenger.entry[0].standby && newMessenger.entry[0].standby[0]) {
            newMessenger.entry[0].standby[0] = payload;
        }
        return newMessenger;
    }

    private async _handleConversionApiAction(payload: IMessenger) {
        if (payload.MessageHasPhone) {
            this.facebookConversionService.createJobForConversionLeadSubmittedEvent(payload);
        }

        if (payload.Order) {
            this.facebookConversionService.handleConversionPurchaseEvent(payload);
        }

    }
}
