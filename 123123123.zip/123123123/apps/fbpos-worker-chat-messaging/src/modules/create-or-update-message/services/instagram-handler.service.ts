import { CACHE_KEYS } from '@kiotviet-facebook-services/cache';
import { ConversationStates, ConversationType, IMessenger, KvLogger, KvResponseMongoDbException, SocialTypes } from '@kiotviet-facebook-services/common';
import { FbUserProfileService, MongodbGroupService, getDbNameSocialConversation } from '@kiotviet-facebook-services/fbpos-master-repository';
import { REDLOCK_CONST, RedisLockService } from '@kiotviet-facebook-services/lock';
import { CACHE_MANAGER, Cache } from '@nestjs/cache-manager';
import { Inject, Injectable } from '@nestjs/common';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
import { DeliveryEventService } from "./delivery-event.service";

const config = require('config');

@Injectable()
export class InstagramHandlerService {

    constructor(
        private readonly _logger: KvLogger,
        private readonly _redlockService: RedisLockService,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _fbUserProfileService: FbUserProfileService,
        private readonly _deliveryEventService: DeliveryEventService,

        @Inject(CACHE_MANAGER) private readonly _cache: Cache,
    ) {
    }
    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    async createInstagramMessage(payload: IMessenger) {
        const { InstagramId, GroupId, SenderId, Psid, ConversationPrefix, Message, TimeStamp } = payload;
        const lock = await this._redlockService.acquire(
            [`${REDLOCK_CONST.MESSAGES.ADD_MESSAGE.NAME}${InstagramId}:${GroupId}`],
            1000 * 60, // 60 seconds
            {},
        );
        const prefixLog = this.prefixLog('createMessage');
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': payload?.InstagramId || payload?.PageId,
                'Kv.SocialType': payload?.InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        try {
            const db = await this._mongodbGroupService.getDatabase({ socialId: InstagramId });
            payload = await this._getMetadataAuto(payload);
            await db.collection(InstagramId).insertOne(payload); // Process insert conversation detail

            // Process insert/update conversation
            const conversationMessage = `${(ConversationPrefix || "")}${(Message || "")}`;
            const senderId = SenderId || Psid;
            const isMessSentFromPage = senderId === InstagramId;
            const isAutoMessage = isMessSentFromPage && 1 == payload.SentAuto;
            const isRead = isMessSentFromPage && !isAutoMessage;

            const updateDefinition = {
                Message: conversationMessage,
                TimeStamp: payload.TimeStamp,
                LastSenderId: senderId,
                LastSenderName: payload.SenderName,
            } as any;

            if (!isMessSentFromPage) {
                updateDefinition.State = ConversationStates.UNREAD;
            } else if (isRead) {
                updateDefinition.State = ConversationStates.READ;
            }

            if (payload.MessageHasPhone) {
                updateDefinition.HasPhone = true;
            }
            if (payload.MessageHasEmail) {
                updateDefinition.HasEmail = true;
            }

            let conversation = null;
            if (!isRead) {
                conversation = await db.collection(getDbNameSocialConversation(InstagramId)).findOne({ _id: GroupId });
                if (conversation && ConversationStates.READ === conversation.State) {
                    updateDefinition.LastUnreadTimestamp = payload.TimeStamp;
                }
            }

            // Update Unread Message Count
            if (!isMessSentFromPage) {
                updateDefinition.UnreadMessageCount = conversation && conversation.UnreadMessageCount && !isRead ? (conversation.UnreadMessageCount + 1) : 1;
                updateDefinition.Resolved = ConversationStates.UNRESOLVED;  // When receive message from fbuser, set conversation is unresolved
            } else if (!isAutoMessage) {
                updateDefinition.UnreadMessageCount = 0;
            }

            const updateResult = await db.collection(getDbNameSocialConversation(InstagramId)).updateOne({ _id: GroupId, TimeStamp: { $lt: TimeStamp } }, { $set: updateDefinition });
            if (updateResult.modifiedCount < 1) {
                let SenderName = payload.SenderName;

                if (!SenderName) {
                    try {
                        const profile = await this._fbUserProfileService.handleReadFbUserProfile(Psid);
                        if (profile) {
                            SenderName = profile.name;
                        }
                    } catch (e) { }
                }

                await db.collection(getDbNameSocialConversation(InstagramId))
                    .insertOne(
                        {
                            _id: payload.GroupId,
                            SenderId: payload.Psid,
                            SenderName: SenderName,
                            InstagramId: payload.InstagramId,
                            Message: conversationMessage,
                            TimeStamp: payload.TimeStamp,
                            LastUnreadTimestamp: payload.TimeStamp,
                            Type: ConversationType.MESSENGER,
                            State: (isRead ? ConversationStates.READ : ConversationStates.UNREAD),
                            HasPhone: (!!payload.MessageHasPhone),
                            HasEmail: (!!payload.MessageHasEmail),
                            LastSenderId: senderId,
                            LastSenderName: payload.SenderName,
                            Resolved: ConversationStates.UNRESOLVED,
                            UnreadMessageCount: isRead ? 0 : 1
                        }
                    );

                if (!SenderName) {
                    this._deliveryEventService.sentEventMQForUpdatingSenderName(InstagramId, Psid);

                }
            }

            const conversationNew = {
                InstagramId,
                _id: payload.GroupId,
                Type: ConversationType.MESSENGER,
                State: (isRead ? ConversationStates.READ : ConversationStates.UNREAD),
                TimeStamp: payload.TimeStamp,
                Staff: (conversation != null ? conversation.Staff : null),
                Action: (conversation != null ? "update" : "create"),
                SenderId: senderId,
                LastMessage:
                {
                    _id: payload._id,
                    TimeStamp: payload.TimeStamp,
                    Field: payload.Field,
                    SenderId: senderId,
                    InstagramId
                },
                QuoteId: payload.QuoteId || ""
            };
            this._deliveryEventService.sentEventMQForUpdatingSomething(conversationNew);
        } catch (err) {
            if (!(err?.message?.includes("E11000 duplicate key error collection"))) {
                this._logger.error({ ...logInput, Error: new KvResponseMongoDbException(err.stack) }, `${prefixLog} fail`);
                throw err;
            }
        } finally {
            await this._redlockService.release(lock);
        };
    }

    async addDirectMessageRead(payload: IMessenger) {
        const { InstagramId, GroupId } = payload;
        const messaging = payload.entry[0].messaging || payload.entry[0].standby;
        const timeRead = messaging[0].timestamp;
        const db = await this._mongodbGroupService.getDatabase({ socialId: InstagramId });
        await db.collection(getDbNameSocialConversation(InstagramId)).updateOne({ _id: GroupId }, { $set: { TimeRead: timeRead } });
    }

    async updateInstagramMessage(payload: IMessenger) {
        const { InstagramId } = payload;
        const updateDefinition = { Version: 1 } as any;
        if (payload.Message) {
            updateDefinition["entry.0.messaging.0.message.text"] = payload.Message;
            updateDefinition["entry.0.standby.0.message.text"] = payload.Message; // standby là do app subscribe không phải luồng chính
            updateDefinition.Message = payload.Message;
        }
        updateDefinition.MessageHasPhone = (!!payload.MessageHasPhone);
        updateDefinition.MessageHasEmail = (!!payload.MessageHasEmail);
        updateDefinition.IsDeleted = !!payload.IsDeleted;
        const db = await this._mongodbGroupService.getDatabase({ socialId: InstagramId });
        await db.collection(InstagramId).updateOne({ _id: payload._id }, { $set: updateDefinition });
        // update conversation
        const conversationUpdateDef = { Version: 1 } as any;
        if (payload.MessageHasPhone) {
            conversationUpdateDef.HasPhone = true;
        }
        if (payload.MessageHasEmail) {
            conversationUpdateDef.HasEmail = true;
        }
        if (updateDefinition.IsDeleted) {
            conversationUpdateDef.Message = updateDefinition.Message;
        }
        await db.collection(getDbNameSocialConversation(InstagramId)).updateOne({ _id: payload.GroupId }, { $set: conversationUpdateDef });
    }

    private async _getMetadataAuto(payload: IMessenger): Promise<IMessenger> {
        const newPayload = { ...payload };
        try {
            const metadataAuto = await this._cache.get<any>(`${CACHE_KEYS.AUTO_ANSWER_COMMENT_BY_INBOX.NAME}${payload._id}`);
            if (metadataAuto) {
                if (newPayload.entry?.[0]?.messaging?.[0]?.message) {
                    newPayload.entry[0].messaging[0].message.metadata = JSON.stringify(metadataAuto);
                }
                newPayload.SentAuto = 1;


                if (metadataAuto.PostReferenceUrl) {
                    newPayload.PostReferenceUrl = metadataAuto.PostReferenceUrl;
                }

                if (metadataAuto.Tag) {
                    newPayload.Tag = metadataAuto.Tag;
                }
            }
        } catch (e) {
        }
        return newPayload;
    }

}
