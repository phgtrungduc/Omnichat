import { RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
  FacebookResponseException,
  IMessenger,
  KvLogger,
  RabbitMqFacebookConversionCancelLeadSubmitted,
  SocialTypes
} from '@kiotviet-facebook-services/common';
import { FacebookConverionApiService, IDatasetEvent } from '@kiotviet-facebook-services/facebook-sdk';
import { PageSubscriptionService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { InjectQueue } from '@nestjs/bullmq';
import { Injectable } from '@nestjs/common';
import { Queue } from 'bullmq';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class FacebookConversionService {
  constructor(
    private readonly _logger: KvLogger,
    private readonly _pageSubscriptionService: PageSubscriptionService,
    private readonly facebookConverionApiService: FacebookConverionApiService,
    @InjectQueue('facebook-conversion') private facebookConversionQueue: Queue
  ) {
  }

  prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

  @RabbitSubscribe({
    exchange: config.get('rabbitMQ').mainExchange,
    routingKey: RabbitMqFacebookConversionCancelLeadSubmitted.ROUTING_KEY,
    queue: `fbpos-worker-chat-messaging:${RabbitMqFacebookConversionCancelLeadSubmitted.QUEUE_NAME}`,
    queueOptions: {
      durable: true,
      arguments: { 'x-queue-type': 'quorum' },
    },
  })
  private async cancelLeadSubmitted(payload: any) {
    const prefixLog = this.prefixLog('cancelLeadSubmitted');
    const baseInfoLog = { Context: { payload }, SourceContext: 'cancelLeadSubmitted' };
    const logInput: IKvLogInput = {
      MessageTemplate: { payload },
      Properties: {
        SourceContext: prefixLog,
        _startTime: Date.now()
      }
    }
    this._logger.info(logInput, `${prefixLog} received payload`);

    if (!payload || !payload.jobId) {
      return Promise.resolve();
    }

    try {
      const { jobId } = payload;

      const job = await this.facebookConversionQueue.getJob(jobId);
      if (job) {
        await job.remove();
      }

      this._logger.info(logInput, `${prefixLog} success`);
    } catch (err) {
      this._logger.error({ ...logInput, Error: err }, `${prefixLog} fail`);
    }

    return Promise.resolve();
  }

  public async handleConversionLeadSubmittedEvent(payload: IMessenger) {
    let event: IDatasetEvent, accessToken: string;
    try {
      event = {
        event_name: 'LeadSubmitted',
        event_time: Math.floor(+new Date() / 1000),
        action_source: 'business_messaging',
        messaging_channel: 'messenger',
        user_data: {
          page_id: payload.PageId,
          page_scoped_user_id: payload.Psid
        }
      }

      const subscription = await this._pageSubscriptionService.getSubscriptionBySocialId(payload.PageId);
      accessToken = subscription?.AccessToken;
      if (!accessToken) {
        return Promise.resolve();
      }
      const result = await this.facebookConverionApiService.sendDatasetEvent(payload.PageId, [event], accessToken);
    } catch (err) {
      const prefixLog = this.prefixLog('handleConversionLeadSubmittedEvent');
      const logInput: IKvLogInput = {
        MessageTemplate: { payload },
        Properties: {
          'Kv.SocialId': payload?.InstagramId || payload?.PageId,
          'Kv.SocialType': payload?.InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
          SourceContext: prefixLog,
          _startTime: Date.now()
        }
      }
      this._logger.error({ ...logInput, Error: new FacebookResponseException(err.stack, { cause: err }) }, `${prefixLog} fail`);
    }
  }

  public async handleConversionPurchaseEvent(payload: IMessenger) {
    let event: IDatasetEvent, accessToken: string;
    try {
      event = {
        event_name: 'Purchase',
        event_time: Math.floor(+new Date() / 1000),
        action_source: 'business_messaging',
        messaging_channel: 'messenger',
        user_data: {
          page_id: payload.PageId,
          page_scoped_user_id: payload.Psid
        },
        custom_data: {
          fb_content: payload?.Order?.products || [],
          fb_content_type: "product",
          currency: payload?.Order?.products[0]?.currency,
          value: payload?.Order?.products.reduce((total, product) => {
            return total + (product.unit_price * product.quantity);
          }, 0)
        }
      }

      const subscription = await this._pageSubscriptionService.getSubscriptionBySocialId(payload.PageId);
      accessToken = subscription?.AccessToken;
      if (!accessToken) {
        return Promise.resolve();
      }
      const result = await this.facebookConverionApiService.sendDatasetEvent(payload.PageId, [event], accessToken);
      // console.log(`handleConversionPurchaseEvent`, JSON.stringify(result));
    } catch (err) {
      const prefixLog = this.prefixLog('handleConversionPurchaseEvent');
      const logInput: IKvLogInput = {
        MessageTemplate: { payload },
        Properties: {
          'Kv.SocialId': payload?.InstagramId || payload?.PageId,
          'Kv.SocialType': payload?.InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
          SourceContext: prefixLog,
          _startTime: Date.now()
        }
      }
      this._logger.error({ ...logInput, Error: new FacebookResponseException(err.stack, { cause: err }) }, `${prefixLog} fail`);
    }
  }

  public async createJobForConversionLeadSubmittedEvent(payload: IMessenger) {
    const { PageId, Message } = payload;
    const phonePattern = /(\(\+84\)|\(84\)|84|0)[0 ]?(9[0-9]|1[2|6|8|9]|3[2-9]|7[0|9|7|6|8]|8[1-9]|5[2|5|6|8|9])((\s|\.|-|\(|\))?\d){6,7}(\)?)/g;
    let phoneNumber = Message.match(phonePattern)[0];

    if (!phoneNumber) {
      return;
    }

    phoneNumber = phoneNumber.replace(/\D/g, '');
    const oneDayMs = 86400000;
    await this.facebookConversionQueue.add(`LeadSubmitted`, payload, {
      jobId: `LeadSubmitted_${PageId}_${phoneNumber}`,
      delay: oneDayMs
    });
  }
}
