import { IMessenger, KvLogger, SocialTypes } from '@kiotviet-facebook-services/common';
import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { Injectable } from '@nestjs/common';
import { FacebookConversionService } from './facebook-conversion.service';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

@Processor('facebook-conversion')
@Injectable()
export class FacebookConversionProcessor extends WorkerHost {

  constructor(
    private readonly facebookConversionService: FacebookConversionService,
    private readonly _logger: KvLogger
  ) {
    super();
  }

  prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

  async process(job: Job<IMessenger, any, string>): Promise<void> {
    const { name, data } = job;

    const prefixLog = this.prefixLog('processor');

    const logInput: IKvLogInput = {
      MessageTemplate: { data },
      Properties: {
        'Kv.SocialId': data?.InstagramId || data?.PageId,
        'Kv.SocialType': data?.InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
        SourceContext: prefixLog,
        _startTime: Date.now()
      }
    }

    this._logger.info(logInput, `${prefixLog} received payload`);

    switch (name) {
      case 'LeadSubmitted':
        await this.facebookConversionService.handleConversionLeadSubmittedEvent(data);
        break;
      default:
        break;
    }

    this._logger.info(logInput, `${prefixLog} success`);
  }
}
