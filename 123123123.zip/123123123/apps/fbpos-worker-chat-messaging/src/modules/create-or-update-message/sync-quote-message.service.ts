import { RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import {
    ERROR_MESSAGE_REDLOCK,
    FacebookResponseException,
    IMessageApi,
    KvLogger,
    RabbitMqConfigQuoteMessage,
    SocialTypes,
} from '@kiotviet-facebook-services/common';
import { FacebookMessageService, InstagramMessageService } from '@kiotviet-facebook-services/facebook-sdk';
import { ConversationService, PageSubscriptionService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { Injectable } from '@nestjs/common';
import { IQuote } from 'libs/repositories/fbpos-master-repository/src/lib/interface';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
import { ISyncQuoteMessagePayload } from './interface/sync-quote-message.interface';

const config = require('config');

@Injectable()
export class SyncQuoteMessageService {
    constructor(
        private readonly _logger: KvLogger,
        private readonly _conversationService: ConversationService,
        private readonly _pageSubscriptionService: PageSubscriptionService,
        private readonly _facebookMessageService: FacebookMessageService,
        private readonly _instagramMessageService: InstagramMessageService
    ) {
    }
    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigQuoteMessage.ROUTING_KEY,
        queue: `fbpos-worker-chat-messaging:${RabbitMqConfigQuoteMessage.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _processQuoteMessage(payload: ISyncQuoteMessagePayload) {
        const prefixLog = this.prefixLog('_processQuoteMessage');
        const { PageId, QuoteId, LastMessage, InstagramId } = payload;

        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': InstagramId || PageId,
                'Kv.SocialType': InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);

        if ((!PageId && !InstagramId) || !QuoteId || !LastMessage) {
            return Promise.resolve();
        }
        try {
            const messageId = LastMessage && LastMessage._id;
            const socialId = PageId || InstagramId;
            const subscription = await this._pageSubscriptionService.getSubscriptionBySocialId(socialId);
            if (!subscription || !subscription.AccessToken || !subscription.State || subscription.IsRemoved) {
                return Promise.resolve();
            }

            const detailMessage = InstagramId ? await this._instagramMessageService.getDetailMessage({ access_token: subscription.AccessToken, id: QuoteId }) : await this._facebookMessageService.getDetailMessage({ access_token: subscription.AccessToken, id: QuoteId });
            await this._conversationService.addQuoteIntoMessageDetail({ socialId, messageId, quote: this._getQuoteParser(detailMessage) });

            this._logger.info(logInput, `${prefixLog} success`);
        } catch (err) {
            if (err?.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._logger.error({ ...logInput, Error: new FacebookResponseException(err.stack, { cause: err }) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }

    private _getQuoteParser(json: IMessageApi): IQuote {
        const quote: IQuote = {};
        if (json) {
            quote.Id = json.id;
            if (json.message) {
                quote.Message = json.message;
            }

            if (json.attachments && json.attachments.data) {
                const attachments = [];
                json.attachments.data.forEach((item) => {
                    if (item.image_data) {
                        attachments.push({
                            type: (item.mime_type && item.mime_type.replace('image/', '')) || 'image',  //mime_type: image/gif, image/png, image/jpeg
                            id: item.id,
                            url: item.image_data.url
                        })
                    } else if (item.video_data) {
                        attachments.push({
                            type: item.mime_type,
                            id: item.id,
                            url: item.video_data.preview_url,
                            link: item.video_data.url
                        })
                    }
                });
                quote.Attachments = attachments;
            }

            if (json.sticker) {
                quote.Sticker = json.sticker;
            }
            quote.CreatedTime = new Date(json.created_time).getTime();
        }
        return quote;
    }
}
