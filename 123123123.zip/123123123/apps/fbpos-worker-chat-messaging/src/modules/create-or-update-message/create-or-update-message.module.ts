import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { FacebookSdkModule } from '@kiotviet-facebook-services/facebook-sdk';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { SyncQuoteMessageService } from './sync-quote-message.service';
import { LockModule } from '@kiotviet-facebook-services/lock';
import { InstagramHandlerService } from './services/instagram-handler.service';
import { SyncMessageWebhookService } from './sync-message-webhook.service';
import { FacebookHandlerService } from "./services/facebook-handler.service";
import { DeliveryEventService } from "./services/delivery-event.service";
import { BullModule } from "@nestjs/bullmq";
import { FacebookConversionProcessor } from './facebook-conversion.processor';
import { FacebookConversionService } from './facebook-conversion.service';

@Module({
  imports: [
    CommonModule,
    KvRabbitMQModule,
    FacebookSdkModule,
    FbPosMasterRepositoryModule,
    LockModule,
    BullModule.registerQueue({
      name: 'facebook-conversion',
      defaultJobOptions: {
        removeOnComplete: true,
        removeOnFail: true
      }
    })
  ],
  providers: [
    SyncQuoteMessageService,
    SyncMessageWebhookService,
    InstagramHandlerService,
    FacebookHandlerService,
    DeliveryEventService,
    FacebookConversionProcessor,
    FacebookConversionService,
  ],
})
export class CreateOrUpdateMessageModule {
}
