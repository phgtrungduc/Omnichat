import { CartStatusEnum } from "@kiotviet-facebook-services/common";
import {
    FbCartsDocument,
    FbLivestreamScriptDocument,
    FbUserProfileDocument,
    TiktokCartsDocument
} from "@kiotviet-facebook-services/fbpos-master-repository";
import { pick } from 'lodash';
import { CustomerSocialTypes } from "@kiotviet-facebook-services/kv-internal-api";

export function getQueryUpdateCart(cart: FbCartsDocument, result: any) {
    const {value, reason} = result;

    const error = reason?.error?.ResponseStatus ||
        reason?.data?.ResponseStatus ||
        reason?.response?.data?.ResponseStatus ||
        reason?.message && {Message: reason.message} || null;
    return {
        updateOne: {
            filter: {_id: cart._id},
            update: {
                $set: {
                    status: value?.data?.Id ? CartStatusEnum.CREATED_INVOICE : CartStatusEnum.ERROR_CREATED_INVOICE,
                    ...value?.data?.Id && {
                        products: [],
                        productInOrders: cart.products.slice()
                    }
                },
                $addToSet: {
                    kvOrders: {
                        kvOrderId: value?.data?.Id || '',
                        kvOrderCode: value?.data?.Code || '',
                        isAuto: true,
                        ...error && {error: error}
                    }
                }
            },
            upsert: true,
        },
    }
};

export function getRetailerOrder(cart: FbCartsDocument, retailerId: number, branchId: number, result) {
    const {value} = result;
    const {products} = cart;
    const comments = [];
    (products || []).forEach(product => {
        comments.push(...product.Comments);
    });
    comments.sort((a, b) => (b.TimeStamp || 0) - (a.TimeStamp || 0));

    const lastCommentId = comments.length ? comments[0].CommentId : undefined;
    if (value && value.Id) {
        return {
            orderId: value.Id,
            conversationId: lastCommentId || cart.fbUserId,
            psId: cart.fbUserId,
            pageId: cart.pageId,
            retailerId,
            branchId,
        }
    }
    return null;
};

export function getCustomerByBranch(fbUserProfiles: FbUserProfileDocument[], fbUserId: string, branchId: number) {
    const foundProfile = fbUserProfiles.find(profile => profile.id === fbUserId);
    const foundCustomerByBranch = foundProfile ? (foundProfile.kvCustomers || []).find(cus => cus['branchId'] === branchId) : null;
    return foundCustomerByBranch ? {
        customerId: foundCustomerByBranch['kvCustomerId'],
        customerCode: foundCustomerByBranch['kvCustomerCode']
    } : null;
}

export function buildPayloadOrder(fbCart: FbCartsDocument, branchId: string, Description: string, customer: any, fromType = CustomerSocialTypes.Facebook): any {
    const {updatedAt, products, priceBookId, priceBookName} = fbCart;
    let customerId = 0, customerCode = '';
    if (customer) {
        customerId = customer.customerId;
        customerCode = customer.customerCode;
    }

    const OrderDetails = products.map((product: any) => {
        return {
            ProductId: product.KvProductId,
            Quantity: product.Quantity,
            Price: product.Price
        }
    });

    const existOrder = fbCart.kvOrders?.length ? fbCart.kvOrders.find(order => order.isAuto && order.kvOrderId) : null;

    return {
        ...existOrder && {Id: existOrder.kvOrderId},
        FromType: fromType,
        IsLivestream: true,
        FromFbPos: true,
        BranchId: branchId,
        PurchaseDate: updatedAt,
        ...priceBookName && priceBookId && {
            Extra: JSON.stringify({
                PriceBookId: {
                    Id: priceBookId,
                    Name: priceBookName
                }
            })
        },
        ...(customerCode && {CustomerCode: customerCode}),
        ...(customerId && {CustomerId: customerId}),
        OrderDetails,
        Description
    };
}

export function getMetadataLivestreamForSendMessage(postReferenceUrl: string, commentId: string, IsOrderConfirm = false, livestreamScript: FbLivestreamScriptDocument) {
    return JSON.stringify({
        RetailerId: livestreamScript ? livestreamScript.retailerId : 0,
        UserId: -1,
        UserName: 'KiotViet',
        From: 'fbpos-worker-chat-messaging',
        CommentId: commentId,
        IsOrderConfirm,
        ...postReferenceUrl && {PostReferenceUrl: postReferenceUrl},
        ...livestreamScript && {LivestreamScript: pick(livestreamScript, ['id', 'videoId', 'livestreamId'])}
    });
}

export function buildPayloadOrderTiktok(tiktokCart: TiktokCartsDocument, branchId: string, Description: string, customer: any, existOrder: any): any {
    const {updatedAt, products, priceBookId, priceBookName} = tiktokCart;
    let customerId = 0, customerCode = '';
    if (customer) {
        customerId = customer.kvCustomerId;
        customerCode = customer.kvCustomerCode;
    }

    const OrderDetails = products.map((product: any) => {
        return {
            ProductId: product.KvProductId,
            Quantity: product.Quantity,
            Price: product.Price
        }
    });

    return {
        ...existOrder && {Id: existOrder.kvOrderId},
        FromType: CustomerSocialTypes.TiktokLive,
        IsLivestream: true,
        BranchId: branchId,
        PurchaseDate: updatedAt,
        Extra: JSON.stringify({PriceBookId: {Id: priceBookId || 0, Name: priceBookName || 'Bảng giá chung'}}),
        ...(customerCode && {CustomerCode: customerCode}),
        ...(customerId && {CustomerId: customerId}),
        OrderDetails,
        Description
    };
}
