export function buildOrderData(order) {
    const data = {};
    if (!order) {
        return data;
    }

    const { Code, Total, TotalQuantity, Customer, DeliveryDetail, OrderDetails } = order;
    data['{Ma_Don_Hang}'] = Code;
    data['{Tam_Ung_Dat_Hang}'] = '0';

    if (Customer) {
        data['{Khach_Hang}'] = Customer.Name || '';
        data['{So_Dien_Thoai}'] = Customer.ContactNumber || '';
        data['{Dia_Chi_Khach_Hang}'] = getAddressFull(Customer);
        data['{Gioi_Tinh_Khach_Hang}'] = Customer.Gender == true ? 'Nam' : (Customer.Gender == false ? 'Nữ' : '');
        data["{Danh_Xung}"] = Customer.Gender == undefined ? 'anh/chị' : (Customer.Gender == true ? 'anh' : 'chị');
    }

    if (OrderDetails) {
        data["{Ma_Hang}"] = OrderDetails.map(d => d.ProductCode).join(", ");
        data["{Ten_Hang_Hoa}"] = OrderDetails.map(d => d.ProductName).join(", ");
        data["{Ma_Ten_Hang}"] = OrderDetails.map(d => d.ProductCode + ": " + d.ProductName).join(", ");
        data["{So_Luong}"] = OrderDetails.map(d => d.Quantity).join(", ");
        data["{Don_Gia}"] = OrderDetails.map(d => d.Price).join(", ");
        data["{So_Luong_Ten_Ma_Hang}"] = OrderDetails.map(d => d.Quantity + " " + d.ProductName + " (" + d.ProductCode + ")").join(", ");
        data['{Tong_So_Luong}'] = getTotalQuantity(OrderDetails);
        data['{Tong_Cong}'] = getTotal(OrderDetails);
    }

    return data;
}

function getAddressFull(customer) {
    const { Address, WardName, LocationName } = customer;
    let reserverLocation = '';
    if (LocationName) {
        const index = LocationName.lastIndexOf('-');
        if (index >= 0 && index < LocationName.length - 1) {
            reserverLocation = LocationName.substring(index + 1).trim() + ', ' + LocationName.substring(0, index).trim();
        }
    }
    return `${Address ? `${Address}, ` : ''}${WardName ? `${WardName}, ` : ''}${reserverLocation}`;
}

function getTotalQuantity(orderDetails) {
    if (!orderDetails || !orderDetails.length) {
        return 0;
    }
    return orderDetails.reduce((sum, orderDetail) => sum + orderDetail.Quantity, 0);
}

function getTotal(orderDetails) {
    if (!orderDetails || !orderDetails.length) {
        return 0;
    }
    return orderDetails.reduce((sum, orderDetail) => sum + (orderDetail.Quantity * orderDetail.Price), 0);
}

export function buildOrderDatav2(customer, phoneNumber, keywordCreateOrder) {
  const data = {};
  if (!customer) {
      return data;
  }

  if (customer) {
      data['{Ten_Khach_Hang}'] = customer.name || '';
    data["{Danh_Xung}"] = customer.gender ? (customer.gender == "male" ? 'anh' : 'chị') : 'anh/chị';
  }

  data['{So_Dien_Thoai}'] = phoneNumber || '';

  data["{Tu_Khoa_Dat_Hang}"] = keywordCreateOrder || '';
  return data;
}
