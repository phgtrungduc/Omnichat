export enum DeliveryStatus {
    Pending = 1,
    Delivering = 2,
    Delivered = 3,
    Returning = 4,
    Returned = 5,
    Void = 6,
    InPickup = 7,
    PickupRetry = 8,
    Pickuped = 9,
    DeliveringRetry = 10,
    ReturnPending = 11,
    ReturnRetry = 12
}

export const ENABLED_DELIVERY_STATUS = [DeliveryStatus.Delivering, DeliveryStatus.Delivered, DeliveryStatus.DeliveringRetry];
