import { RabbitSubscribe } from "@golevelup/nestjs-rabbitmq";
import {
    extractTokens,
    FacebookResponseException,
    KvLogger,
    RabbitMqConfigAutoSendMessageCreateOrder,
    replaceTokens
} from "@kiotviet-facebook-services/common";
import { FacebookFeedService, FacebookMessageService } from "@kiotviet-facebook-services/facebook-sdk";
import { FbLivestreamScriptDocument } from "@kiotviet-facebook-services/fbpos-master-repository";
import { Injectable } from "@nestjs/common";
import { IKvLogInput } from "libs/shared/common/src/lib/logger/interfaces/logger.interface";
import { pick } from 'lodash';
import { buildOrderData } from "./helpers/build-order.helper";
import { IMessageCreateOrderPayload } from "./interface/message-create-order-payload.interface";

const config = require('config');

@Injectable()
export class AutoSendMessageCreateOrderService {
    constructor(
        private readonly _logger: KvLogger,
        private readonly _facebookFeedService: FacebookFeedService,
        private readonly _facebookMessageService: FacebookMessageService) {
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigAutoSendMessageCreateOrder.ROUTING_KEY,
        queue: `fbpos-worker-chat-messaging:${RabbitMqConfigAutoSendMessageCreateOrder.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _handleMessageCreateOrder(payload: IMessageCreateOrderPayload) {
        const prefixLog = this.prefixLog('_handleMessageCreateOrder');
        const { CommentId, AccessToken, OrderConfirm, Order, LivestreamScript } = payload;
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);
        try {
            if (!LivestreamScript) {
                return Promise.resolve();
            }
            await this._autoSendMessageAfterCreatedOrderSuccess({
                comment_id: CommentId,
                access_token: AccessToken,
                OrderConfirm,
                order: Order,
                livestreamScript: LivestreamScript
            });

            this._logger.info(logInput, `${prefixLog} success`);
        } catch (error) {
            this._logger.error({ ...logInput, Error: new FacebookResponseException(error.stack, { cause: error }) }, `${prefixLog} fail`);
        }
        return Promise.resolve();
    }

    private async _autoSendMessageAfterCreatedOrderSuccess({
        comment_id,
        access_token,
        OrderConfirm,
        order,
        livestreamScript
    }) {
        const { Content } = OrderConfirm;
        const tokens = extractTokens(Content);
        const postReference = await this._facebookFeedService.getFeedDetail({ access_token, comment_id });
        const text = tokens.length > 0 ? replaceTokens(Content, tokens, buildOrderData(order)) : Content;
        const detail = {
            metadata: this.getMetadataLivestreamForSendMessage(postReference.permalink_url, comment_id, true, livestreamScript),
            text
        };
        return this._facebookMessageService.sendMessage({
            recipient: { comment_id },
            message: JSON.stringify(detail),
            access_token
        });
    }

    private getMetadataLivestreamForSendMessage(postReferenceUrl: string, commentId: string, IsOrderConfirm = false, livestreamScript: FbLivestreamScriptDocument) {
        return JSON.stringify({
            RetailerId: livestreamScript ? livestreamScript.retailerId : 0,
            UserId: -1,
            UserName: 'KiotViet',
            From: 'fbpos-worker-chat-messaging',
            CommentId: commentId,
            IsOrderConfirm,
            ...postReferenceUrl && { PostReferenceUrl: postReferenceUrl },
            ...livestreamScript && { LivestreamScript: pick(livestreamScript, ['id', 'videoId', 'livestreamId']) }
        });
    }
}
