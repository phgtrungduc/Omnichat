import { RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import { CACHE_KEYS, createHashKeyFromObject } from '@kiotviet-facebook-services/cache';
import {
    ERROR_MESSAGE_REDLOCK,
    extractTokens,
    KvLogger,
    KvResponseInternalApiException,
    RabbitMqConfigKvDelivery,
    replaceTokens,
    SocialTypes
} from '@kiotviet-facebook-services/common';
import { FacebookMessageService, MessageTags } from '@kiotviet-facebook-services/facebook-sdk';
import { PageSubscriptionService } from '@kiotviet-facebook-services/fbpos-master-repository';
import { KvOrderApiService } from '@kiotviet-facebook-services/kv-internal-api';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject, Injectable } from '@nestjs/common';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
import { DeliveryStatus, ENABLED_DELIVERY_STATUS } from './common/shipping-status.enum';
import { IKvDeliveryStatusPayload } from './interface/kv-delivery-status.interface';

const config = require('config');

@Injectable()
export class AutoSendMessageShippingStatusService {
    checkShippingStatusUseCache = (status: number) => {
        return status && [DeliveryStatus.Delivering, DeliveryStatus.Delivered].includes(status);
    }

    constructor(
        private readonly _logger: KvLogger,
        private readonly _kvOrderApiService: KvOrderApiService,
        private readonly _pageSubscriptionService: PageSubscriptionService,
        private readonly _facebookMessageService: FacebookMessageService,
        @Inject(CACHE_MANAGER) private readonly _cache: Cache,
    ) {
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').deliveryExchange,
        routingKey: RabbitMqConfigKvDelivery.ROUTING_KEY,
        queue: `fbpos-worker-chat-messaging:${RabbitMqConfigKvDelivery.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _autoSendShippingMessage(payload: IKvDeliveryStatusPayload) {
        const prefixLog = this.prefixLog('_autoSendShippingMessage');
        const baseInfoLog = { Context: { payload }, SourceContext: '_autoSendShippingMessage' };
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.RetailerId': payload?.RetailerId,
                'Kv.RetailerCode': payload?.RetailerCode,
                'Kv.SocialId': payload.CustomerSocial?.PageIdFacebook?.toString(),
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        this._logger.info(logInput, `${prefixLog} received payload`);


        if (!payload.CustomerSocial || ENABLED_DELIVERY_STATUS.indexOf(payload.Status) < 0 || !payload.DocumentId) {
            return Promise.resolve();
        }
        const { CustomerSocial, RetailerId, Status, DocumentId } = payload;
        const pageId = CustomerSocial.PageIdFacebook.toString();
        const conversationId = CustomerSocial.PsidFacebook.toString();
        try {
            const subscription = await this._pageSubscriptionService.find(RetailerId, pageId);
            if (!subscription || !subscription.AccessToken || !subscription.State || subscription.IsRemoved) {
                return Promise.resolve();
            }

            const { Setting, AccessToken } = subscription;

            let content = '';
            switch (Status) {
                case DeliveryStatus.Delivering:
                    content = Setting?.DeliveringConfirm?.Status && Setting?.DeliveringConfirm?.Content;
                    break;
                case DeliveryStatus.Delivered:
                    content = Setting?.DeliverySuccessConfirm?.Status && Setting?.DeliverySuccessConfirm?.Content;
                    break;
                case DeliveryStatus.DeliveringRetry:
                    content = Setting?.DeliveryFailedConfirm?.Status && Setting?.DeliveryFailedConfirm?.Content;
                    break;
            }
            if (!content) {
                return Promise.resolve();
            }

            const hash = await createHashKeyFromObject({ RetailerId, DocumentId, conversationId, Status });
            const cacheKey = `${CACHE_KEYS.AUTO_SEND_SHIPPING_STATUS.NAME}${hash}`;
            if (this.checkShippingStatusUseCache(Status)) {
                const hasSent = await this._cache.get<boolean>(cacheKey);
                if (hasSent) {
                    this._logger.warn(logInput, `${prefixLog} warning: shipping status have duplicate`);
                    return Promise.resolve();
                }
            }

            const message = await this._getMessageBuilder(payload, content);
            const detail = {
                metadata: this._facebookMessageService.getDefaultMetadata(RetailerId),
                text: message
            };
            await this._facebookMessageService.sendMessage({
                recipient: { id: conversationId },
                message: JSON.stringify(detail),
                access_token: AccessToken,
                tag: MessageTags.POST_PURCHASE_UPDATE
            });

            await this._cache.set(cacheKey, true, { ttl: CACHE_KEYS.AUTO_SEND_SHIPPING_STATUS.TTL } as any);
            this._logger.info(logInput, `${prefixLog} success`);
        } catch (err) {
            if (err?.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            this._logger.error({ ...logInput, Error: new KvResponseInternalApiException(err.stack, { cause: err }) }, `${prefixLog} fail`);

        }

        return Promise.resolve();
    }

    private async _getMessageBuilder(payload: IKvDeliveryStatusPayload, Content: string) {
        const { BranchId, RetailerCode, CustomerId, DocumentId } = payload;
        const tokensFromContent = extractTokens(Content);
        const results = await this._kvOrderApiService.getInvoiceByTokens({
            RetailerCode,
            InvoiceId: DocumentId,
            CustomerId,
            BranchId,
            Content,
            Tokens: tokensFromContent
        });
        const tokens = results.data;
        return replaceTokens(Content, tokensFromContent, tokens);
    }

}
