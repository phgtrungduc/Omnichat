import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import { CACHE_KEYS } from '@kiotviet-facebook-services/cache';
import {
    ERROR_MESSAGE_REDLOCK,
    EventTypes,
    extractTokens,
    FacebookResponseException,
    IInstagramCommentValue,
    KvLogger,
    KvRabbitMQException,
    RabbitMqConfigAutoAnswerCommentByInboxInstagram,
    RabbitMqConfigNotification,
    replaceTokens,
    SocialTypes,
} from '@kiotviet-facebook-services/common';
import {
    IInstagramPostDetail,
    IInstagramUser,
    InstagramFeedService,
    InstagramMessageService,
    InstagramUserService
} from '@kiotviet-facebook-services/facebook-sdk';
import {
    FbUserProfileService,
    isAutoAnswerCommentByInbox,
    ISettingItem,
    MongodbGroupService,
    PageSubscriptionService,
    WebhookSubscriptionDocument
} from '@kiotviet-facebook-services/fbpos-master-repository';
import { RedisLockService, REDLOCK_CONST } from '@kiotviet-facebook-services/lock';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject, Injectable } from '@nestjs/common';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';
import {
    IAutoAnswerCommentByInboxPayload
} from '../create-or-update-message/interface/auto-answer-comment-by-inbox.interface';

const config = require('config');

@Injectable()
export class AutoAnswerCommentByInboxInstagramService {
    readonly INSTAGRAM_USER_TOKENS = [
        {
            token: '{Ten_Khach_Hang}', value: 'name'
        },
        {
            token: '{Ten_Nguoi_Dung}', value: 'username'
        }
    ];

    private readonly _rabbitMQConfig;

    constructor(
        @Inject(CACHE_MANAGER) private readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _pageSubscriptionService: PageSubscriptionService,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _fbUserProfileService: FbUserProfileService,
        private readonly _instagramUserService: InstagramUserService,
        private readonly _instagramFeedService: InstagramFeedService,
        private readonly _instagramMessageService: InstagramMessageService,
        private readonly _redlockService: RedisLockService,
        private readonly _amqpConnection: AmqpConnection,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigAutoAnswerCommentByInboxInstagram.ROUTING_KEY,
        queue: `fbpos-worker-chat-messaging:${RabbitMqConfigAutoAnswerCommentByInboxInstagram.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _autoAnswerCommentByInboxInstagram(payload: IAutoAnswerCommentByInboxPayload) {
        const prefixLog = this.prefixLog('_autoAnswerCommentByInboxInstagram');
        const { SenderId, InstagramId, PageId, RetailerId, RetailerCode, BranchId } = payload;
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.BranchId': BranchId,
                'Kv.RetailerId': RetailerId,
                'Kv.RetailerCode': RetailerCode,
                'Kv.SocialId': InstagramId || PageId,
                'Kv.SocialType': InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }

        this._logger.info(logInput, `${prefixLog} received payload`);
        if (SenderId == InstagramId) {
            return Promise.resolve();
        }

        try {
            const lock = await this._redlockService.acquire(
                [`${REDLOCK_CONST.COMMENT.AUTO_ANSWER_COMMENT_BY_INBOX}${InstagramId}`],
                3000,
                {},
            );
            const subscription = await this._pageSubscriptionService.getSubscriptionBySocialId(InstagramId);
            if (!subscription || !subscription.AccessToken || !subscription.State || subscription.IsRemoved) {
                return Promise.resolve();
            }
            const pageSetting = await this._pageSubscriptionService.getPageSetting(InstagramId);
            const setting = pageSetting?.Setting;
            if (!isAutoAnswerCommentByInbox(setting, payload)) {
                return Promise.resolve();
            }
            const {
                result,
                metadata
            } = await this._sendToGraphApiInstagram(payload, subscription, setting['AutoAnswerCommentByInbox']);
            if (result.message_id) {
                await this._cache.set(`${CACHE_KEYS.AUTO_ANSWER_COMMENT_BY_INBOX.NAME}${result.message_id}`, JSON.parse(metadata), { ttl: CACHE_KEYS.AUTO_ANSWER_COMMENT_BY_INBOX.TTL } as any);

                const db = await this._mongodbGroupService.getDatabase({ socialId: InstagramId });
                await db.collection(InstagramId).updateOne({ _id: payload._id }, { $set: { Metadata: JSON.stringify({ IsCanReplyPrivately: false }) } });

                this._sentNotificationStateReply(result.message_id, payload, logInput);
            }
            await this._redlockService.release(lock);

            this._logger.info(logInput, `${prefixLog} success`);
        } catch (err) {
            if (err?.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            const error = err.response?.data?.error;
            if ('OAuthException' === error?.type) {
                this._sentNotificationOnInvalidTokenEventToMQ(InstagramId);
            }

            this._logger.error({ ...logInput, Error: new FacebookResponseException(err.stack, { cause: err }) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }

    private async _sendToGraphApiInstagram(payload: IAutoAnswerCommentByInboxPayload, subscription: WebhookSubscriptionDocument, setting: ISettingItem) {
        const { AccessToken, RetailerId } = subscription;
        const { tokens, dictionaryToken } = await this._getDataForSending({
            autoAnswerConfig: setting,
            accessToken: AccessToken,
            psid: payload.SenderId,
        });
        const comment_id = payload._id;
        const postid = (payload.entry?.[0].changes?.[0].value as IInstagramCommentValue)?.media?.id;
        const cacheKey = `${CACHE_KEYS.INSTAGRAM_POST_DETAIL.NAME}${postid}`;
        let postReference = await this._cache.get<IInstagramPostDetail>(cacheKey);

        if (!postReference) {
            postReference = await this._instagramFeedService.getPostDetail({ access_token: AccessToken, postid });
            this._cache.set(cacheKey, postReference, { ttl: CACHE_KEYS.INSTAGRAM_POST_DETAIL.TTL } as any);
        }
        const metadata = JSON.stringify({
            RetailerId,
            UserId: -1,
            UserName: 'KiotViet',
            From: 'fbpos-worker-chat-messaging',
            CommentId: comment_id,
            IsCanReplyPrivately: false,
            ...postReference && { PostReferenceUrl: postReference.permalink },
        });
        const detail = {
            metadata,
            text: tokens.length ? replaceTokens(setting.Content, tokens, dictionaryToken) : setting.Content
        };
        const result = await this._instagramMessageService.sendMessage({
            recipient: { comment_id },
            message: JSON.stringify(detail),
            access_token: AccessToken
        });
        return { result, metadata }
    }

    private async _getDataForSending({ autoAnswerConfig, accessToken, psid }) {
        const userTokens = this.INSTAGRAM_USER_TOKENS;
        const tokens = extractTokens(autoAnswerConfig.Content).filter(t => userTokens.map(item => item.token).includes(t));
        let dictionaryToken;
        if (tokens.length > 0) {
            dictionaryToken = await this._getDictionaryToken({ accessToken, tokens, psid })
        }
        return { dictionaryToken, tokens };
    }

    private async _getDictionaryToken({ psid, accessToken, tokens }): Promise<{ [key: string]: string; }> {
        let metaUser: IInstagramUser = await this._fbUserProfileService.handleReadFbUserProfile(psid);
        if (!metaUser || !metaUser.id) {
            metaUser = await this._instagramUserService.getInstagramProfile({ psid, access_token: accessToken })
        }

        const userTokens = this.INSTAGRAM_USER_TOKENS
        return tokens.reduce((res, token) => {
            const item = userTokens.find(t => t.token === token);
            if (item && metaUser) {
                return { ...res, [token]: metaUser[item.value] };
            }
        }, {});
    }

    private _sentNotificationStateReply(messageId: string, payload: IAutoAnswerCommentByInboxPayload, logInput: IKvLogInput) {
        const { InstagramId, PageId, _id } = payload;
        const prefixLog = this.prefixLog('_sentNotificationStateReply');

        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigNotification.ROUTING_KEY, {
            EventType: EventTypes.AutoMessage,
            PageId: InstagramId || PageId,
            Data: messageId,
            ReplyConversationId: _id,
            Type: 'inbox',
        }).catch(err => {
            this._logger.error({ ...logInput, Error: new KvRabbitMQException(err.stack) }, `${prefixLog} fail`);
        });
    }

    private async _sentNotificationOnInvalidTokenEventToMQ(socialId: string, logInput?: IKvLogInput) {
        const prefixLog = this.prefixLog('_sentNotificationOnInvalidTokenEventToMQ');

        const cacheKey = `${CACHE_KEYS.INVALID_ACCESS_TOKEN_DEBOUNCE.NAME}${socialId}`;
        const cache = await this._cache.get<boolean>(cacheKey);
        if (cache) {
            return;
        }

        await this._cache.set(cacheKey, true, { ttl: CACHE_KEYS.INVALID_ACCESS_TOKEN_DEBOUNCE.TTL } as any);
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigNotification.ROUTING_KEY, {
            EventType: EventTypes.InvalidTokenDetected,
            PageId: socialId,
        }).catch(err => {
            this._logger.error({ ...logInput, Error: new KvRabbitMQException(err) }, `${prefixLog} fail`);
        });
    }

}
