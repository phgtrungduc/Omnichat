import { FbCartsDocument, FbLivestreamScriptDocument } from "@kiotviet-facebook-services/fbpos-master-repository";

export interface IMessageCreateOrderPayload {
  CommentId: string;
  AccessToken: string;
  OrderConfirm : any;
  Order : any;
  LivestreamScript : any;
}

export interface IAutoMessageLivestreamPayload {
  CommentId: string;
  FbUserId: string;
  KeywordCreateOrder: string;
  PageId: string;
  VideoId: string;
  Type: number;
  PhoneNumberFound: string;
  OrderCode?: string;
}

export interface IAutoMessageTemplateButton {
    PageId: string;
    RetailerId: string;
    RetailerCode: string;
    Content: string;
    FbUserId: string;
    Metadata?: IMetaDataPayload;
}

export interface IMetaDataPayload {
    OrderCode?: string;
    InvoiceCode?: string;
    CatalogId?: string;
    CatalogName?: string;
}
