import { DeliveryStatus } from "../common/shipping-status.enum";


// {
//     "DocumentId":16706432,
//     "DocumentCode":"HDFBP000019.01",
//     "BranchId":7660,
//     "RetailerId":373165,
//     "Status":1, // Status shipping
//     "StatusNote":"",
//     "CustomerId":4017103,
//     "CustomerSocial":{
//         "Id":72649,
//         "CreatedDate":"2020-12-09T13:51:12.2900000+07:00",
//         "CreatedBy":82445,
//         "RetailerId":373165,
//         "BranchId":7660,
//         "CustomerId":4017103,
//         "PsidFacebook":3395519707212956,
//         "PageIdFacebook":285728215317541,
//         "IdOld":0
//     },
//     "EventType":"DeliveryInfo_Update",
//     "RetailerCode":"raiso"
// }
export interface IKvDeliveryStatusPayload {
    DocumentId: number;
    DocumentCode: string;
    BranchId: number;
    RetailerId: number;
    RetailerCode: string;
    Status: DeliveryStatus;
    StatusNote: string;
    CustomerId: number;
    CustomerSocial: ICustomerSocial;
    EventType: string;
}

export interface ICustomerSocial {
    Id: number;
    CreatedDate: string;
    CreatedBy: number;
    RetailerId: number;
    BranchId: number;
    CustomerId: number;
    PsidFacebook: number;
    PageIdFacebook: number;
    IdOld: number;
}
