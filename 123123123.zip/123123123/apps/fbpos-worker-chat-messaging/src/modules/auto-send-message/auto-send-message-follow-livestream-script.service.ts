import { RabbitSubscribe } from "@golevelup/nestjs-rabbitmq";
import {
    extractTokens,
    FacebookResponseException,
    KvLogger,
    RabbitMqConfigAutoSendMessageFollowLivestreamScript,
    replaceTokens,
    SocialTypes
} from "@kiotviet-facebook-services/common";
import {
    FacebookFeedService,
    FacebookMessageService,
    FacebookUserService,
    IButtonMessageFacebook
} from "@kiotviet-facebook-services/facebook-sdk";
import {
    FbCartsService,
    FbLivestreamScript,
    FbLivestreamScriptService,
    FbUserProfileV2,
    FbUserProfileV2Service,
    WebhookSubscriptionDocument,
    WebhookSubscriptionRepository
} from "@kiotviet-facebook-services/fbpos-master-repository";
import { AutoReplyLivestreamMessage } from "@kiotviet-facebook-services/kv-internal-api";
import { CACHE_MANAGER } from "@nestjs/cache-manager";
import { Inject, Injectable } from "@nestjs/common";
import { createHash } from 'crypto';
import { IKvLogInput } from "libs/shared/common/src/lib/logger/interfaces/logger.interface";
import { pick } from 'lodash';
import { buildOrderDatav2 } from "./helpers/build-order.helper";
import { IAutoMessageLivestreamPayload } from "./interface/message-create-order-payload.interface";

const config = require('config');

@Injectable()
export class AutoSendMessageFollowLivestreamScript {

    private readonly _rabbitMQConfig;
    private readonly orderUrl;
    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    constructor(
        @Inject(CACHE_MANAGER) private readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _facebookMessageService: FacebookMessageService,
        private readonly _facebookUserProfilev2Service: FbUserProfileV2Service,
        private readonly _fbLivestreamScriptService: FbLivestreamScriptService,
        private readonly _webhookSubscriptionRepository: WebhookSubscriptionRepository,
        private readonly _facebookUserService: FacebookUserService,
        private readonly _fbCartService: FbCartsService,
        private readonly _facebookFeedService: FacebookFeedService,) {
        this._rabbitMQConfig = config.get('rabbitMQ');
        this.orderUrl = config.get('orderShoppingOnline')?.url;

    }


    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigAutoSendMessageFollowLivestreamScript.ROUTING_KEY,
        queue: `fbpos-worker-chat-messaging:${RabbitMqConfigAutoSendMessageFollowLivestreamScript.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _handleMessageFollowLivestreamScript(payload: IAutoMessageLivestreamPayload) {
        const prefixLog = this.prefixLog('_handleMessageFollowLivestreamScript');
        const { CommentId, PageId, FbUserId, KeywordCreateOrder, VideoId, Type, PhoneNumberFound, OrderCode } = payload;
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.SocialId': PageId,
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }

        this._logger.info(logInput, `${prefixLog} received payload`);

        try {
            const livestreamScript = await this._fbLivestreamScriptService.getFbLivestreamScript('', { videoId: VideoId }) as FbLivestreamScript;
            if (!this.isSendMessage(Type, livestreamScript)) {
                return Promise.resolve();
            }
            let fbUser = await this._facebookUserProfilev2Service.handleReadFacebookUserProfile(FbUserId, VideoId);
            const socialInfo = await this._webhookSubscriptionRepository.getSubscriptionBySocialId(PageId);
            if (!socialInfo) {
                return Promise.resolve();
            }

            if (!fbUser) {
                try {
                    const res = await this._facebookUserService.getPsidProfile({
                        psid: FbUserId,
                        access_token: socialInfo.AccessToken
                    });
                    if (!res) {
                        this._logger.error(logInput, `${prefixLog} can not get user info`);
                        return Promise.resolve();
                    }
                    fbUser = res as FbUserProfileV2;
                } catch (error) {
                    this._logger.error({ ...logInput, Error: new FacebookResponseException(error.stack, { cause: error }) }, `${prefixLog} can not get user info`);
                    return Promise.resolve();
                }
            }
            const contentReply = Type == AutoReplyLivestreamMessage.ValidComment ? livestreamScript.LiveStreamFormula.AutoSendMessageWithValidComment.Content :
                livestreamScript.LiveStreamFormula.AutoSendMessageWhenOutOfQuantity.Content;

            const tokens = extractTokens(contentReply);

            const text = tokens.length > 0 ? replaceTokens(contentReply, tokens, buildOrderDatav2(fbUser, PhoneNumberFound, KeywordCreateOrder)) : contentReply;
            const postReference = await this._facebookFeedService.getFeedDetail({
                access_token: socialInfo.AccessToken,
                comment_id: CommentId
            });
            const metadata = this.getMetadataLivestreamForSendMessage(postReference.permalink_url, CommentId, true, livestreamScript);

            if ((Type == AutoReplyLivestreamMessage.ValidComment && (!OrderCode || !livestreamScript.LiveStreamFormula.AutoSendMessageWithValidComment.AllowViewOrder)) || Type == AutoReplyLivestreamMessage.OutOfQuantityOrder) {
                const detail = {
                    metadata,
                    text
                };
                this._facebookMessageService.sendMessage({
                    recipient: { comment_id: CommentId },
                    message: JSON.stringify(detail),
                    access_token: socialInfo.AccessToken
                });
            } else {
                let isAddDomainToWhiteList = false;
                try {
                    isAddDomainToWhiteList = await this.handleWhitelistDomainPage(socialInfo, this.orderUrl);
                } catch (error) {
                    console.log('handleWhitelistDomainPage error', error);
                }
                const secretkey = '123ABCdef!@#';
                const key = `key_access_${secretkey}_${OrderCode}_${livestreamScript.retailerCode}`;
                const hashKey = this.encryptKeySHA256Hash(key);
                const url = `${this.orderUrl}/shopping-online/orders/detail?code=${OrderCode}&retailer=${livestreamScript.retailerCode}&key=${hashKey}`;

                let paramMessage = {
                    access_token: socialInfo.AccessToken,
                    recipient: {
                        comment_id: CommentId
                    },
                    message: {
                        metadata: this.getMetadataLivestreamForSendMessage(postReference.permalink_url, CommentId, true, livestreamScript),
                        buttons: [
                            {
                                type: 'web_url',
                                url: url,
                                title: "Xem đơn hàng",
                                ...isAddDomainToWhiteList && { messenger_extensions: true }
                            } as IButtonMessageFacebook
                        ],
                        text: text,
                        access_token: socialInfo.AccessToken
                    }
                };
                this._facebookMessageService.sendPrivateMessageWithButton(paramMessage).then(async res => {
                    if (res) {
                        //update status reply fbcart
                        await this.updatePrivateReply(FbUserId, VideoId);
                        this._logger.info(logInput, `${prefixLog} success`);
                    }
                }).catch(err => {
                    this._logger.error({ ...logInput, Error: new FacebookResponseException(err.stack, { cause: err }) }, `${prefixLog} fail`);
                })

            }
            return Promise.resolve();
        } catch (error) {
            this._logger.error({ ...logInput, Error: new FacebookResponseException(error.stack, { cause: error }) }, `${prefixLog} fail 2`);
        }
        return Promise.resolve();
    }

    private async handleWhitelistDomainPage(webhookSubscription: WebhookSubscriptionDocument, shoppingOnlineDomain: string) {
        try {
            if (webhookSubscription.WhitelistedDomains?.find(x => x == shoppingOnlineDomain)) return true;
            const messageProfile = (await this._facebookMessageService.getWhitelistedDomainsPage(webhookSubscription.AccessToken))?.data;

            const whitelistUpdate = messageProfile && messageProfile.length ? messageProfile[0].whitelisted_domains : [];

            if (whitelistUpdate.find(x => x.includes(shoppingOnlineDomain))) {
                await this._webhookSubscriptionRepository.updateOne({
                    _id: webhookSubscription._id
                }, { WhitelistedDomains: whitelistUpdate });

                return true;
            }
            whitelistUpdate.push(shoppingOnlineDomain);

            await this._facebookMessageService.addDomainToWhitelistPage(whitelistUpdate, webhookSubscription.AccessToken);

            await this._webhookSubscriptionRepository.updateOne({
                _id: webhookSubscription._id
            }, { WhitelistedDomains: whitelistUpdate });
            return true;

        } catch (error) {
            throw error;
        } finally {
            return false;
        }
    }

    private async updatePrivateReply(fbUserId: string, videoId: string) {
        // const fbCarts = await this._fbCartService.handleReadFbCart(fbUserId, videoId);
        await this._fbCartService.handleUpdateFbCart({
            videoId,
            fbUserId,
            isReplyPrivately: 1
        }, true);
    }

    private isSendMessage(type, livestreamScript: FbLivestreamScript): boolean {
        if (type == AutoReplyLivestreamMessage.ValidComment) {
            return livestreamScript.LiveStreamFormula?.AutoSendMessageWithValidComment?.Status && livestreamScript.LiveStreamFormula?.AutoSendMessageWithValidComment?.Content;
        }
        if (type == AutoReplyLivestreamMessage.OutOfQuantityOrder) {
            return livestreamScript.LiveStreamFormula?.AutoSendMessageWhenOutOfQuantity?.Status && livestreamScript.LiveStreamFormula?.AutoSendMessageWhenOutOfQuantity?.Content;
        }
        return false;
    }

    private getMetadataLivestreamForSendMessage(postReferenceUrl: string, commentId: string, IsOrderConfirm = false, livestreamScript: FbLivestreamScript) {
        return JSON.stringify({
            RetailerId: livestreamScript ? livestreamScript.retailerId : 0,
            UserId: -1,
            UserName: 'KiotViet',
            From: 'fbpos-worker-chat-messaging',
            CommentId: commentId,
            IsOrderConfirm,
            ...postReferenceUrl && { PostReferenceUrl: postReferenceUrl },
            ...livestreamScript && { LivestreamScript: pick(livestreamScript, ['id', 'videoId', 'livestreamId', 'retailerId']) }
        });
    }

    private encryptKeySHA256Hash(key: string): string {
        const chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const bytes = Buffer.from(key, 'utf8');

        const hash = createHash('sha256');
        hash.update(bytes);
        const hashBytes = hash.digest();

        const hash2 = new Array<string>(16);
        for (let i = 0; i < hash2.length; i++) {
            hash2[i] = chars[hashBytes[i] % chars.length];
        }

        return hash2.join('');
    }
}
