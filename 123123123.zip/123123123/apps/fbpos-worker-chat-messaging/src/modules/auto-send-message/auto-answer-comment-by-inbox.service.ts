import {
    ERROR_MESSAGE_REDLOCK,
    EventTypes,
    extractTokens,
    FacebookResponseException,
    KvLogger,
    KvRabbitMQException,
    RabbitMqConfigAutoAnswerCommentByInbox,
    RabbitMqConfigNotification,
    replaceTokens,
    SocialTypes,
} from '@kiotviet-facebook-services/common';
import { Inject, Injectable } from '@nestjs/common';
import { AmqpConnection, RabbitSubscribe } from '@golevelup/nestjs-rabbitmq';
import { pick } from 'lodash';
import {
    FbUserProfile,
    FbUserProfileService,
    isAutoAnswerCommentByInbox,
    ISettingItem,
    MongodbGroupService,
    PageSubscriptionService,
    WebhookSubscriptionDocument
} from '@kiotviet-facebook-services/fbpos-master-repository';
import {
    FacebookFeedService,
    FacebookMessageService,
    FacebookUserService,
    IFacebookLiveVideoDetail,
    IInstagramUser
} from '@kiotviet-facebook-services/facebook-sdk';
import {
    IAutoAnswerCommentByInboxPayload
} from '../create-or-update-message/interface/auto-answer-comment-by-inbox.interface';
import { RedisLockService, REDLOCK_CONST } from '@kiotviet-facebook-services/lock';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { CACHE_KEYS } from '@kiotviet-facebook-services/cache';
import { IKvLogInput } from 'libs/shared/common/src/lib/logger/interfaces/logger.interface';

const config = require('config');

@Injectable()
export class AutoAnswerCommentByInboxService {
    readonly USER_TOKENS = [
        {
            token: '{Ten_Khach_Hang}', value: 'first_name'
        },
        {
            token: '{Ho_Khach_Hang}', value: 'last_name'
        },
        {
            token: '{Ten_Day_Du}', value: 'name'
        }
    ];

    private readonly _rabbitMQConfig;

    constructor(
        @Inject(CACHE_MANAGER) private readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _pageSubscriptionService: PageSubscriptionService,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _fbUserProfileService: FbUserProfileService,
        private readonly _facebookUserService: FacebookUserService,
        private readonly _facebookFeedService: FacebookFeedService,
        private readonly _facebookMessageService: FacebookMessageService,
        private readonly _redlockService: RedisLockService,
        private readonly _amqpConnection: AmqpConnection,
    ) {
        this._rabbitMQConfig = config.get('rabbitMQ');
    }

    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigAutoAnswerCommentByInbox.ROUTING_KEY,
        queue: `fbpos-worker-chat-messaging:${RabbitMqConfigAutoAnswerCommentByInbox.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _autoAnswerCommentByInbox(payload: IAutoAnswerCommentByInboxPayload) {
        const prefixLog = this.prefixLog('_autoAnswerCommentByInbox');

        const { SenderId, InstagramId, PageId, RetailerId, RetailerCode, BranchId } = payload;
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.BranchId': BranchId,
                'Kv.RetailerId': RetailerId,
                'Kv.RetailerCode': RetailerCode,
                'Kv.SocialId': InstagramId || PageId,
                'Kv.SocialType': InstagramId ? SocialTypes.INSTAGRAM : SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }


        this._logger.info(logInput, `${prefixLog} received payload`);
        if (SenderId == PageId) {
            return Promise.resolve();
        }

        try {
            const subscription = await this._pageSubscriptionService.getSubscriptionBySocialId(PageId);
            if (!subscription || !subscription.AccessToken || !subscription.State || subscription.IsRemoved) {
                return Promise.resolve();
            }
            const pageSetting = await this._pageSubscriptionService.getPageSetting(PageId);
            const setting = pageSetting?.Setting;
            if (!isAutoAnswerCommentByInbox(setting, payload)) {
                return Promise.resolve();
            }
            if (await this._checkPostIsLivestream(payload, subscription.AccessToken)) {
                return Promise.resolve();
            }
            const result = await this._sendToGraphApi(payload, subscription, setting['AutoAnswerCommentByInbox']);
            if (result.message_id) {
                this._sentEventToMQ(result.message_id, payload);
            }

            this._logger.info(logInput, `${prefixLog} success`);
        } catch (err) {
            if (err?.message.includes(ERROR_MESSAGE_REDLOCK)) {
                return Promise.reject();
            }
            const error = err.response?.data?.error;
            if ('OAuthException' === error?.type) {
                await this._sentNotificationOnInvalidTokenEventToMQ(PageId);
            }
            this._logger.error({ ...logInput, Error: new FacebookResponseException(err.stack) }, `${prefixLog} fail`);
        }

        return Promise.resolve();
    }

    private async _sendToGraphApi(payload: IAutoAnswerCommentByInboxPayload, subscription: WebhookSubscriptionDocument, setting: ISettingItem) {
        const { AccessToken, RetailerId } = subscription;
        const { tokens, dictionaryToken } = await this._getDataForSending({
            autoAnswerConfig: setting,
            accessToken: AccessToken,
            psid: payload.SenderId,
        });
        const comment_id = payload._id;
        const postReference = await this._facebookFeedService.getFeedDetail({ access_token: AccessToken, comment_id });

        const detail = {
            metadata: JSON.stringify({
                RetailerId,
                UserId: -1,
                UserName: 'KiotViet',
                From: 'fbpos-worker-chat-messaging',
                CommentId: comment_id,
                ...postReference && { PostReferenceUrl: postReference.permalink_url },
            }),
            text: tokens.length ? replaceTokens(setting.Content, tokens, dictionaryToken) : setting.Content
        };
        return this._facebookMessageService.sendMessage({
            recipient: { comment_id },
            message: JSON.stringify(detail),
            access_token: AccessToken
        });
    }

    private async _getDataForSending({ autoAnswerConfig, accessToken, psid }) {
        const userTokens = this.USER_TOKENS;
        const tokens = extractTokens(autoAnswerConfig.Content).filter(t => userTokens.map(item => item.token).includes(t));
        let dictionaryToken;
        if (tokens.length > 0) {
            dictionaryToken = await this._getDictionaryToken({ accessToken, tokens, psid })
        }
        return { dictionaryToken, tokens };
    }

    private async _getDictionaryToken({ psid, accessToken, tokens }): Promise<{ [key: string]: string; }> {
        let metaUser: FbUserProfile | IInstagramUser = await this._fbUserProfileService.handleReadFbUserProfile(psid);
        if (!metaUser || !metaUser.id) {
            metaUser = await this._facebookUserService.getPsidProfile({
                psid,
                access_token: accessToken
            }) as FbUserProfile;
        }

        const userTokens = this.USER_TOKENS;
        return tokens.reduce((res, token) => {
            const item = userTokens.find(t => t.token === token);
            if (item && metaUser) {
                return { ...res, [token]: metaUser[item.value] };
            }
        }, {});
    }

    private _sentEventToMQ(messageId: string, payload: IAutoAnswerCommentByInboxPayload) {
        const { InstagramId, PageId, _id } = payload;
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigNotification.ROUTING_KEY, {
            EventType: EventTypes.AutoMessage,
            PageId: InstagramId || PageId,
            Data: messageId,
            ReplyConversationId: _id,
            Type: 'inbox',
        }).catch(err => {
            this._logger.error(`${this.prefixLog('_sentEventToMQ')} fail`,
                new KvRabbitMQException(err.stack), {
                SourceContext: '_sentEventToMQ',
                Context: { messageId, payload },
                ErrorContext: pick(err, ['message', 'stack'])
            });
        });
    }

    private async _sentNotificationOnInvalidTokenEventToMQ(socialId: string) {
        const cacheKey = `${CACHE_KEYS.INVALID_ACCESS_TOKEN_DEBOUNCE.NAME}${socialId}`;
        const cache = await this._cache.get<boolean>(cacheKey);
        if (cache) {
            return;
        }

        await this._cache.set(cacheKey, true, { ttl: CACHE_KEYS.INVALID_ACCESS_TOKEN_DEBOUNCE.TTL } as any);
        this._amqpConnection.publish(this._rabbitMQConfig.mainExchange, RabbitMqConfigNotification.ROUTING_KEY, {
            EventType: EventTypes.InvalidTokenDetected,
            PageId: socialId,
        }).catch(err => {
            this._logger.error(`${this.prefixLog('_sentNotificationOnInvalidTokenEventToMQ')} fail`,
                new KvRabbitMQException(err.stack), {
                SourceContext: '_sentNotificationOnInvalidTokenEventToMQ',
                Context: { pageId: socialId },
                ErrorContext: pick(err, ['message', 'stack'])
            });
        });
    }

    private async _checkPostIsLivestream(payload: IAutoAnswerCommentByInboxPayload, accessToken: string): Promise<boolean> {
        if (!payload || !payload.PageId || !payload.FromLiveVideo) {
            return false;
        }
        const post = payload.entry?.[0].changes?.[0].value?.post;
        if (!post || !post.permalink_url || !post.permalink_url.includes('videos')) {
            return false;
        }

        try {
            const postId = post.id;
            const videoId = postId.split('_') && postId.split('_')[1];  // postId like ${pageId}_{videoId};

            const cacheKey = `${CACHE_KEYS.LIVE_VIDEO_STATUS.NAME}${videoId}`;
            let liveVideo = await this._cache.get<IFacebookLiveVideoDetail>(cacheKey);
            if (liveVideo) {
                return liveVideo?.live_status === 'LIVE';
            }

            liveVideo = await this._facebookFeedService.getLiveVideoStatus({
                access_token: accessToken,
                video_id: videoId
            });
            await this._cache.set(cacheKey, liveVideo, { ttl: CACHE_KEYS.LIVE_VIDEO_STATUS.TTL } as any);

            return liveVideo?.live_status === 'LIVE';
        } catch (error) {
            const prefixLog = this.prefixLog('_checkPostIsLivestream');
            this._logger.error({ MessageTemplate: { payload }, Error: new FacebookResponseException(error.stack, { cause: error }) }, `${prefixLog} fail`);
        }

        return this._checkVideoIdIsLivestream(payload, accessToken);
    }

    /**
     * Nguyên nhân phải viết function checkVideoIdIsLivestream xem link bên dưới
     * https://citigo.atlassian.net/browse/KOL-19733?focusedCommentId=357025
     * @param payload
     * @param accessToken
     * @returns
     */
    private async _checkVideoIdIsLivestream(payload: IAutoAnswerCommentByInboxPayload, accessToken: string): Promise<boolean> {
        const post = payload.entry?.[0].changes?.[0].value?.post;
        const permalinkUrl = post?.permalink_url || '';
        let videoId = permalinkUrl.split('videos/')[1] || '';

        if (permalinkUrl) {
            // Create a URL object with the URL string
            const videoUrl = new URL(permalinkUrl);
            // Get the pathname from the URL object
            const pathname = videoUrl.pathname;
            // Split the pathname by "/"
            const pathParts = pathname.split("/");
            // Find the index of "videos" in the pathParts array
            const videosIndex = pathParts.indexOf("videos");
            if (videosIndex !== -1 && videosIndex < pathParts.length - 1) {
                videoId = pathParts[videosIndex + 1];
            }
        }
        try {
            const cacheKey = `${CACHE_KEYS.LIVE_VIDEO_STATUS.NAME}${videoId}`;
            let liveVideo = await this._cache.get<IFacebookLiveVideoDetail>(cacheKey);
            if (liveVideo) {
                return liveVideo?.live_status === 'LIVE';
            }

            liveVideo = await this._facebookFeedService.getLiveVideoStatus({
                access_token: accessToken,
                video_id: videoId
            });
            this._cache.set(cacheKey, liveVideo, { ttl: CACHE_KEYS.LIVE_VIDEO_STATUS.TTL } as any);

            return liveVideo?.live_status === 'LIVE';
        } catch (error) {
            const prefixLog = this.prefixLog('_checkVideoIdIsLivestream');
            this._logger.error({ MessageTemplate: { payload }, Error: new FacebookResponseException(error.stack, { cause: error }) }, `${prefixLog} fail`);
        }

        return true;
    }
}
