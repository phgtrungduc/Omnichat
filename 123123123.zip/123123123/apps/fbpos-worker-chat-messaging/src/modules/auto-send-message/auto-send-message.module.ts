import { Module } from '@nestjs/common';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { KvRabbitMQModule } from '@kiotviet-facebook-services/rabbitmq';
import { KvInternalApiModule } from '@kiotviet-facebook-services/kv-internal-api';
import { FacebookSdkModule } from '@kiotviet-facebook-services/facebook-sdk';
import { FbPosMasterRepositoryModule } from '@kiotviet-facebook-services/fbpos-master-repository';
import { AutoSendMessageShippingStatusService } from './auto-send-message-kv-shipping-status.service';
import { AutoAnswerCommentByInboxService } from './auto-answer-comment-by-inbox.service';
import { LockModule } from '@kiotviet-facebook-services/lock';
import { AutoAnswerCommentByInboxInstagramService } from "./auto-answer-comment-by-inbox-instagram.service";
import { AutoSendMessageCreateOrderService } from './auto-send-message-create-order.service';
import { AutoSendMessageFollowLivestreamScript } from './auto-send-message-follow-livestream-script.service';
import { AutoSendMessageTemplateService } from "./auto-send-message-template.service";

@Module({
    imports: [CommonModule, KvRabbitMQModule, KvInternalApiModule, FacebookSdkModule, FbPosMasterRepositoryModule, LockModule],
    providers: [
        AutoSendMessageShippingStatusService,
        AutoAnswerCommentByInboxService,
        AutoAnswerCommentByInboxInstagramService,
        AutoSendMessageCreateOrderService,
        AutoSendMessageFollowLivestreamScript,
        AutoSendMessageTemplateService
    ],
})
export class AutoSendMessageModule {
}
