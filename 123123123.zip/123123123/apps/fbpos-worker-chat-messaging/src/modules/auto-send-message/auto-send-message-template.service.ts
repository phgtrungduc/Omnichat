import { RabbitSubscribe } from "@golevelup/nestjs-rabbitmq";
import { FacebookResponseException, KvBaseException, KvLogger, RabbitMqConfigAutoSendMessageTemplate, SocialTypes } from "@kiotviet-facebook-services/common";
import {
    WebhookSubscriptionDocument,
    WebhookSubscriptionRepository
} from "@kiotviet-facebook-services/fbpos-master-repository";
import { CACHE_MANAGER } from "@nestjs/cache-manager";
import { Inject, Injectable } from "@nestjs/common";
import { IAutoMessageTemplateButton, IMetaDataPayload } from "./interface/message-create-order-payload.interface";
import { pick } from 'lodash';
import {
    FacebookMessageService,
    IButtonMessageFacebook,
    MessageSendTypes
} from "@kiotviet-facebook-services/facebook-sdk";
import { createHash } from 'crypto';
import { IKvLogInput } from "libs/shared/common/src/lib/logger/interfaces/logger.interface";

const config = require('config');

@Injectable()
export class AutoSendMessageTemplateService {
    prefixLog = (functionName: string) => this._logger.getPrefixLog(this.constructor.name, functionName);

    private readonly _orderShoppingOnlineUrl;
    private readonly _secretKeyHash;

    constructor(
        @Inject(CACHE_MANAGER) private readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _facebookMessageService: FacebookMessageService,
        private readonly _webhookSubscriptionRepository: WebhookSubscriptionRepository) {
        this._orderShoppingOnlineUrl = config.get('orderShoppingOnline')?.url;
        this._secretKeyHash = config.get('orderShoppingOnline')?.secretKey || '123ABCdef!@#';
    }

    @RabbitSubscribe({
        exchange: config.get('rabbitMQ').mainExchange,
        routingKey: RabbitMqConfigAutoSendMessageTemplate.ROUTING_KEY,
        queue: `fbpos-worker-chat-messaging:${RabbitMqConfigAutoSendMessageTemplate.QUEUE_NAME}`,
        queueOptions: {
            durable: true,
            arguments: { 'x-queue-type': 'quorum' },
        },
    })
    private async _handleAutoSendMessageTemplate(payload: IAutoMessageTemplateButton) {
        const prefixLog = this.prefixLog('_handleAutoSendMessageTemplate');
        const { PageId, FbUserId, Content, Metadata, RetailerId, RetailerCode } = payload;
        const logInput: IKvLogInput = {
            MessageTemplate: { payload },
            Properties: {
                'Kv.RetailerCode': RetailerCode,
                'Kv.RetailerId': RetailerId,
                'Kv.SocialId': payload?.PageId,
                'Kv.SocialType': SocialTypes.FACEBOOK,
                SourceContext: prefixLog,
                _startTime: Date.now()
            }
        }
        try {
            this._logger.info(logInput, `${prefixLog} received payload`);

            if (!Content || !PageId) {
                return Promise.resolve();
            }
            const socialInfo = await this._webhookSubscriptionRepository.getSubscriptionBySocialId(PageId);
            if (!socialInfo) {
                return Promise.resolve();
            }
            const { AccessToken: access_token } = socialInfo;

            const text = Content;
            const metadata = this._getMetadata(RetailerId, Metadata);
            if (Metadata.OrderCode || Metadata.InvoiceCode) {
                await this._sendMessageTemplateWithOrderButton(payload, socialInfo, text, metadata);
            } else {
                await this._sendNormalMessage(FbUserId, metadata, text, access_token);
            }

            this._logger.info(logInput, `${prefixLog} success`);

            return Promise.resolve();
        } catch (error) {
            this._logger.error({ ...logInput, Error: new FacebookResponseException(error.stack, { cause: error }) }, `${prefixLog} fail`);
        }
        return Promise.resolve();
    }

    private _sendNormalMessage(fbUserId: string, metadata: string, text: string, access_token: string) {
        const detail = {
            metadata,
            text
        };
        return this._facebookMessageService.sendMessage({
            messaging_type: MessageSendTypes.RESPONSE,
            recipient: { id: fbUserId },
            message: JSON.stringify(detail),
            access_token: access_token
        });
    }

    private async _sendMessageTemplateWithOrderButton(payload: IAutoMessageTemplateButton,
        socialInfo: WebhookSubscriptionDocument,
        text: string,
        metadata = '') {
        const { FbUserId, Metadata, RetailerCode } = payload;
        const { OrderCode, InvoiceCode } = Metadata;
        const isAddDomainToWhiteList = await this._checkDomainAddedInWhiteList(socialInfo, this._orderShoppingOnlineUrl);

        const code = OrderCode || InvoiceCode;
        const key = `key_access_${this._secretKeyHash}_${code}_${RetailerCode}`;
        const hashKey = this._encryptKeySHA256Hash(key);
        const url = `${this._orderShoppingOnlineUrl}/shopping-online/${InvoiceCode ? 'invoices' : 'orders'}/detail?code=${code}&retailer=${RetailerCode}&key=${hashKey}`;

        const paramMessage = {
            access_token: socialInfo.AccessToken,
            recipient: {
                id: FbUserId
            },
            message: {
                metadata,
                buttons: [
                    {
                        type: 'web_url',
                        url: url,
                        title: "Xem đơn hàng",
                        ...isAddDomainToWhiteList && { messenger_extensions: true }
                    } as IButtonMessageFacebook
                ],
                text: text,
                access_token: socialInfo.AccessToken
            }
        };
        await this._facebookMessageService.sendPrivateMessageWithButton(paramMessage);
    }

    private async _checkDomainAddedInWhiteList(webhookSubscription: WebhookSubscriptionDocument, shoppingOnlineDomain: string) {
        try {
            if (webhookSubscription.WhitelistedDomains?.find(x => x == shoppingOnlineDomain)) {
                return true;
            }
            const { AccessToken } = webhookSubscription;
            const messageProfile = (await this._facebookMessageService.getWhitelistedDomainsPage(AccessToken))?.data;
            const whitelistUpdate = messageProfile?.length ? messageProfile[0].whitelisted_domains : [];

            if (whitelistUpdate.find(x => x.includes(shoppingOnlineDomain))) {
                await this._webhookSubscriptionRepository.updateOne({
                    _id: webhookSubscription._id
                }, { WhitelistedDomains: whitelistUpdate });

                return true;
            }
            whitelistUpdate.push(shoppingOnlineDomain);
            await this._facebookMessageService.addDomainToWhitelistPage(whitelistUpdate, AccessToken);
            await this._webhookSubscriptionRepository.updateOne({
                _id: webhookSubscription._id
            }, { WhitelistedDomains: whitelistUpdate });
            return true;

        } catch (error) {
            const prefixLog = this.prefixLog('_checkDomainAddedInWhiteList');
            this._logger.error({ MessageTemplate: { webhookSubscription, shoppingOnlineDomain }, Error: error }, `${prefixLog} fail`);
        }

        return false;
    }

    private _getMetadata(RetailerId: string, Metadata: IMetaDataPayload) {
        return JSON.stringify({
            RetailerId,
            UserId: -1,
            UserName: 'KiotViet',
            SentAuto: 1,
            From: 'fbpos-worker-chat-messaging',
            ...Metadata
        });
    }

    private _encryptKeySHA256Hash(key: string): string {
        const chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const bytes = Buffer.from(key, 'utf8');

        const hash = createHash('sha256');
        hash.update(bytes);
        const hashBytes = hash.digest();

        const hash2 = new Array<string>(16);
        for (let i = 0; i < hash2.length; i++) {
            hash2[i] = chars[hashBytes[i] % chars.length];
        }

        return hash2.join('');
    }

}
