import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { CoreModule } from './core/core.module';
import { AutoSendMessageModule } from './modules/auto-send-message/auto-send-message.module';
import { AlertNotificationModule } from '@kiotviet-facebook-services/alert-notification';
import { CreateOrUpdateMessageModule } from './modules/create-or-update-message/create-or-update-message.module';
import { ConfigModule, ConfigService } from '@nestjs/config';

process.env['NODE_CONFIG_DIR'] = `${__dirname}/config/`;
const config = require('config');

@Module({
  imports: [
    CoreModule,
    ConfigModule.forRoot({
      isGlobal: true,
      load: [() => config],
    }),
    AutoSendMessageModule,
    CreateOrUpdateMessageModule,
    AlertNotificationModule,
    BullModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => config.get('bullQueue'),
    }),
  ],
  controllers: [],
  providers: [
  ],
})
export class AppModule { }
