import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';

import { KvStrategy } from './stragety/kv.strategy';

@Module({
  imports: [PassportModule],
  controllers: [],
  providers: [KvStrategy],
  exports: [KvStrategy],
})
export class KvAuthModule { }
