import { KvAuthGuard } from '../guards/auth.guard';
import {
  applyDecorators,
  createParamDecorator,
  ExecutionContext,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiUnauthorizedResponse } from '@nestjs/swagger';

export interface IRetailAuth {
  retailerId: number;
  userId: number,
  retailerCode?: string,
  authorization?: string
}

export function Auth() {
  return applyDecorators(
    UseGuards(KvAuthGuard),
    ApiBearerAuth(),
    ApiUnauthorizedResponse({ description: 'Unauthorized' })
  );
}

export const AuthData = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext) => {
    const request = ctx.switchToHttp().getRequest();
    const { retailerId, userId, retailerCode = '' } = request.kvretail;
    return {
      retailerId: retailerId,
      userId: userId,
      retailerCode: retailerCode,
      authorization: request.headers['authorization']
    };
  }
);
