import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';
import * as jwt from 'jsonwebtoken';
import { Strategy } from 'passport-http-bearer';
import { Buffer } from 'buffer';

interface KvPayload {
  kvbid: number;
  kvrcode: string;
  kvrgid: number;
  kvrid: number;
  kvrindid: number;
  kvses: string;
  kvuact: string;
  kvuadmin: string;
  kvuid: number;
  kvulimit: string;
  kvulimittrans: string;
  kvurid: number;
  kvushowsum: string;
  kvutype: number;
  perms: string;
  preferred_username: string;
  roles: string[];
  sub: number;
}

@Injectable()
export class KvStrategy extends PassportStrategy(Strategy, 'kvjwt') {
  rsaPublicKey: any;
  hmacKey: any;
  privateKey: any;
  constructor(private readonly configService: ConfigService) {
    super();
    const kvJwt = configService.get('kvJwt');
    this.rsaPublicKey = kvJwt?.publicKey;
    this.hmacKey = kvJwt?.authKeyBase64;
    this.privateKey = kvJwt?.privateKey;
  }

  private async jwtAuth(token: string): Promise<KvPayload> {
    const decoded: any = jwt.decode(token, { complete: true });
    const algorithm = decoded.header.alg;
    const key = algorithm === 'HS256' ? Buffer.from(this.hmacKey, 'base64') : this.rsaPublicKey;
    return jwt.verify(
      token,
      key,
      { algorithms: [algorithm] },
      (err, payload) => {
        if (err) {
          console.error(err);
          return Promise.reject(err);
        }
        return Promise.resolve(payload as KvPayload);
      }
    );
  }

  private jweAuth(
    jweEncKeyBase64Url,
    ivBase64Url,
    cipherTextBase64Url
  ): KvPayload {
    const iv = Buffer.from(ivBase64Url, 'base64');
    const jweEncKey = Buffer.from(jweEncKeyBase64Url, 'base64');

    const cryptAuthKeys256 = crypto.privateDecrypt(this.privateKey, jweEncKey);
    const cryptKey = cryptAuthKeys256.subarray(16, 32);

    const decipher = crypto.createDecipheriv('aes-128-cbc', cryptKey, iv);
    let decrypted = decipher.update(cipherTextBase64Url, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return JSON.parse(decrypted);
  }

  public async validate(token) {
    const tokenParts = token.split('.');
    const tokenPartNumber = tokenParts.length;
    try {
      let kvPayload: KvPayload;
      if (tokenPartNumber === 3) {
        kvPayload = await this.jwtAuth(token);
      } else if (tokenPartNumber === 5) {
        kvPayload = this.jweAuth(tokenParts[1], tokenParts[2], tokenParts[3]);
      }

      if (kvPayload?.kvurid || kvPayload?.kvrid) {
        const retailerId = kvPayload?.kvurid || kvPayload?.kvrid;
        const userId = kvPayload?.kvuid || kvPayload?.sub;
        const retailerCode = kvPayload?.kvrcode || '';
        return { retailerId, userId, retailerCode };
      }
    } catch (e) {
      // not thing
    }

    throw new HttpException('Invalid bearer token', HttpStatus.UNAUTHORIZED);
  }
}
