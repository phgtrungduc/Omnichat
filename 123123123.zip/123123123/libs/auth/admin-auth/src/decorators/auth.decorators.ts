import { KvAuthGuard } from '../guards/auth.guard';
import {
  applyDecorators,
  createParamDecorator,
  ExecutionContext,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiUnauthorizedResponse } from '@nestjs/swagger';

export interface RetailAuth {
  RetailerId: number;
  UserId: number,
  RetailerCode?: string,
}

export function Auth() {
  return applyDecorators(
    UseGuards(KvAuthGuard),
    ApiBearerAuth(),
    ApiUnauthorizedResponse({ description: 'Unauthorized' })
  );
}

export const AuthData = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext) => {
    const request = ctx.switchToHttp().getRequest();
    const { retailerId, userId, retailerCode = '' } = request.kvretail;
    return {
      RetailerId: retailerId,
      UserId: userId,
      RetailerCode: retailerCode
    };
  }
);
