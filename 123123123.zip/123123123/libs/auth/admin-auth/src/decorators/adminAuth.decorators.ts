import { AdminAuthGuard } from '../guards/adminAuth.guard';
import { applyDecorators, UseGuards } from '@nestjs/common';
import { ApiBasicAuth, ApiUnauthorizedResponse } from '@nestjs/swagger';

export function AdminAuth() {
  return applyDecorators(
    UseGuards(AdminAuthGuard),
    ApiBasicAuth(),
    ApiUnauthorizedResponse({ description: 'Unauthorized' }),
  );
}
