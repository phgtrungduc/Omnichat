import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';

import { KvStrategy } from './stragety/kv.strategy';
import { AdminStrategy } from './stragety/admin.strategy';

@Module({
  imports: [PassportModule],
  controllers: [],
  providers: [KvStrategy, AdminStrategy],
  exports: [KvStrategy],
})
export class KvAuthModule {}
