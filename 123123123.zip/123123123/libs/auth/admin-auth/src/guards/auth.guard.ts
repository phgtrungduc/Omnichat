import { AuthGuard as NestAuthGuard } from '@nestjs/passport';

export class KvAuthGuard extends NestAuthGuard('kvjwt') {
  getAuthenticateOptions() {
    return {
      property: 'kvretail',
    };
  }
}
