import { AuthGuard as NestAuthGuard } from '@nestjs/passport';

export class AdminAuthGuard extends NestAuthGuard('admin') {
  getAuthenticateOptions() {
    return { property: 'admin' };
  }
}
