import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ConfigService } from '@nestjs/config';
import { BasicStrategy as Strategy } from 'passport-http';


@Injectable()
export class AdminStrategy extends PassportStrategy(Strategy, 'admin') {
  private readonly basicAuth;
  constructor(
    private readonly configService: ConfigService,
  ) {
    super();
    this.basicAuth = this.configService.get('basicAuth');
  }

  async validate(username, password): Promise<boolean> {
    if (!this.basicAuth?.username || !this.basicAuth?.password) {
      throw new UnauthorizedException();
    }

    if (
      this.basicAuth.username === username &&
      this.basicAuth.password === password
    ) {
      return true;
    }

    throw new UnauthorizedException();
  }
}
