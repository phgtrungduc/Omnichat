import { CACHE_KEYS } from '@kiotviet-facebook-services/cache';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject, Injectable } from '@nestjs/common';
import { Cache } from 'cache-manager';
import { FbLiveStreamScriptRepository } from '../repositories';
import { MongodbGroupService } from './mongodb-group.service';
import { KvCreateIndexMongoException, KvLogger, SocialTypes, } from '@kiotviet-facebook-services/common';
import { Types } from 'mongoose';

@Injectable()
export class FbLivestreamScriptService {
    constructor(
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly fbLiveStreamScriptRepository: FbLiveStreamScriptRepository
    ) {
    }

    private async createIndexForVideoId(pageId: string) {
        const prefixLog = this._logger.getPrefixLog(
            this.constructor.name,
            'createIndexForVideoId'
        )
        try {
            if (pageId) {
                const db = await this._mongodbGroupService.getDatabase({
                    socialId: pageId,
                }, true);
                const pageIdColl = db.collection(pageId);
                const indexesColl = await pageIdColl.indexInformation();

                if (
                    indexesColl['videoId_-1_IsValidateFormula_1_TimeStamp_-1'] ===
                    undefined
                ) {
                    await pageIdColl.createIndex(
                        { videoId: -1, IsValidateFormula: 1, TimeStamp: -1 },
                        { background: true, sparse: true }
                    );
                    ;
                    this._logger.info({ MessageTemplate: { pageId }, Properties: { 'Kv.SocialId': pageId, 'Kv.SocialType': SocialTypes.FACEBOOK, SourceContext: prefixLog } }, `${prefixLog} success`);
                }
            }
        } catch (error: any) {
            this._logger.error({ MessageTemplate: { pageId }, Error: new KvCreateIndexMongoException(error.stack) }, `${prefixLog} fail`);
        }
    }

    private setCacheAfterQueryDb(data: any) {
        if (data?.retailerId) {
            if (data?.livestreamId) {
                this._cache.set(
                    `${CACHE_KEYS.LIVESTREAM_SCRIPT.CONFIG}${data.livestreamId}`,
                    data,
                    CACHE_KEYS.LIVESTREAM_SCRIPT.TTL
                );
            }

            if (data?.videoId) {
                this._cache.set(
                    `${CACHE_KEYS.LIVESTREAM_SCRIPT.CONFIG}${data.videoId}`,
                    data,
                    CACHE_KEYS.LIVESTREAM_SCRIPT.TTL
                );
            }
        }
    }

    public async updateFbLivestreamScript(
        retailerId: number,
        retailerCode: string,
        data: any
    ) {
        try {
            let filter: any = {};
            if (data._id) {
                filter._id = data._id;
            } else if (data.livestreamId && data.videoId) {
                // Lưu và kết nối
                filter = {};
            } else if (data.livestreamId || data.videoId) {
                if (data.livestreamId) {
                    filter.livestreamId = data.livestreamId;
                }
                if (data.videoId) {
                    filter.videoId = data.videoId;
                }
            }

            if (data.id) {
                delete data.id;
            }
            if (data.deleted) {
                delete data.deleted;
            }

            // update document
            if (filter && Object.keys(filter).length) {
                if (data.createdTime) {
                    delete data.createdTime;
                }
                if (data._id) {
                    delete data._id;
                }

                if (filter._id) {
                    filter._id = new Types.ObjectId(filter._id);
                }

            } else {
                // create new document
                const countDoc =
                    await this.fbLiveStreamScriptRepository.countFbLivestreamScript({
                        retailerId,
                    });
                if (typeof countDoc !== 'number') {
                    return { error: 'Có lỗi xảy ra' };
                }
                data.id = countDoc + 1;
                data._id = new Types.ObjectId();
                data.retailerId = retailerId;
                data.retailerCode = retailerCode;
                data.createdTime = Date.now();
                data.deleted = 0;
                if (data.livestreamId && data.videoId) {
                    data.status = 2; // Đang diễn ra
                } else {
                    data.status = 1; // Lên lịch
                }
                filter._id = data._id;
            }

            const result =
                await this.fbLiveStreamScriptRepository.updateOneFbLivestreamScript(
                    filter,
                    data,
                    { upsert: true, new: true }
                );

            // create index for video id
            this.createIndexForVideoId(data.pageId);
            this.setCacheAfterQueryDb(result);

            return { data: result };
        } catch (error) {
            return { error };
        }
    }

    public async getFbLivestreamScript(retailerId: string | number, filter: any) {
        try {
            let cacheKey = '';
            if (retailerId) {
                filter.retailerId = retailerId;
            }

            if (filter.livestreamId) {
                cacheKey = `${CACHE_KEYS.LIVESTREAM_SCRIPT.CONFIG}${filter.livestreamId}`;
                const cache = (await this._cache.get(cacheKey)) as any;
                if (cache) {
                    return retailerId ? { data: cache } : cache;
                }
            }
            if (filter.videoId) {
                cacheKey = `${CACHE_KEYS.LIVESTREAM_SCRIPT.CONFIG}${filter.videoId}`;
                const cache = (await this._cache.get(cacheKey)) as any;
                if (cache) {
                    return retailerId ? { data: cache } : cache;
                }
            }
            const livestreamScriptConfig =
                await this.fbLiveStreamScriptRepository.getFbLivestreamScript(filter);
            this.setCacheAfterQueryDb(livestreamScriptConfig);

            return retailerId
                ? { data: livestreamScriptConfig || {} }
                : livestreamScriptConfig;
        } catch (error) {
            return { error };
        }
    }

    public async listFbLivestreamScript(retailerId: number, filter: any) {
        try {
            const conditions: any = {};
            conditions.retailerId = retailerId;
            conditions.pageId = {
                $in: filter.pageIds.toString().split(','),
            };
            conditions.branchId = {
                $in: filter.branchIds.toString().split(','),
            };
            conditions.deleted = 0;
            conditions.createdTime = { $gte: filter.startTime, $lte: filter.endTime };
            if (filter.status) {
                conditions.status = filter.status;
            }
            const options = {
                sort: {
                    createdTime: -1,
                },
                limit: 10,
                skip: 0,
            };
            if (filter.limit) {
                options.limit = filter.limit;
            }
            if (filter.skip) {
                options.skip = filter.skip;
            }

            const [list, total] = await Promise.all([
                this.fbLiveStreamScriptRepository.listFbLivestreamScript(
                    conditions,
                    options
                ),
                this.fbLiveStreamScriptRepository.countFbLivestreamScript(conditions),
            ]);
            return { total, data: list };
        } catch (error) {
            return { error };
        }
    }

    public async deleteFbLivestreamScript(body: any) {
        const filter: any = {
            _id: body._id,
            status: {
                $in: [1, 3], // chỉ xóa trạng thái Đã lên lịch, Đã kết thúc
            },
        };
        const updateData = {
            deleted: 1,
        };
        const result =
            await this.fbLiveStreamScriptRepository.updateOneFbLivestreamScript(
                filter,
                updateData,
                { new: true }
            );

        if (result && result.deleted) {
            return { data: result };
        }

        if (result === null) {
            return { error: 'Chỉ xóa được livestream có trạng thái đã lên lịch' };
        }

        return { error: 'Có lỗi xảy ra' };
    }

    public async setEndLivestreamScript(livestreamId: string | number) {
        try {
            const result =
                await this.fbLiveStreamScriptRepository.updateOneFbLivestreamScript(
                    { livestreamId },
                    { $set: { status: 3, endedTime: +new Date() } },
                    { new: true }
                );

            if (result) {
                this.setCacheAfterQueryDb(result);
            }

            return { data: result };
        } catch (error) {
            return { error: 'Có lỗi xảy ra' };
        }
    }

    public async setStartLivestreamScript(
        videoId: string | number,
        livestreamId: string | number
    ) {
        try {
            const result =
                await this.fbLiveStreamScriptRepository.updateOneFbLivestreamScript(
                    { videoId },
                    { $set: { livestreamId } },
                    { new: true, upsert: true }
                );

            return { data: result };
        } catch (error) {
            return { error: 'Có lỗi xảy ra' };
        }
    }

    clearCacheScript(id: any) {
        return this._cache.del(`${CACHE_KEYS.LIVESTREAM_SCRIPT.CONFIG}${id}`);
    }
}
