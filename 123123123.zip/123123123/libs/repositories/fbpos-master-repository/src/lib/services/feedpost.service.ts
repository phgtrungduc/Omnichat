import { Inject, Injectable } from '@nestjs/common';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { FeedPostRepository } from '../repositories';
import { FeedPost } from '../schemas';

@Injectable()
export class FeedPostService {
  constructor(
    @Inject(CACHE_MANAGER) readonly _cache: Cache,
    private readonly feedPostRepository: FeedPostRepository,
  ) {
  }

  async getListByPageIds(queryParams: any): Promise<FeedPost[]> {
    const skip = queryParams && queryParams.skip || 0;
    const limit = Math.min(queryParams && queryParams.limit || 20, 1000); // Protect system from heavy loading
    const sort = queryParams && queryParams.sort || { createdTime: -1 };
    const conditions = queryParams && queryParams.find || {};
    const selectedKeys = (queryParams && queryParams.selectedKeys) 
    || { createdTime: 1, message: 1, pageId: 1, statusType: 1, _id: 1,  };

    try {
      const result = await this.feedPostRepository.find(conditions, {
        selectedKeys: selectedKeys,
        sort: sort,
        skip,
        limit,
      });
      return result;
    } catch (err) {
      return Promise.reject(err);
    }
  }
}
