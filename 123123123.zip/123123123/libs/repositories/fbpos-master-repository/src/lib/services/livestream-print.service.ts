import { KvLogger } from "@kiotviet-facebook-services/common";
import { CACHE_MANAGER, Cache } from "@nestjs/cache-manager";
import { Inject, Injectable } from "@nestjs/common";
import { MongodbGroupService } from "./mongodb-group.service";
import { LivestreamPrintRepository } from "../repositories";
import { LivestreamPrintDocument } from "../schemas";

@Injectable()
export class LivestreamPrintService {
    constructor(
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _livestreamPrintRepository: LivestreamPrintRepository
      ) {
      }
    
    findByUserUniqueId(userUniqueId: string): Promise<LivestreamPrintDocument | null> {
        return this._livestreamPrintRepository.findOne({ userUniqueId: userUniqueId });
    }
}
