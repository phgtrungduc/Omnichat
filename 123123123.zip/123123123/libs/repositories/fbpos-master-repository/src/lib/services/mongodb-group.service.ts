import { CACHE_KEYS } from "@kiotviet-facebook-services/cache";
import { KvLogger, KvNotFoundSubscriptionException } from "@kiotviet-facebook-services/common";
import { RedisLockService, REDLOCK_CONST } from '@kiotviet-facebook-services/lock';
import { Cache, CACHE_MANAGER } from "@nestjs/cache-manager";
import { Inject, Injectable } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { ConnectOptions } from "mongoose";
import { WebhookSubscriptionRepository } from "../repositories";

const mongoose = require('mongoose');

interface IDbGroup {
    group: string;
    url: string;
    dbname: string;
    options?: ConnectOptions;
}

interface IGetDBGroupParam {
    socialId?: string;
    group?: string;
    type?: string;
}

@Injectable()
export class MongodbGroupService {

    private _globalConnection: { [key: string]: any } = {};
    private _dbgroups: IDbGroup[];

    constructor(private readonly _configService: ConfigService,
        private readonly _webhookSubscription: WebhookSubscriptionRepository,
        private readonly _redlockService: RedisLockService,
        private readonly _logger: KvLogger,
        @Inject(CACHE_MANAGER) readonly _cache: Cache) {
        this._dbgroups = this._configService.get('dbGroupsRepository') as IDbGroup[];
    }

    tiktokConversationDetailsCollName = 'tiktok_conversation_details';
    productCatalogsCollName = 'product_catalogs';

    async getDatabase(params: IGetDBGroupParam, usePrimaryPreferred = false) {
        try {
            let group: string | undefined;

            group = params && params.group;
            if (params && params.socialId) {
                params.socialId = params.socialId.trim();
                const cachedValue = await this._cache.get(`${CACHE_KEYS.DATABASE_GROUP.GROUP.NAME}${params.socialId}`);
                if (cachedValue) {
                    group = `${cachedValue}`;
                } else {
                    const subscription = await this._webhookSubscription.findOne({
                        $or: [
                            { PageId: params.socialId },
                            { InstagramId: params.socialId },
                        ],
                    });
                    if (!subscription || (!subscription.PageId && !subscription.InstagramId)) {
                        throw new KvNotFoundSubscriptionException(`subscription not found page: ${params.socialId}`);
                    }
                    group = subscription.Group || this._dbgroups[0].group;
                    await this._cache.set(`${CACHE_KEYS.DATABASE_GROUP.GROUP.NAME}${params.socialId}`, group, { ttl: CACHE_KEYS.DATABASE_GROUP.GROUP.TTL } as any);
                }
            }
            if (group) {
                group = `${group}`;
            } else if (params.type === 'tiktok') {
                group = params.type;
            } else {
                group = "master";
            }
            return this._getDbGroupConnection(group, usePrimaryPreferred);
        } catch (error) {
            const isKvNotFoundSubscriptionException = (error as any)?.ExceptionType === 'KvNotFoundSubscriptionException';
            if (isKvNotFoundSubscriptionException) throw error;
            throw new Error(error as any);
        }
    }

    getAllGroup() {
        return this._dbgroups
            .filter(item => !['tiktok', '1', '6', '7'].includes(item.group))
            .map(item => item.group);
    }

    private _getDbGroupConnection(group: string, usePrimaryPreferred = false) {
        if (this._globalConnection[group]) {
            return this._globalConnection[group];
        }
        return this._createConnection(group, usePrimaryPreferred);
    }

    private async _createConnection(group: string, usePrimaryPreferred = false) {
        const foundConfig = this._dbgroups.find(db => db.group === group);
        if (foundConfig) {
            const lock = await this._redlockService.acquire(
                [`${REDLOCK_CONST.LOCK_KEYS.CONNECT_MONGODB_GROUP}${group}`],
                3000,
                {},
            );
            const defaultOptions = {
                maxPoolSize: 1,
                autoIndex: false,
                // TODO
                // waitQueueTimeoutMS: Number.MAX_VALUE,
                connectTimeoutMS: 5000,
                socketTimeoutMS: 60000,
                // reconnectTries: Number.MAX_VALUE,
                // autoReconnect: true,
                // reconnectInterval: 10 * 1000,
            };

            const connection = await mongoose.createConnection(foundConfig.url, {
                ...defaultOptions,
                ...foundConfig.dbname && { dbName: foundConfig.dbname },
                ...(foundConfig.options || {}),
                ...usePrimaryPreferred && { readPreference: 'primaryPreferred' }
            });
            const db = connection.getClient().db(foundConfig.dbname);
            this._globalConnection[group] = db;

            await this._redlockService.release(lock);
            return db;
        }

        return null;
    }

}
