import { AlertNotificationService } from '@kiotviet-facebook-services/alert-notification';
import {
  KvConnectMongoDbException,
  KvLogger,
  KvResponseMongoDbException,
} from '@kiotviet-facebook-services/common';
import { Injectable } from '@nestjs/common';
import { getDbNameSocialConversation } from '../helpers';
import {
  IAddQuoteIntoMessageDetailParams,
  IGetConversationParams,
  IGetMessagesParams,
} from '../interface';
import { MongodbGroupService } from './mongodb-group.service';

@Injectable()
export class ConversationService {
  constructor(
    private readonly _logger: KvLogger,
    private readonly _mongodbGroupService: MongodbGroupService,
    private readonly alertNotificationService: AlertNotificationService
  ) { }

  getUnreadConversations(params: IGetConversationParams) {
    params.moreFilters = [...params.moreFilters, { State: 0 }];

    return this.getConversations(params);
  }

  getConversations(params: IGetConversationParams) {
    const functionName = `getConversations`;
    const { socialId, projection, moreFilters, limit } = params;
    const defaultProjection = {
      _id: 1,
      PageId: 1,
      InstagramId: 1,
      Type: 1,
      TimeStamp: 1,
    };
    const mergedProjection = Object.assign(
      {},
      defaultProjection,
      projection || {}
    );

    return new Promise((resolve, reject) => {
      const filter: any = [];
      filter.push({
        $or: [{ Type: 'messenger' }, { Type: 'feed' }],
      });

      // add filters from params
      if (moreFilters && moreFilters.length > 0) {
        moreFilters.forEach((f: any) => filter.push(f));
      }
      
      

      this._mongodbGroupService
        .getDatabase({ socialId })
        .then((db) => {
          try {
            let query = db
              .collection(getDbNameSocialConversation(socialId))
              .find({
                $and: filter,
              })
              .project(mergedProjection);

            if (limit) {
              query = query.sort({ TimeStamp: -1 }).limit(limit);
            }

            //change logic to use promise instead of callback to avoid hanging
            query.toArray()
              .then((docs: any) => {
                resolve(docs);
              })
              .catch((err: any) => {
                const prefixLog = this._logger.getPrefixLog(
                  this.constructor.name,
                  functionName
                );
                this._logger.error({ MessageTemplate: { params }, Error: new KvResponseMongoDbException(err.stack) }, `${prefixLog} fail`);

                this.alertNotificationService.send(
                  '[ALERT] getUnreadConversations db.collection toArray',
                  { message: err.message, error: err }
                );
                reject({
                  status: 'error',
                  message: err.message,
                  stack: err.stack,
                });
              });
          } catch (error: any) {
            const prefixLog = this._logger.getPrefixLog(
              this.constructor.name,
              functionName
            );
            this._logger.error({ MessageTemplate: { params }, Error: new KvResponseMongoDbException(error.stack) }, `${prefixLog} fail`);
            this.alertNotificationService.send(
              '[ALERT] getUnreadConversations db.collection project',
              { message: error && error.message, error: error }
            );
            reject({
              status: 'error',
              message: error && error.message,
              error: error,
            });
          }
        })
        .catch((error) => {
          const prefixLog = this._logger.getPrefixLog(
            this.constructor.name,
            functionName
          );
          this._logger.error({ MessageTemplate: { params }, Error: new KvConnectMongoDbException(error.stack) }, `${prefixLog} fail`);
          this.alertNotificationService.send(
            '[ALERT] getUnreadConversations mongoDbConnectionPool.get project',
            { message: error && error.message, error: error }
          );
          reject({
            status: 'error',
            message: error && error.message,
            error: error,
          });
        });
    });
  }

  async getMessages(
    params: IGetMessagesParams = { socialId: '', limit: 1000 }
  ) {
    const { socialId, moreFilters, limit } = params;
    const db = await this._mongodbGroupService.getDatabase(params);

    let filters = [];
    filters.push({
      $or: [{ Field: 'messenger' }, { Field: 'feed' }],
    });
    filters = filters.concat(moreFilters || []);
    const sort = { TimeStamp: 1 };

    return await db
      .collection(socialId)
      .find({ $and: filters })
      .project({
        _id: 1,
        GroupId: 1,
        PageId: 1,
        TimeStamp: 1,
        Field: 1,
        SenderId: 1,
      })
      .sort(sort) // slow query
      .limit(limit)
      .toArray();
  }

  async addQuoteIntoMessageDetail(
    params: IAddQuoteIntoMessageDetailParams
  ) {
    const { socialId, messageId, quote } = params;
    const db = await this._mongodbGroupService.getDatabase(params);
    await db
      .collection(socialId)
      .updateOne(
        { _id: messageId },
        { $set: { Quote: quote } }
      );
  }

  getDetailById(socialId: string, id: string) {
    return this._mongodbGroupService.getDatabase({ socialId }).then((db) => {
      return db.collection(socialId).findOne({ _id: id });
    });
  }

  getById(socialId: string, id: string) {
    return this._mongodbGroupService.getDatabase({ socialId }).then((db) => {
      return db
        .collection(getDbNameSocialConversation(socialId))
        .findOne({ _id: id });
    });
  }

  async getMessagesByKeyword(socialId: string, keyword: string, limit = 1000) {
    const functionName = `getMessagesByKeyword`;
    
    try {
      const db = await this._mongodbGroupService.getDatabase({ socialId });
      
      // Sử dụng aggregation để tìm kiếm tin nhắn và join với conversation
      const results = await db.collection(socialId).aggregate([
        {
          $match: {
            $or: [
              { SenderName: { $regex: keyword, $options: 'i' } },
              { Message: { $regex: keyword, $options: 'i' } }
            ]
          }
        },
        {
          $sort: { TimeStamp: -1 }
        },
        {
          $limit: limit
        },
        {
          $lookup: {
            from: getDbNameSocialConversation(socialId),
            let: {
              conversationId: '$GroupId',
              pageId: '$PageId'
            },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$GroupId', '$$conversationId'] },
                      { $eq: ['$PageId', '$$pageId'] }
                    ]
                  }
                }
              }
            ],
            as: 'Conversation'
          }
        },
        {
          $unwind: {
            path: '$Conversation',
            preserveNullAndEmptyArrays: true
          }
        }
      ]).toArray();

      return results;
    } catch (error: any) {
      const prefixLog = this._logger.getPrefixLog(
        this.constructor.name,
        functionName
      );
      this._logger.error({ 
        MessageTemplate: { socialId, keyword, limit }, 
        Error: new KvResponseMongoDbException(error.stack) 
      }, `${prefixLog} fail`);

      this.alertNotificationService.send(
        '[ALERT] getMessagesByKeyword aggregation',
        { message: error.message, error: error }
      );
      
      throw {
        status: 'error',
        message: error.message,
        stack: error.stack,
      };
    }
  }
}
