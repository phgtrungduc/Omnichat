import { KvLogger, } from '@kiotviet-facebook-services/common';
import { Inject, Injectable } from '@nestjs/common';
import { MongodbGroupService } from './mongodb-group.service';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { FbCatalogUserTokenRepository, PageStaffRepository } from '../repositories';

@Injectable()
export class FbCatalogUserTokenService {
    constructor(
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _fbCatalogUserTokenRepository: FbCatalogUserTokenRepository,
    ) {
    }

    getLatestCatalogUserToken(retailerId: number, catalogId: string) {
        return this._fbCatalogUserTokenRepository.findOne({ retailerId, catalogId }, {  sort: { updatedAt: -1 },lean: true });
    }
}
