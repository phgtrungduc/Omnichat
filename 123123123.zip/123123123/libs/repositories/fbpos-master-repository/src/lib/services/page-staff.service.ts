import { KvLogger, } from '@kiotviet-facebook-services/common';
import { Inject, Injectable } from '@nestjs/common';
import { MongodbGroupService } from './mongodb-group.service';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { PageSettingsRepository, PageStaffRepository } from '../repositories';
import { PageSettings } from '../schemas';
import { getDbNameSocialConversation } from '../helpers';

@Injectable()
export class PageStaffService {
    constructor(
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _pageStaffRepository: PageStaffRepository,
        private readonly _pageSettingRepository: PageSettingsRepository,
    ) {
    }

    private toStaffId(userId: string): string {
        if (userId.indexOf("staff_") < 0) {
            return "staff_" + userId;
        }
        return userId;
    }

    getStaffs(pageId: string, otherConditions = {}) {
        let filter = Array.isArray(pageId) ? { pageId: { $in: pageId } } : { pageId };
        if (Object.keys(otherConditions).length !== 0) {
            filter = {
                ...filter,
                ...otherConditions,
            };
        }
        return this._pageStaffRepository.find(filter, { lean: true });
    }

    async assignStaff(pageId: string, staffId: string, conversationId: string, turn?: number): Promise<void> {
        try {
            // Get database connection
            const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });

            // Update conversation with staff assignment
            await db.collection(pageId + "_conversation")
                .updateOne(
                    { _id: conversationId },
                    {
                        $set: {
                            Staff: [staffId],
                            LastAssigned: Date.now()
                        }
                    }
                );

            // Update staff information
            const staffUpdate: any = { lastAssigned: Date.now() };
            if (turn) {
                staffUpdate.assignmentTurn = turn;
            }

            await this._pageStaffRepository.updateOne({ pageId, staffId }, { $set: staffUpdate });


        } catch (error: any) {
            this._logger.error(`Error assigning staff: ${error.message}`, error.stack);
            throw error;
        }
    }

    async unassign(pageId: string, staffId: string, conversationId: string) {
        const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });

        await db.collection(pageId + "_conversation")
            .updateOne({ _id: conversationId }, { $pull: { Staff: staffId } });
    }

    async setOffline(pageIds: string[], userId: string, socketId?: string): Promise<void> {
        const staffId = this.toStaffId(userId);
        const bulkOps = [];

        if (pageIds && pageIds.length) {
            for (const pageId of pageIds) {
                if (socketId) {
                    bulkOps.push({
                        updateOne: {
                            filter: { pageId, staffId },
                            update: { $pull: { socketIds: socketId } }
                        }
                    });
                } else {
                    bulkOps.push({
                        updateOne: {
                            filter: { pageId, staffId },
                            update: { $set: { socketIds: [] } }
                        }
                    });
                }
            }

            const db = await this._mongodbGroupService.getDatabase({ socialId: pageIds[0] });
            await db.collection('page_staff').bulkWrite(bulkOps);
        }
    }

    async setOnline(pageId: string, userId: string, socketId: string): Promise<void> {
        const staffId = this.toStaffId(userId);
        const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });

        await db.collection('page_staff')
            .updateOne(
                { pageId, staffId },
                { $addToSet: { socketIds: socketId } }
            );
    }

    async removeAssignedStaff(pageId: string, staffId: string): Promise<void> {
        const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });

        await db.collection(pageId + "_conversation")
            .updateMany({}, { $pull: { Staff: staffId } });
    }

    async removeStaff(pageId: string, staffId: string) {
        const pageSettings = await this._pageSettingRepository.find({ PageId: pageId, ConversationAssignment: { $exists: true } }, { limit: 1 });
        if (pageSettings && pageSettings.length > 0) {
            const conversationAssignment = pageSettings[0].ConversationAssignment as any;
            const data = {
                ...conversationAssignment,
                ReplyMessageStaff: (conversationAssignment.ReplyMessageStaff || []).filter((s: string) => s !== staffId),
                ReplyCommentStaff: (conversationAssignment.ReplyCommentStaff || []).filter((s: string) => s !== staffId),
            };
            return await this._pageSettingRepository.updateOne({ PageId: pageId }, {
                $set: {
                    _id: pageId,
                    PageId: pageId,
                    Timestamp: Date.now(),
                    $inc: { "Version": 1 },
                    ConversationAssignment: data
                }
            });
        }
        return false;
    }

    public async updatePageStaff(pageId: string, staffId: string, data: any) {
        return await this._pageStaffRepository.updateOne(
            { pageId, staffId },
            data
        );
    }

    async bulkUnassign(pageIds: string[], conversations: any[]): Promise<void> {
        try {
            if (pageIds && pageIds.length > 0) {
                for (const pageId of pageIds) {
                    const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
                    const conversationIds = (conversations || []).filter(c => c.PageId === pageId).map(c => c.Id);
                    const filter = {} as any;
                    if (conversationIds && conversationIds.length > 1) {
                        filter._id = { $in: conversationIds };
                    } else {
                        filter._id = conversationIds[0];
                    }
                    await db.collection(getDbNameSocialConversation(pageId))
                        .updateMany(
                            filter,
                            { $set: { Staff: [] } },
                        );
                }
            }
        } catch (error: any) {
            this._logger.error(`Error in bulkUnassign: ${error.message}`, error.stack);
            throw error;
        }
    }

    async bulkAssign(pageIds: string[], staffId: string, conversations: any[]): Promise<void> {
        try {
            if (pageIds && pageIds.length > 0) {
                for (const pageId of pageIds) {
                    const db = await this._mongodbGroupService.getDatabase({ socialId: pageId });
                    const conversationIds = (conversations || []).filter(c => c.PageId === pageId).map(c => c.Id);

                    await db.collection(pageId + "_conversation")
                        .updateMany(
                            { _id: { $in: conversationIds } },
                            { $set: { Staff: [staffId], LastAssigned: Date.now() } },
                        );

                    await this._pageStaffRepository.updateOne(
                        { pageId, staffId },
                        { $set: { lastAssigned: Date.now() } }
                    );
                }
            }
        } catch (error: any) {
            this._logger.error(`Error in bulkAssign: ${error.message}`, error.stack);
            throw error;
        }
    }
}
