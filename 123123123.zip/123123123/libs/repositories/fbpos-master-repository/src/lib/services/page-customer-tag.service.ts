import { Injectable } from '@nestjs/common';
import { PageCustomerTagRepository } from '../repositories/page-customer-tag.repository';
import { PageCustomerTagDocument } from '../schemas/page-customer-tag.schema';

@Injectable()
export class PageCustomerTagService {
  constructor(
    private readonly pageCustomerTagRepository: PageCustomerTagRepository,
  ) {}

  async findByCustomerTagId(pageId: string, customerTagIds: string[]): Promise<PageCustomerTagDocument[]> {
    return this.pageCustomerTagRepository.find({ pageId, customerTagId: { $in: customerTagIds } });
  }

} 