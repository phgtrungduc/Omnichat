import { KvLogger, } from '@kiotviet-facebook-services/common';
import { Inject, Injectable } from '@nestjs/common';
import { MongodbGroupService } from './mongodb-group.service';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { PageSettingsRepository } from '../repositories';

@Injectable()
export class PageSettingService {
    constructor(
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _pageSettingRepository: PageSettingsRepository,
    ) {
    }
}