import { KvLogger, } from '@kiotviet-facebook-services/common';
import { Inject, Injectable } from '@nestjs/common';
import { MongodbGroupService } from './mongodb-group.service';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { FbCatalogConnectionRepository } from '../repositories';
import { FbCatalogConnectionDocument } from "../schemas";

@Injectable()
export class FbCatalogConnectionService {
    constructor(
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _fbCatalogConnectionRepository: FbCatalogConnectionRepository,
    ) {
    }

    getCatalogConnection(retailerId: number, catalogId: string, pageId: string) {
        return this._fbCatalogConnectionRepository.findOne({
            retailerId,
            removed: false,
            catalogId,
            pageId
        }, {lean: true});
    }

    async getAllActivateCatalogConnection(limit = 1000) {
        const data: FbCatalogConnectionDocument[] = [];
        let skip = 0;
        let remaining = true;
        while (remaining) {
            const chunk = await this._fbCatalogConnectionRepository.find({removed: false}, {lean: true, skip, limit});
            if (chunk.length === 0) {
                remaining = false;
            } else {
                data.push(...chunk);
                skip += limit;
            }
        }
        return data;
    }
}
