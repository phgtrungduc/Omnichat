import { KvLogger, } from '@kiotviet-facebook-services/common';
import { Inject, Injectable } from '@nestjs/common';
import { MongodbGroupService } from './mongodb-group.service';
import { AlertNotificationService } from '@kiotviet-facebook-services/alert-notification';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { FbUserProfileRepository } from '../repositories';
import { CACHE_KEYS } from '@kiotviet-facebook-services/cache';
import { FbUserProfile } from '../schemas';

@Injectable()
export class FbUserProfileService {
    constructor(
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly fbUserProfileRepository: FbUserProfileRepository,
        private readonly alertNotificationService: AlertNotificationService
    ) {
    }

    public async handleUpdateFbUserProfile(profile: any, upsert = false) {
        try {
            if (profile.id) {
                profile.id = `${profile.id}`;
            }
            await this.fbUserProfileRepository.updateOne(
                {id: profile.id},
                profile,
                {upsert}
            );
            await this._cache.del(`${CACHE_KEYS.FB_USER_PROFILE.NAME}${profile.id}`);
            return Promise.resolve();
        } catch (err) {
            return Promise.reject(err);
        }
    }

    public async handleReadFbUserProfile(id: string) {
        try {
            if (id) {
                id = `${id}`;
            }

            const cacheKey = `${CACHE_KEYS.FB_USER_PROFILE.NAME}${id}`;
            const cache = (await this._cache.get(cacheKey)) as FbUserProfile;
            if (cache) {
                return Promise.resolve(cache);
            }

            let profile = await this.fbUserProfileRepository.findOne({id});
            if (profile) {
                profile = profile.toObject();
                profile.id = profile.id.toString();
                await this._cache.set(
                    cacheKey,
                    profile,
                    {ttl: CACHE_KEYS.FB_USER_PROFILE.TTL} as any
                );
            }

            return Promise.resolve(profile);
        } catch (err) {
            return Promise.reject(err);
        }
    }

    public async handleReadFbUserProfileList(ids: string[]) {
        try {
            const profiles = await this.fbUserProfileRepository.find({
                id: {$in: ids},
            });
            return Promise.resolve(profiles);
        } catch (err) {
            return Promise.reject(err);
        }
    }
}
