import { KvLogger, } from '@kiotviet-facebook-services/common';
import { Inject, Injectable } from '@nestjs/common';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { KvOrderErrorsRepository } from '../repositories';

@Injectable()
export class KvOrderErrorsService {
    constructor(
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _kvOrderErrorsRepository: KvOrderErrorsRepository
    ) {
    }

    async updateKvOrderError(kvOrderError: any, upsert = false) {
        try {

            const {_id} = kvOrderError;
            return Promise.resolve(await this._kvOrderErrorsRepository.updateOne(
                {_id},
                kvOrderError,
                {upsert, lean: true}
            ));
        } catch (err) {
            return Promise.reject(err);
        }
    }


}
