import { Inject, Injectable } from '@nestjs/common';
import { FbCartsRepository } from '../repositories';
import { CACHE_MANAGER, Cache } from '@nestjs/cache-manager';
import { CACHE_KEYS, createHashKeyFromObject } from '@kiotviet-facebook-services/cache';
import { FbCartsDocument } from '../schemas';

@Injectable()
export class FbCartsService {
  constructor(
    private readonly _fbCartsRepository: FbCartsRepository,
    @Inject(CACHE_MANAGER) readonly _cache: Cache
  ) { }

  async getTotalCustomerOrders(videoId: string | number) {
      try {
          return Promise.resolve(await this._fbCartsRepository.getTotalCartHasOrder(videoId));
      } catch (err) {
          return Promise.reject(err);
      }
  }

    async getTotalOrdersAndRevenue(videoId: string | number) {
        try {
            const limit = 1000;
            let skip = 0;
            let isRunning = true;
            let revenue = 0;
            let totalOrders = 0;
            while (isRunning) {
                const fbCarts = await this._fbCartsRepository.getFbCartsLivestream(
                    videoId,
                    undefined,
                    skip,
                    limit
                );
                const currentLength = fbCarts.length;
                skip += currentLength;
                isRunning = currentLength >= limit;
                if (currentLength > 0) {
                    fbCarts.forEach((cart) => {
                        totalOrders += (cart.kvOrders || []).filter(
                            (order) => order.kvOrderId && !order.kvOrderCode?.includes('HD')
                        ).length;

                        revenue += (cart.productInOrders || []).reduce((acc, item) => {
                            const productSum = item.Quantity * item.Price;
                            return acc + productSum;
                        }, 0);
                    });
                }
            }
            return Promise.resolve({ totalOrders, revenue });
        } catch (err) {
            return Promise.reject(err);
        }
    }

  async getRevenue(videoId: string | number) {
    try {
      const limit = 1000;
      let skip = 0;
      let isRunning = true;
      let revenue = 0;
      while (isRunning) {
        const fbCarts = await this._fbCartsRepository.getFbCartsLivestream(
          videoId,
          undefined,
          skip,
          limit
        );
        const currentLength = fbCarts.length;
        skip += currentLength;
        isRunning = currentLength >= limit;
        if (currentLength > 0) {
          fbCarts.forEach((cart) => {
            revenue += (cart.productInOrders || []).reduce((acc, item) => {
              const productSum = item.Quantity * item.Price;
              return acc + productSum;
            }, 0);

            revenue += (cart.products || []).reduce((acc, item) => {
              const productSum = item.Quantity * item.Price;
              return acc + productSum;
            }, 0);
          });
        }
      }
      return Promise.resolve(revenue);
    } catch (err) {
      return Promise.reject(err);
    }
  }

  async handleUpdateFbCart(cart: any, upsert = false) {
    try {
      const { fbUserId, videoId } = cart;

      await this._fbCartsRepository.updateOneFbCart({ fbUserId: `${fbUserId}`, videoId }, { $set: { ...cart } }, { upsert });
      const hash = await createHashKeyFromObject({ fbUserId, videoId });
      const cacheKey = `${CACHE_KEYS.FACEBOOK_CART.NAME}${hash}`;
      await this._cache.del(cacheKey);
      return Promise.resolve();
    } catch (err) {
      return Promise.reject(err);
    }
  }

  async handleReadFbCart(fbUserId: string, videoId: string) {
    try {
      const hash = await createHashKeyFromObject({ fbUserId, videoId });
      const cacheKey = `${CACHE_KEYS.FACEBOOK_CART.NAME}${hash}`;
      const cache = await this._cache.get(cacheKey) as FbCartsDocument;
      if (cache) {
        return Promise.resolve(cache);
      }
      let cart = await this._fbCartsRepository.readFbCart({ videoId, fbUserId: `${fbUserId}` });
      if (cart) {
        cart = cart.toObject();
        cart.fbUserId = cart.fbUserId.toString();
        await this._cache.set(cacheKey, cart, {ttl: CACHE_KEYS.FACEBOOK_CART.TTL} as any);
      }
      return Promise.resolve(cart);
    } catch (err) {
      return Promise.reject(err);
    }
  }

  async handleReadFbCartByCommentId(commentId: string, videoId: string) {
    try {
      let cart = await this._fbCartsRepository.readFbCart({ videoId, "products.Comments.CommentId": commentId });
      if (cart) {
        cart = cart.toObject();
        cart.fbUserId = cart.fbUserId.toString();
      }
      return Promise.resolve(cart);
    } catch (err) {
      return Promise.reject(err);
    }
  }

  async deleteOneFbCartById(_id: any) {
    try {
      await this._fbCartsRepository.deleteOneFbCart({ _id });
      return Promise.resolve();
    } catch (err) {
      return Promise.reject(err);
    }
  }
}
