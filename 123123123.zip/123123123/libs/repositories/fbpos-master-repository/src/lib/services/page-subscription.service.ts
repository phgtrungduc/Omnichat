import { KvBaseException, KvLogger } from '@kiotviet-facebook-services/common';
import { Inject, Injectable } from '@nestjs/common';
import { MongodbGroupService } from './mongodb-group.service';
import { PageSettingsRepository, WebhookSubscriptionRepository, } from '../repositories';
import { CACHE_KEYS } from '@kiotviet-facebook-services/cache';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { WebhookSubscriptionDocument } from '../schemas';

@Injectable()
export class PageSubscriptionService {
    private DEFAULT_PAGE_SETTINGS = { AllowSentMessageAfter24hours: true };

    constructor(
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly pageSettingsRepository: PageSettingsRepository,
        private readonly webhookSubscriptionRepository: WebhookSubscriptionRepository
    ) {
    }

    private async getPageSettingLegacy(socialId: string) {
        const subscription = await this.webhookSubscriptionRepository.find(
            { PageId: socialId, Setting: { $exists: true } },
            { sort: { TimeStamp: -1 }, limit: 1 }
        );

        return subscription && subscription.length > 0 && subscription[0].Setting;
    }

    private async getConversationAssignmentLegacy(socialId: string) {
        const subscription = await this.webhookSubscriptionRepository.find(
            { PageId: socialId, ConversationAssignment: { $exists: true } },
            { sort: { TimeStamp: -1 }, limit: 1 }
        );

        return (
            subscription &&
            subscription.length > 0 &&
            subscription[0].ConversationAssignment
        );
    }

    public async getPageSetting(socialId: string) {
        return await this.pageSettingsRepository.findOne({ _id: socialId });
    }

    public async updatePageSetting(socialId: string, data: any) {
        return await this.pageSettingsRepository.updateOne(
            { _id: socialId },
            data,
            { upsert: true }
        );
    }

    public async find(retailerId: number, pageId: string) {
        const subscription = await this.webhookSubscriptionRepository.findOne({
            _id: `${retailerId}_${pageId}`,
        });

        if (!subscription) {
            throw new Error('Invalid Subscription for RetailerId and PageId!');
        }

        const setting = await this.getPageSetting(subscription.PageId);
        subscription.Setting = setting && (setting.Setting as any);

        if (!subscription.Setting) {
            const legacy = await this.getPageSettingLegacy(subscription.PageId);

            if (legacy) {
                await this.updatePageSetting(subscription.PageId, {
                    _id: subscription.PageId,
                    PageId: subscription.PageId,
                    Timestamp: Date.now(),
                    $inc: { Version: 1 },
                    Setting: legacy,
                });
                subscription.Setting = legacy;
            } else {
                subscription.Setting = this.DEFAULT_PAGE_SETTINGS;
                await this.updatePageSetting(subscription.PageId, {
                    _id: subscription.PageId,
                    PageId: subscription.PageId,
                    Timestamp: Date.now(),
                    $inc: { Version: 1 },
                    Setting: this.DEFAULT_PAGE_SETTINGS,
                });
            }
        }

        subscription.Setting.ConversationAssignment =
            setting && setting.ConversationAssignment;
        if (!subscription.Setting.ConversationAssignment) {
            const legacy = await this.getConversationAssignmentLegacy(
                subscription.PageId
            );
            if (legacy) {
                await this.updatePageSetting(subscription.PageId, {
                    _id: subscription.PageId,
                    PageId: subscription.PageId,
                    Timestamp: Date.now(),
                    $inc: { Version: 1 },
                    ConversationAssignment: legacy,
                });
                subscription.Setting.ConversationAssignment = legacy;
            } else {
                subscription.Setting.ConversationAssignment = {};
            }
        }

        if (!subscription.Setting.hasOwnProperty('AllowSentMessageAfter24hours')) {
            subscription.Setting.AllowSentMessageAfter24hours = true;
        }
        subscription.Setting.LiveStreamFormula =
            (setting && setting.LiveStreamFormula) || {};

        return subscription;
    }

    public async getSubscriptionByPageId(pageId: string, ignoreCache = false) {
        try {
            if (ignoreCache) {
                return Promise.resolve(
                    this.webhookSubscriptionRepository.findOne(
                        { PageId: pageId, InstagramId: { $exists: false } },
                        { sort: { TimeStamp: -1 } }
                    )
                );
            }

            const key = `${CACHE_KEYS.PAGE_SUBSCRIPTION.NAME}${pageId}`;
            const cachedPageSubscription = await this._cache.get(key) as WebhookSubscriptionDocument;
            if (cachedPageSubscription) {
                return Promise.resolve(cachedPageSubscription);
            }
            const pageSubscription = await this.webhookSubscriptionRepository.findOne(
                {
                    PageId: pageId,
                    InstagramId: { $exists: false },
                },
                { sort: { TimeStamp: -1 } }
            );
            if (pageSubscription) {
                await this._cache.set(
                    key,
                    pageSubscription,
                    { ttl: CACHE_KEYS.PAGE_SUBSCRIPTION.TTL } as any
                );
            }

            return Promise.resolve(pageSubscription);
        } catch (err: any) {
            const prefixLog = this._logger.getPrefixLog(
                this.constructor.name,
                'getSubscriptionByPageId'
            );
            this._logger.error({ MessageTemplate: { pageId }, Error: new KvBaseException(err.stack) }, `${prefixLog} fail`);
            return Promise.reject(err);
        }
    }

    public async getSubscriptionBySocialId(
        socialId: string,
        ignoreCache = false
    ) {
        try {
            if (ignoreCache) {
                let result = await this.webhookSubscriptionRepository.findOne(
                    {
                        InstagramId: socialId,
                        IsRemoved: 0,
                    },
                    { sort: { TimeStamp: -1 } }
                );

                if (!result) {
                    result = await this.webhookSubscriptionRepository.findOne(
                        {
                            PageId: socialId,
                            IsRemoved: 0,
                            InstagramId: { $exists: false },
                        },
                        { sort: { TimeStamp: -1 } }
                    );
                }

                return Promise.resolve(result);
            }

            const key = `${CACHE_KEYS.PAGE_SUBSCRIPTION.NAME}${socialId}`;
            const cachedPageSubscription = await this._cache.get(key);
            if (cachedPageSubscription) {
                return Promise.resolve(cachedPageSubscription as WebhookSubscriptionDocument);
            }

            let pageSubscription = await this.webhookSubscriptionRepository.findOne(
                {
                    InstagramId: socialId,
                    IsRemoved: 0,
                },
                { sort: { TimeStamp: -1 } }
            );

            if (!pageSubscription) {
                pageSubscription = await this.webhookSubscriptionRepository.findOne(
                    {
                        PageId: socialId,
                        IsRemoved: 0,
                        InstagramId: { $exists: false },
                    },
                    { sort: { TimeStamp: -1 } }
                );
            }

            if (pageSubscription) {
                await this._cache.set(
                    key,
                    pageSubscription,
                    { ttl: CACHE_KEYS.PAGE_SUBSCRIPTION.TTL } as any
                );
            }

            return Promise.resolve(pageSubscription);
        } catch (err: any) {
            const prefixLog = this._logger.getPrefixLog(
                this.constructor.name,
                'getSubscriptionBySocialId'
            );
            this._logger.error({ MessageTemplate: { socialId }, Error: new KvBaseException(err.stack) }, `${prefixLog} fail`);
            return Promise.reject(err);
        }
    }

    public async getByPageId(pageId: string) {
        let subs = await this.webhookSubscriptionRepository.find({ PageId: pageId, IsRemoved: 0 });
        let setting = await this.getPageSetting(pageId);
        return subs.map(s => {
            s.Setting = setting && setting.Setting;
            return s;
        });
    }
}
