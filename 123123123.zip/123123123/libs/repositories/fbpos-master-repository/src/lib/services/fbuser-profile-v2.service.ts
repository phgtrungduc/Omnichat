import { KvLogger, } from '@kiotviet-facebook-services/common';
import { Inject, Injectable } from '@nestjs/common';
import { MongodbGroupService } from './mongodb-group.service';
import { Cache, CACHE_MANAGER } from '@nestjs/cache-manager';
import { FbUserProfileV2Repository } from '../repositories';
import { CACHE_KEYS } from '@kiotviet-facebook-services/cache';
import { FbUserProfileV2 } from '../schemas';

@Injectable()
export class FbUserProfileV2Service {
    constructor(
        @Inject(CACHE_MANAGER) readonly _cache: Cache,
        private readonly _logger: KvLogger,
        private readonly _mongodbGroupService: MongodbGroupService,
        private readonly _fbUserProfileV2Repository: FbUserProfileV2Repository,
    ) {
    }

    buildCacheKey = (videoId: any, userId: any) => `${CACHE_KEYS.FB_USER_PROFILE_V2.NAME}${videoId}:${userId}`;

    async handleUpdateFacebookUserProfile(profile: any, upsert = false) {
        try {
            if (profile.id) {
                profile.id = `${profile.id}`;
            }
            const updated = await this._fbUserProfileV2Repository.updateOne(
                {id: profile.id, videoId: profile.videoId},
                profile,
                {upsert, lean: true}
            );
            await this._cache.del(this.buildCacheKey(profile.videoId, profile.id));
            return Promise.resolve(updated);
        } catch (err) {
            return Promise.reject(err);
        }
    }

    async handleReadFacebookUserProfile(id: string, videoId: string) {
        try {
            if (id) {
                id = `${id}`;
            }

            const cacheKey = this.buildCacheKey(videoId, id);
            const cache = (await this._cache.get(cacheKey)) as FbUserProfileV2;
            if (cache) {
                return Promise.resolve(cache);
            }

            let profile = await this._fbUserProfileV2Repository.findOne({videoId, id});
            if (profile) {
                profile = profile.toObject();
                profile.id = profile.id.toString();
                await this._cache.set(
                    cacheKey,
                    profile,
                    {ttl: CACHE_KEYS.FB_USER_PROFILE_V2.TTL} as any
                );
            }

            return Promise.resolve(profile);
        } catch (err) {
            return Promise.reject(err);
        }
    }

    getCountCustomersByLivestreamId(videoId: string, type = null) {
        const query: any = {
            videoId
        }
        if (type) {
            query.type = type;
        }
        return this._fbUserProfileV2Repository.countDocuments(query)
    }
}
