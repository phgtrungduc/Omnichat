import { IFeed, IFeedEntry, IMessenger } from "@kiotviet-facebook-services/common";

// export function isHideComment (setting, message)  {
//     return setting.HideAllComment
//         || (setting.HideCommentHasPhone && stringUtil.hasPhone(message))
//         || (setting.HideCommentHasEmail && stringUtil.hasEmail(message));
// };


export function isAutoAnswerCommentByComment(setting: any, comment: IFeed) {
  return setting && setting.AutoAnswerComment
    && (setting.AutoAnswerCommentByComment && setting.AutoAnswerCommentByComment.Status)
    && (!setting.AutoAnswerCommentIgnoreReply || !getCommentIdIfBeingReply(comment));
}


export function isAutoAnswerCommentByInbox(setting: any, comment: IFeed) {
  return setting && setting.AutoAnswerComment
    && (setting.AutoAnswerCommentByInbox && setting.AutoAnswerCommentByInbox.Status)
    && (!setting.AutoAnswerCommentIgnoreReply || !getCommentIdIfBeingReply(comment));
}

export function getCommentIdIfBeingReply(comment: IFeed) {
  if (comment.InstagramId) {
    return comment
      && comment.entry
      && comment.entry[0]
      && comment.entry[0].changes
      && comment.entry[0].changes[0]
      && comment.entry[0].changes[0].value
      && comment.entry[0].changes[0].value.parent_id;
  }
  comment.entry = comment.entry as IFeedEntry[];
  const commentId = comment.entry && comment.entry[0].changes[0].value.comment_id.split('_');
  const parentId = comment.entry && comment.entry[0].changes[0].value.parent_id?.split('_');
  return comment
    && comment.entry
    && comment.entry[0]
    && comment.entry[0].changes
    && comment.entry[0].changes[0]
    && comment.entry[0].changes[0].value
    && comment.entry[0].changes[0].value.post_id !== comment.entry[0].changes[0].value.parent_id
    && commentId?.length
    && parentId?.length
    && commentId[0] === parentId[0]
    && comment.entry[0].changes[0].value.parent_id;
}

export function isMessageReply(messenger: IMessenger) {
  return !!(messenger.PostReferenceUrl && getCommentIdInMetadata(messenger));
}

export function getCommentIdInMetadata(messenger: IMessenger) {
  if (!messenger.entry || !messenger.entry.length || !(messenger.entry[0].messaging || messenger.entry[0].standby)) {
    return false;
  }

  const messaging = messenger.entry[0].messaging || messenger.entry[0].standby;
  // @ts-ignore
  if (!messaging.length && !messaging[0].message && !messaging[0].message?.metadata) {
    return false;
  }

  // @ts-ignore
  let metadata = messaging[0].message.metadata;

  try {
    // @ts-ignore
    metadata = JSON.parse(metadata);
    // @ts-ignore
    if (metadata.hasOwnProperty('CommentId')) {
      // @ts-ignore
      return metadata.CommentId;
    }

    return false;
  } catch (error) {
    return false;
  }
}

export function isAutoSendMessageWithOrderPreview(setting: any) {
  return setting && setting.OrderConfirm && setting.OrderConfirm.Status && setting.OrderConfirm.Content && setting.OrderConfirm.CanSendOrderPreview;
}

export function isAutoSendMessageWithoutOrderPreview(setting: any) {
  return setting && setting.OrderConfirm && setting.OrderConfirm.Status && setting.OrderConfirm.Content;
}
