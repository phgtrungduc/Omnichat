export function getDbNameSocialConversation(socialId: string) {
    return `${socialId}_conversation`;
}
