export interface ISettingItem {
  Status?: boolean;
  Content?: string;
  CanSendImage?: boolean;
}
