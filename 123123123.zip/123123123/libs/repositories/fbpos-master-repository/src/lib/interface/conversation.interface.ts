export interface IGetConversationParams {
  socialId: string;
  projection?: any;
  moreFilters?: any;
  limit?: number;
}

export interface IGetMessagesParams {
  socialId: string;
  moreFilters?: any;
  limit?: number;
}

export interface IAddQuoteIntoMessageDetailParams {
  socialId?: string;
  messageId?: string;
  quote?: IQuote;
}

export interface IQuote {
  Id?: string;
  Message?: string;
  Attachments?: IQuoteAttachment[];
  Sticker?: string;
  CreatedTime?: number;
}

export interface IQuoteAttachment {
  type?: string,
  id?: string,
  url?: string;
  link?: string
}
