import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { PageSettings } from './page-settings.schema';

export type WebhookSubscriptionDocument = WebhookSubscription & Document;

@Schema({
  _id: false,
  strict: false,
  timestamps: {
    currentTime: () => {
      return Math.floor(Date.now() / 1000);
    },
    createdAt: 'CreatedAt',
    updatedAt: 'UpdatedAt',
  },
  collection: 'webhook_subscription',
})
export class WebhookSubscription {
  @Prop({
    type: String,
    required: true,
  })
  _id: string;

  @Prop({
    type: Number,
    required: true,
  })
  RetailerId: number;

  @Prop({
    type: String,
    required: true,
  })
  PageId: string;

  @Prop({
    type: Number,
    default: 0
  })
  State: number;

  @Prop({
    type: Number,
    default: 0,
  })
  IsRemoved: number;

  @Prop({ type: Number })
  TimeStamp: number;

  @Prop({ type: Number })
  Version: number;

  @Prop({
    type: String
  })
  AccessToken: string;

  @Prop({ type: String })
  Group: string;

  @Prop({ type: Object })
  Setting: any;

  @Prop({ type: Object })
  ConversationAssignment: object;

  @Prop({ type: Object })
  PageInfo: object;

  @Prop({ type: Number })
  DateRemoved: number;

  @Prop({ type: Number })
  LastAccess: number;

  @Prop({ type: String })
  InstagramId: string;

  @Prop({ type: Object })
  InstagramInfo: object;

  @Prop({ type: String })
  SocialType: string;

  @Prop({ type: [String] })
  WhitelistedDomains : string[];

  @Prop({ type: Number })
  Industry: number;
}

const WebhookSubscriptionSchema = SchemaFactory.createForClass(WebhookSubscription);

WebhookSubscriptionSchema.index({ RetailerId: 1 });
WebhookSubscriptionSchema.index({ PageId: 1 });
WebhookSubscriptionSchema.index({ InstagramId: 1 });
WebhookSubscriptionSchema.index({ IsRemoved: 1, _id: 1 });

export { WebhookSubscriptionSchema };
