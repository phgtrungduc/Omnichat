import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
const { v4: uuidv4 } = require('uuid');

export type PageCustomerTagDocument = PageCustomerTag & Document;

@Schema({
  _id: false,
  strict: false,
  timestamps: {
    currentTime: () => {
      return Math.floor(Date.now() / 1000);
    },
    createdAt: 'CreatedAt',
    updatedAt: 'UpdatedAt',
  },
  collection: 'page_customer_tag',
})
export class PageCustomerTag {
  @Prop({
    type: String,
    required: true,
    default: uuidv4
  })
  _id: string;

  @Prop({
    type: String,
    required: true,
  })
  pageId: string;

  @Prop({
    type: String,
    required: true,
  })
  senderId: string;

  @Prop({
    type: String,
  })
  customerTagId: string;

  @Prop({
    type: Number,
    default: Date.now
  })
  timestamp: number;
}

const PageCustomerTagSchema = SchemaFactory.createForClass(PageCustomerTag);

export { PageCustomerTagSchema }; 