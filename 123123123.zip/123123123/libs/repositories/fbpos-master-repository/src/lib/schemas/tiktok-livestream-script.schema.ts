import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import {
    LivestreamStatusEnum,
    TiktokLivestreamAutoPrintType,
    TiktokSyntaxCreateOrderType
} from '@kiotviet-facebook-services/common';
import { Document, SchemaTypes, Types } from 'mongoose';

export type TiktokLivestreamScriptDocument = TiktokLivestreamScript & Document;

@Schema({
    _id: false,
    strict: false,
    versionKey: false,
    collection: 'tiktok_livestream_scripts',
})
export class TiktokLivestreamScript {

    @Prop({type: SchemaTypes.ObjectId, required: true})
    _id: number;

    @Prop({type: String, required: true})
    id: number;

    @Prop({type: String, required: true})
    name: string;

    @Prop({type: String, required: true})
    userId: string;

    @Prop({type: String, required: true})
    userUniqueId: string;

    @Prop({type: Number, required: true})
    retailerId: number;

    @Prop({type: String})
    retailerCode?: string;

    @Prop({type: Number, required: true})
    branchId: number;

    @Prop({type: Number, default: 0})
    priceBookId?: number;

    @Prop({type: String, default: 'Bảng giá chung'})
    priceBookName?: string;

    @Prop({type: Number, default: Date.now()})
    createdTime: number;

    @Prop({
        type: Number,
        enum: [
            LivestreamStatusEnum.SCHEDULE,
            LivestreamStatusEnum.PROCESSING,
            LivestreamStatusEnum.FINISHED,
        ],
        default: LivestreamStatusEnum.SCHEDULE,
    })
    status: LivestreamStatusEnum;

    @Prop({type: [{_id: false}]})
    products: {
        KvProductId: number;
        KvProductCode: string;
        KvProductName: string;
        KvProductImage: string;
        KvAttributeLabel: string;
        KvUnit: string;
        Price: number;
        ProductKey: string[];
        SellQuantity: number;
        OrderQuantity: number;
        AutoPrinted: Number;
    }[];

    @Prop({
        type: {
            AutoPrinting: Boolean,
            AutoPrintType: {
                type: Number,
                enum: [TiktokLivestreamAutoPrintType.ALL, TiktokLivestreamAutoPrintType.LIMIT_NUMBER],
            },
            AutoPrintingLimitNumber: Number,
            UseFeature: Boolean, // Tự động tạo khách hàng
            AutoCreatingOrder: Boolean,
            PreventCreatingOrderWhenOutOfQuantity: Boolean,
            WarningOutOfQuantity: Boolean,
            AutoTakeScreenshot: Boolean
        },
        default: {
            AutoPrinting: false,
            AutoPrintingLimitNumber: 0,
            UseFeature: false,
            AutoCreatingOrder: false,
            WarningOutOfQuantity: false,
            PreventCreatingOrderWhenOutOfQuantity: false,
            AutoTakeScreenshot: false
        },
    })
    LiveStreamFormula: any;

    @Prop({
        type: Number,
        enum: [
            TiktokSyntaxCreateOrderType.DETAIL_KEYWORD,
            TiktokSyntaxCreateOrderType.GENERAL_KEYWORD
        ],
        required: true
    })
    syntaxCreateOrderType: TiktokSyntaxCreateOrderType;

    @Prop({
        type: [{
            Key: {type: String, required: true},
            AutoPrinted: {type: Number, default: 0},
            _id: {type: SchemaTypes.ObjectId, default: () => new Types.ObjectId()}
        }],
        default: []
    })
    generalKeyWords:
        {
            Key: String,
            AutoPrinted: {
                type: Number,
                default: 0
            },
            _id: Types.ObjectId
        }[];

    @Prop({type: Number, default: 0})
    totalComments: number;

    @Prop({type: Number, default: 0})
    totalCustomers: number;

    @Prop({type: Number, default: 0})
    totalCustomerValidateFormulas: number;

    @Prop({type: Number, default: 0})
    totalCustomerCreatedOrders: number;

    @Prop({type: Number, default: 0})
    totalValidComments: number;

    @Prop({type: Number, default: 0})
    totalOrders: number;

    @Prop({type: Number, default: 0})
    totalCommentPrinted: number;

    @Prop({type: Number, default: 0})
    totalCustomerCommentPrinted: number;

    @Prop({type: Number, default: 0})
    totalCareComments: number;

    @Prop({type: Number, default: 0})
    totalNegativeComments: number;

    @Prop({type: Number, default: 0})
    totalPositiveComments: number;
    
    @Prop({type: Number, default: 0})
    revenue: number;

    @Prop({type: Number})
    deleted?: number;

    @Prop({type: Number})
    endedTime?: number;

    @Prop({type: Number})
    connectedTime?: number;

    @Prop({type: String})
    livestreamSocketId?: string;
}

const TiktokLivestreamScriptSchema = SchemaFactory.createForClass(TiktokLivestreamScript);

TiktokLivestreamScriptSchema.index({retailerId: 1, createdTime: -1});

TiktokLivestreamScriptSchema.index({
    userUniqueId: 1,
    branchId: 1,
    retailerId: 1,
    status: 1,
    deleted: 1,
    createdTime: -1
});

TiktokLivestreamScriptSchema.path('id').get(function (id: number) {
    if (id < 1000000) {
        return `LIVETIKTOK${id.toString().padStart(6, '0')}`;
    }

    return `LIVETIKTOK${id}`;
});
TiktokLivestreamScriptSchema.set('toJSON', {getters: true, virtuals: false});
TiktokLivestreamScriptSchema.set('toObject', {getters: true});

export { TiktokLivestreamScriptSchema };
