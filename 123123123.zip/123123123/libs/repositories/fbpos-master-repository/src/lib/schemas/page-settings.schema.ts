import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
export type PageSettingsDocument = PageSettings & Document;

@Schema({
  _id: false,
  strict: false,
  collection: 'page_settings',
})
export class PageSettings {
  @Prop({ type: String, required: true })
  _id: string;

  @Prop({ type: String })
  PageId: string;

  @Prop({ type: Number })
  TimeStamp: object;

  @Prop({ type: Number, default: 1 })
  Version: number;

  @Prop({ type: Object })
  Setting: object;

  @Prop({ type: Object })
  ConversationAssignment: object;

  @Prop({ type: Boolean })
  InitMessageReport: boolean;

  @Prop({ type: Object })
  LiveStreamFormula: object;
}

const PageSettingsSchema = SchemaFactory.createForClass(PageSettings);

export { PageSettingsSchema };
