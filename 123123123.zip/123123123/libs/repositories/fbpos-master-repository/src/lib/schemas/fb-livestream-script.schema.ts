import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { LivestreamStatusEnum, LivestreamSyntaxCreateOrderType } from '@kiotviet-facebook-services/common';
import { Document, SchemaTypes, Types } from 'mongoose';

export type FbLivestreamScriptDocument = FbLivestreamScript & Document;

@Schema({
  _id: false,
  strict: false,
  versionKey: false,
  collection: 'fb_livestream_scripts',
})
export class FbLivestreamScript {
  @Prop({type: SchemaTypes.ObjectId, required: true})
  _id: number;

  @Prop({ type: String, required: true })
  id: number;

  @Prop({ type: String, required: true })
  name: string;

  @Prop({ type: String, required: true })
  pageId: string;

  @Prop({ type: Number, required: true })
  retailerId: number;

  @Prop({ type: String })
  retailerCode?: string;

  @Prop({ type: Number, required: true })
  branchId: number;

  @Prop({ type: Number, default: 0 })
  priceBookId?: number;

  @Prop({ type: String, default: 'Bảng giá chung' })
  priceBookName?: string;

  @Prop({ type: String, unique: true, sparse: true, index: true })
  livestreamId?: string;

  @Prop({ type: String, unique: true, sparse: true, index: true })
  videoId?: string;

  @Prop({ type: Number, default: Date.now() })
  createdTime: number;

  @Prop({
    type: Number,
    enum: [
      LivestreamStatusEnum.SCHEDULE,
      LivestreamStatusEnum.PROCESSING,
      LivestreamStatusEnum.FINISHED,
    ],
    default: LivestreamStatusEnum.SCHEDULE,
  })
  status: LivestreamStatusEnum;

  @Prop({ type: [{ _id: false }] })
  products: {
    KvProductId: number;
    KvProductCode: string;
    KvProductName: string;
    KvProductImage: string;
    KvAttributeLabel: string;
    KvUnit: string;
    Price: number;
    ProductKey: string[];
    SellQuantity: number;
    OrderQuantity: number;
  }[];

  @Prop({
    type: {
      AutoPrinting: Boolean,
      UseFeature: Boolean,
      AutoCreatingOrder: Boolean,
      WarningOutOfQuantity: Boolean,
      PreventCreatingOrderWhenOutOfQuantity: Boolean,
      Delimiter: {
        Type: Number,
        Name: String,
        Value: String,
      },
      Fields: [
        {
          _id: false,
          Type: Number,
          Name: String,
          Order: Number,
        },
      ],
      AutoSendMessageWithValidComment: {
        Status: {
          type: Boolean,
          default: false
        },
        Content: {
          type: String,
          required: false
        },
        AllowViewOrder: {
          type: Boolean,
          default: false
        },
      },
      AutoSendMessageWhenOutOfQuantity: {
        Status: {
          type: Boolean,
          default: false
        },
        Content: {
          type: String,
          required: false
        }
      }
    },
    default: {
      AutoPrinting: false,
      UseFeature: false,
      AutoCreatingOrder: false,
      WarningOutOfQuantity: false,
      PreventCreatingOrderWhenOutOfQuantity: false,
      Delimiter: {
        Type: 0,
        Name: '',
        Value: '',
      },
      Fields: [],
    },
  })
  LiveStreamFormula: any;

  @Prop({ type: Number, default: 0 })
  totalComments: number;

  @Prop({ type: Number, default: 0 })
  totalCustomers: number;

  @Prop({ type: Number, default: 0 })
  totalCustomerValidateFormulas: number;

  @Prop({ type: Number, default: 0 })
  totalCustomerCreatedOrders: number;

  @Prop({ type: Number, default: 0 })
  totalValidComments: number;

  @Prop({ type: Number, default: 0 })
  totalAlmostValidComments: number;

  @Prop({ type: Number, default: 0 })
  totalOrders: number;

  @Prop({ type: Number, default: 0 })
  totalCareComments: number;

  @Prop({ type: Number, default: 0 })
  totalNegativeComments: number;

  @Prop({ type: Number, default: 0 })
  totalPositiveComments: number;

  @Prop({ type: Number, default: 0 })
  revenue: number;

  @Prop({ type: Number })
  deleted?: number;

  @Prop({ type: Number })
  endedTime?: number;

  @Prop({ type: Number })
  connectedTime?: number;

  @Prop({
    type: Number,
    enum: [
      LivestreamSyntaxCreateOrderType.DETAIL_KEYWORD,
      LivestreamSyntaxCreateOrderType.GENERAL_KEYWORD
    ],
    required: true
  })
  syntaxCreateOrderType: LivestreamSyntaxCreateOrderType;

  @Prop({
    type: [{
      Key: { type: String, required: true },
      AutoPrinted: { type: Number, default: 0 },
      _id: { type: SchemaTypes.ObjectId, default: () => new Types.ObjectId() }
    }],
    default: []
  })
  generalKeyWords:
    {
      Key: String,
      AutoPrinted: {
        type: Number,
        default: 0
      },
      _id: Types.ObjectId
    }[];
}

const FbLivestreamScriptSchema =
  SchemaFactory.createForClass(FbLivestreamScript);

FbLivestreamScriptSchema.index({
  pageId: 1,
  branchId: 1,
  retailerId: 1,
  status: 1,
  deleted: 1,
  createdTime: -1,
});

FbLivestreamScriptSchema.path('id').get(function (id: number) {
  if (id < 1000000) {
    return `LIVE${id.toString().padStart(6, '0')}`;
  }

  return `LIVE${id}`;
});
FbLivestreamScriptSchema.set('toJSON', { getters: true, virtuals: false });
FbLivestreamScriptSchema.set('toObject', { getters: true });

export { FbLivestreamScriptSchema };
