import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { FacebookCatalogSyncInventoryTypes, SocialTypes } from "@kiotviet-facebook-services/common";

export type FbCatalogConnectionDocument = FbCatalogConnection & Document;

@Schema({
    _id: false,
    strict: false,
    timestamps: true,
    versionKey: false,
    collection: 'fb_catalog_connection',
})
export class FbCatalogConnection {
    @Prop({
        type: String,
        required: true
    })
    catalogId: string;

    @Prop({
        type: Number,
    })
    retailerId: number;

    @Prop({
        type: Number,
    })
    branchId: number;

    @Prop({
        type: Number,
    })
    pricebookId: number;

    @Prop({
        type: String,
    })
    pricebookName: string;

    @Prop({
        type: String,
    })
    catalogName: string;

    @Prop({
        type: String,
    })
    businessId: string;

    @Prop({
        type: String,
    })
    businessName: string;

    @Prop({
        type: String,
    })
    pageId: string;

    @Prop({
        type: Boolean,
    })
    removed: boolean;

    @Prop({
        type: String,
        enum: [FacebookCatalogSyncInventoryTypes.INVENTORY, FacebookCatalogSyncInventoryTypes.INVENTORY_EXCLUDING_ORDER_ITEM],
        default: FacebookCatalogSyncInventoryTypes.INVENTORY,
    })
    syncInventory: FacebookCatalogSyncInventoryTypes;
}

const FbCatalogConnectionSchema = SchemaFactory.createForClass(FbCatalogConnection);

export { FbCatalogConnectionSchema };
