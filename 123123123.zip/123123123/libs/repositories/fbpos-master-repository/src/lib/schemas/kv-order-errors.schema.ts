import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { KvOrderSourceType } from "@kiotviet-facebook-services/common";

export type KvOrderErrorsDocument = KvOrderErrors & Document;

@Schema({
    strict: false,
    timestamps: {
        createdAt: 'createdAt',
        updatedAt: 'updatedAt'
    },
    versionKey: false,
    collection: 'kv_order_errors',
})
export class KvOrderErrors {
    @Prop({ type: String, required: true })
    _id: string;
    
    @Prop({
        type: String,
        required: true
    })
    pageId: string;

    @Prop({
        type: Number,
        required: true
    })
    retailerId: number;

    @Prop({
        type: String,
        required: true
    })
    retailerCode: string;

    @Prop({
        type: Number,
        required: true
    })
    branchId: string;

    @Prop({
        type: String,
    })
    fbUserId: string;

    @Prop({
        type: String,
    })
    kvCustomerId: string;

    @Prop({
        type: String,
    })
    sourceId: string; // CatalogId | LivestreamId

    @Prop({
        type: String,
        enum: [KvOrderSourceType.FACEBOOK_LIVESTREAM, KvOrderSourceType.FACEBOOK_CATALOG],
        default: KvOrderSourceType.FACEBOOK_LIVESTREAM,
    })
    sourceType: KvOrderSourceType;

    @Prop({
        type: Object,
    })
    payload?: object; // body order json.stringify or payload

    @Prop({type: Object})
    error?: object;

    @Prop({ type: Date, default: Date.now })
    createdAt: Date;

    @Prop({ type: Date, default: Date.now })
    updatedAt: Date;
}

const KvOrderErrorsSchema = SchemaFactory.createForClass(KvOrderErrors);

KvOrderErrorsSchema.index({
    retailerId: 1,
    pageId: 1,
});

export { KvOrderErrorsSchema };
