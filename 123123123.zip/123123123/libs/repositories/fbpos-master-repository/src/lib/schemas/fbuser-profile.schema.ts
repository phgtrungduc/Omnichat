import { SocialTypes } from '@kiotviet-facebook-services/common';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type FbUserProfileDocument = FbUserProfile & Document;

@Schema({
  _id: false,
  strict: false,
  versionKey: false,
  timestamps: true,
  collection: 'fb_user_profile',
})
export class FbUserProfile {
  @Prop({
    type: String,
    required: true,
    index: true
  })
  id: string;

  @Prop({
    type: String,
  })
  first_name: string;

  @Prop({
    type: String,
  })
  last_name: string;

  @Prop({
    type: String,
  })
  name: string;

  @Prop({
    type: String,
  })
  username: string; // for instagram

  @Prop({
    type: String,
  })
  profile_pic: string;

  @Prop({
    type: String,
  })
  gender: string;

  @Prop({
    type: String,
  })
  socialId: string;

  @Prop({
    type: String,
  })
  phoneNumber: string;

  @Prop({
    type: String,
    enum: [SocialTypes.FACEBOOK, SocialTypes.INSTAGRAM],
    default: SocialTypes.FACEBOOK
  })
  socialType: SocialTypes;

  @Prop({ type: [Object] })
  kvCustomers: any[];

  @Prop({ type: [Object] })
  livestreamInfoes: any[];

  @Prop({ type: Date, default: Date.now })
  updatedAt: Date;

  @Prop({ type: Boolean })
  markForReport: boolean;
}

const FbUserProfileSchema = SchemaFactory.createForClass(FbUserProfile);

FbUserProfileSchema.index(
  {
    "livestreamInfoes.videoId": 1,
    "name": 1,
    "phoneNumber": 1,
    "livestreamInfoes.isValidate": 1,
    "livestreamInfoes.isAlmostValidate": 1,
    updatedAt: -1
  },
);

export { FbUserProfileSchema };
