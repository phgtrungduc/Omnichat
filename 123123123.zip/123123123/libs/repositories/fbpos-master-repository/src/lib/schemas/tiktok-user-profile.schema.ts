import { TiktokUserLivestreamPrintType, UserLivestreamType } from '@kiotviet-facebook-services/common';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type TiktokUserProfileDocument = TiktokUserProfile & Document;

@Schema({
    _id: false,
    strict: false,
    versionKey: false,
    timestamps: false,
    collection: 'tiktok_user_profile',
})
export class TiktokUserProfile {
    @Prop({
        type: String,
        required: true,
        index: true
    })
    id: string;

    @Prop({
        type: String,
    })
    uniqueId: string;

    @Prop({
        type: String,
    })
    nickname: string

    @Prop({
        type: String,
    })
    avatar: string;

    @Prop({
        type: String,
        require: true
    })
    livestreamScriptId: string;

    @Prop({
        type: [String],
        default: []
    })
    tagIds: string[];

    @Prop({
        type: [String],
        default: []
    })
    kvProductIds: string[];

    @Prop({
        type: Number,
        enum: [UserLivestreamType.NORMAL, UserLivestreamType.VALIDATE_FORMULA, UserLivestreamType.ALMOST_VALIDATE],
        default: UserLivestreamType.NORMAL
    })
    type: UserLivestreamType;

    @Prop({
        type: Number,
        enum: [TiktokUserLivestreamPrintType.BOTH_PRINTED_AND_NOT, TiktokUserLivestreamPrintType.ALL_PRINTED, TiktokUserLivestreamPrintType.ALL_NOT_PRINT],
        default: TiktokUserLivestreamPrintType.ALL_NOT_PRINT
    })
    printType: TiktokUserLivestreamPrintType;

    @Prop({type: Number, default: Date.now})
    updatedAt: number;

    @Prop({type: Number, default: Date.now})
    createdAt: number;
}

const TiktokUserProfileSchema = SchemaFactory.createForClass(TiktokUserProfile);

TiktokUserProfileSchema.index({livestreamScriptId: 1, id: 1}, {unique: true, background: true});

export { TiktokUserProfileSchema };
