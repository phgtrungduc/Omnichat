import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { CartStatusEnum } from '@kiotviet-facebook-services/common';

export type FbCartsDocument = FbCarts & Document;

@Schema({
    _id: false,
    strict: false,
    versionKey: false,
    timestamps: true,
    collection: 'fb_carts',
})

export class FbCarts {
    @Prop({ type: String, required: true, index: true })
    fbUserId: string;

    @Prop({ type: String, required: true, index: true })
    videoId: string;

    @Prop({ type: String })
    pageId: string;

    @Prop({ type: Number })
    retailerId: number;

    @Prop({ type: Number })
    branchId: number;

    @Prop({ type: Number })
    priceBookId: number;

    @Prop({ type: String })
    priceBookName: string;

    @Prop({ type: [{ kvOrderId: String, kvOrderCode: String, isAuto: Boolean, error: Object }] })
    kvOrders: {
        kvOrderId: string;
        kvOrderCode: string;
        isAuto?: boolean;
        error?: object;
    }[];

    @Prop({ type: Number, default: 0 })
    isResolved: number;

    @Prop({ type: Number, default: 0 })
    isReplyPrivately: number;

    @Prop({ type: Number, enum: [CartStatusEnum.UNRESOLVED, CartStatusEnum.CREATED_INVOICE, CartStatusEnum.ERROR_CREATED_INVOICE] })
    status: number;

    @Prop({ type: [{ KvProductId: Number, Price: Number, Quantity: Number, Comments: [{ CommentId: String, Quantity: Number, PhoneNumber: String, TimeStamp: Number }] }] })
    products: {
        KvProductId: number;
        Price: number;
        Quantity: number;
        Comments?: {
            CommentId: string;
            Quantity: number;
            PhoneNumber: string;
            TimeStamp: number;
            KeywordCreateOrder: string;
            IsOutOfQuantity: boolean;
        }[];
    }[];

    @Prop({ type: [{ KvProductId: Number, Price: Number, Quantity: Number, Comments: [{ CommentId: String, Quantity: Number, PhoneNumber: String, TimeStamp: Number }] }] })
    productInOrders: {
        KvProductId: number;
        Price: number;
        Quantity: number;
        Comments?: {
            CommentId: string;
            Quantity: number;
            PhoneNumber: string;
            TimeStamp: number;
        }[];
    }[];

    @Prop({ type: Date, default: Date.now })
    updatedAt: Date;
}

const FbCartSchema = SchemaFactory.createForClass(FbCarts);

FbCartSchema.index(
    {
        "videoId": 1,
        "fbUserId": 1,
        "status": 1
    }, { unique: true }
);

export { FbCartSchema };
