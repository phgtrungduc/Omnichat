import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type FbCatalogUserTokenDocument = FbCatalogUserToken & Document;

@Schema({
    _id: false,
    strict: false,
    timestamps: {
        currentTime: () => {
            return Math.floor(Date.now() / 1000);
        },
        createdAt: 'createdAt',
        updatedAt: 'updatedAt',
    },
    collection: 'fb_catalog_user_token',
})
export class FbCatalogUserToken {
    @Prop({
        type: String,
        required: true
    })
    catalogId: string;

    @Prop({
        type: String,
    })
    id: string;

    @Prop({
        type: String,
    })
    name: string;

    @Prop({
        type: String,
    })
    businessId: string;

    @Prop({
        type: String,
    })
    pageId: string;

    @Prop({
        type: Number,
    })
    retailerId: number;

    @Prop({
        type: String,
    })
    token: string;
}

const FbCatalogUserTokenSchema = SchemaFactory.createForClass(FbCatalogUserToken);

export { FbCatalogUserTokenSchema };
