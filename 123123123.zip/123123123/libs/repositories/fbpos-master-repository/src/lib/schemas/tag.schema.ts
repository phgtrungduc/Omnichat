import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
const { v4: uuidv4 } = require('uuid');
export type TagDocument = Tag & Document;

@Schema({
  _id: false,
  strict: false,
  timestamps: {
    currentTime: () => {
      return Math.floor(Date.now() / 1000);
    },
    createdAt: 'CreatedAt',
    updatedAt: 'UpdatedAt',
  },
  collection: 'tags',
})
export class Tag {
  @Prop({
    type: String,
    required: true,
    default: uuidv4
  })
  _id: string;

  @Prop({
    type: String,
    required: true,
  })
  pageId: string;

  @Prop({ type: Object })
  detail: object;

  @Prop({ type: Number, default: 1 })
  version: number;

  @Prop({ type: Number })
  state: number;

  @Prop({ type: Number, default: Date.now })
  timestamp: number;

  @Prop({
    type: [String],
    required: true,
  })
  conversations: string[];

}

const TagSchema = SchemaFactory.createForClass(Tag);

export { TagSchema };
