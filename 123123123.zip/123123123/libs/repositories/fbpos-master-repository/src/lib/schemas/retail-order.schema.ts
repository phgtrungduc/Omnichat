import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
export type RetailOrderDocument = RetailOrder & Document;

@Schema({ timestamps: true, versionKey: false ,collection: 'retail_order'})
export class RetailOrder extends Document {
    @Prop({ type: Number, required: true })
    orderId: number;

    @Prop({ type: String, required: true })
    conversationId: string;

    @Prop({ type: Number, required: true })
    retailerId: number;

    @Prop({ type: Number, required: true })
    branchId: number;

    @Prop({ type: String, required: true })
    pageId: string;

    @Prop({ type: String })
    messageId: string;

    @Prop({ type: String })
    psId: string;
}

const RetailOrderSchema = SchemaFactory.createForClass(RetailOrder);

RetailOrderSchema.index(
    {
        "orderId": 1,
        "branchId": 1,
        "retailerId": 1
    }
);
RetailOrderSchema.index(
    {
        "branchId": 1,
        "retailerId": 1
    }
);

export { RetailOrderSchema };