import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
const { v4: uuidv4 } = require('uuid');

export type FeedPostDocument = FeedPost & Document;

@Schema({
  _id: false,
  strict: false,
  timestamps: {
    currentTime: () => {
      return Math.floor(Date.now() / 1000);
    },
    createdAt: 'CreatedAt',
    updatedAt: 'UpdatedAt',
  },
  collection: 'feed_post',
})
export class FeedPost {
  @Prop({
    type: String,
    required: true,
    default: uuidv4
  })
  _id: string;

  @Prop({
    type: String,
    required: true,
  })
  pageId: string;

  @Prop({
    type: Boolean,
  })
  incompleteData: boolean;

  @Prop({
    type: String,
  })
  statusType: string;

  @Prop({
    type: String,
  })
  permalinkUrl: string;

  @Prop({
    type: Boolean,
  })
  isPublished: boolean;

  @Prop({
    type: String,
  })
  id: string;

  @Prop({
    type: String,
  })
  fullPicture: string;

  @Prop({
    type: String,
  })
  photoId: string;

  @Prop({
    type: String,
  })
  verb: string;

  @Prop({
    type: String,
  })
  reactionType: string;

  @Prop({
    type: Number,
  })
  published: number;

  @Prop({
    type: String,
  })
  postId: string;

  @Prop({
    type: String,
  })
  link: string;

  @Prop({
    type: String,
  })
  message: string;

  @Prop({
    type: Number,
  })
  timestamp: number;

  @Prop({
    type: Number,
  })
  createdTime: number;

  @Prop({
    type: Object,
  })
  from: {
    id: string;
    name: string;
  };

  @Prop({
    type: String,
  })
  item: string;

  @Prop({
    type: [String],
  })
  photos: string[];

  @Prop({
    type: String,
  })
  videoId: string;

  @Prop({
    type: String,
  })
  shareId: string;

  @Prop({
    type: Number,
  })
  timePost: number;

  @Prop({
    type: Number,
  })
  recipientId: number;

  @Prop({
    type: String,
  })
  type: string;

  @Prop({
    type: Boolean,
  })
  isHidden: boolean;

  @Prop({
    type: String,
    default: 'post',
  })
  _type: string;
}

const FeedPostSchema = SchemaFactory.createForClass(FeedPost);

// Add index
FeedPostSchema.index({ pageId: 1, published: 1, createdTime: -1 });

export { FeedPostSchema }; 