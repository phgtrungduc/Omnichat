import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type LivestreamPrintDocument = LivestreamPrint & Document;

@Schema({
    collection: 'livestream_print',
    timestamps: true,
    versionKey: false
})
export class LivestreamPrint {
    @Prop({ type: String, required: true, index: true, unique: true })
    postId: string;

    @Prop({ type: String, index: true, default: '' })
    socketId: string;

    @Prop({ type: Number, required: true })
    pageId: number;

    @Prop({ type: Boolean, default: false })
    isEnded: boolean;

    @Prop({ type: Number, index: true, required: true })
    livestreamId: number;

    @Prop({ type: Boolean, default: false })
    published: boolean;

    @Prop({ type: Date, default: Date.now, expires: 60 * 60 * 24 * 3 })
    updatedAt: Date;

    @Prop({ type: String, required: true })
    userUniqueId: string;
}

const LivestreamPrintSchema = SchemaFactory.createForClass(LivestreamPrint);

export { LivestreamPrintSchema };
