import { SocialTypes } from '@kiotviet-facebook-services/common';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type SocialUserKvCustomerDocument = SocialUserKvCustomer & Document;

@Schema({
    _id: true,
    strict: false,
    versionKey: false,
    timestamps: false,
    collection: 'social_user_kv_customer',
})
export class SocialUserKvCustomer {
    @Prop({
        type: String,
        enum: [SocialTypes.FACEBOOK, SocialTypes.INSTAGRAM, SocialTypes.TIKTOK],
        required: true
    })
    socialType: SocialTypes;

    @Prop({
        type: String,
        required: true
    })
    userId: string;

    @Prop({
        type: String,
        required: true
    })
    kvCustomerId: string;

    @Prop({
        type: String,
    })
    kvCustomerCode: string;

    @Prop({
        type: Number,
        required: true
    })
    retailerId: number;

    @Prop({
        type: String,
    })
    retailerCode: string;

    @Prop({
        type: String,
        required: true
    })
    branchId: string;

    @Prop({type: Number, default: Date.now})
    updatedAt: number;

    @Prop({type: Number, default: Date.now})
    createdAt: number;
}

const SocialUserKvCustomerSchema = SchemaFactory.createForClass(SocialUserKvCustomer);

SocialUserKvCustomerSchema.index({userId: 1, retailerId: 1, branchId: 1}, { background: true});
export { SocialUserKvCustomerSchema };
