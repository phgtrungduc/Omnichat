import { SocialTypes, UserLivestreamType } from '@kiotviet-facebook-services/common';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type FbUserProfileV2Document = FbUserProfileV2 & Document;

@Schema({
    _id: false,
    strict: false,
    versionKey: false,
    timestamps: true,
    collection: 'fb_user_profile_v2',
})
export class FbUserProfileV2 {
    @Prop({
        type: String,
        required: true,
        index: true
    })
    id: string;

    @Prop({
        type: String,
    })
    first_name: string;

    @Prop({
        type: String,
    })
    last_name: string;

    @Prop({
        type: String,
    })
    name: string;

    @Prop({
        type: String,
    })
    profile_pic: string;

    @Prop({
        type: String,
    })
    gender: string;

    @Prop({
        type: String,
    })
    socialId: string;

    @Prop({
        type: String,
    })
    phoneNumber: string;

    @Prop({
        type: String,
        enum: [SocialTypes.FACEBOOK, SocialTypes.INSTAGRAM],
        default: SocialTypes.FACEBOOK
    })
    socialType: SocialTypes;

    @Prop({
        type: String,
        require: true
    })
    videoId: string;

    @Prop({
        type: [String],
        default: []
    })
    tagIds: string[];

    @Prop({
        type: [String],
        default: []
    })
    kvProductIds: string[];

    @Prop({
        type: Number,
        enum: [UserLivestreamType.NORMAL, UserLivestreamType.VALIDATE_FORMULA, UserLivestreamType.ALMOST_VALIDATE],
        default: UserLivestreamType.NORMAL
    })
    type: UserLivestreamType;

    @Prop({type: Number, default: Date.now})
    updatedAt: number;

    @Prop({type: Number, default: Date.now})
    createdAt: number;
}

const FbUserProfileV2Schema = SchemaFactory.createForClass(FbUserProfileV2);

//TODO Đức bm thêm index ở đây
// FbUserProfileV2Schema.index(
//     {
//         "livestreamInfoes.videoId": 1,
//         "name": 1,
//         "phoneNumber": 1,
//         "livestreamInfoes.isValidate": 1,
//         "livestreamInfoes.isAlmostValidate": 1,
//         updatedAt: -1
//     },
// );

export { FbUserProfileV2Schema };
