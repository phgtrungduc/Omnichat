import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type PageStaffDocument = PageStaff & Document;

@Schema({
    _id: false,
    strict: false,
    collection: 'page_staffs',
})
export class PageStaff {
    @Prop({type: String, index: true, required: true})
    pageId: string;

    @Prop({type: String, index: true, required: true})
    staffId: string;

    @Prop({type: String})
    appUserId: string;

    @Prop({type: String})
    name: string;

    @Prop({type: String})
    picture: string;

    @Prop({type: Number})
    state: number;

    @Prop({type: Number})
    timestamp: number;

    @Prop({type: Number})
    lastAssigned: number;

    @Prop({type: Number})
    assignmentTurn: number;

    @Prop({type: [String]})
    socketIds: string[];
}

const PageStaffSchema = SchemaFactory.createForClass(PageStaff);

export { PageStaffSchema };
