import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { LockModule } from '@kiotviet-facebook-services/lock';
import { CommonModule } from '@kiotviet-facebook-services/common';
import { AlertNotificationService } from '@kiotviet-facebook-services/alert-notification';

import {
    FbCarts,
    FbCartSchema,
    FbCatalogConnection,
    FbCatalogConnectionSchema,
    FbCatalogUserToken,
    FbCatalogUserTokenSchema,
    FbLivestreamScript,
    FbLivestreamScriptSchema,
    FbUserProfile,
    FbUserProfileSchema,
    FbUserProfileV2,
    FbUserProfileV2Schema,
    KvOrderErrors,
    KvOrderErrorsSchema,
    LivestreamPrint,
    LivestreamPrintSchema,
    PageSettings,
    PageSettingsSchema,
    PageStaff,
    PageStaffSchema,
    PageCustomerTag,
    PageCustomerTagSchema,
    RetailOrder,
    RetailOrderSchema,
    SocialUserKvCustomer,
    SocialUserKvCustomerSchema,
    Tag,
    TagSchema,
    TiktokCarts,
    TiktokCartsSchema,
    TiktokLivestreamScript,
    TiktokLivestreamScriptSchema,
    TiktokUserProfile,
    TiktokUserProfileSchema,
    WebhookSubscription,
    WebhookSubscriptionSchema,
    FeedPost,
    FeedPostSchema
} from './schemas';

import {
    FbCartsRepository,
    FbCatalogConnectionRepository,
    FbCatalogUserTokenRepository,
    FbLiveStreamScriptRepository,
    FbUserProfileRepository,
    FbUserProfileV2Repository,
    KvOrderErrorsRepository,
    LivestreamPrintRepository,
    PageSettingsRepository,
    PageStaffRepository,
    PageCustomerTagRepository,
    RetailOrderRepository,
    SocialUserKvCustomerRepository,
    TagRepository,
    TiktokCartsRepository,
    TiktokLiveStreamScriptRepository,
    TiktokUserProfileRepository,
    WebhookSubscriptionRepository,
    FeedPostRepository
} from './repositories';

import {
    ConversationService,
    FbCartsService,
    FbCatalogConnectionService,
    FbCatalogUserTokenService,
    FbLivestreamScriptService,
    FbUserProfileService,
    FbUserProfileV2Service,
    LivestreamPrintService,
    MongodbGroupService,
    PageStaffService,
    PageSubscriptionService,
    PageCustomerTagService,
    RetailOrderService,
    SocialUserKvCustomerService,
    TiktokCartsService,
    TiktokLivestreamScriptService,
    TiktokUserProfileService,
    FeedPostService
} from './services';
import { KvOrderErrorsService } from "./services/kv-order-errors.service";

const providers = [
    // Repositories
    WebhookSubscriptionRepository,
    TagRepository,
    PageSettingsRepository,
    LivestreamPrintRepository,
    FbUserProfileRepository,
    FbUserProfileV2Repository,
    RetailOrderRepository,
    FbCartsRepository,
    FbLiveStreamScriptRepository,
    TiktokLiveStreamScriptRepository,
    TiktokUserProfileRepository,
    TiktokCartsRepository,
    SocialUserKvCustomerRepository,
    PageStaffRepository,
    PageCustomerTagRepository,
    FbCatalogUserTokenRepository,
    FbCatalogConnectionRepository,
    KvOrderErrorsRepository,
    FeedPostRepository,

    // Services
    MongodbGroupService,
    ConversationService,
    PageSubscriptionService,
    AlertNotificationService,
    RetailOrderService,
    FbCartsService,
    FbLivestreamScriptService,
    FbUserProfileService,
    FbUserProfileV2Service,
    TiktokLivestreamScriptService,
    LivestreamPrintService,
    TiktokUserProfileService,
    TiktokCartsService,
    SocialUserKvCustomerService,
    PageStaffService,
    PageCustomerTagService,
    FbCatalogUserTokenService,
    FbCatalogConnectionService,
    KvOrderErrorsService,
    FeedPostService
];

@Global()
@Module({
    imports: [
        MongooseModule.forRootAsync({
            imports: [ConfigModule],
            inject: [ConfigService],
            useFactory: async (config: ConfigService) => ({
                ...config.get('fbposMasterRepository.db'),
                // disable index automatic creation, indices must be created manually
                autoIndex: false,
            }),
        }),
        MongooseModule.forFeature([
            {
                name: WebhookSubscription.name,
                schema: WebhookSubscriptionSchema,
            },
            {
                name: Tag.name,
                schema: TagSchema,
            },
            {
                name: PageSettings.name,
                schema: PageSettingsSchema,
            },
            {
                name: FbUserProfile.name,
                schema: FbUserProfileSchema,
            },
            {
                name: FbUserProfileV2.name,
                schema: FbUserProfileV2Schema,
            },
            {
                name: FbLivestreamScript.name,
                schema: FbLivestreamScriptSchema,
            },
            {
                name: RetailOrder.name,
                schema: RetailOrderSchema,
            },
            {
                name: FbCarts.name,
                schema: FbCartSchema,
            },
            {
                name: TiktokLivestreamScript.name,
                schema: TiktokLivestreamScriptSchema,
            },
            {
                name: TiktokUserProfile.name,
                schema: TiktokUserProfileSchema,
            },
            {
                name: TiktokCarts.name,
                schema: TiktokCartsSchema,
            },
            {
                name: LivestreamPrint.name,
                schema: LivestreamPrintSchema,
            },
            {
                name: SocialUserKvCustomer.name,
                schema: SocialUserKvCustomerSchema,
            },
            {
                name: PageStaff.name,
                schema: PageStaffSchema,
            },
            {
                name: PageCustomerTag.name,
                schema: PageCustomerTagSchema,
            },
            {
                name: FbCatalogUserToken.name,
                schema: FbCatalogUserTokenSchema
            },
            {
                name: FbCatalogConnection.name,
                schema: FbCatalogConnectionSchema
            },
            {
                name: KvOrderErrors.name,
                schema: KvOrderErrorsSchema
            },
            {
                name: FeedPost.name,
                schema: FeedPostSchema
            }
        ]),
        CommonModule,
        LockModule,
    ],
    controllers: [],
    providers,
    exports: [...providers],
})
export class FbPosMasterRepositoryModule {
}
