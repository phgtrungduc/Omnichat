import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import {RetailOrderDocument, RetailOrder } from '../schemas';
import { Cache } from 'cache-manager';

@Injectable()
export class RetailOrderRepository extends BaseRepository<RetailOrderDocument> {
    constructor(
        @InjectModel(RetailOrder.name)
        private readonly retailOrder: Model<RetailOrderDocument>,
        cache: Cache
    ) {
        super(retailOrder, cache);
    }
}
