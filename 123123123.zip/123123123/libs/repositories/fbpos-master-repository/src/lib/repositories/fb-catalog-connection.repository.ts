import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { FbCatalogConnection, FbCatalogConnectionDocument } from '../schemas';
import { Cache } from 'cache-manager';

@Injectable()
export class FbCatalogConnectionRepository extends BaseRepository<FbCatalogConnectionDocument> {
    constructor(
        @InjectModel(FbCatalogConnection.name)
        private readonly fbCatalogConnection: Model<FbCatalogConnectionDocument>,
        cache: Cache
    ) {
        super(fbCatalogConnection, cache);
    }
}
