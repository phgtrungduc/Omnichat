import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { PageSettings, PageSettingsDocument } from '../schemas';
import { Cache } from 'cache-manager';

@Injectable()
export class PageSettingsRepository extends BaseRepository<PageSettingsDocument> {
  constructor(
    @InjectModel(PageSettings.name)
    private readonly pageSettingsModel: Model<PageSettingsDocument>,
    cache: Cache
  ) {
    super(pageSettingsModel, cache);
  }
}
