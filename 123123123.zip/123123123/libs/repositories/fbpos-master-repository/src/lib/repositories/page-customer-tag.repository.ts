import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { PageCustomerTag, PageCustomerTagDocument } from '../schemas/page-customer-tag.schema';
import { BaseRepository } from './base.repository';
import { Cache } from 'cache-manager';

@Injectable()
export class PageCustomerTagRepository extends BaseRepository<PageCustomerTagDocument> {
  constructor(
    @InjectModel(PageCustomerTag.name)
    private readonly pageCustomerTagModel: Model<PageCustomerTagDocument>,
    cache: Cache
  ) {
    super(pageCustomerTagModel, cache);
  }
} 