import { Injectable } from '@nestjs/common';
import { BaseQueryOptions, BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { FbLivestreamScriptDocument, FbLivestreamScript } from '../schemas';
import { Cache } from 'cache-manager';
import { CACHE_KEYS } from '@kiotviet-facebook-services/cache';

@Injectable()
export class FbLiveStreamScriptRepository extends BaseRepository<FbLivestreamScriptDocument> {
  constructor(
    @InjectModel(FbLivestreamScript.name)
    private readonly fbLivestreamScript: Model<FbLivestreamScriptDocument>,
    cache: Cache
  ) {
    super(fbLivestreamScript, cache);
  }

  public async updateOneFbLivestreamScript(
    conditions: any,
    updates: any,
    options: BaseQueryOptions = {}
  ) {
    try {
      return this.updateOne(conditions, updates, options);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  public async getFbLivestreamScript(
    conditions: any,
    options: BaseQueryOptions = {}
  ) {
    try {
      return this.findOne(conditions, options);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  public async listFbLivestreamScript(
    conditions: any,
    options: BaseQueryOptions = {}
  ) {
    try {
      if (options.limit) {
        options.limit = options.limit < 50 ? options.limit : 50;
      }

      return this.find(conditions, options);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  public async countFbLivestreamScript(conditions: any) {
    try {
      return this.countDocuments(conditions);
    } catch (error) {
      return Promise.reject(error);
    }
  }
}
