import { Inject } from '@nestjs/common';
import { Model, Document, PipelineStage, FilterQuery } from 'mongoose';
import { Cache } from 'cache-manager';
import { CACHE_MANAGER } from '@nestjs/cache-manager';

export interface BaseQueryOptions {
    selectedKeys?: any;
    skip?: number;
    sort?: any;
    limit?: number;
    populates?: any[];
    upsert?: boolean;
    new?: boolean;
    lean?: boolean;
}

export abstract class BaseRepository<T extends Document> {
    protected constructor(
        private readonly _model: Model<T>,
        @Inject(CACHE_MANAGER) readonly _cache: Cache
    ) {
    }

    async create(doc: Partial<T> | Partial<T>[]): Promise<T> {
        return this._model.create(doc);
    }

    async aggregate(pipeline: PipelineStage[]) {
        return this._model.aggregate(pipeline);
    }

    async find(conditions: any, options?: BaseQueryOptions): Promise<T[]> {
        options = options || {};
        const query = this._model.find();
        query.where(conditions);
        if (options.skip) {
            query.skip(options.skip);
        }
        if (options.limit) {
            query.limit(options.limit);
        }
        if (options.selectedKeys) {
            query.select(options.selectedKeys);
        }
        if (options.sort) {
            query.sort(options.sort);
        }
        if (options.populates) {
            options.populates.forEach((p) => query.populate(p));
        }
        if (options.lean) {
            return query.lean();
        }
        return query.exec();
    }

    async findOne(
        conditions: any,
        options?: BaseQueryOptions
    ): Promise<T | null> {
        options = options || {};
        const query = this._model.findOne();
        query.where(conditions);
        if (options.skip) {
            query.skip(options.skip);
        }
        if (options.selectedKeys) {
            query.select(options.selectedKeys);
        }
        if (options.sort) {
            query.sort(options.sort);
        }
        if (options.lean) {
            return query.lean();
        }
        return query.exec();
    }

    async findById(id: any, useDb = false): Promise<T | null> {
        return await this._model.findById(id).exec();
    }

    async count(data: {
        conditions: object;
        cachePrefix?: string;
        limit?: number;
    }): Promise<{
        count: number;
        hasMore?: boolean;
    }> {
        let {conditions, cachePrefix, limit} = data;
        limit = limit ? limit : 0;
        if (!limit) {
            const count = await this._model.countDocuments(conditions).exec();
            return {count};
        }

        // if (!cachePrefix) {
        //   throw new PreconditionFailedException('Cache prefix must be provided for count limit query');
        // }
        const limitExceededCount = {
            count: limit - 1,
            hasMore: true,
        };
        // const hash = await createHashKeyFromObject({ conditions, limit });
        // const cacheKey = `${cachePrefix}${hash}`;
        // const cache = await this.cache.get(cacheKey);
        // if (cache) {
        //   return limitExceededCount;
        // }

        // @ts-ignore
        const count = await this._model
            .find(conditions)
            .limit(limit)
            .countDocuments()
            .exec();
        if (count >= limit) {
            // await this.cache.set(cacheKey, 1);
            return limitExceededCount;
        }
        return {count};
    }

    async bulkWrite(bulkOps: any): Promise<any> {
        return this._model.bulkWrite(bulkOps);
    }

    async updateMany(conditions: any, updates: any, options = {}): Promise<any> {
        return this._model.updateMany(conditions, updates, options);
    }

    async updateOne(
        conditions: any,
        updates: any,
        options = {}
    ): Promise<T | null> {
        return this._model.findOneAndUpdate(conditions, updates, {
            new: true,
            ...options,
        });
    }

    async insertMany(docs: Partial<T>[]) {
        return this._model.insertMany(docs);
    }

    async countDocuments(conditions: FilterQuery<T>) {
        return this._model.countDocuments(conditions);
    }

    async delete(conditions: FilterQuery<T>) {
        return this._model.deleteOne(conditions);
    }

    async deleteMany(conditions: FilterQuery<T>): Promise<any> {
        return this._model.deleteMany(conditions);
    }

    async distinct(field: any, conditions?: FilterQuery<T>) {
        return this._model.distinct(field, conditions || {});
    }
}
