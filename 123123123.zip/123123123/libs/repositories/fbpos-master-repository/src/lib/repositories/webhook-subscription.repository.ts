import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { WebhookSubscription, WebhookSubscriptionDocument } from '../schemas';
import { Cache } from 'cache-manager';
import { CACHE_KEYS } from '@kiotviet-facebook-services/cache';

@Injectable()
export class WebhookSubscriptionRepository extends BaseRepository<WebhookSubscriptionDocument> {
  constructor(
    @InjectModel(WebhookSubscription.name)
    private readonly webhookSubscriptionModel: Model<WebhookSubscriptionDocument>,
    cache: Cache
  ) {
    super(webhookSubscriptionModel, cache);
  }

  async getSubscriptionBySocialId(socialId: string, isGettingRemovedFanpage = false) {
    let pageSubscription = await this.findOne({ InstagramId: socialId, ...!isGettingRemovedFanpage && { IsRemoved: 0 } }, { sort: { TimeStamp: -1 } });
    const cacheKey = `${CACHE_KEYS.WEBHOOK_SUBSCRIPTION.GET_BY_SOCIAL_ID.NAME}${socialId}`;
    const cache = await this._cache.get(cacheKey);
    const notExistedValue = '';
    if (cache || cache === notExistedValue) {
      return cache as WebhookSubscriptionDocument;
    }
    if (!pageSubscription) {
      pageSubscription = await this.findOne({ PageId: socialId, ...!isGettingRemovedFanpage && { IsRemoved: 0 }, InstagramId: { $exists: false } }, { sort: { TimeStamp: -1 } });
    }
    if (pageSubscription) {
      await this._cache.set(cacheKey, pageSubscription, {ttl: CACHE_KEYS.WEBHOOK_SUBSCRIPTION.GET_BY_SOCIAL_ID.TTL} as any);
    }
    return pageSubscription;
  }
}
