import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Cache } from 'cache-manager';
import { SocialUserKvCustomer, SocialUserKvCustomerDocument } from "../schemas";

@Injectable()
export class SocialUserKvCustomerRepository extends BaseRepository<SocialUserKvCustomerDocument> {
    constructor(
        @InjectModel(SocialUserKvCustomer.name)
        private readonly model: Model<SocialUserKvCustomerDocument>,
        cache: Cache
    ) {
        super(model, cache);
    }
}
