import { Injectable } from '@nestjs/common';
import { BaseQueryOptions, BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { TiktokLivestreamScript, TiktokLivestreamScriptDocument } from '../schemas';
import { Cache } from 'cache-manager';


@Injectable()
export class TiktokLiveStreamScriptRepository extends BaseRepository<TiktokLivestreamScriptDocument> {
  constructor(
    @InjectModel(TiktokLivestreamScript.name)
    private readonly tiktokLivestreamScriptDocumentModel: Model<TiktokLivestreamScriptDocument>,
    cache: Cache
  ) {
    super(tiktokLivestreamScriptDocumentModel, cache);
  }

  async updateOneTiktokLivestreamScript(
    conditions: any,
    updates: any,
    options: BaseQueryOptions = {}
  ) {
    try {
      return this.updateOne(conditions, updates, options);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async getTiktokLivestreamScript(
    conditions: any,
    options: BaseQueryOptions = {}
  ) {
    try {
      return this.findOne(conditions, options);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async getTiktokLivestreamScripts(
    conditions: any,
    options: BaseQueryOptions = {}
  ) {
    try {
      return this.find(conditions, options);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async countTiktokLivestreamScript(conditions: any) {
    try {
      return this.countDocuments(conditions);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async updatePrintedTiktokLivestreamScript(id: any) {
    try {
      return this.tiktokLivestreamScriptDocumentModel.findByIdAndUpdate({_id: id},
        { $inc: { 'LiveStreamFormula.AutoPrinted': 1 } },
        { new: true, upsert: true, useFindAndModify: false });
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async updatePrintedGeneral(IdRecord: any, IdKeyword: any) {
    try {
      return this.tiktokLivestreamScriptDocumentModel.updateOne({ _id: IdRecord, "generalKeyWords._id": IdKeyword },
        { $inc: { "generalKeyWords.$.AutoPrinted": 1 } });
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async updatePrintedDetail(IdRecord: any, kvProductId: any) {
    try {
      return this.tiktokLivestreamScriptDocumentModel.updateOne({ _id: IdRecord, "products.KvProductId": kvProductId },
        { $inc: { "products.$.AutoPrinted": 1 } });
    } catch (error) {
      return Promise.reject(error);
    }
  }
}
