import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { FbUserProfileV2, FbUserProfileV2Document } from '../schemas';
import { Cache } from 'cache-manager';

@Injectable()
export class FbUserProfileV2Repository extends BaseRepository<FbUserProfileV2Document> {
    constructor(
        @InjectModel(FbUserProfileV2.name)
        private readonly fbUserProfileV2Model: Model<FbUserProfileV2Document>,
        cache: Cache
    ) {
        super(fbUserProfileV2Model, cache);
    }
}
