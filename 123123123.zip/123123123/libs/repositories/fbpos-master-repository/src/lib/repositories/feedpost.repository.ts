import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { FeedPost, FeedPostDocument } from '../schemas';
import { Cache } from 'cache-manager';

@Injectable()
export class FeedPostRepository extends BaseRepository<FeedPostDocument> {
  constructor(
    @InjectModel(FeedPost.name)
    private readonly feedPostModel: Model<FeedPostDocument>,
    cache: Cache
  ) {
    super(feedPostModel, cache);
  }
}
