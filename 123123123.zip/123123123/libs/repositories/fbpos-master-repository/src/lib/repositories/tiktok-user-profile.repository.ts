import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { TiktokUserProfile, TiktokUserProfileDocument } from '../schemas';
import { Cache } from 'cache-manager';

@Injectable()
export class TiktokUserProfileRepository extends BaseRepository<TiktokUserProfileDocument> {
  constructor(
    @InjectModel(TiktokUserProfile.name)
    private readonly model: Model<TiktokUserProfileDocument>,
    cache: Cache
  ) {
    super(model, cache);
  }
}
