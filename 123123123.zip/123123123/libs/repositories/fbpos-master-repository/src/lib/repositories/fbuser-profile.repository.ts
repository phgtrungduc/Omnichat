import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { FbUserProfile, FbUserProfileDocument } from '../schemas';
import { Cache } from 'cache-manager';

@Injectable()
export class FbUserProfileRepository extends BaseRepository<FbUserProfileDocument> {
  constructor(
    @InjectModel(FbUserProfile.name)
    private readonly fbUserProfileModel: Model<FbUserProfileDocument>,
    cache: Cache
  ) {
    super(fbUserProfileModel, cache);
  }
}
