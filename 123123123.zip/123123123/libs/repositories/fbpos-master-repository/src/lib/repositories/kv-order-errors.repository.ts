import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Cache } from 'cache-manager';
import { KvOrderErrors, KvOrderErrorsDocument } from "../schemas";

@Injectable()
export class KvOrderErrorsRepository extends BaseRepository<KvOrderErrorsDocument> {
    constructor(
        @InjectModel(KvOrderErrors.name)
        private readonly kvOrderErrors: Model<KvOrderErrorsDocument>,
        cache: Cache
    ) {
        super(kvOrderErrors, cache);
    }
}
