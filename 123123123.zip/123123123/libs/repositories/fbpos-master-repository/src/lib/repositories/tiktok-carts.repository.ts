import { Injectable } from '@nestjs/common';
import { BaseQueryOptions, BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { TiktokCarts, TiktokCartsDocument } from '../schemas';
import { Cache } from 'cache-manager';
import { CartStatusEnum, } from '@kiotviet-facebook-services/common';

@Injectable()
export class TiktokCartsRepository extends BaseRepository<TiktokCartsDocument> {
    constructor(
        @InjectModel(TiktokCarts.name)
        private readonly tiktokCarts: Model<TiktokCartsDocument>,
        cache: Cache
    ) {
        super(tiktokCarts, cache);
    }

    public async updateOneTiktokCart(
        conditions: any,
        updates: any,
        options: BaseQueryOptions = {}
    ) {
        try {
            return this.updateOne(conditions, updates, options);
        } catch (err) {
            return Promise.reject(err);
        }
    }

    public async readTiktokCart(conditions: any, options: BaseQueryOptions = {}) {
        try {
            return this.findOne(conditions, options);
        } catch (err) {
            return Promise.reject(err);
        }
    }


    async getTiktokCartsLivestream(
        livestreamScriptId: string | number,
        status: CartStatusEnum | undefined,
        skip = 0,
        limit = 1000
    ) {
        try {
            return this.find({livestreamScriptId, ...(status && {status})}, {skip, limit});
        } catch (err) {
            return Promise.reject(err);
        }
    }

    async bulkWriteTiktokCarts(bulkOps: any) {
        try {
            return this.bulkWrite(bulkOps);
        } catch (err) {
            return Promise.reject(err);
        }
    }

    async getTiktokCartsLivestreamHasOrders(
        livestreamScriptId: string | number,
        skip = 0,
        limit = 1000
    ) {
        try {
            return this.find(
                {livestreamScriptId, kvOrders: {$exists: true, $not: {$size: 0}}},
                {skip, limit, selectedKeys: {kvOrders: 1}}
            );
        } catch (err) {
            return Promise.reject(err);
        }
    }

    async getTotalTiktokCarts(livestreamScriptId: string | number) {
        try {
            return this.countDocuments(
                {livestreamScriptId, kvOrders: {$exists: true, $not: {$size: 0}}},
            );
        } catch (err) {
            return Promise.reject(err);
        }
    }

}
