import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { PageStaff, PageStaffDocument } from '../schemas';
import { Cache } from 'cache-manager';

@Injectable()
export class PageStaffRepository extends BaseRepository<PageStaffDocument> {
    constructor(
        @InjectModel(PageStaff.name)
        private readonly pageStaff: Model<PageStaffDocument>,
        cache: Cache
    ) {
        super(pageStaff, cache);
    }
}
