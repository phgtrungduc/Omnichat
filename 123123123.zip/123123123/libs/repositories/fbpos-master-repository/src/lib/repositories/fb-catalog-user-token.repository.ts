import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { FbCatalogUserToken, FbCatalogUserTokenDocument } from '../schemas';
import { Cache } from 'cache-manager';

@Injectable()
export class FbCatalogUserTokenRepository extends BaseRepository<FbCatalogUserTokenDocument> {
    constructor(
        @InjectModel(FbCatalogUserToken.name)
        private readonly fbCatalogUserToken: Model<FbCatalogUserTokenDocument>,
        cache: Cache
    ) {
        super(fbCatalogUserToken, cache);
    }
}
