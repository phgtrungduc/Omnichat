import { Injectable } from '@nestjs/common';
import { BaseQueryOptions, BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { FbCarts, FbCartsDocument } from '../schemas';
import { Cache } from 'cache-manager';
import { CartStatusEnum, } from '@kiotviet-facebook-services/common';

@Injectable()
export class FbCartsRepository extends BaseRepository<FbCartsDocument> {
    constructor(
        @InjectModel(FbCarts.name)
        private readonly fbCarts: Model<FbCartsDocument>,
        cache: Cache
    ) {
        super(fbCarts, cache);
    }

    public async updateOneFbCart(
        conditions: any,
        updates: any,
        options: BaseQueryOptions = {}
    ) {
        try {
            return this.updateOne(conditions, updates, options);
        } catch (err) {
            return Promise.reject(err);
        }
    }

    public async readFbCart(conditions: any, options: BaseQueryOptions = {}) {
        try {
            return this.findOne(conditions, options);
        } catch (err) {
            return Promise.reject(err);
        }
    }

    public async deleteOneFbCart(conditions: any) {
        try {
            return this.delete(conditions);
        } catch (err) {
            return Promise.reject(err);
        }
    }

    public async getFbCartsLivestreamByProfile(
        videoId: string | number,
        fbUserIds: string[]
    ) {
        try {
            return this.find(
                {videoId, fbUserId: {$in: fbUserIds}},
                {
                    limit: fbUserIds.length,
                    selectedKeys: {fbUserId: 1, products: 1, status: 1, kvOrders: 1},
                }
            );
        } catch (err) {
            return Promise.reject(err);
        }
    }

    public async getFbCartsLivestream(
        videoId: string | number,
        status: CartStatusEnum | undefined,
        skip = 0,
        limit = 1000
    ) {
        try {
            return this.find({videoId, ...(status && {status})}, {skip, limit});
        } catch (err) {
            return Promise.reject(err);
        }
    }

    public async getFbCartsHasProduct(
        videoId: string | number,
        isGetCartWaitingCustomer = false,
        skip = 0,
        limit = 1000
    ) {
        try {
            let status: any = CartStatusEnum.UNRESOLVED;
            if (isGetCartWaitingCustomer) {
                status = {$in: [CartStatusEnum.UNRESOLVED, CartStatusEnum.WAITING_CREATE_CUSTOMER]};
            }
            return this.find({
                videoId,
                products: {$exists: true, $not: {$size: 0}},
                status
            }, {skip, limit});
        } catch (err) {
            return Promise.reject(err);
        }
    }

    public async bulkWriteFbCarts(bulkOps: any) {
        try {
            return this.bulkWrite(bulkOps);
        } catch (err) {
            return Promise.reject(err);
        }
    }

    public async getFbCartsLivestreamHasOrders(
        videoId: string | number,
        skip = 0,
        limit = 1000
    ) {
        try {
            return this.find(
                {videoId, kvOrders: {$exists: true, $not: {$size: 0}}},
                {skip, limit, selectedKeys: {kvOrders: 1}}
            );
        } catch (err) {
            return Promise.reject(err);
        }
    }

    public async countTotalOrders(videoId: string | number) {
        try {
            return this.countDocuments({
                videoId,
                status: CartStatusEnum.CREATED_INVOICE,
            });
        } catch (err) {
            return Promise.reject(err);
        }
    }

    async getTotalCartHasOrder(videoId: string | number) {
        try {
            return this.countDocuments(
                {
                    videoId, kvOrders: {
                        $exists: true,
                        $not: {$size: 0},
                        $elemMatch: {
                            kvOrderCode: {$not: /HD/}
                        }
                    }
                },
            );
        } catch (err) {
            return Promise.reject(err);
        }
    }
}
