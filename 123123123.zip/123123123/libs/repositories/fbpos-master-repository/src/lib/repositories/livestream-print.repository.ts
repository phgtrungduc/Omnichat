import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { LivestreamPrint, LivestreamPrintDocument } from '../schemas';
import { Cache } from 'cache-manager';

@Injectable()
export class LivestreamPrintRepository extends BaseRepository<LivestreamPrintDocument> {
  constructor(
    @InjectModel(LivestreamPrint.name)
    private readonly livestreamPrintModel: Model<LivestreamPrintDocument>,
    cache: Cache
  ) {
    super(livestreamPrintModel, cache);
  }
}
